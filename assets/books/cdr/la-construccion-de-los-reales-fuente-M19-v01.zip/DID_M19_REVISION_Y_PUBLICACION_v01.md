---
project: Construcción de los reales DiD
edition: M19-v01
date: 2026-10-23
predecessor: M18-v05
---

# Revisión editorial y publicación M19 v01

La intervención responde a la solicitud explícita de actualizar el libro con los protocolos vigentes y publicar su lectura web íntegra y su PDF actualizado. Se recuperó el maestro M18 v05 desde la carpeta canónica de Drive y se conserva como testigo, con sus 300.798 bytes. El sucesor es `DID_LIBRO_LA_CONSTRUCCION_DE_LOS_REALES_M19_v01.md`.

Se consultaron MA-PED v1.1, MA-STYLE v2.1 y MA-CALIBRO v3.2 directamente en Drive, junto con PGE v1.0, el protocolo local DID y el corpus de voz v1.2. Las anclas leídas fueron la demostración aprobada C09 v2.2 de Elementos del cálculo y su capítulo C01 publicado. El modelo Bracho se aplica según sus criterios recogidos en los protocolos; en esta intervención no se afirma una nueva lectura directa de su libro.

## Pasada literaria y pedagógica

Las 60 intervenciones registradas reescriben aperturas, transiciones y cierres de los cuatro capítulos, los apéndices y los preliminares. Se formularon afirmativamente las caracterizaciones expositivas de sistema real, cortadura, comparación estructural y completitud; se sustituyeron subtítulos de control por títulos matemáticos y se aclararon los retornos de la aproximación racional, los testigos y el control de tolerancias. El problema cuadrático vincula los capítulos I y II; los perfiles racionales vinculan existencia y unicidad; la estimación triangular enlaza magnitudes, errores y límites.

La revisión mantuvo la arquitectura de cuatro capítulos y tres apéndices. Se conservaron las formulaciones formales de las cortaduras: las restricciones lógicas de sus dominios conservan su significado matemático. Los contraejemplos y las negaciones necesarias para estudiar fronteras o demostrar contradicciones permanecen en sus argumentos respectivos.

La remisión del ejemplo cuadrático indica expresamente que la prueba de su identidad multiplicativa se lee después de construir producto, refinamiento e inclusión racional. Se corrigieron dos remisiones antiguas a números de sección sin referencia estable. El expediente completo de antes/después está en `changes.json` y `revision.diff`.

## Pasada matemática propia

Se examinó por separado la equivalencia de las definiciones reescritas: tener un elemento interior y otro exterior equivale a las condiciones de subconjunto no vacío y propio; disponer para cada elemento de otro mayor expresa la cláusula formal usada en la definición de cortadura. Se revisaron las nuevas transiciones contra las hipótesis y dependencias de sus pruebas, incluida la remisión del ejemplo cuadrático.

El cotejo automático registra 4.734 expresiones matemáticas en el testigo y 4.729 en el sucesor. La diferencia corresponde exclusivamente a cinco menciones de nombres de conjuntos retiradas con prosa redundante: dos `A`, dos `Q` y una `Q` en delimitadores alternativos. Se conservan todas las fórmulas sustantivas, los cuatro bloques de enunciados formales detectados por el control y, byte por byte, los 78 bloques de ejercicios y soluciones. La verificación mecánica acredita esa conservación; la revisión matemática propia se circunscribe a los pasajes intervenidos y sus dependencias. No constituye una nueva auditoría completa de todas las pruebas preexistentes.

La decisión editorial del 21 de octubre sustituye el antiguo requisito de revisión externa por revisiones propias documentadas en pasadas separadas. El cotejo audiovisual integral continúa abierto en las cuatro clases. La edición mantiene su carácter de estudio y su reserva crítica.

## Control de formatos

La lectura web comprende diez unidades: nota al lector, cuatro capítulos, tres apéndices, símbolos y fuentes. Cada cuerpo coincide exactamente con el segmento correspondiente del maestro, tras normalizar los delimitadores matemáticos para Quarto. Cada página enlaza el índice y sus vecinas, y hereda la hoja de lectura canónica del sitio.

El PDF se construyó con AMSBook, pdfLaTeX y Computer Modern/AMS en papel carta. Tiene 93 páginas; la diferencia respecto de las 101 páginas anteriores procede de la nueva composición y de los cambios de prosa registrados. Se verificaron las 78 soluciones y la integridad matemática desde el maestro. La compilación final completó tres pasadas, con cero avisos LaTeX, cero desbordamientos y cero palabras fuera de los límites seguros de página. Se renderizaron las 93 páginas y se inspeccionaron sus mosaicos, además de páginas con fórmulas extensas. Se comprobaron la numeración arábiga del cuerpo y las letras de los tres apéndices.

La compilación local completa de Quarto se detuvo por permisos de su caché fuera de la carpeta de trabajo. La generación HTML con Pandoc completó las diez páginas. El servidor local también quedó limitado por el entorno; por ello la revisión de navegador local no recibe PASS. La compilación y verificación del sitio publicado se registran separadamente cuando termine el despliegue.

## Identidad y persistencia

El JSON `verification.json` contiene las huellas SHA-256 del testigo y el sucesor, las cuentas de integridad y los estados de control. El ZIP de edición conserva el PDF, el maestro, el proyecto LaTeX autónomo, los diez fuentes web y el expediente de cambios. Las versiones anteriores de Drive permanecen conservadas. Los estados de publicación remota se añaden después de la respuesta efectiva de los servicios y su lectura posterior.

---
title: "Introducción al cálculo: del número real a la derivada"
subtitle: "Edición temática de los apuntes del curso de Jorge San Martín (2021)"
author: "Jorge San Martín — curso original; compilación y edición temática de notas de estudio (no oficial)"
date: "Edición del 1 de noviembre de 2026"
lang: es-CL
curso: "Introducción al Cálculo (IC2021)"
fuentes: "28 cátedras originales, semanas 1–14"
tipo: libro-de-estudio
estado: "Edición temática integral v1.0; auditoría audiovisual adicional pendiente"
protocolo: "PNC v1.0"
toc-depth: 0
indice_editorial: "partes-capitulos-apendices"
tags: [matematicas, calculo, numeros-reales, funciones, sucesiones, limites, derivadas, san-martin]
---

## Presentación {.unnumbered}

Este libro reúne los apuntes de las veintiocho cátedras del primer semestre de **Introducción al Cálculo (IC2021)** impartido por **Jorge San Martín**. Está organizado según dependencias conceptuales, desde la estructura de los números reales hasta las técnicas elementales de derivación. Las lecciones originales funcionan como fuentes, mientras que los temas constituyen la unidad de lectura.

La compilación combina apuntes reconstruidos previamente a partir de grabaciones y materiales del curso, con ampliaciones pedagógicas identificadas en cada fuente. Esta edición es **un material de estudio independiente y no oficial**: el docente no figura como autor ni revisor de las intervenciones editoriales. Las referencias a ejercicios, fechas, grabaciones o clases específicas se conservan cuando permiten verificar una afirmación o reconstruir una demostración.

**Convenciones de lectura.** Las definiciones se formulan por sus propiedades; las demostraciones conservan cuantificadores, hipótesis y condiciones de dominio. Las expresiones marcadas como *ampliación editorial* proceden de los apuntes y se distinguen de la exposición documentada. Las figuras son monocromáticas y los enlaces de fuente conducen a las grabaciones originales. La numeración de capítulos pertenece a este libro; las claves «cátedra 1.1», «cátedra 7.2» y similares identifican la procedencia.

El texto preserva profundidad y ejercicios resueltos. Las introducciones administrativas, los itinerarios repetidos y las síntesis duplicadas se trasladan o consolidan en los aparatos editoriales. La compilación **no constituye una nueva transcripción ni un cotejo audiovisual completo de las 28 clases**; ese examen de fidelidad a pizarra es una fase separada de revisión.

## Cómo estudiar con este libro {.unnumbered}

Cada capítulo inicia con una idea matemática organizadora. Se recomienda reconstruir las demostraciones sobre papel, detenerse en las condiciones de existencia y trabajar los ejercicios antes de leer las soluciones. Para ubicar el tramo exacto de una explicación, véase la concordancia y las guías audiovisuales del apéndice. Las expresiones como «la clase anterior» se refieren al orden de las grabaciones originales y se interpretan aquí por medio de la secuencia temática.

La dependencia general es: *cuerpo ordenado → geometría y funciones → supremo → sucesiones → exponencial y logaritmo → límite de funciones → derivada*. La trigonometría ocupa una parte específica porque sus identidades se usan posteriormente para obtener los límites fundamentales y las derivadas trigonométricas.

# Parte I. Fundamentos: de los reales a la geometría

## La estructura algebraica de los números reales

Un curso de cálculo comienza por fijar qué operaciones se admiten y qué reglas las gobiernan. Los axiomas de cuerpo organizan las primeras demostraciones y muestran cómo se distingue una propiedad postulada de una consecuencia probada.

**Grabaciones de referencia:** [grabación de la cátedra 1.1](https://www.youtube.com/watch?v=08n7qZ-H7W8), [grabación de la cátedra 1.2](https://www.youtube.com/watch?v=Tl5Hf5d4U2Y).

*Procedencia de este tramo: cátedra 1.1.*

### El problema inicial: ¿cómo introducir los números reales?

La exposición comienza con una decisión metodológica. Una vía **constructiva** obtiene una estructura mediante objetos anteriores y procedimientos explícitos de construcción. Por ejemplo, en un desarrollo posterior pueden construirse los enteros desde los naturales, los racionales desde los enteros y los reales mediante clases de sucesiones de Cauchy o cortaduras de Dedekind. Estas construcciones son ejemplos explicativos de la presente edición y **no se desarrollan en la clase**.

La vía elegida por el curso es **axiomática**: se declara un conjunto $\mathbb R$, se introducen operaciones y se prescriben relaciones entre ellas. Esas relaciones forman la base a partir de la cual se demostrarán propiedades adicionales. El profesor compara la construcción de la teoría con la formulación progresiva de las reglas del ajedrez: un tablero, las piezas y sus movimientos constituyen datos iniciales; las situaciones posibles se investigan después a partir de ellos.

El programa axiomático de los reales se distribuye en tres estratos:

1. **Axiomas de cuerpo:** estructura algebraica de suma y producto.
2. **Axiomas de orden:** relaciones de comparación compatibles con las operaciones.
3. **Axiomas de completitud:** propiedad del continuo real que permitirá fundamentar los límites.

En esta primera sesión se trabaja en el primer estrato. Orden y completitud aparecen únicamente como contexto del curso.

#### Primer dato: un conjunto
Se introduce $\mathbb R$ como un conjunto. Sus elementos se llaman **números reales**; se representan por letras como $x,y,z,a,b,c$. La escritura

$$x\in\mathbb R$$

se lee «$x$ pertenece a $\mathbb R$». En este punto, la teoría todavía ha descrito una estructura muy general: se ha designado un conjunto y se ha nombrado a sus elementos. El profesor insiste en respetar el orden lógico del desarrollo: cada afirmación requiere un fundamento ya incorporado.

**Lectura estructural:** el significado matemático de $\mathbb R$ se precisa progresivamente mediante sus operaciones y axiomas. El trabajo deductivo posterior dependerá de tales propiedades.

### Las operaciones fundamentales y su buena definición

[Inicio aproximado: 11:48](https://www.youtube.com/watch?v=08n7qZ-H7W8&t=708s).

El segundo ingrediente consiste en dotar al conjunto de **dos operaciones binarias**: la suma y el producto. Formalmente, una operación binaria sobre $\mathbb R$ es una función

$$\circ\colon\mathbb R\times\mathbb R\longrightarrow\mathbb R.$$

Cada par ordenado $(x,y)$ determina un elemento $x\circ y$ de $\mathbb R$. Las dos operaciones del curso son

$$+\colon\mathbb R\times\mathbb R\to\mathbb R,\quad(x,y)\mapsto x+y,$$

$$\cdot\colon\mathbb R\times\mathbb R\to\mathbb R,\quad(x,y)\mapsto xy.$$

Que sean operaciones **internas** expresa que para cualesquiera $x,y\in\mathbb R$ también $x+y\in\mathbb R$ y $xy\in\mathbb R$. Estas son propiedades incorporadas a la presentación de ambas operaciones. La resta y la división se introducirán posteriormente en función de suma, producto y elementos apropiados.

#### ¿Qué significa «bien definida»?
El docente concede especial importancia a que cada operación asigne **un resultado determinado a los mismos operandos**. Dos nombres pueden designar un mismo real. Si $x=w$, entonces $x+y$ y $w+y$ designan un mismo resultado. Análogamente, si $x=x'$ e $y=y'$, entonces

$$x+y=x'+y',\qquad xy=x'y'.$$

En el lenguaje de funciones, estas igualdades expresan que el resultado depende de los elementos de entrada y respeta la igualdad de dichas entradas. En concreto,

$$x=w\quad\Longrightarrow\quad x+z=w+z$$

para cada $z\in\mathbb R$; la misma consideración vale para $z+x=z+w$ y para el producto.

**Dos niveles de justificación.** La igualdad $x+y=y+x$ requiere el **axioma de conmutatividad**. En cambio, si ya sabemos que $x+y=y+x$, podemos concluir

$$(x+y)+z=(y+x)+z$$

mediante la **buena definición de la suma exterior**. El primer motivo establece que los operandos internos coinciden; el segundo permite sustituirlos dentro de una nueva operación.

El profesor anticipa que estas justificaciones, aparentemente minuciosas, serán decisivas en las primeras pruebas del curso.

#### La sustitución paso a paso
Supongamos $a=b$. Para demostrar $a+c=b+c$:

1. El primer operando de $a+c$ es el real $a$.
2. El primer operando de $b+c$ es el real $b$, que coincide con $a$ por hipótesis.
3. Ambos segundos operandos son el mismo real $c$.
4. Como la operación suma está bien definida, ambos resultados coinciden.

Esta operación lógica se denomina **sustitución de iguales por iguales** o *congruencia de la igualdad* respecto de la operación.

### Axioma 1: conmutatividad

[Inicio aproximado: 23:32](https://www.youtube.com/watch?v=08n7qZ-H7W8&t=1412s).

La **conmutatividad** afirma que el orden de los dos operandos puede permutarse conservando el resultado de cada una de las operaciones fundamentales:

$$\boxed{\forall x,y\in\mathbb R,\qquad x+y=y+x,\qquad xy=yx.}$$

La conmutatividad de la suma y la conmutatividad del producto se presentan juntas como **axioma 1**. En el método elegido constituyen datos constitutivos de la teoría. Su función consiste en legitimar cada permutación usada en una demostración.

El contraste pedagógico es importante: comprobar que $7\cdot8=8\cdot7$ confirma un caso particular en la aritmética usual; el axioma

$$xy=yx\qquad\text{para cualesquiera }x,y\in\mathbb R$$

se aplica a **todos** los pares de reales sin necesidad de repetir un cálculo numérico.

#### Una propiedad derivada: conmutar dentro de una suma mayor
Demostrar:

$$(x+y)+z=(y+x)+z.$$

**Demostración.** Por la conmutatividad de la suma, $x+y=y+x$. A continuación, la suma está bien definida y ambos miembros pueden sumarse al mismo $z$. Por consiguiente,

$$\underbrace{(x+y)+z}_{\text{suma exterior}}=\underbrace{(y+x)+z}_{\text{suma exterior}}.$$

Aquí intervienen dos razones distinguibles: conmutatividad **dentro del paréntesis** y congruencia **fuera del paréntesis**. $\square$

#### Una propiedad con dos sustituciones internas
Demostrar:

$$(x+y)+(x+y)=(y+x)+(y+x).$$

**Demostración.** El axioma 1 proporciona $x+y=y+x$ para el primer sumando y nuevamente $x+y=y+x$ para el segundo. La suma exterior de pares de operandos iguales produce resultados iguales, de donde sigue la tesis. $\square$

#### ¿Qué hace de una afirmación un axioma?
El profesor presenta los axiomas como los **pilares** de una construcción deductiva: se aceptan en el marco de la teoría y permiten derivar nuevas propiedades. Cada afirmación derivada debe apoyarse en un axioma, una hipótesis o una propiedad previamente demostrada. Un mismo resultado puede admitir distintas demostraciones; la suficiencia lógica de sus pasos es lo que establece su validez.

Esta arquitectura permite reconocer la diferencia entre:

- **Axioma:** propiedad fijada como fundamento de la teoría.
- **Hipótesis:** dato asumido en el enunciado de un problema o teorema.
- **Proposición demostrable:** conclusión obtenida por una cadena de inferencias justificadas.

### Axioma 2: asociatividad

[Inicio aproximado: 36:52](https://www.youtube.com/watch?v=08n7qZ-H7W8&t=2212s).

Como la suma y el producto son operaciones **binarias**, una expresión con tres reales debe interpretarse mediante dos operaciones sucesivas. Para $x,y,z\in\mathbb R$, las sumas $(x+y)+z$ y $x+(y+z)$ están definidas: primero se combinan dos números y después su resultado con el tercero.

La **asociatividad** afirma que las dos agrupaciones producen el mismo real:

$$\boxed{(x+y)+z=x+(y+z),\qquad (xy)z=x(yz).}$$

Este es el **axioma 2**. Su utilidad esencial consiste en modificar los paréntesis conservando el orden de los factores o sumandos. En esta presentación, se justificará la supresión de paréntesis mediante la asociatividad, una vez establecida la propiedad.

#### Diferencia operativa entre conmutar y asociar
- **Conmutar** intercambia los operandos de una operación: $x+y=y+x$.
- **Asociar** cambia la posición de un paréntesis en una composición de tres términos: $(x+y)+z=x+(y+z)$.

Una demostración extensa puede alternar ambas acciones, cada una con su fundamento.

#### Primera demostración encadenada de la sesión
[Tramo aproximado: 39:34–43:55](https://www.youtube.com/watch?v=08n7qZ-H7W8&t=2374s).

**Proposición.** Para cualesquiera $x,y,z\in\mathbb R$,

$$(x+y)+z=(y+z)+x.$$

**Demostración.** Se comienza en el miembro izquierdo y se busca llegar al derecho. Primero se aplica la asociatividad para reagrupar $x$, $y$ y $z$; después se conmuta la suma de $x$ con el paréntesis $(y+z)$:

$$\begin{aligned}
(x+y)+z
&=x+(y+z) &&\text{(asociatividad de la suma)}\\
&=(y+z)+x &&\text{(conmutatividad de la suma).}
\end{aligned}$$

Los extremos de la cadena son iguales por transitividad de la igualdad. $\square$

**Método de trabajo.** Las demostraciones de identidades suelen presentarse como cadenas de expresiones, cada una igual a la siguiente por una razón declarada. La propiedad buscada se obtiene cuando el último término coincide con el objetivo. El profesor insiste en que las igualdades, y las razones que las garantizan, constituyen el centro de la corrección matemática.

### Axioma 3: distributividad

[Inicio aproximado: 48:56](https://www.youtube.com/watch?v=08n7qZ-H7W8&t=2936s).

La **distributividad del producto respecto de la suma** enlaza las dos operaciones fundamentales:

$$\boxed{x(y+z)=xy+xz.}$$

Es el **axioma 3** en su presentación por la izquierda. El factor exterior $x$ multiplica a cada sumando del paréntesis. La igualdad respectiva por la derecha es

$$(x+y)z=xz+yz.$$

El profesor muestra que puede **deducirse** de la distributividad izquierda y de la conmutatividad del producto. Sin embargo, para los ejercicios y evaluaciones del curso se admite usar ambas versiones directamente como formulaciones autorizadas del axioma, por convenio docente.

#### Demostración detallada de la distributividad por la derecha
**Proposición.** Si $x,y,z\in\mathbb R$, entonces $(x+y)z=xz+yz$.

**Demostración.** Comenzamos por el miembro izquierdo:

$$\begin{aligned}
(x+y)z
&=z(x+y) &&\text{(conmutatividad del producto)}\\
&=zx+zy &&\text{(distributividad por la izquierda)}\\
&=xz+yz &&\text{(conmutatividad de cada producto}\text{; buena definición de la suma).}
\end{aligned}$$

El paso final reúne tres justificaciones: $zx=xz$, $zy=yz$ y, como los dos sumandos respectivos coinciden, sus sumas también coinciden. De este modo se ha obtenido la versión derecha a partir de los axiomas ya establecidos. $\square$

#### Una expresión engañosa
La identidad

$$x(y+z)=xy+z$$

omite el producto de $x$ por el segundo sumando. El axioma prescribe explícitamente **dos productos**:

$$x(y+z)=xy+xz.$$

Asimismo, la fórmula

$$x+yz=(x+y)(x+z)$$

sería una presunta distributividad de la **suma sobre el producto**. El profesor la plantea como pregunta que más adelante podrá examinarse con los axiomas completos.

> **Ampliación de estas notas — contraejemplo en la aritmética usual.** Si $x=1$, $y=2$ y $z=3$, entonces $x+yz=1+2\cdot3=7$, mientras que $(x+y)(x+z)=3\cdot4=12$. Por consiguiente, la segunda igualdad carece de validez universal en los reales usuales. Este contraejemplo numérico utiliza el modelo familiar de $\mathbb R$ y pertenece a la ampliación, dado que el profesor difiere la cuestión mientras introduce los axiomas.

#### El valor de distinguir «axioma» de «propiedad derivada»
Que una igualdad sea consecuencia de otras permite **economizar** el sistema de axiomas. Una presentación puede escoger distributividad izquierda como axioma y demostrar la derecha; también puede escoger la derecha y recuperar la izquierda por conmutatividad. La clase explica por qué ambas formas se aceptan en los controles: la elección fundacional es flexible siempre que la estructura deductiva quede explicitada.

#### ¿Cuánto detalle debe tener una demostración?
[Tramo aproximado: 1:06:46–1:10:27](https://www.youtube.com/watch?v=08n7qZ-H7W8&t=4006s).

En la **primera semana**, el docente pide justificar cada paso con los nombres completos de las propiedades aplicadas: por ejemplo, «conmutatividad del producto» o «distributividad del producto respecto de la suma». El propósito es instalar una disciplina de inferencia. Más adelante, una vez adquiridas las técnicas básicas, las mismas reglas podrán utilizarse con mayor fluidez, manteniendo el rigor de las transformaciones.

Cuando se afirma que dos expresiones son iguales, debe existir una razón para cada signo igual. Para refutar una igualdad universal, puede exhibirse un **contraejemplo**: una elección de operandos para la cual ambos lados generan valores distintos.

### Axioma 4: existencia de elementos neutros

[Inicio aproximado: 1:22:29](https://www.youtube.com/watch?v=08n7qZ-H7W8&t=4949s).

El **elemento neutro aditivo** es un real $e$ que satisface

$$\boxed{\forall x\in\mathbb R,\qquad x+e=x.}$$

Por conmutatividad también se tiene $e+x=x$. El axioma 4 establece la **existencia de al menos un** real con esta propiedad. De manera paralela, se anuncia un **elemento neutro multiplicativo**, un real $u$ que satisface

$$\boxed{\forall x\in\mathbb R,\qquad xu=x,}$$

junto con $ux=x$ por conmutatividad. Esta segunda existencia se menciona como parte del mismo grupo axiomático; la clase concentra su análisis posterior en el neutro aditivo.

La escritura usual llamará **$0$** al neutro aditivo y **$1$** al neutro multiplicativo, una vez justificada su unicidad. En esta sesión el docente usa deliberadamente símbolos genéricos como $e$, $e_1$ y $e_2$ antes de concluir dicha unicidad.

#### Existencia y unicidad: dos cuestiones distintas
- La afirmación **«existe al menos uno»** se formaliza mediante un cuantificador existencial: $\exists e\in\mathbb R\;\forall x\in\mathbb R,\;x+e=x$.
- La afirmación **«existe exactamente uno»** añade que cualesquiera dos elementos que cumplen esa propiedad deben ser iguales.

La primera afirmación procede del **axioma 4**. La segunda será el contenido de un **teorema**, que deberá demostrarse desde las propiedades disponibles.

El profesor utiliza una imagen didáctica: imaginemos el conjunto de los reales como un saco. Extraemos un elemento neutro y lo llamamos $e_1$; volvemos a seleccionar uno y lo llamamos $e_2$. La manera correcta de garantizar unicidad es tomar **cualesquiera** dos candidatos y establecer $e_1=e_2$.

#### Planteamiento de la primera demostración de unicidad
**Teorema anunciado.** El neutro aditivo de $\mathbb R$ es único.

**Hipótesis inicial:** sean $e_1,e_2\in\mathbb R$ elementos neutros aditivos. Esto significa que para todo $x\in\mathbb R$ se cumplen $x+e_1=x$ y $x+e_2=x$.

**Objetivo (P.D.Q.):** demostrar $e_1=e_2$.

El docente presenta este esquema y **deja la demostración pendiente para la siguiente clase** [1:35:04–1:36:26](https://www.youtube.com/watch?v=08n7qZ-H7W8&t=5704s). El paso decisivo es que ambos candidatos actúan como neutro respecto de cualquier real, incluidos los propios candidatos.

#### Ampliación de estas notas: demostración completa de unicidad
**Teorema.** Si $e_1$ y $e_2$ son neutros aditivos, entonces $e_1=e_2$.

**Demostración.** Por la propiedad de neutro de $e_2$, aplicada al real $x=e_1$, obtenemos

$$e_1+e_2=e_1.$$

Por la propiedad de neutro de $e_1$, aplicada al real $x=e_2$, y usando conmutatividad cuando corresponda, obtenemos

$$e_1+e_2=e_2.$$

Por transitividad de la igualdad,

$$\boxed{e_1=e_1+e_2=e_2.}$$

Así, cualesquiera dos candidatos coinciden, que es exactamente la unicidad buscada. $\square$

**Lectura lógica de la prueba.** Su punto de partida son dos elementos **arbitrarios** con la misma propiedad. Aplicamos la propiedad de uno al otro y la del otro al primero. La doble igualdad fuerza su coincidencia. El razonamiento ilustra un patrón general para demostrar unicidades.

#### Ampliación de estas notas: unicidad del neutro multiplicativo
Si $u_1$ y $u_2$ satisfacen $xu_i=x$ para todo $x\in\mathbb R$, entonces

$$u_1=u_1u_2=u_2,$$

pues $u_2$ actúa como neutro sobre $u_1$ y $u_1$ sobre $u_2$ (usando, si se necesita, conmutatividad del producto). Por ello existe a lo sumo un neutro multiplicativo. Como el axioma garantiza al menos uno, resulta único.

Esta demostración es un complemento editorial; la clase no la desarrolla.

### El lenguaje de las demostraciones

La sesión ofrece un primer vocabulario de prueba:

| Expresión | Función en el razonamiento |
|---|---|
| **«Sean $x,y,z\in\mathbb R$»** | Introduce elementos arbitrarios del conjunto. |
| **«Supongamos que $x=y$»** | Declara una hipótesis particular. |
| **«Por demostrar que» (P.D.Q.)** | Enuncia con precisión la conclusión perseguida. |
| **«Por el axioma de…»** | Identifica una propiedad fundacional usada en un paso. |
| **«Por buena definición»** | Justifica sustituir operandos iguales en una operación. |
| **«Por transitividad»** | Concluye $a=c$ a partir de $a=b$ y $b=c$. |
| **«Contraejemplo»** | Exhibe un caso que invalida una afirmación universal. |
| **«Teorema»** | Resultado demostrado a partir de las hipótesis y fundamentos aceptados. |

#### Protocolo de demostración de una igualdad
Ante una identidad de la forma $A=B$, conviene:

1. **Especificar** las variables y sus dominios.
2. **Leer la estructura** de $A$ y $B$: operaciones interiores, operaciones exteriores y paréntesis.
3. **Elegir una transformación** justificable por axiomas o resultados previos.
4. **Escribir una cadena de igualdades** $A=A_1=A_2=\cdots=B$, acompañando cada paso de su razón.
5. **Cerrar la demostración** mediante la transitividad de la igualdad.

Para una prueba de unicidad, el primer paso especializado es: **«Sean $u$ y $v$ dos elementos arbitrarios que satisfacen la propiedad»**. El objetivo especializado es deducir $u=v$.

### Ejemplos de estudio desarrollados

Los siguientes desarrollos amplían la ejercitación de la clase y sirven como modelos de escritura.

#### Ejemplo 1. Reordenar una suma de cuatro términos
Para $a,b,c,d\in\mathbb R$, demostremos

$$((a+b)+c)+d=(c+d)+(b+a).$$

**Solución.**

$$\begin{aligned}
((a+b)+c)+d
&=(a+b)+(c+d) &&\text{(asociatividad)}\\
&=(c+d)+(a+b) &&\text{(conmutatividad)}\\
&=(c+d)+(b+a) &&\text{(conmutatividad interior y buena definición).}
\end{aligned}$$

En la primera línea se reorganizan los paréntesis mediante la asociatividad; en la segunda se permutan los dos grandes sumandos; en la tercera se permutan $a$ y $b$ dentro del segundo paréntesis, conservando la suma exterior.

#### Ejemplo 2. Distribuir un producto por una suma de tres términos
**Objetivo:** justificar $x(y+z+w)=xy+xz+xw$, donde $y+z+w$ se entiende con una agrupación explícita.

$$\begin{aligned}
x\bigl((y+z)+w\bigr)
&=x(y+z)+xw &&\text{(distributividad)}\\
&=(xy+xz)+xw &&\text{(distributividad interior y buena definición)}.
\end{aligned}$$

Por asociatividad de la suma, la expresión final también puede escribirse $xy+(xz+xw)$.

#### Ejemplo 3. Una propiedad universal y su prueba
**Proposición:** $(xy)z=z(yx)$ para todos $x,y,z\in\mathbb R$.

$$\begin{aligned}
(xy)z
&=z(xy) &&\text{(conmutatividad del producto)}\\
&=z(yx) &&\text{(conmutatividad interior y buena definición).}
\end{aligned}$$

#### Ejemplo 4. Dos operaciones de una misma forma, propiedades diferentes
> **Ampliación.** En el conjunto usual $\mathbb R$ definimos $x\star y=(x+y)/2$. La operación es conmutativa, pues $x+y=y+x$. Sin embargo, para $x=0$, $y=0$ y $z=2$,
>
> $$(0\star0)\star2=1,\qquad 0\star(0\star2)=\tfrac12.$$
>
> Por lo tanto, la asociatividad es una propiedad adicional que exige su propia justificación. Este ejemplo usa división y aritmética ordinaria para ilustrar la independencia conceptual de conmutatividad y asociatividad; queda fuera del desarrollo estrictamente axiomático de la primera sesión.

### Glosario mínimo

**Axioma.** Proposición fundamental fijada como punto de partida de una teoría deductiva.

**Operación binaria.** Función que asigna a cada par ordenado de elementos de un conjunto un elemento de ese mismo conjunto.

**Operación bien definida.** Función cuyo valor queda determinado por sus argumentos y respeta la igualdad de estos.

**Conmutatividad.** Propiedad de una operación según la cual permutar dos operandos conserva el resultado.

**Asociatividad.** Propiedad según la cual las dos agrupaciones sucesivas de tres elementos producen el mismo resultado.

**Distributividad.** Relación por la cual un producto aplicado a una suma se expresa como suma de productos.

**Elemento neutro.** Elemento que, combinado con cualquier elemento mediante cierta operación, conserva ese elemento.

**Existencia.** Afirmación según la cual un objeto con cierta propiedad está presente en el dominio considerado.

**Unicidad.** Propiedad según la cual cualesquiera dos objetos que satisfacen la caracterización propuesta coinciden.

**Teorema.** Proposición que cuenta con una demostración fundada en axiomas, hipótesis y resultados anteriores.

**Contraejemplo.** Caso particular que muestra la falsedad de una afirmación universal.

---

**Referencia primaria:** Jorge San Martín, «IC2021: Cátedra 1.1 (Lunes 15/3/21 14:30)», YouTube, transmisión del 15 de marzo de 2021, [enlace](https://www.youtube.com/watch?v=08n7qZ-H7W8). **Criterio de fidelidad:** reconstrucción didáctica, con ampliaciones propias explícitamente identificadas; no constituye transcripción literal ni versión oficial de apuntes del docente.

*Procedencia de este tramo: cátedra 1.2.*

### De una teoría axiomática a sus consecuencias

**En la cátedra (02:01–03:36).** La clase continúa exactamente donde terminó la Cátedra 1.1. El profesor había introducido el conjunto $\mathbb R$, las operaciones binarias $+$ y $\cdot$, la conmutatividad, la asociatividad, la distributividad y, finalmente, el **axioma 4**, que garantiza que existen elementos neutros. El propósito inmediato consiste en demostrar una propiedad adicional: la **unicidad** del neutro aditivo. Luego aparecen los inversos, la caracterización de cuerpo y un pequeño conjunto de teoremas derivados.

El procedimiento axiomático tiene un orden lógico. Se establecen ciertas propiedades primitivas y se demuestra, por reglas de inferencia, cuanto se sigue de ellas. Formalmente, las dos operaciones son funciones

$$
+\colon\mathbb R\times\mathbb R\to\mathbb R,\qquad
\cdot\colon\mathbb R\times\mathbb R\to\mathbb R.
$$

La buena definición de una operación permite sustituir operandos iguales: $a=b$ implica $a+c=b+c$ y $ac=bc$, para todo $c\in\mathbb R$. La **conmutatividad** afirma $a+b=b+a$, $ab=ba$; la **asociatividad**, $(a+b)+c=a+(b+c)$, $(ab)c=a(bc)$; la **distributividad**, $a(b+c)=ab+ac$. Esas son las primeras tres familias de axiomas del curso.

#### Existencia y unicidad son afirmaciones distintas
El axioma de existencia de neutro aditivo puede escribirse como

$$
\exists e\in\mathbb R\quad\forall x\in\mathbb R:\ x+e=x.
$$

Esto afirma que el conjunto de elementos con esa propiedad tiene al menos un miembro. Para obtener unicidad debe probarse

$$
\forall e_1,e_2\in\mathbb R:\quad
\left[\bigl(\forall x,\ x+e_1=x\bigr)\land
      \bigl(\forall x,\ x+e_2=x\bigr)\right]\Rightarrow e_1=e_2.
$$

La combinación lógica de ambas afirmaciones se simboliza con $\exists!e$ (*existe exactamente uno*). Esta descomposición es una herramienta habitual para resolver problemas matemáticos: primero se construye o garantiza una solución, luego se comparan dos soluciones cualesquiera.

#### Identificar datos y lo que se debe demostrar
**En la cátedra (04:43–10:38).** El profesor introduce dos neutros simbólicos $e_1,e_2$ para formular el objetivo $e_1=e_2$. Las hipótesis $x+e_1=x$ y $x+e_2=x$ son **datos**. La igualdad $e_1=e_2$ es la **conclusión** que debe alcanzarse. Su advertencia central es metodológica: usar como hipótesis la igualdad que se pretende demostrar produce un razonamiento circular. La proposición $P\Rightarrow P$ es una tautología lógica, pero su verdad por sí sola no establece la verdad de $P$.

**Ejemplo lógico.** Si $P$ es «$e_1=e_2$», escribir «supongamos $e_1=e_2$; entonces $e_1=e_2$» establece la tautología $P\Rightarrow P$. Una demostración verdadera de unicidad debe partir, en cambio, de la condición que caracteriza a ambos neutros y de los axiomas conocidos.

### Primer teorema de la clase: el neutro aditivo es único

**En la cátedra (10:50–15:46).** Sean $e_1$ y $e_2$ neutros aditivos. Por definición,

$$
\forall x\in\mathbb R:\quad x+e_1=x,\qquad x+e_2=x.
$$

La **idea decisiva** es sustituir $x$ por el otro neutro en cada identidad. Con $x=e_2$ en la primera, se obtiene $e_2+e_1=e_2$. Con $x=e_1$ en la segunda, se obtiene $e_1+e_2=e_1$. Enseguida,

$$
\boxed{\ e_1\overset{\text{neutro }e_2}{=}
(e_1+e_2)\overset{\text{conmutatividad}}{=}
(e_2+e_1)\overset{\text{neutro }e_1}{=}e_2\ }.
$$

Por tanto, $e_1=e_2$. Como el axioma 4 ya había garantizado al menos un neutro, concluimos que existe **exactamente un** neutro aditivo. Se lo denota por $0$, y su propiedad constitutiva es

$$\boxed{\quad\forall x\in\mathbb R:\ x+0=x.\quad}$$

**Corolario de reconocimiento.** Si $\alpha\in\mathbb R$ cumple $x+\alpha=x$ para todo $x$, entonces $\alpha=0$: satisface la propiedad caracterizadora del neutro y este es único.

**Nota de rigor.** La conmutatividad interviene expresamente en la prueba dada por el profesor. En una estructura con neutro **bilateral** puede probarse su unicidad incluso sin conmutatividad, pues $e_1=e_1e_2=e_2$; para neutros definidos por una sola cara se requieren hipótesis adicionales. Esta observación amplía el comentario pedagógico del video y delimita el alcance general del argumento.

#### El neutro multiplicativo
**En la cátedra (16:00–17:58).** El axioma 4 garantiza también un neutro del producto, caracterizado por

$$\forall x\in\mathbb R:\quad x\cdot u=x.$$

El profesor deja **como ejercicio** repetir la prueba anterior para demostrar su unicidad. Al elemento único lo llamamos $1$. La convención de cuerpo utilizada en el curso exige además

$$\boxed{\quad 0\ne1,\qquad\forall x\in\mathbb R:\ x\cdot1=x.\quad}$$

**Ampliación — resolución de la tarea.** Sean $u_1,u_2$ neutros multiplicativos. Por sus propiedades y la conmutatividad,

$$u_1=u_1u_2=u_2u_1=u_2.$$

El teorema muestra que el símbolo $1$ designa una propiedad estructural precisa: ser el único elemento neutro para la multiplicación. La condición $0\ne1$ sostiene la existencia de un cuerpo con al menos dos elementos, asunto al que el profesor vuelve después de demostrar la tabla del cero.

### Axioma 5: existencia de opuestos y de recíprocos

#### Opuesto aditivo
**En la cátedra (18:01–19:49).** Para cada $x\in\mathbb R$, el axioma 5 garantiza la existencia de al menos un real $p$ tal que

$$x+p=0.$$

Se llama **opuesto** o **inverso aditivo** de $x$ a cualquier elemento que satisface esa igualdad. El profesor precisa que la existencia se asegura para **cada** real y presenta como teorema la unicidad del opuesto correspondiente a cada $x$.

#### Unicidad del opuesto: demostración reconstruida paso a paso
**En la cátedra (19:51–31:45).** Fijemos $x\in\mathbb R$ y sean $p_1,p_2$ opuestos de ese **mismo** $x$. Los datos son

$$x+p_1=0,\qquad x+p_2=0;$$

y el objetivo es $p_1=p_2$. El profesor escribe una cadena de igualdades y detiene la atención en el empleo de la buena definición de la suma cuando queda un sumando externo. Reproducimos el razonamiento con indicaciones precisas:

$$
\begin{aligned}
p_1
&=p_1+0 &&\text{(neutro aditivo)}\\
&=p_1+(x+p_2) &&\text{(dato }x+p_2=0\text{; sustitución)}\\
&=(p_1+x)+p_2 &&\text{(asociatividad)}\\
&=(x+p_1)+p_2 &&\text{(conmutatividad; sustitución)}\\
&=0+p_2 &&\text{(dato }x+p_1=0\text{; sustitución)}\\
&=p_2+0 &&\text{(conmutatividad)}\\
&=p_2 &&\text{(neutro aditivo).}
\end{aligned}
$$

La demostración concluye $p_1=p_2$. Como cada $x$ tenía al menos un opuesto por axioma, existe exactamente uno. Lo denotamos por $-x$ y obtenemos

$$\boxed{\quad\forall x\in\mathbb R:\ x+(-x)=0.\quad}$$

**Por qué se explicitan los «sumandos que sobran».** De $x+p_2=0$ se pasa a $p_1+(x+p_2)=p_1+0$ usando que una operación respeta la igualdad de sus argumentos. De $p_1+x=x+p_1$ se pasa a $(p_1+x)+p_2=(x+p_1)+p_2$ por la misma razón. La conmutatividad, por sí sola, transforma el subparéntesis; la buena definición de la suma garantiza la igualdad completa.

#### La notación y el reconocimiento del opuesto
**En la cátedra (38:39–44:44).** El símbolo $-x$ nombra el único real que sumado con $x$ produce $0$. A partir de aquí se aplica el **criterio de reconocimiento**

$$\boxed{\quad x+y=0\quad\Longrightarrow\quad y=-x.\quad}$$

Por ejemplo,

$$a+(b+c)=0\quad\Longrightarrow\quad b+c=-a,$$

porque el real $(b+c)$ cumple la condición de ser opuesto de $a$. Asimismo,

$$(b+c)+a=0\quad\Longrightarrow\quad a=-(b+c).$$

Para demostrar $a=-b$ basta, en esta teoría conmutativa, con demostrar $b+a=0$. Esta sustitución de una igualdad con signo menos por una igualdad cuyo resultado es cero será la técnica principal para estudiar las reglas de los signos.

### El recíproco y la extensión exacta del axioma

**En la cátedra (45:00–53:17).** La parte multiplicativa del axioma 5 establece que cada real $x\ne0$ admite por lo menos un número $r$ tal que

$$xr=1.$$

Un tal elemento se llama **recíproco** o **inverso multiplicativo** de $x$. El profesor insiste en una precisión lógica fundamental: el enunciado sobre $x\ne0$ proporciona información acerca de todos esos reales, mientras que la situación particular $x=0$ requiere un argumento independiente. En esta etapa todavía debe investigarse qué sucede con el cero; más adelante se concluye que carece de inverso multiplicativo.

El profesor deja como tarea la unicidad del recíproco. Una vez establecida, se usa la notación $x^{-1}$ y se escribe

$$\boxed{\quad x\ne0\quad\Longrightarrow\quad x x^{-1}=1.\quad}$$

**Ampliación — prueba de unicidad.** Sean $r,s$ recíprocos de un mismo $x\ne0$, de modo que $xr=xs=1$. Entonces

$$
\begin{aligned}
r&=r\cdot1=r(xs)=(rx)s=(xr)s=1\cdot s=s.
\end{aligned}
$$

Por eso, si $xy=1$ con $x\ne0$, el criterio de reconocimiento es $y=x^{-1}$. La condición $x\ne0$ aparecerá justificada por una propiedad demostrada en la siguiente parte.

#### ¿Qué es exactamente un cuerpo?
El hito explícito de [53:17](https://www.youtube.com/watch?v=Tl5Hf5d4U2Y&t=3197s) es

$$\boxed{\quad(\mathbb R,+,\cdot)\text{ es un cuerpo}.\quad}$$

La expresión designa **un conjunto con dos operaciones** que satisface las familias de axiomas adoptadas: conmutatividad, asociatividad, distributividad, neutros distintos entre sí, inversos aditivos para todos los elementos e inversos multiplicativos para los elementos distintos de cero. Esta primera etapa muestra la **estructura algebraica** de $\mathbb R$. Las propiedades de orden y completitud pertenecen a etapas posteriores del curso.

### Primera propiedad derivada: la tabla del cero

**En la cátedra (59:54–72:46).** Todo real $a$ satisface

$$\boxed{\quad a\cdot0=0.\quad}$$

El profesor contrasta cuidadosamente este hecho con $a\cdot1=a$. La segunda igualdad caracteriza al neutro multiplicativo y está respaldada por el axioma 4; la primera es un **teorema** que relaciona el neutro aditivo con el producto, y requiere distributividad.

#### Demostración siguiendo la estrategia del profesor
Fijemos $a\in\mathbb R$ y escribamos $w=a\cdot0$. El truco consiste en insertar $0$, expresarlo como $w+(-w)$, agrupar, factorizar el producto y suprimir finalmente el par mediante el inverso aditivo. Con todos los pasos:

$$
\begin{aligned}
a\cdot0
&=a\cdot0+0 &&\text{(neutro aditivo)}\\
&=a\cdot0+\bigl(a\cdot0+(-a\cdot0)\bigr)
  &&\text{(opuesto de }a\cdot0\text{)}\\
&=\bigl(a\cdot0+a\cdot0\bigr)+(-a\cdot0)
  &&\text{(asociatividad)}\\
&=a\cdot(0+0)+(-a\cdot0)
  &&\text{(distributividad, de derecha a izquierda)}\\
&=a\cdot0+(-a\cdot0)
  &&\text{(neutro }0+0=0\text{; sustitución)}\\
&=0 &&\text{(opuesto aditivo).}
\end{aligned}
$$

**La idea matemática.** En la igualdad $a\cdot(0+0)=a\cdot0+a\cdot0$, la distributividad relaciona la suma y el producto. Gracias a esa interacción, el valor de $a\cdot0$ queda determinado por la estructura de cuerpo. «Factorizar» es utilizar la igualdad distributiva en sentido inverso; constituye una lectura de un mismo axioma.

#### Demostración corta alternativa — ampliación
Sea $w=a0$. La distributividad aplicada a $0+0=0$ proporciona

$$w=a(0+0)=a0+a0=w+w.$$

Sumamos $-w$ a los dos lados y usamos asociatividad:

$$w+(-w)=(w+w)+(-w)=w+(w+(-w))=w+0=w.$$

El lado izquierdo es cero, luego $w=0$. Es la misma idea expresada mediante cancelación. La prueba de la cátedra resulta especialmente útil para aprender a transformar un lado de una igualdad hasta alcanzar el otro.

### El cero carece de recíproco multiplicativo

**En la cátedra (72:46–77:34).** Una vez demostrado $a0=0$, se resuelve la cuestión pendiente. Si algún $r\in\mathbb R$ fuese recíproco de $0$, cumpliría $0r=1$. Pero, usando la tabla del cero y conmutatividad, $0r=r0=0$. Resultaría

$$1=0r=0,$$

en contradicción con el axioma $0\ne1$. Se concluye:

$$\boxed{\quad\forall r\in\mathbb R:\ 0r=0,\qquad 0\text{ carece de recíproco multiplicativo}.\quad}$$

El profesor examina además el motivo de la condición $0\ne1$. Si se admitiera $0=1$, entonces, para cada $a\in\mathbb R$,

$$a=a\cdot1=a\cdot0=0.$$

Todos los elementos coincidirían con el cero y el conjunto tendría un único elemento. En álgebra se estudia esta estructura de un elemento, llamada **anillo cero**. En la convención usual de teoría de cuerpos se exige $0\ne1$, que conserva la estructura algebraica con al menos dos elementos.

### La ecuación $a+x=b$, la resta y la división

#### La solución única de una ecuación aditiva
**En la cátedra (77:34–80:56).** Dados $a,b\in\mathbb R$, el profesor propone resolver

$$a+x=b.$$

Ahora $x$ es una **incógnita**: se busca un real que satisfaga la ecuación. Anuncia como resultado que existe una única solución y que esta es

$$\boxed{\quad x=b+(-a).\quad}$$

La clase deja las pruebas de existencia y unicidad **como tarea**, con indicaciones para resolverlas. Las escribimos completas a continuación.

**Ampliación — existencia.** Tomamos $x=b+(-a)$. Entonces

$$
\begin{aligned}
a+x&=a+\bigl(b+(-a)\bigr)\\
&=a+\bigl((-a)+b\bigr) &&\text{(conmutatividad dentro del paréntesis)}\\
&=\bigl(a+(-a)\bigr)+b &&\text{(asociatividad)}\\
&=0+b=b.
\end{aligned}
$$

**Ampliación — unicidad.** Sean $x_1,x_2$ soluciones: $a+x_1=b=a+x_2$. Se tiene

$$
\begin{aligned}
x_1&=0+x_1=\bigl((-a)+a\bigr)+x_1
=(-a)+(a+x_1)\\
&=(-a)+(a+x_2)
=\bigl((-a)+a\bigr)+x_2=0+x_2=x_2.
\end{aligned}
$$

Este resultado se denomina **cancelación aditiva**: si $a+x=a+y$, entonces $x=y$.

#### La resta como operación derivada
Cuando el real $b+(-a)$ ha quedado caracterizado como solución única de $a+x=b$, recibe el nombre de **diferencia** entre $b$ y $a$, y escribimos

$$\boxed{\quad b-a:=b+(-a).\quad}$$

Así, la resta se construye mediante la suma y el opuesto, tal como anticipaba el método axiomático: se introducen dos operaciones primitivas y luego se definen otras sobre ellas.

**Ampliación — ecuación multiplicativa.** Si $a\ne0$, la ecuación $ax=b$ tiene solución única

$$x=b\,a^{-1},$$

que se escribe $b/a$ y se denomina **cociente**. El profesor remite este resultado al apunte y concentra la parte final de la cátedra en las reglas de los signos. El requisito $a\ne0$ es indispensable para utilizar el recíproco.

### Reglas de los signos mediante la definición de opuesto

#### El opuesto del opuesto
**En la cátedra (81:31–85:49).** El primer resultado es

$$\boxed{\quad-(-a)=a.\quad}$$

En lugar de desplazar signos, el profesor traduce la afirmación: para demostrar que $a$ es el opuesto de $-a$, basta establecer $(-a)+a=0$. En efecto,

$$(-a)+a=a+(-a)=0,$$

por conmutatividad y definición de opuesto. La unicidad del opuesto permite identificarlo con $a$ y concluir $-(-a)=a$.

#### El opuesto de una suma
**En la cátedra (85:57–89:55).** Se busca demostrar

$$\boxed{\quad-(a+b)=(-a)+(-b).\quad}$$

El profesor reduce el problema al objetivo

$$(a+b)+\bigl((-a)+(-b)\bigr)=0,$$

y comienza una transformación con conmutatividad y asociatividad. Deja el cierre como tarea. Escribimos una prueba completa:

$$
\begin{aligned}
(a+b)+\bigl((-a)+(-b)\bigr)
&=(b+a)+\bigl((-a)+(-b)\bigr)\\
&=b+\bigl(a+((-a)+(-b))\bigr)\\
&=b+\bigl((a+(-a))+(-b)\bigr)\\
&=b+\bigl(0+(-b)\bigr)\\
&=b+\bigl((-b)+0\bigr)\\
&=(b+(-b))+0\\
&=0+0=0.
\end{aligned}
$$

Por el criterio de reconocimiento del opuesto, $(-a)+(-b)$ es el único opuesto de $a+b$. La fórmula queda demostrada.

#### El signo menos dentro de un producto
**En la cátedra (90:14–91:15).** El profesor plantea y deja como ejercicio

$$\boxed{\quad a(-b)=-(ab).\quad}$$

La estrategia recomendada es probar que $a(-b)$ es el opuesto de $ab$, mediante la ecuación

$$ab+a(-b)=0.$$

**Ampliación — solución.** Factorizamos por $a$ y usamos que $b+(-b)=0$:

$$ab+a(-b)=a\bigl(b+(-b)\bigr)=a\cdot0=0.$$

Por unicidad del inverso aditivo, $a(-b)=-(ab)$. Usando conmutatividad se obtiene también $(-a)b=-(ab)$ y, a partir de ambas, $(-a)(-b)=ab$.

### Metodología demostrativa y convenciones de escritura

En toda la clase, el profesor convierte el cálculo algebraico escolar en un argumento deductivo verificable. Su pauta es distinguir: (1) **hipótesis dadas**; (2) **objetivo por demostrar**; (3) **cadena de igualdades**; (4) **justificación de cada paso** mediante un axioma, teorema o una igualdad previamente obtenida; y (5) **conclusión** que enlaza los extremos de la cadena.

Durante la primera semana se exige indicar cuidadosamente los paréntesis y las leyes empleadas. La asociatividad permite reordenar agrupaciones; la conmutatividad permite intercambiar operandos; la buena definición de una operación garantiza que las sustituciones preservan los resultados. Después de probar la independencia respecto de agrupaciones y permutaciones pertinentes, se acepta escribir sumas largas y productos con notación más ágil.

Un ejemplo particularmente instructivo aparece a [32:26](https://www.youtube.com/watch?v=Tl5Hf5d4U2Y&t=1946s): de $(a+b)+c=a+(b+c)$ se deduce

$$\bigl((a+b)+c\bigr)z=\bigl(a+(b+c)\bigr)z,$$

usando **asociatividad de la suma** dentro de los paréntesis y **buena definición del producto** al multiplicar ambos lados por el mismo $z$.

#### Hilo conductor y estudio autónomo
En el cierre, el profesor muestra el apunte oficial (menciona las páginas 12 y 21) y la expansión de identidades como el cuadrado de un binomio:

$$\boxed{\quad(a+b)^2=a^2+2ab+b^2.\quad}$$

Esta expresión resulta de aplicar distributividad, conmutatividad, asociatividad y las convenciones $a^2:=aa$ y $2ab:=ab+ab$. La formula es **una consecuencia demostrable**, cuyo uso fluido descansa en el trabajo fundacional de la primera semana.

Además, el profesor recomienda volver a fragmentos de la grabación, reconstruir las razones de cada igualdad y analizar el hilo conductor de la explicación, junto con resolver los problemas del apunte. La sesión de preguntas sigue después de aproximadamente [1:32:20](https://www.youtube.com/watch?v=Tl5Hf5d4U2Y&t=5540s).

### Glosario conceptual

**Cuerpo.** Conjunto equipado con dos operaciones binarias que cumplen los axiomas algebraicos de conmutatividad, asociatividad, distributividad, existencia de neutros aditivo y multiplicativo distintos, opuestos aditivos e inversos multiplicativos de los elementos distintos de cero.

**Axioma.** Enunciado fundamental adoptado como punto de partida dentro de una teoría deductiva.

**Teorema.** Enunciado demostrado mediante inferencias válidas apoyadas en axiomas, hipótesis y resultados ya establecidos.

**Unicidad.** Propiedad de una solución caracterizada por la coincidencia de cualesquiera dos candidatos que cumplen la condición exigida.

**Neutro aditivo.** Elemento $e$ que satisface $x+e=x$ para cada $x$; en el cuerpo de los reales se representa por $0$.

**Neutro multiplicativo.** Elemento $u$ que satisface $xu=x$ para cada $x$; en los reales se representa por $1$.

**Opuesto de $x$.** Elemento $p$ que satisface $x+p=0$; su unicidad permite escribir $p=-x$.

**Recíproco de $x$.** Elemento $r$ que satisface $xr=1$ para $x\ne0$; se escribe $r=x^{-1}$.

**Distributividad.** Relación estructural $a(b+c)=ab+ac$ entre el producto y la suma.

**Buena definición de la operación.** Propiedad funcional por la que cada par de operandos determina un valor y la sustitución de iguales conserva ese valor.

**Resta.** Operación derivada $b-a=b+(-a)$, cuyo valor es la solución única de $a+x=b$.

**Cociente.** Operación derivada $b/a=b\,a^{-1}$ para $a\ne0$, cuyo valor es la solución única de $ax=b$.

### Fuentes y correspondencia con la grabación

**Fuente primaria, consultada:** Jorge San Martín, [*IC2021: Cátedra 1.2 (viernes 19 de marzo de 2021)*](https://www.youtube.com/watch?v=Tl5Hf5d4U2Y). Transcripción automática en español recuperada desde la página del video. El audio tiene aproximadamente 1 h 42 min e incluye preguntas posteriores al cierre formal de la clase. Las marcas temporales de la guía al comienzo permiten contrastar directamente los conceptos.

**Continuidad:** Jorge San Martín, [*IC2021: Cátedra 1.1 (lunes 15 de marzo de 2021)*](https://www.youtube.com/watch?v=08n7qZ-H7W8). En su conclusión se anunció que la clase siguiente comenzaría demostrando la unicidad del elemento neutro aditivo.

**Apunte del curso citado por el docente:** durante el video se remite a las páginas 12 y 21 del apunte oficial, donde aparecen identidades algebraicas y ejercicios de demostración. En la bóveda de Obsidian del curso existen además materiales denominados «CAL Apunte 2.pdf» y «CAL Soluciones Apunte2.pdf»; su correspondencia exacta con las páginas citadas en la grabación no se ha establecido en estas notas.

**Diferenciación autoral.** Los resultados de las secciones 1 a 9 están ordenados conforme a la grabación; la demostración del neutro aditivo, la del opuesto y la de la tabla del cero siguen el razonamiento presentado por el docente. Las pruebas que él propuso y dejó pendientes, las alternativas más breves, el ejercicio sobre el neutro bilateral y el banco de ejercicios con respuestas constituyen **ampliaciones editoriales**, incorporadas para hacer el material autocontenido.

### Taller de problemas y soluciones

Los ejercicios se presentan a continuación según la fuente de origen; las ampliaciones editoriales de cada apuntes permanecen expresamente identificadas.

#### Ejercicios propuestos — cátedra 1.1

**E1.** Para $x,y,z\in\mathbb R$, demostrar $z+(x+y)=z+(y+x)$. Especificar las dos razones que intervienen.

**E2.** Probar que $x(y+z)=yx+zx$. Justificar la operación exterior.

**E3.** Demostrar, mediante una cadena de igualdades, que $(x+y)+z=(z+y)+x$.

**E4.** Tomar como axioma la distributividad derecha $(x+y)z=xz+yz$ y deducir la distributividad izquierda $z(x+y)=zx+zy$.

**E5.** Explicar, en lenguaje formal, qué demuestra el argumento «Sean $e_1$ y $e_2$ neutros aditivos arbitrarios. Entonces $e_1=e_2$» y qué hace falta para completarlo.

**E6.** En los reales usuales, encontrar un contraejemplo a la igualdad universal $(x+y)(z+w)=xz+yw$.

**E7.** Justificar por qué la expresión $x+y+z$ requiere una convención de agrupación antes de disponer del axioma de asociatividad.

**E8.** Escribir una demostración detallada de $(ab)c=c(ba)$, identificando los lugares donde se usa la buena definición.

#### Solucionario desarrollado de la Cátedra 1.1 (E1–E8)
> **Nota editorial.** Los ejercicios E1–E8 son problemas de consolidación redactados para estas notas a partir de las técnicas expuestas en la primera clase. Las soluciones siguientes detallan cada uso de las operaciones, los axiomas y la sustitución de expresiones iguales. La prueba de unicidad del neutro, anunciada al final de la clase, se termina formalmente en la Cátedra 1.2.

##### E1. Sustitución de una suma en una expresión mayor
Se pide demostrar, para cualesquiera $x,y,z\in\mathbb R$,

$$z+(x+y)=z+(y+x).$$

**Demostración.** El axioma de conmutatividad aditiva garantiza

$$x+y=y+x.$$

Por tratarse de **un mismo número real** en ambos lados, podemos sumarle $z$ por la izquierda. La buena definición de la suma garantiza que esa sustitución conserva el resultado:

$$
\underbrace{z+(x+y)}_{\text{suma exterior}}
=\underbrace{z+(y+x)}_{\text{suma exterior}}.
$$

Intervienen **dos razones**: conmutatividad en el paréntesis y buena definición de la suma exterior. La asociatividad resulta innecesaria: la posición de los paréntesis se conserva.

##### E2. Distributividad y conmutatividad
Debemos probar $x(y+z)=yx+zx$.

**Demostración.** Aplicamos primero la distributividad del producto sobre la suma:

$$x(y+z)=xy+xz.$$

Por conmutatividad multiplicativa, $xy=yx$ y $xz=zx$. Como $+$ asigna el mismo resultado a pares de operandos iguales, sustituimos ambos términos en la suma:

$$
\begin{aligned}
x(y+z)&=xy+xz &&\text{(distributividad)}\\
&=yx+zx &&\text{(conmutatividad en ambos productos; buena definición de $+$).}
\end{aligned}
$$

La segunda igualdad reúne **dos aplicaciones** de la conmutatividad y una de la buena definición de la suma. Es un ejemplo de cómo una propiedad local se prolonga a una expresión compuesta.

##### E3. Transformar una suma mediante igualdades justificadas
El objetivo es $(x+y)+z=(z+y)+x$.

**Demostración.** Seguimos una cadena cuyas transformaciones preservan el valor:

$$
\begin{aligned}
(x+y)+z
&=x+(y+z) &&\text{(asociatividad)}\\
&=(y+z)+x &&\text{(conmutatividad de la suma exterior)}\\
&=(z+y)+x &&\text{(conmutatividad interior; buena definición de $+$ exterior).}
\end{aligned}
$$

La última línea merece atención: el axioma afirma $y+z=z+y$; después se sumó el mismo $x$ a ambos números obtenidos. La transitividad de la igualdad enlaza el primer y el último miembro y concluye la demostración.

##### E4. Recuperar la distributividad izquierda desde la derecha
Supongamos que se adopta como axioma la distributividad por la derecha,

$$(x+y)z=xz+yz.$$

Queremos deducir $z(x+y)=zx+zy$.

**Demostración.** Sean $x,y,z\in\mathbb R$. Entonces:

$$
\begin{aligned}
z(x+y)
&=(x+y)z &&\text{(conmutatividad del producto)}\\
&=xz+yz &&\text{(distributividad por la derecha, hipótesis)}\\
&=zx+zy &&\text{(conmutatividad en cada producto y buena definición de la suma).}
\end{aligned}
$$

La igualdad final muestra que el axioma izquierdo queda demostrado a partir del derecho y de la conmutatividad. En particular, **la elección de una dirección como axioma constituye una decisión de presentación**; la otra queda como propiedad demostrable. La demostración opuesta sigue exactamente el mismo patrón.

##### E5. Formalización completa de una prueba de unicidad
El enunciado «sean $e_1,e_2$ neutros aditivos arbitrarios; entonces $e_1=e_2$» proporciona **el esquema** de unicidad. Su forma lógica es:

$$
\forall e_1,e_2\in\mathbb R:\
\bigl(N(e_1)\land N(e_2)\bigr)\Longrightarrow e_1=e_2,
$$

donde $N(e)$ significa $\forall x\in\mathbb R,\;x+e=x$.

**Demostración.** Por $N(e_2)$, tomando $x=e_1$, se obtiene $e_1+e_2=e_1$. Por $N(e_1)$, tomando $x=e_2$, se obtiene $e_2+e_1=e_2$. Por ello,

$$
\begin{aligned}
e_1&=e_1+e_2 &&\text{(neutro $e_2$)}\\
&=e_2+e_1 &&\text{(conmutatividad)}\\
&=e_2 &&\text{(neutro $e_1$).}
\end{aligned}
$$

Como ambos candidatos eran arbitrarios, cualesquiera dos neutros aditivos coinciden. **La existencia** proviene del axioma 4 y **la unicidad** se establece en esta demostración. Este ejercicio anticipa formalmente la resolución que desarrolla el profesor al comienzo de la Cátedra 1.2.

##### E6. Un contraejemplo a una igualdad universal
Consideremos la afirmación

$$(x+y)(z+w)=xz+yw\quad\text{para todos }x,y,z,w\in\mathbb R.$$

**Contraejemplo.** Tomemos $x=y=z=w=1$ en los reales usuales. Entonces

$$
\begin{aligned}
(x+y)(z+w)&=(1+1)(1+1)=2\cdot2=4,\\
xz+yw&=1\cdot1+1\cdot1=2.
\end{aligned}
$$

Como $4\neq2$, la igualdad universal es falsa. La expansión que proporciona la distributividad es

$$(x+y)(z+w)=xz+xw+yz+yw,$$

con una agrupación adecuada de sumas. El contraejemplo revela precisamente el papel de los **términos cruzados** $xw$ y $yz$. Para refutar una afirmación universal basta exhibir una elección admisible que la contradiga.

##### E7. Por qué es importante agrupar una operación binaria
Una suma binaria es una función $+:\mathbb R\times\mathbb R\to\mathbb R$. Por ello, cada aplicación recibe **un par de argumentos**. Para tres elementos $x,y,z$ disponemos de dos composiciones canónicas:

$$
\begin{array}{ll}
\text{Primera:}&(x+y)+z,\\
\text{Segunda:}&x+(y+z).
\end{array}
$$

El axioma de asociatividad garantiza su igualdad y permite abreviar ambas expresiones como $x+y+z$.

**Comprobación de por qué la regla tiene contenido.** En la aritmética real usual definamos, a modo de ilustración externa al sistema axiomático del curso, $x\star y=(x+y)/2$. Para $x=0$, $y=0$, $z=2$,

$$(0\star0)\star2=1,\qquad 0\star(0\star2)=\tfrac12.$$

El ejemplo enseña que una operación binaria bien definida puede producir valores distintos al variar la agrupación. La asociatividad aporta la condición precisa que permite omitir los paréntesis.

##### E8. Producto anidado y buena definición
Demostrar $(ab)c=c(ba)$.

**Demostración.** Aplicamos primero conmutatividad al producto exterior y luego al producto interior:

$$
\begin{aligned}
(ab)c
&=c(ab) &&\text{(conmutatividad exterior: los factores son $ab$ y $c$)}\\
&=c(ba) &&\text{(conmutatividad interior $ab=ba$; buena definición de $\cdot$ exterior).}
\end{aligned}
$$

La segunda igualdad tiene dos niveles: el producto interior ha sido transformado mediante un axioma, y el producto exterior conserva su valor por sustitución de factores iguales. **No se ha empleado asociatividad**, pues se conserva la agrupación de cada producto de dos factores.

**Control final.** Las ocho demostraciones establecen sus conclusiones a partir de los axiomas correspondientes, de propiedades definitorias y de la sustitución de iguales. Se han explicitado los pasos de buena definición precisamente allí donde una igualdad interior forma parte de una operación mayor.

#### Ejercicios para consolidar la segunda cátedra — cátedra 1.2

Los ejercicios siguientes son **elaboración editorial** a partir de las técnicas y las tareas planteadas en la clase. Se incluyen soluciones en la sección siguiente; puede intentarse primero cada prueba sin consultarlas.

1. Sean $e_1,e_2$ neutros aditivos. Demostrar, indicando cada propiedad utilizada, que $e_1=e_2$.
2. Demostrar la unicidad del neutro multiplicativo y precisar el lugar donde se utiliza conmutatividad.
3. Dados $a\in\mathbb R$, sean $p,q$ dos opuestos de $a$. Probar $p=q$ sin presuponer el resultado.
4. Dados $a\ne0$, sean $r,s$ recíprocos de $a$. Probar $r=s$.
5. Deducir $-0=0$, $-(-a)=a$ y $-(a+b)=(-a)+(-b)$.
6. Demostrar que $a0=0$ e identificar el paso distributivo; luego explicar por qué $0$ carece de recíproco.
7. Resolver $a+x=b$ y demostrar tanto la existencia de solución como la unicidad.
8. Para $a\ne0$, resolver $ax=b$ y demostrar la unicidad. Explicar la restricción sobre $a$.
9. Demostrar $(-a)b=-(ab)$, $a(-b)=-(ab)$ y $(-a)(-b)=ab$.
10. A partir de los axiomas, demostrar $(a+b)^2=a^2+2ab+b^2$ señalando el papel de distributividad y asociatividad.
11. Analizar la validez lógica de la prueba «sean $x,y$ soluciones; supongamos $x=y$; concluimos $x=y$» y escribir el esquema legítimo de una prueba de unicidad.
12. **Desafío:** generalizar la unicidad del neutro bilateral a una operación asociativa potencialmente no conmutativa.

#### Solucionario desarrollado de la Cátedra 1.2 (ejercicios 1–12) — cátedra 1.2

> **Nota editorial.** Los doce ejercicios anteriores son elaboración de estudio. Algunos recogen **tareas efectivamente propuestas por el docente**: unicidad de neutros y recíprocos, ecuaciones con solución única, opuesto de una suma y producto con un factor opuesto. Otros consolidan sus técnicas. Cada prueba es autónoma y señala las hipótesis utilizadas. En las demostraciones de la primera semana se mantienen los paréntesis relevantes.

#### Ejercicio 1. Unicidad del neutro aditivo
Sean $e_1,e_2$ neutros aditivos: para cada $x\in\mathbb R$, $x+e_1=x$ y $x+e_2=x$. En particular, con $x=e_2$ en la primera identidad y $x=e_1$ en la segunda,

$$e_2+e_1=e_2,\qquad e_1+e_2=e_1.$$

Por lo tanto,

$$
\begin{aligned}
e_1&=e_1+e_2 &&\text{(neutro $e_2$)}\\
&=e_2+e_1 &&\text{(conmutatividad)}\\
&=e_2 &&\text{(neutro $e_1$).}
\end{aligned}
$$

Así $e_1=e_2$. **Referencia de la clase:** [03:36–14:29](https://www.youtube.com/watch?v=Tl5Hf5d4U2Y&t=216s). Se obtiene unicidad; la existencia estaba garantizada por el axioma 4.

#### Ejercicio 2. Unicidad del neutro multiplicativo
Sean $u_1,u_2$ neutros multiplicativos; es decir, $xu_i=x$ para todo real $x$ y $i\in\{1,2\}$. Al aplicar estas identidades a los otros neutros, obtenemos

$$u_1u_2=u_1,\qquad u_2u_1=u_2.$$

La conmutatividad multiplicativa permite escribir

$$
\begin{aligned}
u_1&=u_1u_2 &&\text{(neutro $u_2$)}\\
&=u_2u_1 &&\text{(conmutatividad del producto)}\\
&=u_2 &&\text{(neutro $u_1$).}
\end{aligned}
$$

Ambos candidatos coinciden. El neutro multiplicativo único se denota $1$. **Nota de precisión:** si un neutro está definido desde el comienzo como *bilateral*, la unicidad puede demostrarse directamente como $u_1=u_1u_2=u_2$; la prueba anterior reproduce la convención de neutro derecho seguida en esta cátedra. **Tarea del profesor:** [16:00–17:38](https://www.youtube.com/watch?v=Tl5Hf5d4U2Y&t=960s).

#### Ejercicio 3. Unicidad del opuesto de un real
Fijemos $a\in\mathbb R$ y sean $p,q$ dos opuestos suyos. Son **datos** $a+p=0$ y $a+q=0$; queremos demostrar $p=q$.

$$
\begin{aligned}
p&=p+0 &&\text{(neutro aditivo)}\\
&=p+(a+q) &&\text{(dato $a+q=0$ y buena definición de la suma)}\\
&=(p+a)+q &&\text{(asociatividad)}\\
&=(a+p)+q &&\text{(conmutatividad interior; buena definición exterior)}\\
&=0+q &&\text{(dato $a+p=0$ y buena definición de la suma)}\\
&=q+0 &&\text{(conmutatividad)}\\
&=q &&\text{(neutro).}
\end{aligned}
$$

La igualdad buscada se obtiene al final de una cadena fundada exclusivamente en hipótesis y axiomas. Por ello el opuesto recibe la notación $-a$. **Clase:** [19:51–31:48](https://www.youtube.com/watch?v=Tl5Hf5d4U2Y&t=1191s).

#### Ejercicio 4. Unicidad del recíproco de un real distinto de cero
Sea $a\neq0$. Por el axioma 5 existen recíprocos; tomemos dos, $r,s$, de manera que $ar=1$ y $as=1$. La demostración compara a los candidatos:

$$
\begin{aligned}
r&=r\cdot1 &&\text{(neutro multiplicativo)}\\
&=r(as) &&\text{(dato $as=1$; buena definición del producto)}\\
&=(ra)s &&\text{(asociatividad)}\\
&=(ar)s &&\text{(conmutatividad interior; buena definición exterior)}\\
&=1s &&\text{(dato $ar=1$; buena definición del producto)}\\
&=s1 &&\text{(conmutatividad)}\\
&=s &&\text{(neutro multiplicativo).}
\end{aligned}
$$

En consecuencia $r=s$, y el único recíproco se denota $a^{-1}$. La hipótesis $a\neq0$ asegura su **existencia** mediante el axioma correspondiente. **Tarea del profesor:** [51:45–52:44](https://www.youtube.com/watch?v=Tl5Hf5d4U2Y&t=3105s).

#### Ejercicio 5. Tres identidades de opuestos
**(a) El opuesto de cero.** Como $0+0=0$, el número $0$ satisface la caracterización del opuesto de $0$. Por unicidad, $\boxed{-0=0}$.

**(b) Opuesto del opuesto.** Para cada $a$,

$$(-a)+a=a+(-a)=0,$$

por conmutatividad y definición de opuesto. Por lo tanto $a$ es el opuesto de $-a$ y, en virtud de la unicidad, $\boxed{-(-a)=a}$.

**(c) Opuesto de una suma.** Buscamos comprobar que $(-a)+(-b)$, sumado a $a+b$, produce el neutro:

$$
\begin{aligned}
(a+b)+\bigl((-a)+(-b)\bigr)
&=a+\bigl(b+((-a)+(-b))\bigr) &&\text{(asociatividad)}\\
&=a+\bigl((b+(-a))+(-b)\bigr) &&\text{(asociatividad interior)}\\
&=a+\bigl(((-a)+b)+(-b)\bigr) &&\text{(conmutatividad interior; buena definición)}\\
&=a+\bigl((-a)+(b+(-b))\bigr) &&\text{(asociatividad interior)}\\
&=a+\bigl((-a)+0\bigr) &&\text{(opuesto de $b$; buena definición)}\\
&=a+(-a) &&\text{(neutro; buena definición)}\\
&=0 &&\text{(opuesto de $a$).}
\end{aligned}
$$

Por el criterio de reconocimiento y unicidad del opuesto, $\boxed{-(a+b)=(-a)+(-b)}$. **Clase:** [81:31–89:55](https://www.youtube.com/watch?v=Tl5Hf5d4U2Y&t=4891s).

#### Ejercicio 6. Tabla del cero y ausencia de recíproco del cero
**Primera parte.** Sea $a\in\mathbb R$ y escribamos $z=a0$. Como $0+0=0$, la distributividad permite concluir

$$z=a0=a(0+0)=a0+a0=z+z.$$

Sumemos el opuesto $-z$ a ambos lados. Mediante buena definición, asociatividad y neutro:

$$
\begin{aligned}
0&=z+(-z) &&\text{(definición de opuesto)}\\
&=(z+z)+(-z) &&\text{(sustitución de $z=z+z$)}\\
&=z+(z+(-z)) &&\text{(asociatividad)}\\
&=z+0 &&\text{(opuesto)}\\
&=z &&\text{(neutro).}
\end{aligned}
$$

Por consiguiente, $\boxed{a0=0}$. El **paso esencial** que relaciona suma y producto es $a(0+0)=a0+a0$, precisamente la distributividad.

**Segunda parte.** Si existiera $r$ con $0r=1$, por conmutatividad y la tabla del cero tendríamos $0r=r0=0$. Se seguiría $1=0$, mientras que el axioma 4 establece $0\neq1$. Por tanto el cero carece de recíproco multiplicativo. **Clase:** [59:54–76:45](https://www.youtube.com/watch?v=Tl5Hf5d4U2Y&t=3594s).

#### Ejercicio 7. Resolver $a+x=b$ y demostrar unicidad
Sean $a,b\in\mathbb R$ conocidos. La **existencia** se demuestra proponiendo $x=b+(-a)$ y verificando:

$$
\begin{aligned}
a+\bigl(b+(-a)\bigr)
&=a+\bigl((-a)+b\bigr) &&\text{(conmutatividad interior; buena definición)}\\
&=\bigl(a+(-a)\bigr)+b &&\text{(asociatividad)}\\
&=0+b &&\text{(opuesto; buena definición)}\\
&=b+0 &&\text{(conmutatividad)}\\
&=b &&\text{(neutro).}
\end{aligned}
$$

Para la **unicidad**, sean $x_1,x_2$ soluciones: $a+x_1=b=a+x_2$. Partimos de $x_1$:

$$
\begin{aligned}
x_1&=0+x_1 &&\text{(neutro y conmutatividad)}\\
&=\bigl((-a)+a\bigr)+x_1 &&\text{(opuesto)}\\
&=(-a)+(a+x_1) &&\text{(asociatividad)}\\
&=(-a)+(a+x_2) &&\text{(igualdad de los datos; buena definición)}\\
&=\bigl((-a)+a\bigr)+x_2 &&\text{(asociatividad)}\\
&=0+x_2 &&\text{(opuesto)}\\
&=x_2 &&\text{(neutro y conmutatividad).}
\end{aligned}
$$

La solución única es $\boxed{x=b-a:=b+(-a)}$. Este resultado justifica la **cancelación aditiva**. **Tarea del profesor:** [77:34–80:56](https://www.youtube.com/watch?v=Tl5Hf5d4U2Y&t=4654s).

#### Ejercicio 8. Resolver $ax=b$ y analizar el caso $a=0$
Con $a\neq0$, el axioma 5 proporciona $a^{-1}$. La solución candidata $x=a^{-1}b$ cumple:

$$
\begin{aligned}
a(a^{-1}b)
&=(aa^{-1})b &&\text{(asociatividad)}\\
&=1b &&\text{(definición del recíproco)}\\
&=b1 &&\text{(conmutatividad)}\\
&=b &&\text{(neutro).}
\end{aligned}
$$

Si $ax_1=b=ax_2$, la buena definición del producto y la asociatividad permiten escribir

$$
\begin{aligned}
x_1&=1x_1=(a^{-1}a)x_1=a^{-1}(ax_1)\\
&=a^{-1}(ax_2)=(a^{-1}a)x_2=1x_2=x_2.
\end{aligned}
$$

Así existe exactamente una solución, $\boxed{x=a^{-1}b=b/a}$.

Si $a=0$, la tabla del cero da $0x=0$ para cualquier real $x$. De aquí se deduce la **clasificación completa**: cuando $b=0$, todo real es solución; cuando $b\neq0$, la ecuación carece de soluciones. El requisito $a\neq0$ identifica precisamente el caso con solución única para todo $b$.

#### Ejercicio 9. Signos y productos
**Primera igualdad.** La distributividad y el opuesto de $b$ dan

$$ab+a(-b)=a(b+(-b))=a0=0.$$

Luego $a(-b)$ es el opuesto de $ab$, por lo que $\boxed{a(-b)=-(ab)}$.

**Segunda igualdad.** Por conmutatividad,

$$(-a)b=b(-a)=-(ba)=-(ab).$$

El paso central aplica la identidad anterior con $a$ y $b$ intercambiados; la última igualdad usa $ba=ab$ y la unicidad de opuestos. Así, $\boxed{(-a)b=-(ab)}$.

**Tercera igualdad.** Sustituimos $a$ por $-a$ en la primera identidad:

$$(-a)(-b)=-\bigl((-a)b\bigr)=-\bigl(-(ab)\bigr)=ab,$$

utilizando la segunda identidad y el resultado $-(-u)=u$. Por tanto $\boxed{(-a)(-b)=ab}$. **Tarea del profesor:** [90:14–91:15](https://www.youtube.com/watch?v=Tl5Hf5d4U2Y&t=5414s).

#### Ejercicio 10. Cuadrado de un binomio
Por definición, $(a+b)^2=(a+b)(a+b)$. Aplicamos distributividad **dos veces**:

$$
\begin{aligned}
(a+b)(a+b)
&=((a+b)a)+((a+b)b) &&\text{(distributividad derecha)}\\
&=(aa+ba)+(ab+bb) &&\text{(distributividad derecha en cada sumando)}\\
&=(aa+ab)+(ab+bb) &&\text{(conmutatividad $ba=ab$; buena definición)}.
\end{aligned}
$$

Por asociatividad de la suma, esa última expresión puede agruparse como $aa+((ab+ab)+bb)$. Introducimos las notaciones usuales

$$a^2:=aa,\qquad b^2:=bb,\qquad 2ab:=ab+ab.$$

Con estas convenciones, la identidad es

$$\boxed{(a+b)^2=a^2+2ab+b^2}.$$

En una escritura completamente estricta, la agrupación queda fijada por los paréntesis anteriores; la convención de omitirlos se apoya en la asociatividad. **Referencia final de la clase:** [1:32:49–1:34:19](https://www.youtube.com/watch?v=Tl5Hf5d4U2Y&t=5569s).

#### Ejercicio 11. Diagnóstico de una demostración circular
Sea $P$ la afirmación «$x=y$». El argumento «supongamos $x=y$; por tanto $x=y$» demuestra únicamente $P\Rightarrow P$, proposición válida por reflexividad de la implicación. La validez de esa implicación es compatible con que $P$ sea verdadera o falsa; **por ello no establece la igualdad buscada**.

Un esquema legítimo para un problema de unicidad es: (i) elegir candidatos arbitrarios $x$ e $y$ que satisfacen **las mismas condiciones definitorias**; (ii) escribir esas condiciones como hipótesis; (iii) usar axiomas y resultados previamente demostrados para formar una cadena de igualdades; (iv) obtener $x=y$ **como conclusión**. El ejercicio 7 proporciona un modelo completo para dos soluciones de $a+x=b$.

#### Ejercicio 12. Unicidad de un neutro bilateral sin conmutatividad
Sea $S$ un conjunto con una operación binaria $\circ:S\times S\to S$. Un **neutro bilateral** $e$ satisface $e\circ x=x$ y $x\circ e=x$ para todo $x\in S$.

Sean $e,f$ dos elementos con esta propiedad. Por el hecho de que $f$ actúa como neutro derecho de $e$, obtenemos $e\circ f=e$. Por el hecho de que $e$ actúa como neutro izquierdo de $f$, obtenemos $e\circ f=f$. En consecuencia,

$$\boxed{e=e\circ f=f}.$$

La demostración utiliza las dos identidades laterales y **funciona para toda operación binaria**; incluso la asociatividad resulta innecesaria.

**Precisión estructural.** La unicidad cambia cuando solo se exige una identidad unilateral. En $S=\{0,1\}$ con operación $x\circ y:=x$, cada $e\in S$ satisface $x\circ e=x$; por tanto existen dos neutros **derechos**. En cambio, para los neutros **bilaterales** la prueba precedente siempre garantiza unicidad. La distinción explica exactamente qué hipótesis se emplean en el razonamiento.

#### Correspondencia entre tareas de la grabación y soluciones
| Tarea enunciada o dejada abierta en clase | Solución desarrollada | Momento del video |
|---|---|---|
| Unicidad del neutro multiplicativo | Ejercicio 2 | [16:00](https://www.youtube.com/watch?v=Tl5Hf5d4U2Y&t=960s) |
| Unicidad del recíproco | Ejercicio 4 | [51:45](https://www.youtube.com/watch?v=Tl5Hf5d4U2Y&t=3105s) |
| Resolver $a+x=b$ y probar unicidad | Ejercicio 7 | [77:34](https://www.youtube.com/watch?v=Tl5Hf5d4U2Y&t=4654s) |
| Resolver $ax=b$, tratamiento análogo indicado en apunte | Ejercicio 8 | [80:56](https://www.youtube.com/watch?v=Tl5Hf5d4U2Y&t=4856s) |
| Cerrar la prueba del opuesto de una suma | Ejercicio 5(c) | [85:57](https://www.youtube.com/watch?v=Tl5Hf5d4U2Y&t=5157s) |
| Producto con un factor opuesto | Ejercicio 9 | [90:14](https://www.youtube.com/watch?v=Tl5Hf5d4U2Y&t=5414s) |

Los ejercicios adicionales 1, 3, 6, 10, 11 y 12 constituyen práctica de consolidación elaborada para estas notas. En particular, la prueba de $a0=0$ corresponde al desarrollo realizado por el docente, mientras que su presentación como ejercicio sirve para reconstruirla autónomamente.

---

## Orden, desigualdades e inecuaciones

El orden añade a la estructura de cuerpo una noción precisa de positividad. A partir de ella se desarrollan las reglas para comparar, transformar y resolver desigualdades, incluidas las inecuaciones racionales.

**Grabaciones de referencia:** [grabación de la cátedra 2.1](https://www.youtube.com/watch?v=o5TbpGI9KsU), [grabación de la cátedra 2.2](https://www.youtube.com/watch?v=-NZgH0yH-NI).

*Procedencia de este tramo: cátedra 2.1.*

### De un cuerpo a un cuerpo ordenado

#### Qué se conserva de la primera semana
**En la cátedra (06:40–08:14).** La teoría se construye de manera acumulativa. Los primeros cinco axiomas garantizan que $(\mathbb R,+,\cdot)$ es un **cuerpo**: las operaciones son asociativas y conmutativas, el producto distribuye sobre la suma, hay neutros $0$ y $1$ con $0\ne1$, cada real tiene opuesto y cada real distinto de cero posee recíproco. La resta y la división se introducen como operaciones derivadas:

$$
a-b=a+(-b),\qquad \frac ab=a\,b^{-1}\quad(b\ne0).
$$

En particular, se puede utilizar la cancelación, el opuesto de una suma, las reglas de los signos y la identidad $a\cdot0=0$, demostradas o estudiadas durante la primera semana. La precisión axiomática sigue operando aunque, desde ahora, los cálculos podrán abreviarse utilizando propiedades ya establecidas.

#### El conjunto de reales positivos
**En la cátedra (08:20–10:28).** Se distingue un subconjunto

$$
\mathbb R_+^*\subseteq\mathbb R,
$$

cuyos miembros se denominan **reales estrictamente positivos**. El signo $+$ recuerda la positividad y el asterisco indica que se excluye el cero, conforme al uso adoptado por el profesor. Conviene conservar la estrella porque la notación $\mathbb R_+$ se utiliza de manera diferente entre autores; aquí siempre escribiremos $\mathbb R_+^*$ para la positividad estricta.

Este conjunto se caracteriza axiomáticamente por dos propiedades. El desarrollo parte del lenguaje de pertenencia y de las operaciones del cuerpo; la relación $<$ será introducida más adelante mediante una definición.

#### Axioma 6: tricotomía
**En la cátedra (10:28–17:01).** Para cada $x\in\mathbb R$ ocurre **exactamente una** de las tres posibilidades

$$
\boxed{\quad x\in\mathbb R_+^*,\qquad -x\in\mathbb R_+^*,\qquad x=0.\quad}
$$

En la primera posibilidad $x$ recibe el nombre **positivo**. En la segunda, $x$ recibe el nombre **negativo**, porque su opuesto es positivo. La tercera corresponde al cero. La expresión «una y solo una» incluye dos propiedades: cada real pertenece a una de las tres clases y las clases son mutuamente excluyentes. En especial, $0\notin\mathbb R_+^*$ y la positividad de $x$ excluye la positividad de $-x$.

La tricotomía expresa una estructura de signos. Todavía hace falta una conexión entre esa estructura y las dos operaciones del cuerpo.

**Ejemplo comentado por el profesor (13:50–15:24).** El cuerpo de dos elementos $\mathbb F_2=\{0,1\}$ con $1+1=0$ posee $-1=1$. Si sus elementos satisficieran este axioma, como $1\ne0$, la alternativa $1\in\mathbb R_+^*$ implicaría simultáneamente $-1\in\mathbb R_+^*$; la alternativa opuesta produciría el mismo conflicto. En consecuencia, ese cuerpo admite las operaciones de cuerpo y resulta incompatible con estos axiomas de orden. Esto enseña que **la estructura de cuerpo ordenado aporta propiedades adicionales**.

#### Axioma 7: clausura de los positivos
**En la cátedra (17:01–26:48).** Para cualesquiera $u,v\in\mathbb R_+^*$ se tiene

$$
\boxed{\quad u+v\in\mathbb R_+^*,\qquad uv\in\mathbb R_+^*.\quad}
$$

El conjunto es **cerrado por suma y producto**: al aplicar cualquiera de estas operaciones a dos miembros, el resultado vuelve a pertenecer al mismo conjunto. Esta clausura será el mecanismo que permite construir desigualdades nuevas a partir de desigualdades conocidas.

**Observación conceptual.** Los axiomas 6 y 7 se formulan conjuntamente con los cinco axiomas de cuerpo. Juntos expresan que la estructura $(\mathbb R,+,\cdot,\mathbb R_+^*)$ es un **cuerpo ordenado**. La propiedad de completitud —central en el desarrollo posterior del cálculo— pertenece a una etapa ulterior del curso.

### Definir las relaciones de orden

#### La desigualdad como diferencia positiva
**En la cátedra (26:50–32:28).** Una definición introduce un nombre para una condición expresada con recursos ya disponibles. La expresión $x<y$ designa el hecho de que la diferencia $y-x$ sea positiva. Así, para $x,y\in\mathbb R$:

$$
\begin{aligned}
x<y&\iff y-x\in\mathbb R_+^*,\\
x>y&\iff x-y\in\mathbb R_+^*,\\
x\le y&\iff(x<y)\ \lor\ (x=y),\\
x\ge y&\iff(x>y)\ \lor\ (x=y).
\end{aligned}
$$

Las dos primeras relaciones son **estrictas**. Las otras dos incluyen el caso de igualdad. Cuando $x<y$, la diferencia que examinamos se construye restando el término izquierdo del término derecho. El orden de esa resta constituye una parte fundamental de la definición y determina la dirección de la desigualdad.

> **Regla de lectura.** $x<y$ se estudia mediante $y-x\in\mathbb R_+^*$; $x>y$ mediante $x-y\in\mathbb R_+^*$. Al demostrar desigualdades, la estrategia habitual consiste en probar la positividad de la diferencia correspondiente.

#### Los signos en términos del cero
**En la cátedra (32:37–37:40).** La definición produce inmediatamente

$$
\boxed{\quad x>0\iff x\in\mathbb R_+^*,\qquad
x<0\iff -x\in\mathbb R_+^*.\quad}
$$

**Demostración.** $x>0$ equivale por definición a $x-0\in\mathbb R_+^*$; puesto que $x-0=x$, se obtiene la primera equivalencia. Del mismo modo, $x<0$ equivale a $0-x\in\mathbb R_+^*$ y $0-x=-x$. La tricotomía puede por tanto formularse como la afirmación de que para todo real $x$ se cumple exactamente una de $x>0$, $x=0$, $x<0$.

#### Tricotomía comparativa
**En la cátedra (38:18–41:56).** Dados $x,y\in\mathbb R$, exactamente una de las relaciones

$$
\boxed{\quad x<y,\qquad x=y,\qquad x>y\quad}
$$

es verdadera.

**Demostración.** La resta $d=y-x$ es un real. Aplíquese el axioma 6 a $d$. Si $d\in\mathbb R_+^*$, por definición $x<y$. Si $-d=x-y\in\mathbb R_+^*$, entonces $x>y$; la igualdad $-d=x-y$ deriva de las propiedades de los opuestos. Si $d=0$, se obtiene $y=x$. La exclusividad de las tres relaciones se hereda de la tricotomía aplicada a $d$. $\square$

### La relación de orden y sus primeras propiedades

#### Transitividad estricta
**En la cátedra (42:00–44:14).** Si $x<y$ y $y<z$, entonces $x<z$.

**Demostración detallada.** Las hipótesis equivalen a

$$
y-x\in\mathbb R_+^*,\qquad z-y\in\mathbb R_+^*.
$$

Por el axioma 7, su suma pertenece a $\mathbb R_+^*$. Puesto que

$$
(y-x)+(z-y)=z-x,
$$

tenemos $z-x\in\mathbb R_+^*$ y, por definición, $x<z$. $\square$

Esta prueba muestra la función precisa del axioma 7: **la suma de dos diferencias positivas vuelve a ser positiva**. La cancelación del término intermedio convierte esa suma en la diferencia entre los extremos.

#### Antisimetría de $\le$ — demostración completada
**Tarea indicada en la cátedra (44:15–44:40).** Mostrar que

$$
(x\le y\ \land\ y\le x)\ \Longrightarrow\ x=y.
$$

**Solución.** Supongamos $x\le y$ y $y\le x$. Si $x\ne y$, la tricotomía establece que $x<y$ o $y<x$. La primera opción contradice $y\le x$, que exige $y<x$ o $y=x$; la segunda contradice $x\le y$. De modo que necesariamente $x=y$. $\square$

**Aclaración lógica.** La antisimetría compara dos desigualdades en sentidos opuestos y concluye igualdad. Es una propiedad característica de una relación de orden.

#### Transitividad de $\le$ — demostración completada
**Tarea indicada en la cátedra (44:40–44:59).** Probar que

$$
(x\le y\ \land\ y\le z)\Longrightarrow x\le z.
$$

**Solución por casos.** Si $x=y$, la conclusión coincide con $y\le z$. Si $y=z$, coincide con $x\le y$. En el caso restante, las hipótesis implican $x<y$ y $y<z$, de donde $x<z$ por transitividad estricta. En cada posibilidad resulta $x\le z$. $\square$

#### Reflexividad y totalidad — ampliación
Para todo $x$, $x\le x$ se cumple porque $x=x$. Además, para cada par $x,y$, la tricotomía comparativa implica $x\le y$ o $y\le x$. Con reflexividad, antisimetría, transitividad y totalidad queda establecida la estructura de **orden total** de $\le$ en $\mathbb R$.

### Cómo demostrar una implicación

**En la cátedra (45:35–48:37).** Una proposición $P\Rightarrow Q$ afirma que cada situación donde $P$ es verdadera constituye una situación donde $Q$ también es verdadera. El procedimiento habitual de prueba consiste en asumir $P$ y deducir $Q$. Es importante distinguir **datos** (hipótesis, axiomas y propiedades ya demostradas) de **objetivo** (la conclusión). Si se parte del resultado que se pretende probar, aparece un razonamiento circular.

En una demostración de desigualdades, el esquema es particularmente eficaz:

1. Traducir las hipótesis $x<y$ en positividad de diferencias.
2. Traducir la conclusión buscada en otra diferencia positiva.
3. Transformar la diferencia objetivo mediante operaciones de cuerpo y el axioma 7.
4. Reconocer expresiones positivas gracias a los datos.

Esta arquitectura explica las demostraciones siguientes y permite controlar el sentido de cada signo.

### Transformaciones de desigualdades

#### Sumar la misma cantidad a ambos lados
**En la cátedra (48:38–52:29).** Para cualquier $a\in\mathbb R$,

$$
\boxed{\quad x<y\Longrightarrow x+a<y+a.\quad}
$$

**Demostración.** La hipótesis dice que $y-x\in\mathbb R_+^*$. A su vez,

$$
(y+a)-(x+a)=y-x.
$$

Por igualdad de estas diferencias, la primera pertenece al conjunto positivo; por definición $x+a<y+a$. $\square$

La misma transformación vale para $\le$, $>$ y $\ge$. Además es **reversible**: de $x+a<y+a$ se recupera $x<y$ al sumar $-a$ en ambos miembros. Por ello

$$
x<y\quad\iff\quad x+a<y+a.
$$

#### Multiplicar por una constante positiva
**En la cátedra (56:50–58:14).** Si $a>0$, entonces

$$
\boxed{\quad x<y\Longrightarrow ax<ay.\quad}
$$

**Demostración completada** (el profesor escoge desarrollar el caso negativo). Como $y-x\in\mathbb R_+^*$ y $a\in\mathbb R_+^*$, por clausura multiplicativa

$$
a(y-x)=ay-ax\in\mathbb R_+^*.
$$

Por tanto, $ax<ay$. $\square$

#### Multiplicar por una constante negativa
**En la cátedra (58:14–62:28).** Si $a<0$, entonces

$$
\boxed{\quad x<y\Longrightarrow ax>ay.\quad}
$$

**Demostración del profesor, reconstruida.** De $x<y$ se obtiene $y-x\in\mathbb R_+^*$. De $a<0$, $-a\in\mathbb R_+^*$. Como ambos son positivos,

$$
(-a)(y-x)\in\mathbb R_+^*.
$$

Por las reglas de signos,

$$
(-a)(y-x)=a(x-y)=ax-ay.
$$

Luego $ax-ay\in\mathbb R_+^*$, lo que expresa $ax>ay$. $\square$

**Caso de frontera.** Multiplicar por $a=0$ da $0=0$ en ambos lados. Por eso una desigualdad estricta se convierte en igualdad cuando ambos lados se multiplican por cero.

#### Sumar dos desigualdades estrictas
**En la cátedra (68:08–70:45).** Si $x<y$ y $u<v$, entonces

$$
\boxed{\quad x+u<y+v.\quad}
$$

**Demostración.** Por las hipótesis, $y-x>0$ y $v-u>0$. Su suma es positiva y vale

$$
(y-x)+(v-u)=(y+v)-(x+u).
$$

Por definición, $x+u<y+v$. $\square$

La propiedad utiliza **dos desigualdades distintas**. Su demostración vuelve a depender de la clausura aditiva de $\mathbb R_+^*$.

#### Multiplicar desigualdades entre positivos: «ni quita ni pone»
**En la cátedra (70:47–79:26).** Supóngase

$$
0<x<y,\qquad 0<u<v.
$$

Entonces

$$
\boxed{\quad xu<yv.\quad}
$$

El obstáculo pedagógico es que en $yv-xu$ aparecen factores diferentes. El profesor introduce una maniobra conocida en la facultad como **«ni quita ni pone»**: insertar el mismo término con signos opuestos, de modo que su contribución neta sea cero. Elegimos $xv$ porque facilita agrupar por los factores pertinentes:

$$
\begin{aligned}
yv-xu
&=yv-xv+xv-xu\\
&=(y-x)v+x(v-u).
\end{aligned}
$$

Los cuatro factores $y-x$, $v$, $x$ y $v-u$ son positivos. Los productos $(y-x)v$ y $x(v-u)$ son positivos por el axioma 7; su suma también lo es. En consecuencia, $yv-xu>0$ y, por definición, $xu<yv$. $\square$

**Por qué funciona.** El término introducido $-xv+xv=0$ conserva exactamente el valor de la expresión original. Lo decisivo es que permite una **descomposición en sumandos cuyo signo conocemos**. La identidad constituye una forma elemental de construir una prueba a partir de la expresión objetivo.

#### Qué transformaciones son reversibles
Sumar una cantidad fija a ambos lados es una equivalencia. Multiplicar por $a\ne0$ también lo es si se conoce su signo: la transformación inversa consiste en multiplicar por $a^{-1}$, que conserva el signo de $a$. Estas equivalencias serán decisivas al resolver inecuaciones, pues permiten describir **exactamente el mismo conjunto de soluciones** en formas algebraicas diferentes.

### Otras consecuencias de los axiomas de orden

En esta parte, el profesor presenta varias propiedades brevemente y pide estudiarlas en el apunte. Se desarrollan aquí las demostraciones, con el objetivo de completar el trabajo matemático correspondiente a la clase.

#### Todo cuadrado es no negativo — demostración completada
**Propuesta de la cátedra (79:48–80:10).** Para todo $x\in\mathbb R$,

$$
\boxed{\quad x^2\ge0.\quad}
$$

**Demostración.** Se distinguen los tres casos de la tricotomía. Si $x=0$, entonces $x^2=0$. Si $x>0$, la clausura multiplicativa da $x^2=x\cdot x>0$. Si $x<0$, su opuesto $-x$ es positivo, y por lo tanto

$$
(-x)(-x)>0.
$$

Como $(-x)(-x)=x^2$ por las reglas de signos, también se obtiene $x^2>0$. En todos los casos $x^2\ge0$. Además, si $x\ne0$, el cuadrado es **estrictamente positivo**. $\square$

#### La unidad multiplicativa es positiva — demostración completada
El elemento $1$ cumple $1\ne0$ por los axiomas de cuerpo. Puesto que $1^2=1$ y el cuadrado de todo elemento distinto de cero es positivo,

$$
\boxed{\quad 1>0.\quad}
$$

Este resultado es teoremático: la orientación positiva del número $1$ se deduce de la estructura de cuerpo ordenado.

#### Signos de los productos — demostraciones completadas
**Tareas de la cátedra (80:10–81:22).** Se tienen las siguientes propiedades:

$$
\begin{array}{lll}
a>0,\ b>0&\Longrightarrow&ab>0,\\
a>0,\ b<0&\Longrightarrow&ab<0,\\
a<0,\ b<0&\Longrightarrow&ab>0.
\end{array}
$$

La primera es exactamente la clausura multiplicativa del axioma 7. Para la segunda, $a>0$ y $-b>0$ implican $a(-b)>0$. Como $a(-b)=-(ab)$, la positividad del opuesto determina $ab<0$. Para la tercera, $-a>0$ y $-b>0$ implican $(-a)(-b)>0$; las reglas de signos identifican este producto con $ab$. El caso $a<0$, $b>0$ se deduce por conmutatividad. $\square$

#### El recíproco conserva el signo — demostración completada
**Tarea de la cátedra (81:23–82:12).** Para $x\ne0$,

$$
\boxed{\quad x>0\Longrightarrow x^{-1}>0,
\qquad x<0\Longrightarrow x^{-1}<0.\quad}
$$

**Demostración con la idea sugerida por el profesor.** El inverso $x^{-1}$ es distinto de cero, porque $xx^{-1}=1\ne0$. Por el resultado anterior, $\bigl(x^{-1}\bigr)^2>0$. Además,

$$
\boxed{\quad x^{-1}=\bigl(x^{-1}\bigr)^2x,\quad}
$$

pues el producto de la derecha se reagrupa como $x^{-1}(x^{-1}x)=x^{-1}\cdot1=x^{-1}$. Así, $x^{-1}$ es producto de un factor positivo y el factor $x$. Si $x>0$, el producto es positivo; si $x<0$, es negativo. $\square$

**Otra vía.** Si $x>0$ y $x^{-1}<0$, se tendría $xx^{-1}<0$, en contradicción con $xx^{-1}=1>0$. El caso negativo se trata de forma análoga. La primera prueba reproduce más de cerca el razonamiento de la clase.

#### Producto nulo e incompatibilidad con inversos — ampliación
Si $ab=0$ y $a\ne0$, se puede multiplicar por $a^{-1}$:

$$
b=(a^{-1}a)b=a^{-1}(ab)=a^{-1}\cdot0=0.
$$

Se obtiene la **propiedad del producto nulo**: $ab=0$ implica $a=0$ o $b=0$. Esta propiedad es útil para resolver ecuaciones y, más adelante, inecuaciones factorizadas. La demostración es una consecuencia de los axiomas de cuerpo, y se incorpora aquí como ampliación; el profesor no la desarrolla en este tramo de la grabación.

### Recta real e intervalos

**En la cátedra (82:42–84:48).** El profesor presenta la ordenación geométrica habitual de los reales: los mayores a la derecha, los menores a la izquierda. La recta numérica expresa visualmente las relaciones construidas de manera axiomática.

Para $a<b$, las notaciones principales son:

| Nombre | Notación | Condición caracterizadora |
|---|---|---|
| Intervalo abierto | $(a,b)$ | $\{x\in\mathbb R:a<x<b\}$ |
| Intervalo cerrado | $[a,b]$ | $\{x\in\mathbb R:a\le x\le b\}$ |
| Semiabierto a la izquierda | $(a,b]$ | $\{x\in\mathbb R:a<x\le b\}$ |
| Semiabierto a la derecha | $[a,b)$ | $\{x\in\mathbb R:a\le x<b\}$ |
| Semirrecta abierta derecha | $(a,+\infty)$ | $\{x\in\mathbb R:x>a\}$ |
| Semirrecta cerrada derecha | $[a,+\infty)$ | $\{x\in\mathbb R:x\ge a\}$ |
| Semirrecta abierta izquierda | $(-\infty,b)$ | $\{x\in\mathbb R:x<b\}$ |
| Semirrecta cerrada izquierda | $(-\infty,b]$ | $\{x\in\mathbb R:x\le b\}$ |

Se escribe asimismo $\mathbb R=(-\infty,+\infty)$. Los símbolos $\pm\infty$ señalan la prolongación ilimitada de los intervalos; el extremo señalado por infinito siempre se escribe con paréntesis redondo. El profesor recomienda la notación estándar de intervalos para facilitar la escritura matemática digital.

**Observación de rigor.** Aquí se estudian intervalos como conjuntos descritos mediante desigualdades. Las propiedades topológicas de apertura y cerradura requieren definiciones adicionales que aparecerán más adelante en una teoría de límites y espacios métricos. En esta lección, las expresiones «abierto» y «cerrado» se refieren a la inclusión de sus extremos finitos.

### Resolver todas las inecuaciones de primer grado

#### Problema general y punto de corte
**En la cátedra (85:15–85:59).** Sean $a,b\in\mathbb R$ datos, con $a\ne0$. Se busca el conjunto de soluciones de cada una de las cuatro inecuaciones

$$
ax+b<0,\qquad ax+b\le0,\qquad ax+b>0,\qquad ax+b\ge0.
$$

El número

$$
\boxed{\quad c=-\frac ba\quad}
$$

es el **punto de corte** de la expresión lineal, porque $ac+b=0$. Es el único cero de $x\mapsto ax+b$ cuando $a\ne0$. Divide la recta real en dos intervalos donde la expresión tiene signo constante.

#### Caso $a>0$: desarrollo de la clase
**En la cátedra (86:01–92:58).** El profesor empieza por $ax+b<0$. Sumar $-b$ a ambos lados preserva la desigualdad:

$$
ax+b<0\ \iff\ ax<-b.
$$

El recíproco $a^{-1}$ es positivo por la propiedad demostrada anteriormente, por lo cual multiplicar por él preserva nuevamente el sentido:

$$
ax<-b\ \iff\ x<-ba^{-1}\ \iff\ x<c.
$$

Cada paso es una **equivalencia**: podemos efectuar la transformación inversa y recuperar la inecuación inicial. Por tanto, los conjuntos solución quedan exactamente determinados, para $a>0$, por la siguiente tabla:

| Inecuación | Condición sobre $x$ | Conjunto solución |
|---|---|---|
| $ax+b<0$ | $x<c$ | $(-\infty,c)$ |
| $ax+b\le0$ | $x\le c$ | $(-\infty,c]$ |
| $ax+b>0$ | $x>c$ | $(c,+\infty)$ |
| $ax+b\ge0$ | $x\ge c$ | $[c,+\infty)$ |

**Tabla de signos para $a>0$.**

| Región | $x<c$ | $x=c$ | $x>c$ |
|---|:---:|:---:|:---:|
| Signo de $ax+b$ | $-$ | $0$ | $+$ |

La tabla resume la explicación oral: a la izquierda del punto de corte la expresión es negativa; en el punto de corte vale cero; a la derecha es positiva.

#### Caso $a<0$: tarea resuelta
**Tarea expresamente propuesta (86:01 y 93:00–94:14).** Resolver el caso $a<0$ y justificar la inversión de los signos.

**Solución desarrollada.** Si $ax+b<0$, sumamos $-b$:

$$
ax+b<0\iff ax<-b.
$$

Como $a<0$, su recíproco también es negativo. Al multiplicar por $a^{-1}$, el sentido de la desigualdad se invierte:

$$
ax<-b\iff x>-ba^{-1}=c.
$$

Cada implicación es reversible porque $a\ne0$. Las otras tres variantes se obtienen aplicando las reglas respectivas a $\le,>,\ge$. Así, si $a<0$,

| Inecuación | Condición sobre $x$ | Conjunto solución |
|---|---|---|
| $ax+b<0$ | $x>c$ | $(c,+\infty)$ |
| $ax+b\le0$ | $x\ge c$ | $[c,+\infty)$ |
| $ax+b>0$ | $x<c$ | $(-\infty,c)$ |
| $ax+b\ge0$ | $x\le c$ | $(-\infty,c]$ |

**Tabla de signos para $a<0$.**

| Región | $x<c$ | $x=c$ | $x>c$ |
|---|:---:|:---:|:---:|
| Signo de $ax+b$ | $+$ | $0$ | $-$ |

La pendiente $a$ determina el orden de los signos a ambos lados del único cero $c$; la estructura de ambas tablas procede directamente de los axiomas de orden y del álgebra de cuerpo.

#### Por qué importa la equivalencia lógica
**En la cátedra (87:18–90:13).** Resolver una inecuación consiste en describir **todos y exactamente** los valores de $x$ que satisfacen la condición. Por eso, al transformar expresiones, debemos conservar la equivalencia lógica:

$$
P\iff Q\quad\text{significa}\quad(P\Rightarrow Q)\land(Q\Rightarrow P).
$$

En el caso lineal, sumar una cantidad y multiplicar por una constante distinta de cero son operaciones reversibles. El punto de corte ofrece una lectura geométrica equivalente a la solución algebraica.

#### Ampliación: qué ocurre cuando $a=0$
El docente adopta $a\ne0$ para estudiar inecuaciones propiamente de primer grado. Si $a=0$, la condición se reduce a una proposición sobre $b$:

$$
0\cdot x+b\mathrel{\square}0\iff b\mathrel{\square}0.
$$

En ese caso, el conjunto solución es $\mathbb R$ cuando la proposición sobre $b$ es verdadera, y es $\varnothing$ cuando es falsa. Esta verificación es una **ampliación**, útil para reconocer correctamente expresiones lineales degeneradas.

### Síntesis: hilo lógico de la cátedra

El recorrido matemático de la sesión puede describirse mediante cuatro etapas encadenadas:

1. **Estructura algebraica previa:** $\mathbb R$ es un cuerpo, con suma, producto, opuestos y recíprocos.
2. **Estructura de signos:** los axiomas 6 y 7 seleccionan un conjunto de positivos con tricotomía y clausura.
3. **Relaciones de orden:** las diferencias positivas definen $<$ y $>$, y a partir de ellas se obtienen $\le$ y $\ge$.
4. **Operaciones y problemas:** transitividad, suma y producto de desigualdades, intervalos e inecuaciones lineales.

En todas las demostraciones se repite una misma arquitectura: la conclusión sobre el orden se traduce en una **diferencia positiva**, que después se transforma hasta expresarla como suma o producto de positivos conocidos. La técnica «ni quita ni pone» es una instancia especialmente clara de esta estrategia.

#### Checklist de estudio
- [ ] Puedo enunciar con precisión el axioma de tricotomía y explicar «exactamente una».
- [ ] Puedo enunciar la clausura de $\mathbb R_+^*$ para suma y producto.
- [ ] Puedo convertir $x<y$ en una afirmación de pertenencia: $y-x\in\mathbb R_+^*$.
- [ ] Puedo demostrar transitividad y antisimetría sin usar la conclusión como hipótesis.
- [ ] Sé justificar el efecto de sumar y multiplicar una desigualdad, incluidos los tres signos del multiplicador.
- [ ] Puedo reconstruir $yv-xu=(y-x)v+x(v-u)$ mediante «ni quita ni pone».
- [ ] Puedo probar que todo cuadrado es no negativo y que $1>0$.
- [ ] Puedo resolver las cuatro inecuaciones $ax+b\mathrel{\square}0$ para $a>0$ y $a<0$.
- [ ] Distingo una implicación de una equivalencia al transformar el conjunto de soluciones.

#### Glosario mínimo
**Tricotomía:** organización de cada real en exactamente una de las clases positivo, cero o negativo. **Clausura:** conservación de la pertenencia a un conjunto cuando se aplican ciertas operaciones. **Orden total:** relación reflexiva, antisimétrica, transitiva y comparable para todo par de elementos. **Diferencia positiva:** número $y-x$ que pertenece a $\mathbb R_+^*$ y caracteriza $x<y$. **Inecuación:** condición de desigualdad que se pide satisfacer mediante ciertos valores de una incógnita. **Punto de corte:** cero de la expresión lineal $ax+b$, dado por $-b/a$ cuando $a\ne0$. **Ni quita ni pone:** inserción de un término junto con su opuesto para reescribir una expresión conservando su valor.

#### Fuente y trazabilidad
- San Martín, Jorge, [«IC2021: Cátedra 2.1 (Lunes 22/3/21 14:30)»](https://www.youtube.com/watch?v=o5TbpGI9KsU). Grabación de 2021; transcripción automática revisada para la presente edición.
- **Continuidad:** [Cátedra 1.1](https://www.youtube.com/watch?v=08n7qZ-H7W8) y [Cátedra 1.2](https://www.youtube.com/watch?v=Tl5Hf5d4U2Y), cuyos resultados de cuerpo se emplean como preliminares.
- **Criterio de fidelidad:** los axiomas, la secuencia de temas, las demostraciones trabajadas y las tareas atribuidas al profesor se documentan mediante la grabación. Los ejemplos numéricos, las demostraciones completadas y los ejercicios identificados como «Práctica adicional» corresponden a elaboración editorial para el estudio.

*Procedencia de este tramo: cátedra 2.2.*

### La expresión afín como unidad de análisis

#### Punto de corte y factorización
**En la cátedra (09:02–12:36).** Sea $a\in\mathbb R\setminus\{0\}$ y $b\in\mathbb R$. Para la expresión

$$
L(x)=ax+b
$$

existe un único número $r$ tal que $L(r)=0$, a saber,

$$
\boxed{r=-\frac ba.}
$$

Este es el **punto de corte** de la función afín con el eje horizontal. La identidad decisiva es

$$
L(x)=a\left(x+\frac ba\right)=a(x-r).
$$

La factorización separa dos informaciones: $a$ tiene signo fijo y $x-r$ tiene signo determinado por la posición de $x$ respecto de $r$.

| Posición de $x$ | Signo de $x-r$ | Signo de $L(x)=a(x-r)$ |
|---|---|---|
| $x<r$ | negativo | contrario al signo de $a$ |
| $x=r$ | cero | cero |
| $x>r$ | positivo | igual al signo de $a$ |

**Demostración.** Si $x>r$, entonces $x-r>0$. Por la regla de los signos, $a(x-r)$ tiene el signo de $a$. Si $x<r$, entonces $x-r<0$ y el signo del producto se invierte. En $x=r$ tenemos $x-r=0$, luego $L(r)=0$.

El profesor propone una verificación sencilla: sustituir $x=r+1$. Entonces

$$
L(r+1)=a(r+1)+b=(ar+b)+a=a.
$$

La misma evaluación con $r-t$ y $t>0$ da $L(r-t)=-at$, que tiene el signo contrario al de $a$.

#### Inecuaciones factorizadas y su dominio
**En la cátedra (12:38–14:23).** Se estudian expresiones racionales de la forma

$$
R(x)=\frac{\prod_{i=1}^{n}(a_i x+b_i)}{\prod_{j=1}^{m}(c_j x+d_j)},\qquad
 a_i\ne0,\quad c_j\ne0,
$$

comparadas con cero mediante una de las relaciones $<,\le,>,\ge$. Su **dominio** es

$$
D=\left\{x\in\mathbb R:\prod_{j=1}^{m}(c_jx+d_j)\ne0\right\}.
$$

El dominio permanece fijo durante todas las transformaciones equivalentes. En particular, cuando una fracción se simplifica algebraicamente, se conserva la condición del denominador original. Cada factor lineal aporta un **punto crítico** $-b_i/a_i$ o $-d_j/c_j$. Un punto crítico del numerador puede producir el valor cero; uno del denominador es un punto donde la expresión queda indefinida.

**Precisión editorial.** La forma factorizada es el punto de partida del algoritmo de signos. Un polinomio de grado superior puede requerir trabajo adicional de factorización, y factores cuadráticos sin raíces reales pueden tratarse directamente mediante su signo constante. La cátedra introduce precisamente esta ampliación en su segunda mitad.

### Preparación algebraica del ejemplo de la cátedra

**En la cátedra (14:24–20:58).** El profesor considera la inecuación

$$
\boxed{\frac{x+1}{x}\le\frac{x+1}{x-1}-\frac3x,\qquad x\ne0,\quad x\ne1.}
\tag{E}
$$

Llevar todas las expresiones al miembro izquierdo da

$$
\frac{x+1}{x}-\frac{x+1}{x-1}+\frac3x\le0.
$$

Al reducir a denominador común $x(x-1)$ se obtiene

$$
\begin{aligned}
\frac{x+1}{x}-\frac{x+1}{x-1}+\frac3x
&=\frac{(x+1)(x-1)-x(x+1)+3(x-1)}{x(x-1)}\\
&=\frac{(x^2-1)-(x^2+x)+(3x-3)}{x(x-1)}\\
&=\frac{2x-4}{x(x-1)}.
\end{aligned}
$$

Por consiguiente, la inecuación original es equivalente, **en el dominio $D=\mathbb R\setminus\{0,1\}$**, a

$$
\boxed{\frac{2x-4}{x(x-1)}\le0.}\tag{F}
$$

El numerador se factoriza como $2(x-2)$; el factor constante $2$ es positivo. Los puntos críticos son $0$, $1$ y $2$.

La reducción tiene dos fases conceptualmente distintas: escribir el comparador contra cero y factorizar el numerador y el denominador para reconocer las zonas de signo constante. Las operaciones con fracciones son identidades en el dominio común.

### Algoritmo de los puntos críticos y tabla de signos

#### Las cinco etapas
**En la cátedra (20:58–33:45).** Para resolver $R(x)\,\square\,0$, donde $\square\in\{<,\le,>,\ge\}$:

1. **Calcular** los puntos críticos de cada factor del numerador y del denominador.
2. **Ordenarlos**, conservando una vez cada valor distinto. Si hay $n+m$ factores lineales y $s$ puntos críticos distintos, entonces $s\le n+m$.
3. **Formar los $s+1$ intervalos abiertos** delimitados por esos valores ordenados.
4. **Determinar el signo de $R$ en cada intervalo** a partir de los signos de sus factores y seleccionar los intervalos que satisfacen la desigualdad.
5. **Examinar los puntos críticos individualmente:** en una desigualdad amplia, incorporar cada cero del numerador que pertenezca al dominio; excluir siempre los ceros del denominador.

El profesor subraya que el signo del cociente de factores lineales es constante dentro de cada intervalo abierto. Si $k$ es el número total de factores negativos, **contados con multiplicidad** en numerador y denominador, el signo del cociente es $(-1)^k$, multiplicado por el signo de los coeficientes constantes que se hayan separado. Un $k$ par da signo positivo; un $k$ impar, negativo.

**Justificación.** Cada factor $a_ix+b_i$ es continuo y tiene un único cero. Entre dos puntos críticos consecutivos, permanece a un lado de su cero y, por la tabla anterior, conserva el signo. El producto y el cociente de signos fijos también conservan signo. Esta explicación puede formularse usando únicamente las propiedades de orden de la clase precedente; la mención a continuidad es una lectura posterior y se incluye aquí como ampliación conceptual.

#### Ejemplo de dominio: una cancelación aparente
**En la cátedra (33:45–36:58).** Consideremos

$$
\frac{x-1}{x-1}\ge0.
$$

El dominio es $D=\mathbb R\setminus\{1\}$. En todo punto de $D$, la fracción vale $1$, y por ello satisface la desigualdad. El conjunto solución es

$$
\boxed{(-\infty,1)\cup(1,\infty)=\mathbb R\setminus\{1\}.}
$$

Es legítimo reducir la fracción a $1$ **junto con la restricción $x\ne1$**. La condición original mantiene su relevancia aun cuando el factor común desaparezca del cociente simplificado. Esta distinción anticipa una regla general: una igualdad algebraica entre expresiones racionales se enuncia sobre su dominio común.

#### Tabla de signos del ejemplo principal
**En la cátedra (37:00–50:15).** Para

$$
R(x)=\frac{2(x-2)}{x(x-1)},\qquad x\in\mathbb R\setminus\{0,1\},
$$

los puntos ordenados son $0<1<2$, de modo que aparecen cuatro intervalos abiertos. La tabla de signos es:

| Factor o cociente | $(-\infty,0)$ | $(0,1)$ | $(1,2)$ | $(2,\infty)$ |
|---|:---:|:---:|:---:|:---:|
| $2(x-2)$ | $-$ | $-$ | $-$ | $+$ |
| $x$ | $-$ | $+$ | $+$ | $+$ |
| $x-1$ | $-$ | $-$ | $+$ | $+$ |
| $R(x)$ | $-$ | $+$ | $-$ | $+$ |

La condición $R(x)\le0$ escoge los intervalos primero y tercero. El valor $x=2$ satisface $R(2)=0$ y pertenece al dominio; $0$ y $1$ hacen cero el denominador. Así,

$$
\boxed{S=(-\infty,0)\cup(1,2].}
$$

Con la misma función, las otras tres comparaciones producen

$$
\begin{array}{rcl}
R(x)<0 &\Longleftrightarrow& x\in(-\infty,0)\cup(1,2),\\
R(x)>0 &\Longleftrightarrow& x\in(0,1)\cup(2,\infty),\\
R(x)\ge0 &\Longleftrightarrow& x\in(0,1)\cup[2,\infty).
\end{array}
$$

**Verificación rápida.** En $x=-1$, $R(-1)=-3<0$; en $x=\tfrac12$, $R(1/2)=12>0$; en $x=\tfrac32$, $R(3/2)=-\tfrac43<0$; en $x=3$, $R(3)=\tfrac13>0$. Los valores elegidos comprueban cada intervalo, aunque la demostración de signo constante es la que justifica el resultado para todos sus puntos.

#### Factores con coeficiente negativo y valores repetidos
**En la cátedra (52:39–59:11).** Una expresión como $-x$ tiene punto crítico $0$, signo positivo a la izquierda y negativo a la derecha. Es posible conservar ese factor en la tabla o extraer un signo menos global, recordando que multiplicar una desigualdad por $-1$ invierte su sentido.

Si un mismo valor anula simultáneamente factores del numerador y denominador, la restricción del denominador prevalece. El profesor ilustra esta precaución añadiendo factores $x-5$, $x-4$ y $x-1$ al numerador: los valores $5$ y $4$ pueden incluirse en una comparación amplia cuando pertenecen al dominio; el valor $1$ queda excluido porque también anula un factor del denominador.

**Ampliación: factores de multiplicidad par e impar.** En $(x-r)^k$, el signo cambia al cruzar $r$ si $k$ es impar y se conserva si $k$ es par. La regla se deduce de que $(x-r)^2$ es positivo para $x\ne r$ y de que multiplicar por $x-r$ altera el signo al cruzar el punto. Esta observación permite construir tablas más rápidamente sin perder las restricciones de dominio.

### Completar cuadrados perfectos

#### El patrón fundamental
**En la cátedra (60:14–69:37).** La identidad de partida es

$$
(x+h)^2=x^2+2hx+h^2.
$$

La técnica de **completar el cuadrado** consiste en identificar el término que transforma una suma de dos términos en un trinomio cuadrado perfecto, agregándolo y compensándolo de manera exacta. El recurso que el profesor llama «ni quita ni pone» aparece aquí como sumar y restar la misma cantidad:

$$
\begin{aligned}
x^2+2hx
&=x^2+2hx+h^2-h^2\\
&=\boxed{(x+h)^2-h^2}.
\end{aligned}
$$

Para $x^2+mx$, se reescribe $mx=2(\tfrac m2)x$. Por tanto,

$$
\boxed{x^2+mx=\left(x+\frac m2\right)^2-\frac{m^2}{4}.}
$$

En esta expresión se reconocen las dos decisiones metodológicas que enfatiza la clase: identificar la mitad del coeficiente lineal y añadir su cuadrado, conservando el valor inicial mediante una resta de igual magnitud.

#### Una cuadrática general
**En la cátedra (75:14–80:59).** Sea

$$
q(x)=ax^2+bx+c,\qquad a\ne0.
$$

Primero se factoriza por $a$:

$$
q(x)=a\left(x^2+\frac ba x+\frac ca\right).
$$

Dentro del paréntesis, la mitad del coeficiente lineal es $b/(2a)$. Se añade y se resta su cuadrado:

$$
\begin{aligned}
q(x)
&=a\left[x^2+2\frac{b}{2a}x+\left(\frac{b}{2a}\right)^2
-\left(\frac{b}{2a}\right)^2+\frac ca\right]\\
&=a\left[\left(x+\frac{b}{2a}\right)^2
-\frac{b^2}{4a^2}+\frac{4ac}{4a^2}\right]\\
&=\boxed{a\left[\left(x+\frac{b}{2a}\right)^2
-\frac{b^2-4ac}{4a^2}\right]}.
\end{aligned}
$$

Se define el **discriminante**

$$
\boxed{\Delta=b^2-4ac.}
$$

La identidad central de esta parte del curso es, por consiguiente,

$$
\boxed{q(x)=a\left[\left(x+\frac b{2a}\right)^2-\frac\Delta{4a^2}\right].}\tag{C}
$$

El denominador $4a^2$ es estrictamente positivo. La comparación de $\Delta$ con cero determina el comportamiento del término entre corchetes. El factor $a$ determina la orientación final del signo de $q$.

### Tres casos del discriminante

#### Discriminante negativo: signo constante
**En la cátedra (82:22–88:15).** Si $\Delta<0$, entonces $-\Delta/(4a^2)>0$. El cuadrado de la identidad (C) es mayor o igual que cero; al sumarle una constante estrictamente positiva resulta

$$
\left(x+\frac b{2a}\right)^2-\frac\Delta{4a^2}>0
\qquad\text{para todo }x\in\mathbb R.
$$

Se concluye que $q(x)$ tiene **el signo de $a$ para todo $x\in\mathbb R$**, y además $q(x)\ne0$ para todo $x$. Una cuadrática de este tipo puede tratarse como un factor de signo constante en la tabla de una inecuación. Si $a>0$, puede dividirse por ella conservando el sentido; si $a<0$, dividir por ella invierte el sentido. En ambas operaciones se conserva el dominio original.

**Ejemplo de la clase.** $x^2+1>0$ en todo $\mathbb R$. El factor $-(x^2+1)<0$ en todo $\mathbb R$. Por ello,

$$
-\frac{2x-4}{x(x-1)}(x^2+1)\ge0
\quad\Longleftrightarrow\quad
\frac{2x-4}{x(x-1)}\le0,
$$

para $x\ne0,1$. El conjunto solución vuelve a ser $(-\infty,0)\cup(1,2]$.

#### Discriminante cero: un punto de anulación
**En la cátedra (88:17–90:30).** Si $\Delta=0$, la identidad (C) queda

$$
\boxed{q(x)=a\left(x+\frac b{2a}\right)^2.}
$$

El punto $r=-b/(2a)$ satisface $q(r)=0$. En cada $x\ne r$, la cuadrática tiene el signo de $a$; al cruzar $r$ ese signo se conserva. Se trata de un cero de multiplicidad dos.

En una tabla de signos, el punto $r$ debe señalarse expresamente. Si el factor aparece en el numerador de una expresión racional y la desigualdad permite igualdad, puede incorporarse como solución cuando pertenece al dominio; si aparece en el denominador, queda excluido.

#### Discriminante positivo: raíces y factorización
**En la cátedra (90:31–101:10, inicio del caso).** El profesor observa que, si $\Delta>0$, la identidad (C) enfrenta un cuadrado con una constante positiva que se resta. Para estudiar los puntos donde ambos se igualan necesita considerar la ecuación $u^2=\Delta$ y la raíz cuadrada. Explica por qué la cuestión de **existencia** de $\sqrt\Delta$ se pospone hasta la completitud de los reales en una semana posterior; en la presente clase estudia la cuestión de **unicidad de la solución no negativa**.

**Ampliación (culminación algebraica para el estudio).** Asumiendo la existencia de la raíz positiva $\sqrt\Delta$ —hecho conocido para los reales, cuya justificación axiomática queda pendiente en el itinerario del curso— se tiene

$$
\begin{aligned}
q(x)
&=a\left[\left(x+\frac b{2a}\right)^2
-\left(\frac{\sqrt\Delta}{2a}\right)^2\right]\\
&=a\left(x+\frac b{2a}-\frac{\sqrt\Delta}{2a}\right)
      \left(x+\frac b{2a}+\frac{\sqrt\Delta}{2a}\right)\\
&=\boxed{a(x-r_1)(x-r_2)},
\end{aligned}
$$

con

$$
r_1=\frac{-b+\sqrt\Delta}{2a},\qquad
r_2=\frac{-b-\sqrt\Delta}{2a}.
$$

Definimos $r_-:=\min\{r_1,r_2\}$ y $r_+:=\max\{r_1,r_2\}$. Puesto que las raíces son distintas, se cumple $r_-<r_+$. Entonces:

| Intervalo | Signo de $(x-r_-)(x-r_+)$ | Signo de $q(x)$ |
|---|:---:|---|
| $x<r_-$ | $+$ | signo de $a$ |
| $r_-<x<r_+$ | $-$ | contrario al signo de $a$ |
| $x>r_+$ | $+$ | signo de $a$ |

En $r_-$ y $r_+$ la cuadrática vale cero. Esto completa el panorama operativo que el profesor deja remitido al apunte: con $\Delta>0$ aparecen dos puntos críticos; con $\Delta=0$, uno doble; con $\Delta<0$, la cuadrática tiene signo constante.

#### Existencia y unicidad de la raíz cuadrada
**En la cátedra (94:41–101:10).** Consideremos $d>0$ y la ecuación $u^2=d$. Si $u$ es solución, $-u$ también satisface la ecuación. Además, dos soluciones cualesquiera $u,v$ cumplen

$$
u^2=v^2\quad\Longrightarrow\quad(u-v)(u+v)=0
\quad\Longrightarrow\quad u=v\ \text{o}\ u=-v.
$$

Toda solución resulta, por tanto, igual a una solución dada o a su opuesta. Cuando se exige $u\ge0$, la solución, **si existe**, es única: si $u,v\ge0$ y $u^2=v^2=d>0$, la posibilidad $u=-v$ llevaría a $u=v=0$, incompatible con $d>0$, por lo que necesariamente $u=v$. La raíz cuadrada $\sqrt d$ nombra esa solución no negativa.

Es esencial distinguir los dos enunciados:

$$
u^2=d\quad\Longleftrightarrow\quad u=\sqrt d\ \text{o}\ u=-\sqrt d,
\qquad\text{mientras que}\qquad \sqrt d\ge0.
$$

Por ejemplo, $u^2=4$ tiene las soluciones $2$ y $-2$, mientras que $\sqrt4=2$. El profesor pospone la prueba axiomática de la existencia general de raíces cuadradas positivas hasta el tratamiento posterior de la completitud.

#### Valor absoluto: una ampliación anunciada
**Ampliación editorial.** Al terminar la cátedra, el profesor remite también el *módulo* (valor absoluto) al apunte oficial, sin desarrollarlo en la pizarra. Para disponer de una referencia de estudio, introducimos aquí la función

$$
|x|=\begin{cases}x,&x\ge0,\\-x,&x<0.\end{cases}
$$

La función $|x|$ expresa la distancia de $x$ al cero. Para $r>0$, la desigualdad $|x|<r$ corresponde a los puntos del intervalo $(-r,r)$, mientras que $|x|\le r$ corresponde a $[-r,r]$:

$$
|x|<r\ \Longleftrightarrow\ -r<x<r,\qquad
|x|\le r\ \Longleftrightarrow\ -r\le x\le r.
$$

Para comprobarlo, se consideran los casos $x\ge0$ y $x<0$ de la definición. Por ejemplo, $|2x-3|\le5$ equivale a $-5\le2x-3\le5$; sumando $3$ y dividiendo por $2>0$, se obtiene $-1\le x\le4$. Este desarrollo es material complementario y prepara el uso de inecuaciones con módulo en clases posteriores.

### Reversibilidad en las demostraciones

**En el intercambio posterior a la cátedra (105:00–111:45).** La conversación vuelve sobre la diferencia entre demostrar una igualdad y transformar formalmente expresiones. Para establecer $F=G$ se puede:

- transformar $F$ mediante igualdades justificadas hasta obtener $G$;
- comenzar con una identidad conocida y obtener $F=G$;
- demostrar que $F-G=0$;
- demostrar por contradicción que la hipótesis $F\ne G$ conduce a una contradicción.

El profesor advierte sobre un procedimiento inválido: comenzar **suponiendo la igualdad buscada** y deducir una identidad verdadera mediante operaciones que pierdan información. Por ejemplo,

$$
-1=0\quad\Longrightarrow\quad 0=0
$$

si se multiplican ambos lados por cero; la conclusión verdadera permite un antecedente falso. La solución es reconstruir una cadena de equivalencias reversibles, o bien redactar la demostración directamente desde premisas admitidas.

La misma cautela afecta a las inecuaciones: multiplicar por una expresión de signo variable, cancelar factores que pueden anularse o elevar al cuadrado exige analizar condiciones. El algoritmo de signos sistematiza estas verificaciones.

### Síntesis de método

En los ejercicios de inecuaciones, la secuencia de trabajo es **dominio, expresión comparada con cero, factorización, puntos críticos distintos, intervalos abiertos, signos y extremos**. En las cuadráticas, la cadena correspondiente es **factorizar por $a$, completar el cuadrado, distinguir los tres casos de $\Delta$ y describir signo y raíces según corresponda**.

La clase ilustra además un criterio de rigor aplicable a todo el cálculo: las operaciones algebraicas pueden escribirse como equivalencias cuando preservan exactamente los valores admisibles de la incógnita. Las condiciones de denominador y las hipótesis de signo acompañan a esas equivalencias durante todo el procedimiento.

### Referencias y notas de alcance

- Jorge San Martín, [*IC2021: Cátedra 2.2 (Viernes 26/3 12:00)*](https://www.youtube.com/watch?v=-NZgH0yH-NI), grabación del 26 de marzo de 2021, duración aproximada de 1 h 53 min. Fuente principal efectivamente revisada mediante la transcripción automática visible en YouTube.
- [*Introducción al Cálculo (base 2021)*](https://www.youtube.com/playlist?list=PLw1jfR3gkMOurwHWcqKw6AAW7mrAljjFM), lista de reproducción del curso.
- **Alcance de esta edición.** El profesor remite la culminación de la factorización con $\Delta>0$ y los detalles del módulo al apunte oficial. Aquí la primera se incluye como **ampliación matemática** y se aporta además una colección original de ejercicios resueltos. Las afirmaciones sobre existencia de $\sqrt d$ para todo $d>0$ se presentan como hechos del sistema real cuyo fundamento se introduce más adelante con la completitud.

### Taller de problemas y soluciones

Los ejercicios se presentan a continuación según la fuente de origen; las ampliaciones editoriales de cada apuntes permanecen expresamente identificadas.

#### Solucionario desarrollado: ejercicios de estudio — cátedra 2.1

Los ejercicios siguientes reúnen las tareas anunciadas en la cátedra y otros problemas de consolidación redactados para las notas. Las actividades directamente mencionadas por el profesor se identifican como **[Tarea de la clase]**; las restantes, como **[Práctica adicional]**.

#### Ejercicio 1. Tricotomía en un cuerpo de característica dos — [Tarea de la clase]
**Enunciado.** Justificar por qué un cuerpo $K$ con $1+1=0$ puede ser un cuerpo algebraico y, a la vez, carecer de un conjunto positivo compatible con los axiomas 6 y 7.

**Solución.** En ese cuerpo, $1$ es su propio opuesto: $1+1=0$ implica $-1=1$ por unicidad del opuesto. En una tricotomía compatible con un cuerpo ordenado, $1\ne0$ obliga a que se cumpla $1\in K_+^*$ o $-1\in K_+^*$. Como $1=-1$, ambas alternativas se convertirían en la misma pertenencia, contradiciendo la exclusividad del axioma 6. Por lo tanto, ningún conjunto positivo de esta clase puede dotar a $K$ de ese orden. El ejemplo canónico es $\mathbb F_2$, cuyas operaciones módulo dos satisfacen los axiomas de cuerpo. $\square$

#### Ejercicio 2. $0<1$ a partir de los axiomas — [Tarea de la clase]
**Enunciado.** Probar que $1>0$ partiendo de la tricotomía, la clausura y $1\ne0$.

**Solución.** Dado $1\ne0$, la tricotomía afirma que $1>0$ o $-1>0$. Si $-1>0$, el producto de los positivos $(-1)(-1)$ también es positivo por el axioma 7. Pero $(-1)(-1)=1$, así que igualmente $1>0$. La única conclusión compatible con los axiomas es $1>0$. Esta segunda prueba permite llegar a la misma tesis aun antes de sistematizar todas las propiedades de los cuadrados. $\square$

#### Ejercicio 3. Transitividad de $\le$ — [Tarea de la clase]
**Enunciado.** Sean $x\le y$ e $y\le z$. Demostrar $x\le z$.

**Solución.** Cada desigualdad permite dos posibilidades: $x<y$ o $x=y$, y $y<z$ o $y=z$. Si aparece una igualdad, se sustituye el término correspondiente y queda inmediatamente una desigualdad del mismo sentido. Cuando ambas son estrictas, la transitividad probada en la sección 3.1 proporciona $x<z$. En todos los casos $x\le z$. $\square$

#### Ejercicio 4. Antisimetría — [Tarea de la clase]
**Enunciado.** Probar que $x\le y$ e $y\le x$ implican $x=y$.

**Solución.** Por tricotomía, $x<y$, $x=y$ o $x>y$, de manera exclusiva. El caso $x<y$ contradice $y\le x$, y el caso $x>y$ contradice $x\le y$. La alternativa que permanece es $x=y$. $\square$

#### Ejercicio 5. Multiplicar por un positivo — [Tarea de la clase]
**Enunciado.** Si $x<y$ y $a>0$, demostrar $ax<ay$.

**Solución.** De $x<y$ se tiene $y-x\in\mathbb R_+^*$; asimismo $a\in\mathbb R_+^*$. El axioma 7 implica $a(y-x)\in\mathbb R_+^*$. Por distributividad, $a(y-x)=ay-ax$, y por definición $ax<ay$. $\square$

#### Ejercicio 6. Producto de desigualdades — [Tarea de la clase]
**Enunciado.** Demostrar que $0<x<y$ y $0<u<v$ implican $xu<yv$.

**Solución.** Se calcula la diferencia

$$
\begin{aligned}
yv-xu&=yv-xv+xv-xu\\
&=(y-x)v+x(v-u).
\end{aligned}
$$

Por las hipótesis, $y-x$, $v$, $x$ y $v-u$ son estrictamente positivos. Cada producto del último miembro es positivo, y la suma de ambos también, por el axioma 7. Así $yv-xu>0$ y $xu<yv$. La inserción de $-xv+xv=0$ es exactamente la técnica «ni quita ni pone» de la cátedra. $\square$

#### Ejercicio 7. Producto de un positivo por un negativo — [Tarea de la clase]
**Enunciado.** Si $x>0$ y $y<0$, demostrar $xy<0$.

**Solución.** $x\in\mathbb R_+^*$ y $-y\in\mathbb R_+^*$. Por clausura, $x(-y)\in\mathbb R_+^*$. Como $x(-y)=-(xy)$, el opuesto del producto es positivo y, por la tricotomía y la definición, $xy<0$. $\square$

#### Ejercicio 8. Producto de dos negativos — [Tarea de la clase]
**Enunciado.** Si $x<0$ e $y<0$, demostrar $xy>0$.

**Solución.** Los opuestos $-x$ y $-y$ son positivos. Su producto pertenece a $\mathbb R_+^*$; por las reglas de signos, $(-x)(-y)=xy$. Por tanto $xy>0$. $\square$

#### Ejercicio 9. Recíprocos y signo — [Tarea de la clase]
**Enunciado.** Si $x\ne0$, demostrar que $x^{-1}$ tiene el mismo signo que $x$.

**Solución.** Primero, $x^{-1}\ne0$ porque $xx^{-1}=1$. Por el teorema de los cuadrados, $(x^{-1})^2>0$. La identidad

$$
x^{-1}=(x^{-1})^2x
$$

expresa el recíproco como producto de un número positivo por $x$. La regla de signos demuestra ambos casos: $x>0\Rightarrow x^{-1}>0$ y $x<0\Rightarrow x^{-1}<0$. $\square$

#### Ejercicio 10. Inecuación con coeficiente negativo — [Tarea de la clase]
**Enunciado.** Resolver $-3x+6<0$.

**Solución.** Restamos $6$ a ambos lados: $-3x<-6$. Multiplicamos por $-\frac13$, que es negativo, e invertimos el sentido:

$$
-3x<-6\iff x>2.
$$

El conjunto solución es $(2,+\infty)$. Verificación: $x=3$ da $-3<0$, mientras que $x=1$ da $3>0$. El punto de corte $c=2$ queda excluido por la desigualdad estricta. $\square$

#### Ejercicio 11. Las cuatro variantes de una expresión — [Práctica adicional]
**Enunciado.** Resolver $2x-8<0$, $2x-8\le0$, $2x-8>0$ y $2x-8\ge0$.

**Solución.** En cada caso $2>0$ y el punto de corte es $c=4$. La resta de $-8$ equivale a sumar $8$; dividir por $2$ conserva el orden. Se obtiene:

$$
\begin{aligned}
2x-8<0&\iff x<4 &&\Rightarrow\quad (-\infty,4),\\
2x-8\le0&\iff x\le4&&\Rightarrow\quad (-\infty,4],\\
2x-8>0&\iff x>4 &&\Rightarrow\quad (4,+\infty),\\
2x-8\ge0&\iff x\ge4&&\Rightarrow\quad [4,+\infty).
\end{aligned}
$$

La inclusión de $4$ corresponde exactamente a los casos con igualdad permitida. $\square$

#### Ejercicio 12. Todas las variantes con pendiente negativa — [Tarea de la clase, ampliada]
**Enunciado.** Resolver $-2x-4\mathrel{\square}0$ para cada uno de los signos $<,\le,>,\ge$.

**Solución.** El punto de corte es $c=-\frac{-4}{-2}=-2$. Restar la constante equivale a sumar $4$ y dividir por $-2$ invierte la dirección. Se obtiene:

$$
\begin{aligned}
-2x-4<0&\iff x>-2&&\Rightarrow\quad (-2,+\infty),\\
-2x-4\le0&\iff x\ge-2&&\Rightarrow\quad [-2,+\infty),\\
-2x-4>0&\iff x<-2&&\Rightarrow\quad (-\infty,-2),\\
-2x-4\ge0&\iff x\le-2&&\Rightarrow\quad (-\infty,-2].
\end{aligned}
$$

En $x=-2$ la expresión se anula: $-2(-2)-4=0$. $\square$

#### Ejercicio 13. Suma de desigualdades y transitividad — [Práctica adicional]
**Enunciado.** Si $-1<x<3$ y $2<u<5$, determinar un intervalo abierto que contenga a $x+u$.

**Solución.** De $-1<x$ y $2<u$, la suma de desigualdades estrictas da $1<x+u$. Por otra parte, $x<3$ y $u<5$ dan $x+u<8$. Juntas,

$$
1<x+u<8\quad\Longleftrightarrow\quad x+u\in(1,8).
$$

El intervalo expresa una cota universal bajo las hipótesis; de hecho los extremos se pueden aproximar mediante elecciones de $x$ y $u$ próximas a los límites permitidos. $\square$

#### Ejercicio 14. Orden y recíprocos — [Práctica adicional]
**Enunciado.** Sean $0<x<y$. Demostrar $0<y^{-1}<x^{-1}$.

**Solución.** Los recíprocos $x^{-1},y^{-1}$ son positivos. Como $y-x>0$, el producto $(y-x)x^{-1}y^{-1}$ también lo es. Por distributividad y las identidades inversas,

$$
(y-x)x^{-1}y^{-1}=x^{-1}-y^{-1}>0.
$$

Esto equivale a $y^{-1}<x^{-1}$. La positividad de $y^{-1}$ se obtuvo anteriormente. De esta forma, la operación de tomar recíprocos invierte el orden entre reales estrictamente positivos. $\square$

#### Ejercicio 15. Una inecuación con variable en ambos lados — [Práctica adicional]
**Enunciado.** Resolver $4x-7\le x+5$.

**Solución.** Sumamos $-x$ y $7$ en ambos lados, preservando la desigualdad:

$$
4x-7\le x+5\iff 3x\le12\iff x\le4.
$$

En el último paso se multiplicó por $1/3>0$. El conjunto solución es $(-\infty,4]$. Verificación en el extremo: $4(4)-7=9$ y $4+5=9$. $\square$

#### Ejercicio 16. Una inecuación con paréntesis — [Práctica adicional]
**Enunciado.** Resolver $-2(3x-1)+4>10$.

**Solución.** Se distribuye y se reúnen las constantes:

$$
-6x+2+4>10\iff -6x>4\iff x<-\frac23.
$$

En el último paso se dividió por $-6$, por lo cual el sentido se invirtió. El conjunto solución es $(-\infty,-2/3)$. Sustituyendo $x=-1$ resulta $-2(-4)+4=12>10$, mientras que el punto $x=-2/3$ produce igualdad y queda excluido. $\square$

#### Ejercicio 17. Condición con igualdad de frontera — [Práctica adicional]
**Enunciado.** Resolver simultáneamente $2x+1\ge0$ y $3x-6<0$.

**Solución.** La primera desigualdad da $x\ge-1/2$ y la segunda $x<2$. Las dos condiciones deben cumplirse a la vez, de modo que el conjunto solución es la intersección

$$
[-1/2,+\infty)\cap(-\infty,2)=\boxed{[-1/2,2)}.
$$

El extremo izquierdo pertenece al conjunto porque admite igualdad; el derecho queda excluido por la desigualdad estricta. $\square$

#### Ejercicio 18. Inecuación degenerada — [Práctica adicional]
**Enunciado.** Determinar el conjunto solución de $0x-5<0$ y de $0x+5<0$.

**Solución.** El axioma de cuerpo implica $0x=0$. La primera condición se reduce a $-5<0$, verdadera para todo real $x$, de modo que su conjunto solución es $\mathbb R$. La segunda se reduce a $5<0$, falsa para todo real $x$, por lo cual su conjunto solución es $\varnothing$. El coeficiente principal igual a cero transforma el problema en evaluar una constante. $\square$

#### Solucionario: tareas de la cátedra y ejercicios de consolidación — cátedra 2.2

Los ejercicios **P** corresponden a propuestas o desarrollos dejados pendientes, relacionados directamente con la clase. Los ejercicios **A** son ampliaciones de práctica añadidas para consolidar el procedimiento. Cada solución se presenta con su dominio, su método y su conjunto solución.

#### P1. Resolver todas las variantes del ejemplo principal
**Problema.** Para $R(x)=(2x-4)/[x(x-1)]$, resolver $R(x)<0$, $R(x)\le0$, $R(x)>0$ y $R(x)\ge0$.

**Solución.** El dominio es $D=\mathbb R\setminus\{0,1\}$. Las filas de signos obtenidas para los cuatro intervalos son $-,+,-,+$. El único cero del numerador que está en $D$ es $x=2$. Por tanto:

$$
\begin{array}{rcl}
R<0 &:& (-\infty,0)\cup(1,2),\\
R\le0 &:& (-\infty,0)\cup(1,2],\\
R>0 &:& (0,1)\cup(2,\infty),\\
R\ge0 &:& (0,1)\cup[2,\infty).
\end{array}
$$

En particular, $x=0$ y $x=1$ quedan excluidos en todos los casos por ser ceros del denominador.

#### P2. Mantener el dominio al cancelar un factor
**Problema.** Resolver $\frac{x-1}{x-1}\ge0$.

**Solución.** Primero se registra $D=\mathbb R\setminus\{1\}$. En este dominio, la fracción es igual a $1$. Puesto que $1\ge0$, cada $x\in D$ satisface la condición, y

$$
S=\boxed{(-\infty,1)\cup(1,\infty)}.
$$

La reducción de una fracción a $1$ conserva el dominio bajo el cual tiene sentido.

#### P3. Resolver una inecuación con factor $-x$
**Problema.** Resolver $\frac{2x-4}{(-x)(x-1)}\le0$.

**Solución.** Para $x\ne0,1$ la expresión es $-R(x)$, donde $R$ es la función de P1. Por tanto,

$$
-R(x)\le0\quad\Longleftrightarrow\quad R(x)\ge0.
$$

Aplicando P1 obtenemos $S=(0,1)\cup[2,\infty)$. El mismo resultado sale de la tabla de signos de $-x$, positiva en $x<0$ y negativa en $x>0$.

#### P4. Una raíz común del numerador y del denominador
**Problema.** Resolver $\frac{(x-1)(x-2)}{(x-1)(x+3)}\ge0$.

**Solución.** El dominio original es $D=\mathbb R\setminus\{-3,1\}$. Para $x\in D$,

$$
\frac{(x-1)(x-2)}{(x-1)(x+3)}=\frac{x-2}{x+3}.
$$

Los puntos críticos relevantes son $-3$ (denominador), $1$ (restricción heredada) y $2$ (cero del numerador reducido). La fracción reducida es positiva para $x<-3$ y $x>2$, negativa para $-3<x<2$. Se incluye $x=2$ porque produce cero y pertenece al dominio. Así,

$$
S=\boxed{(-\infty,-3)\cup[2,\infty)}.
$$

El punto $x=1$ permanece excluido, aunque se ubica en una zona que de todos modos queda fuera de la solución. Registrar el dominio antes de cancelar sigue siendo indispensable.

#### P5. Completar cuadrados para una expresión monómica-lineal
**Problema.** Expresar $x^2+mx$ como cuadrado perfecto más una constante.

**Solución.** El término $mx$ se escribe como $2(m/2)x$. Se agrega el cuadrado de $m/2$ y simultáneamente se lo resta:

$$
\begin{aligned}
x^2+mx
&=x^2+2\frac m2x+\left(\frac m2\right)^2-\left(\frac m2\right)^2\\
&=\boxed{\left(x+\frac m2\right)^2-\frac{m^2}{4}}.
\end{aligned}
$$

Esta identidad es válida para todo par de reales $x,m$.

#### P6. Obtener las raíces y los signos de una cuadrática con $\Delta>0$
**Problema.** Completar el análisis del caso $\Delta>0$ de $ax^2+bx+c$, con $a\ne0$.

**Solución (ampliación).** De la identidad (C), la condición $q(x)=0$ equivale a

$$
\left(x+\frac b{2a}\right)^2=\frac\Delta{4a^2}.
$$

Admitiendo la raíz positiva de $\Delta$ se obtienen las dos soluciones

$$
r_1=\frac{-b+\sqrt\Delta}{2a},\qquad r_2=\frac{-b-\sqrt\Delta}{2a}.
$$

Por diferencia de cuadrados, $q(x)=a(x-r_1)(x-r_2)$. Ordenando las raíces como $r_-<r_+$, el producto de los factores es positivo en los intervalos exteriores y negativo entre las raíces. La cuadrática tiene, por consiguiente, el signo de $a$ en el exterior y el contrario entre sus dos ceros.

#### P7. Diferenciar las dos preguntas sobre $u^2=d$
**Problema.** Sea $d>0$. Demostrar que, si hay soluciones reales de $u^2=d$, son exactamente dos, opuestas entre sí, y que hay a lo sumo una solución no negativa.

**Solución.** Si $v^2=d$, entonces $(-v)^2=d$. Puesto que $d>0$, se tiene $v\ne0$, por lo que $v\ne-v$. Ahora, si $u^2=d=v^2$, la diferencia de cuadrados proporciona

$$
(u-v)(u+v)=0.
$$

La ley del producto nulo da $u=v$ o $u=-v$. Por tanto, todas las soluciones pertenecen al conjunto $\{v,-v\}$, y ambos miembros son distintos y soluciones. De ellos, exactamente uno es positivo. La existencia de al menos una solución para cada $d>0$ corresponde a la completitud de los reales, que el profesor pospone.

#### P8. Signo de una cuadrática de discriminante negativo
**Problema.** Justificar el signo de $3x^2-6x+8$.

**Solución.** Aquí $a=3$, $b=-6$ y $c=8$. Entonces

$$
\Delta=(-6)^2-4\cdot3\cdot8=36-96=-60<0.
$$

Completando cuadrados,

$$
3x^2-6x+8=3(x-1)^2+5>0
$$

para todo $x\in\mathbb R$. La última desigualdad se sigue de que $3(x-1)^2\ge0$ y $5>0$.

#### P9. Signo y punto de anulación cuando $\Delta=0$
**Problema.** Analizar $-2x^2+8x-8$.

**Solución.** Se factoriza

$$
-2x^2+8x-8=-2(x-2)^2.
$$

El único cero es $x=2$. Para $x\ne2$, el cuadrado es positivo y su producto con $-2$ es negativo. Así, la expresión es menor o igual que cero en todo $\mathbb R$, y estrictamente negativa en $\mathbb R\setminus\{2\}$.

#### P10. Regla de equivalencias y operaciones reversibles
**Problema.** Explicar por qué la inferencia $F=G\Rightarrow 0=0$, obtenida multiplicando por cero, constituye una demostración insuficiente de $F=G$; indicar un procedimiento válido.

**Solución.** La regla $F=G\Rightarrow 0=0$ es válida para cualquier par de expresiones $F,G$, aun cuando sus valores sean distintos. En consecuencia, la conclusión deja abierta la verdad del antecedente. Un procedimiento válido consiste en comenzar con una igualdad conocida y obtener $F=G$, o en probar $F-G=0$. También se puede partir de una cadena de equivalencias, siempre que cada transformación sea reversible en el dominio considerado.

#### A1. Una fracción con tres puntos críticos
**Problema.** Resolver $\frac{(x+2)(x-3)}{x-1}<0$.

**Solución.** El dominio exige $x\ne1$. Los puntos críticos ordenados son $-2,1,3$. La tabla por factores es

| Intervalo | $x+2$ | $x-3$ | $x-1$ | Cociente |
|---|:---:|:---:|:---:|:---:|
| $(-\infty,-2)$ | $-$ | $-$ | $-$ | $-$ |
| $(-2,1)$ | $+$ | $-$ | $-$ | $+$ |
| $(1,3)$ | $+$ | $-$ | $+$ | $-$ |
| $(3,\infty)$ | $+$ | $+$ | $+$ | $+$ |

Al ser estricta la desigualdad, se seleccionan los intervalos negativos con extremos abiertos: $S=(-\infty,-2)\cup(1,3)$.

#### A2. Multiplicidades pares e impares
**Problema.** Resolver $\frac{(x-1)^2(x+2)}{(x-3)^3}\ge0$.

**Solución.** El dominio es $x\ne3$. Los puntos críticos son $-2,1,3$. La multiplicidad dos de $x-1$ conserva el signo al cruzar $1$ y el exponente tres de $x-3$ lo invierte al cruzar $3$. Para $x<-2$, $(x+2)<0$ y $(x-3)^3<0$, luego el cociente es positivo; para $-2<x<3$ es negativo salvo en $x=1$, donde vale cero; para $x>3$ es positivo. Los ceros admisibles $-2$ y $1$ se incorporan. Así,

$$
S=\boxed{(-\infty,-2]\cup\{1\}\cup(3,\infty)}.
$$

#### A3. Un factor cuadrático siempre positivo
**Problema.** Resolver $\frac{(x^2+4)(x-2)}{x+1}\le0$.

**Solución.** Para todo real, $x^2+4>0$. Por lo tanto, el signo depende de $(x-2)/(x+1)$ y el dominio es $x\ne-1$. Esta fracción es positiva en $(-\infty,-1)$, negativa en $(-1,2)$ y positiva en $(2,\infty)$. Puesto que se permite el cero en $x=2$,

$$
S=\boxed{(-1,2]}.
$$

#### A4. Una cuadrática con dos raíces reales
**Problema.** Resolver $x^2-5x+6\le0$.

**Solución.** Se factoriza $x^2-5x+6=(x-2)(x-3)$. El coeficiente principal es positivo y las raíces ordenadas son $2<3$. Por la tabla del caso $\Delta>0$, la cuadrática es negativa entre las raíces y vale cero en ellas. De ahí

$$
S=\boxed{[2,3]}.
$$

#### A5. Una cuadrática con discriminante cero en denominador
**Problema.** Resolver $\frac{x+1}{(x-2)^2}>0$.

**Solución.** El dominio es $x\ne2$. En él, $(x-2)^2>0$, así que el cociente tiene el signo de $x+1$. Se requiere $x>-1$ y también $x\ne2$. El punto $-1$ queda excluido por ser desigualdad estricta. En conclusión,

$$
S=\boxed{(-1,2)\cup(2,\infty)}.
$$

#### A6. Una racional con factor común conservado en el dominio
**Problema.** Resolver $\frac{(x-1)^2}{x-1}\le0$.

**Solución.** El dominio es $x\ne1$. En ese dominio, el cociente coincide con $x-1$. Se requiere $x-1\le0$, es decir, $x\le1$, manteniendo $x\ne1$. Por tanto,

$$
S=\boxed{(-\infty,1)}.
$$

#### A7. Una cuadrática negativa en todo su dominio
**Problema.** Resolver $-x^2-4x-7<0$.

**Solución.** Al completar cuadrados se obtiene

$$
-x^2-4x-7=-\bigl((x+2)^2+3\bigr)<0
$$

para todo real. El conjunto solución es $S=\mathbb R$. También se obtiene con $\Delta=(-4)^2-4(-1)(-7)=-12<0$ y coeficiente principal $a=-1<0$.

#### A8. Una ecuación cuadrática y el sentido de la raíz
**Problema.** Resolver $x^2=9$ y evaluar $\sqrt9$.

**Solución.** La factorización $x^2-9=(x-3)(x+3)=0$ da $x=3$ o $x=-3$. La raíz cuadrada principal es la solución no negativa: $\sqrt9=3$. La notación $\pm3$ designa el conjunto de ambas soluciones, mientras que $\sqrt9$ designa un único real.

#### A9. Inecuación con valor absoluto
**Problema.** Resolver $|3x+2|<7$.

**Solución.** La caracterización del valor absoluto para radio $7>0$ transforma la condición en

$$
-7<3x+2<7.
$$

Se resta $2$ a los tres miembros y se divide por $3>0$:

$$
-9<3x<5\quad\Longleftrightarrow\quad -3<x<\frac53.
$$

La solución es $S=\boxed{(-3,5/3)}$. Los extremos son abiertos porque la desigualdad es estricta.

---

## Coordenadas, distancias y rectas

El plano cartesiano transforma propiedades algebraicas en lugares geométricos. La distancia euclidiana y la pendiente proporcionan dos herramientas esenciales para describir rectas y circunferencias.

**Grabaciones de referencia:** [grabación de la cátedra 3.1](https://www.youtube.com/watch?v=vxF8xwRmesA), [grabación de la cátedra 3.2](https://www.youtube.com/watch?v=h-eNbC2gUpw).

*Procedencia de este tramo: cátedra 3.1.*

### Del cuerpo ordenado al plano cartesiano

**En la cátedra (08:00–13:17).** Durante las primeras semanas se habían establecido los axiomas de cuerpo y de orden de $\mathbb R$. La propiedad de **completitud** se reserva para la semana ocho. El profesor recuerda que, en consecuencia, la existencia de raíces cuadradas positivas se ha empleado provisionalmente antes de su fundamentación posterior. Esta diferencia entre *usar* una propiedad y *haber demostrado* su existencia es importante para comprender el orden lógico del curso.

La **geometría analítica** permite representar figuras del plano mediante ecuaciones e inecuaciones en coordenadas, resolver problemas con técnicas algebraicas y dar una interpretación geométrica a las relaciones obtenidas. Se plantean dos movimientos complementarios: de la geometría a las ecuaciones y de las ecuaciones a los lugares geométricos.

En la planificación docente se anuncian cuatro sesiones de geometría analítica; en la semana 3 corresponden la **circunferencia** y la **recta**, temas pertinentes para el primer control. En esta cátedra se desarrolla especialmente la circunferencia; la recta se reserva para la sesión posterior.

#### Coordenadas de un punto
**En la cátedra (13:20–18:14).** Se fijan dos ejes perpendiculares que se cortan en el origen $O=(0,0)$. El eje horizontal es el de las **abscisas** $x$ y el vertical es el de las **ordenadas** $y$. A cada punto del plano le corresponde un par ordenado $(x,y)$, donde $x$ mide su posición horizontal e $y$ su posición vertical. Así se introduce

$$
\boxed{\mathbb R^2=\{(x,y):x\in\mathbb R,\ y\in\mathbb R\}.}
$$

La primera coordenada se interpreta en el eje horizontal y la segunda en el vertical. El ejemplo explícito del profesor diferencia $(3,2)$ de $(2,3)$ y agrega el punto $(-3,2)$ para mostrar el efecto del signo de la abscisa. Formalmente,

$$
(x_1,y_1)=(x_2,y_2)\quad\Longleftrightarrow\quad (x_1=x_2)\land(y_1=y_2).
$$

En particular, $(3,2)\ne(2,3)$. La colección no ordenada $\{2,3\}$, propia de la teoría de conjuntos, responde a una convención distinta: en ella los elementos pueden nombrarse en cualquier orden. El par ordenado registra papeles de coordenadas diferenciados.

> **Ampliación de precisión.** En teoría de conjuntos es posible *construir* formalmente un par ordenado como cierto conjunto (por ejemplo, mediante la convención de Kuratowski). La advertencia pedagógica de la clase contrasta el par $(2,3)$ con el conjunto ordinario $\{2,3\}$: ambos objetos tienen criterios de igualdad diferentes.


![Coordenadas cartesianas: el orden y el signo de las componentes determinan puntos distintos.](figuras/IC2021_Catedra_3_1/01_coordenadas.png)

*Figura. Coordenadas cartesianas: el orden y el signo de las componentes determinan puntos distintos.*

### Los lugares geométricos: una condición sobre pares ordenados

**En la cátedra (18:27–21:17).** Un **lugar geométrico** en el plano es un conjunto de puntos caracterizado por una condición sobre sus coordenadas. Si $P(x,y)$ es una propiedad, escribimos

$$
L_P=\{(x,y)\in\mathbb R^2:P(x,y)\}.
$$

Esta forma de expresar conjuntos traduce una figura a un problema lógico y algebraico. La condición puede ser una ecuación, una inecuación o una composición de condiciones unidas mediante $\land$ (conjunción) o $\lor$ (disyunción). Su interpretación en conjuntos emplea intersecciones y uniones, respectivamente.

#### Los siete lugares elementales de la clase
**En la cátedra (21:20–34:44).** La sucesión de ejemplos hace visible el papel de cada condición:

1. $A_1=\{(x,y):x=0\land y=0\}=\{(0,0)\}$: el **origen**.
2. $A_2=\{(x,y):x=0\}=\{(0,y):y\in\mathbb R\}$: el **eje de las ordenadas**.
3. $A_3=\{(x,y):y=0\}=\{(x,0):x\in\mathbb R\}$: el **eje de las abscisas**.
4. $A_4=\{(x,y):xy=0\}=A_2\cup A_3$: la **unión de ambos ejes**.
5. $A_5=\{(x,y):x>0\land y>0\}$: el **primer cuadrante abierto**.
6. $A_6=\{(x,y):x=a\}=\{(a,y):y\in\mathbb R\}$: una **recta vertical**, para un $a$ fijo.
7. $A_7=\{(x,y):y=b\}=\{(x,b):x\in\mathbb R\}$: una **recta horizontal**, para un $b$ fijo.

La identidad $xy=0\iff(x=0)\lor(y=0)$ explica el cuarto ejemplo por la propiedad del producto nulo demostrada en la primera semana. La conjunción $x=0\land y=0$ corresponde a la intersección de ambos ejes y produce el origen. La diferencia entre $x=0$ en $\mathbb R$, que selecciona un real, y $x=0$ en $\mathbb R^2$, que selecciona toda una recta, muestra la importancia del dominio ambiente.


![Lugares geométricos de $x=0$, $y=0$ y $xy=0$: eje vertical, eje horizontal y unión de ambos.](figuras/IC2021_Catedra_3_1/02_lugares_elementales.png)

*Figura. Lugares geométricos de $x=0$, $y=0$ y $xy=0$: eje vertical, eje horizontal y unión de ambos.*

#### Los cuatro cuadrantes
Los cuadrantes abiertos se caracterizan por los signos de las coordenadas:

| Cuadrante | Condición |
|:--|:--|
| I | $x>0$, $y>0$ |
| II | $x<0$, $y>0$ |
| III | $x<0$, $y<0$ |
| IV | $x>0$, $y<0$ |

**Ampliación editorial.** Las desigualdades estrictas describen cuadrantes abiertos: cada uno contiene puntos interiores con las dos coordenadas del signo indicado. Los ejes conforman sus fronteras. La condición $x\ge0\land y\ge0$ incorpora los semiejes positivos y el origen.


![Cuadrantes y ejemplos de rectas definidas mediante una coordenada constante.](figuras/IC2021_Catedra_3_1/03_cuadrantes_y_rectas.png)

*Figura. Cuadrantes y ejemplos de rectas definidas mediante una coordenada constante.*

### La distancia euclidiana en el plano

#### Deducción desde Pitágoras
**En la cátedra (35:34–42:53).** Sean $A=(x_1,y_1)$ y $B=(x_2,y_2)$. El profesor considera un dibujo donde $x_2>x_1$ e $y_2>y_1$ y reconoce que esa disposición representa un caso particular. La fórmula resultante se propone para cualesquiera puntos, independientemente del orden de sus coordenadas.

Se traza el punto auxiliar $C=(x_2,y_1)$. Los segmentos $AC$ y $CB$ son perpendiculares; sus longitudes son

$$
|x_2-x_1|\qquad\text{y}\qquad |y_2-y_1|.
$$

La distancia entre $A$ y $B$ es la hipotenusa del triángulo rectángulo $ACB$. Por el teorema de Pitágoras,

$$
d(A,B)^2=|x_2-x_1|^2+|y_2-y_1|^2.
$$

Como $|u|^2=u^2$ para todo real $u$, obtenemos

$$
\boxed{d(A,B)=\sqrt{(x_2-x_1)^2+(y_2-y_1)^2}.}
$$

La raíz cuadrada designa aquí el valor **mayor o igual que cero** cuyo cuadrado coincide con la suma de cuadrados. En los casos $A=B$, el resultado es $0$; para puntos distintos, es estrictamente positivo.


![La distancia euclidiana es la hipotenusa del triángulo rectángulo con catetos $|x_2-x_1|$ y $|y_2-y_1|$.](figuras/IC2021_Catedra_3_1/04_distancia_pitagoras.png)

*Figura. La distancia euclidiana es la hipotenusa del triángulo rectángulo con catetos $|x_2-x_1|$ y $|y_2-y_1|$.*

#### Propiedades elementales de la fórmula — ampliación
**Simetría:** el intercambio de $A$ y $B$ conserva cada cuadrado, luego $d(A,B)=d(B,A)$.

**Reconocimiento de puntos iguales:** $d(A,B)=0$ si y solo si $(x_2-x_1)^2+(y_2-y_1)^2=0$. Ambos cuadrados son mayores o iguales que cero, por lo que cada uno debe valer cero. Se deduce $x_1=x_2$, $y_1=y_2$, y así $A=B$.

**Coordenadas compartidas:** si $y_1=y_2$, la fórmula toma la forma $d(A,B)=|x_2-x_1|$; si $x_1=x_2$, toma la forma $d(A,B)=|y_2-y_1|$. La distancia lineal en $\mathbb R$ aparece como caso particular de la distancia plana.

**Ejemplo resuelto.** Para $A=(-2,1)$ y $B=(4,9)$,

$$
d(A,B)=\sqrt{(4+2)^2+(9-1)^2}=\sqrt{36+64}=10.
$$

### La circunferencia como lugar geométrico

#### Centro, radio y condición de equidistancia
**En la cátedra (43:17–47:17).** Se fija un centro $A=(x_0,y_0)\in\mathbb R^2$ y un radio $r>0$. La **circunferencia** de centro $A$ y radio $r$ es el lugar geométrico de los puntos cuya distancia al centro vale $r$:

$$
\boxed{\mathcal C(A,r)=\{P=(x,y)\in\mathbb R^2:d(P,A)=r\}.}
$$

La fórmula de distancia traduce la condición geométrica a

$$
\sqrt{(x-x_0)^2+(y-y_0)^2}=r.
$$

En la convención empleada durante la clase, el radio es estrictamente positivo. Si se toma $r=0$, el lugar resultante está formado por el único punto $A$; el profesor prefiere denominarlo sencillamente **punto** y reservar «circunferencia» para los radios positivos.

La región formada por los puntos cuya distancia al centro es menor que $r$ corresponde al **interior**. La región $d(P,A)\le r$ comprende el **disco cerrado** o círculo con borde. En adelante distinguiremos expresamente el borde de la región interior.


![Circunferencia, centro y radio; distinción entre puntos interiores, del borde y exteriores.](figuras/IC2021_Catedra_3_1/05_circunferencia_disco.png)

*Figura. Circunferencia, centro y radio; distinción entre puntos interiores, del borde y exteriores.*

#### Por qué la ecuación puede elevarse al cuadrado
**En la cátedra (49:39–1:01:59).** Para reales cualesquiera $u,v$, la igualdad $u=v$ implica $u^2=v^2$. Su recíproca requiere examinar los signos: por diferencia de cuadrados,

$$
u^2=v^2\iff (u-v)(u+v)=0\iff(u=v)\lor(u=-v).
$$

Por ejemplo, $u=-2$ y $v=2$ tienen cuadrados iguales, aunque representan reales distintos. Por ello, al elevar arbitrariamente una ecuación al cuadrado se puede ampliar el conjunto solución. Si se conoce previamente que $u\ge0$ y $v\ge0$, entonces

$$
\boxed{u=v\quad\Longleftrightarrow\quad u^2=v^2.}
$$

**Prueba de la recíproca bajo la restricción de signo.** De $u^2=v^2$ sigue $u=v$ o $u=-v$. En el segundo caso, $u\ge0$ y $v\ge0$ implican $u=v=0$, de modo que también se tiene $u=v$.

En la ecuación de distancia, tanto la raíz cuadrada como el radio $r$ son mayores o iguales que cero; por eso sí se conserva la equivalencia al elevar al cuadrado. Así se obtiene la **ecuación canónica de la circunferencia**:

$$
\boxed{(x-x_0)^2+(y-y_0)^2=r^2,\qquad r>0.}
$$

**Precisión lógica.** Una demostración que transforma una ecuación con el signo $\Longleftrightarrow$ conserva exactamente su conjunto solución. Al transformar solo mediante una implicación puede obtenerse un conjunto que incluya soluciones adicionales. El docente relaciona esta diferencia con la igualdad de conjuntos, demostrada por doble inclusión.

#### Ejemplo de ampliación del lugar por elevar al cuadrado
La condición $y=x$ determina una recta. La condición $y^2=x^2$ equivale a $(y=x)\lor(y=-x)$: determina **dos rectas**. En particular, $(-2,2)$ satisface $y^2=x^2$ y pertenece a la segunda recta, mientras que su coordenada $y$ es diferente de $x$. Es el contraejemplo que desarrolla el profesor en [57:50](https://www.youtube.com/watch?v=vxF8xwRmesA&t=3470s).


![Al elevar al cuadrado $y=x$ aparece la recta adicional $y=-x$; el punto $(-2,2)$ verifica únicamente la ecuación cuadrada.](figuras/IC2021_Catedra_3_1/06_cuadratura_no_equivale.png)

*Figura. Al elevar al cuadrado $y=x$ aparece la recta adicional $y=-x$; el punto $(-2,2)$ verifica únicamente la ecuación cuadrada.*

### Los cuatro ejemplos de circunferencias de la clase

**En la cátedra (1:02:37–1:16:28).** Después de un corte técnico de la transmisión, el profesor desarrolla cuatro ecuaciones de dificultad creciente. Conviene distinguir cuidadosamente los enunciados verbalizados de las lecturas que sugiere la explicación:

#### Ejemplo 1. Lectura directa
$$
(x-1)^2+(y-2)^2=3^2.
$$

Comparando con la ecuación canónica, el centro es $A=(1,2)$ y el radio es $r=3$.

#### Ejemplo 2. Discrepancia en la transcripción o el enunciado oral
Aproximadamente en [1:10:20](https://www.youtube.com/watch?v=vxF8xwRmesA&t=4220s) se reconoce verbalmente el enunciado $x^2+y^2=-1$, seguido de una discusión que identifica centro en el origen y radio $1$. Estas dos afirmaciones corresponden a ecuaciones distintas:

- **Si el enunciado es $x^2+y^2=-1$**, el conjunto solución es $\varnothing$: cada cuadrado es mayor o igual que cero, por lo que su suma también lo es.
- **Si el enunciado es $x^2+y^2=(-1)^2=1$**, el centro es $(0,0)$ y el radio es $1$; elevar $-1$ al cuadrado produce exactamente $1$.

La secuencia oral del docente se ajusta a la segunda interpretación, pero se conserva explícita la discrepancia. Para decidir la escritura exacta de la pizarra haría falta cotejar la imagen correspondiente del video.

#### Ejemplo 3. Identificación de signos y cuadrados
$$
(x+3)^2+(y+4)^2=(-5)^2.
$$

La expresión $(x+3)^2$ puede escribirse $(x-(-3))^2$ y análogamente para $y$. Como $(-5)^2=25$, el centro es $(-3,-4)$ y el radio es $5$.

#### Ejemplo 4. Completación de un cuadrado
El profesor considera

$$
x^2+y^2=-2x.
$$

Pasamos todos los términos al lado izquierdo y agrupamos los que contienen $x$:

$$
x^2+2x+y^2=0.
$$

Introducimos simultáneamente $+1$ y $-1$, operación que el profesor llama **«ni quita ni pone»**:

$$
\begin{aligned}
x^2+2x+y^2=0
&\iff x^2+2x+1+y^2=1\\
&\iff (x+1)^2+y^2=1.
\end{aligned}
$$

Por lo tanto, **centro $(-1,0)$ y radio $1$**. Durante la explicación se escucha fugazmente «menos uno, uno» al nombrar el centro; el cálculo escrito conduce a $(-1,0)$. Esta precisión es editorial y está apoyada en la ecuación que el docente ha demostrado.


![Dos ejemplos de la cátedra: circunferencia de centro $(1,2)$ y radio $3$, y circunferencia de centro $(-1,0)$ y radio $1$.](figuras/IC2021_Catedra_3_1/07_ejemplos_circunferencia.png)

*Figura. Dos ejemplos de la cátedra: circunferencia de centro $(1,2)$ y radio $3$, y circunferencia de centro $(-1,0)$ y radio $1$.*

### De la ecuación canónica a la ecuación general

**En la cátedra (1:16:34–1:20:20).** Expandimos ambos cuadrados de

$$
(x-x_0)^2+(y-y_0)^2=r^2.
$$

Aplicando la fórmula del cuadrado de un binomio,

$$
x^2-2x_0x+x_0^2+y^2-2y_0y+y_0^2=r^2.
$$

Al reagrupar se obtiene

$$
x^2+y^2+(-2x_0)x+(-2y_0)y+(x_0^2+y_0^2-r^2)=0.
$$

Con los nombres $A=-2x_0$, $B=-2y_0$ y $C=x_0^2+y_0^2-r^2$, toda circunferencia se expresa mediante

$$
\boxed{x^2+y^2+Ax+By+C=0.}
$$

Esta es la **forma general o desarrollada** de la ecuación. La cuestión inversa, que ocupa el resto de la clase, es determinar qué lugar geométrico describe dicha ecuación para valores arbitrarios de $A,B,C\in\mathbb R$.

### Clasificación completa mediante dos cuadrados

#### Transformación por equivalencias
**En la cátedra (1:21:21–1:29:03).** Para $A,B,C\in\mathbb R$ dados, estudiemos

$$
M=\{(x,y)\in\mathbb R^2:x^2+y^2+Ax+By+C=0\}.
$$

Reordenamos términos para completar dos cuadrados independientes. La identidad central para cada variable es

$$
x^2+Ax=\left(x+\frac A2\right)^2-\frac{A^2}{4}.
$$

Y también

$$
y^2+By=\left(y+\frac B2\right)^2-\frac{B^2}{4}.
$$

Sustituyendo y trasladando las constantes, cada paso es reversible:

$$
\begin{aligned}
x^2+y^2+Ax+By+C=0
&\iff \left(x+\frac A2\right)^2-\frac{A^2}{4}
+\left(y+\frac B2\right)^2-\frac{B^2}{4}+C=0\\
&\iff \boxed{\left(x+\frac A2\right)^2+\left(y+\frac B2\right)^2
=\frac{A^2+B^2-4C}{4}.}
\end{aligned}
$$

Introducimos los parámetros

$$
H=\left(-\frac A2,-\frac B2\right),\qquad
D=A^2+B^2-4C.
$$

La ecuación pasa a la forma $d((x,y),H)^2=D/4$. El signo de $D$ determina por completo el lugar geométrico. Este $D$ se introduce aquí como abreviatura editorial de la expresión que aparece en clase, para favorecer el análisis de casos; funciona como parámetro de clasificación del lugar circular.

#### Caso I: una circunferencia ($D>0$)
Si $D>0$, la cantidad $D/4$ es positiva y existe un radio real positivo

$$
r=\frac{\sqrt D}{2}.
$$

Así, $M$ es la **circunferencia** de centro $H$ y radio $r$. Es una figura con infinitos puntos que están a la misma distancia $r$ de $H$:

$$
\boxed{M=\mathcal C\!\left(\left(-\tfrac A2,-\tfrac B2\right),\tfrac{\sqrt{A^2+B^2-4C}}2\right).}
$$

La existencia de $\sqrt D$ para $D>0$ se utiliza en el nivel de la clase, con su justificación mediante completitud reservada para más adelante.

#### Caso II: un punto ($D=0$)
Si $D=0$,

$$
\left(x+\frac A2\right)^2+\left(y+\frac B2\right)^2=0.
$$

Como cada cuadrado es mayor o igual que cero, la igualdad equivale a las dos condiciones simultáneas

$$
x=-\frac A2,\qquad y=-\frac B2.
$$

El lugar consiste en **un solo punto**:

$$
\boxed{M=\left\{\left(-\tfrac A2,-\tfrac B2\right)\right\}.}
$$

La clase contempla la expresión «circunferencia de radio cero» como interpretación degenerada; en estas notas se sigue la elección terminológica del docente y se llama a este lugar **punto**.

#### Caso III: conjunto vacío ($D<0$)
Si $D<0$, el lado derecho es un real estrictamente negativo y el lado izquierdo una suma de cuadrados mayor o igual que cero. La igualdad es incompatible con los axiomas del orden; de ahí

$$
\boxed{M=\varnothing.}
$$

La condición de tricotomía fundamenta la separación excluyente entre los tres casos. La conclusión puede resumirse en la siguiente tabla:

| Signo de $D=A^2+B^2-4C$ | Lugar geométrico | Parámetros |
|:--|:--|:--|
| $D>0$ | Circunferencia | Centro $(-A/2,-B/2)$; radio $\sqrt D/2$ |
| $D=0$ | Punto | $(-A/2,-B/2)$ |
| $D<0$ | Conjunto vacío | Sin puntos del plano |


![Clasificación de $x^2+y^2+Ax+By+C=0$ según $D=A^2+B^2-4C$: circunferencia, punto o conjunto vacío.](figuras/IC2021_Catedra_3_1/08_tres_casos_circunferencia.png)

*Figura. Clasificación de $x^2+y^2+Ax+By+C=0$ según $D=A^2+B^2-4C$: circunferencia, punto o conjunto vacío.*

### Consecuencias conceptuales y conexiones

**Primera conexión: ecuaciones y conjuntos.** Cada cadena de equivalencias corresponde a una descripción distinta del mismo lugar geométrico. En cambio, una implicación unidireccional puede describir un conjunto de soluciones más amplio. Este cuidado es esencial al elevar ecuaciones al cuadrado y al multiplicar por expresiones cuyo valor podría anularse.

**Segunda conexión: geometría de la condición algebraica.** La expresión $x^2+y^2+Ax+By+C$ contiene la distancia cuadrática al punto $(-A/2,-B/2)$ una vez que se completa el cuadrado. La clasificación geométrica nace del signo de un número calculado exclusivamente a partir de los coeficientes.

**Tercera conexión: circunferencia y círculo.** Si $r>0$, la ecuación

$$
(x-x_0)^2+(y-y_0)^2=r^2
$$

caracteriza el borde. Las desigualdades $\le r^2$ y $<r^2$ determinan respectivamente el disco cerrado y el disco abierto. Las desigualdades $\ge r^2$ y $>r^2$ caracterizan las regiones exteriores correspondientes, incluyendo o excluyendo la circunferencia según el símbolo utilizado.

**Cuarta conexión: panorama del curso.** El cierre de la sesión, alrededor de [1:39:11](https://www.youtube.com/watch?v=vxF8xwRmesA&t=5951s), anuncia las **rectas** como tema de la clase siguiente. La cuestión de la existencia de raíces positivas se recuperará al estudiar completitud.

### Solucionario completo y razonado (E1–E16)

#### E1. Coordenadas y orden
La regla de igualdad de pares exige igualdad componente a componente. Las primeras coordenadas de $(3,2)$ y $(2,3)$ son distintas; las primeras de $(3,2)$ y $(-3,2)$ también lo son. Por tanto, los tres puntos son distintos. La primera coordenada se mide horizontalmente y la segunda verticalmente; $(3,2)$ está tres unidades hacia la derecha y dos hacia arriba, mientras que $(-3,2)$ está tres hacia la izquierda y dos hacia arriba.

#### E2. Ejes e intersección
El lugar de $x=0$ es $E_y=\{(0,y):y\in\mathbb R\}$; el de $y=0$ es $E_x=\{(x,0):x\in\mathbb R\}$. Por la propiedad del producto nulo,

$$
\{(x,y):xy=0\}=E_x\cup E_y.
$$

La conjunción de ambas ecuaciones identifica $E_x\cap E_y=\{(0,0)\}$, porque el origen es el único par con ambas coordenadas iguales a cero.

#### E3. Producto de coordenadas positivo
Por las reglas de signos, $xy>0$ ocurre cuando ambas coordenadas son positivas o cuando ambas son negativas. Por ello,

$$
\{(x,y):xy>0\}
=\{x>0,y>0\}\cup\{x<0,y<0\},
$$

donde la notación $\{x>0,y>0\}$ abrevia el conjunto de pares que cumplen esas dos condiciones. Son los cuadrantes I y III, con los ejes excluidos debido a que en cualquiera de ellos $xy=0$.

#### E4. Una unión de dos rectas
La igualdad $(x-1)(y+2)=0$ equivale a $(x-1=0)\lor(y+2=0)$. Los lugares correspondientes son la recta vertical $x=1$ y la horizontal $y=-2$; el conjunto buscado es su unión. Las dos rectas se encuentran en el punto $(1,-2)$.

#### E5. Distancia y simetría
$$
d((-2,1),(4,9))=\sqrt{(4+2)^2+(9-1)^2}
=\sqrt{36+64}=10.
$$

Al invertir el orden,

$$
d((4,9),(-2,1))=\sqrt{(-2-4)^2+(1-9)^2}=\sqrt{36+64}=10.
$$

Se trata de una comprobación concreta de la simetría de la fórmula.

#### E6. Distancia nula e igualdad de puntos
Si $A=B$, sus coordenadas coinciden; ambas diferencias son cero, por lo que $d(A,B)=0$. Recíprocamente, $d(A,B)=0$ lleva, tras elevar al cuadrado cantidades no negativas, a

$$
(x_2-x_1)^2+(y_2-y_1)^2=0.
$$

Cada sumando es mayor o igual que cero. Una suma de dos reales con esas propiedades vale cero exactamente cuando ambos valen cero. Luego $x_2-x_1=0$ y $y_2-y_1=0$, de donde $A=B$.

#### E7. Centro y radio dados; comprobación de pertenencia
La ecuación pedida es

$$
\boxed{(x-1)^2+(y-2)^2=9.}
$$

El punto $(1,5)$ satisface $0^2+3^2=9$ y pertenece a la circunferencia. Para $(0,0)$, la suma es $(-1)^2+(-2)^2=5$, que difiere de $9$; por tanto ese punto queda fuera de la circunferencia. Su distancia al centro es $\sqrt5$, estrictamente menor que $3$; se encuentra en el disco interior.

#### E8. Signos en la forma canónica
$$
(x+3)^2+(y+4)^2=25
\iff (x-(-3))^2+(y-(-4))^2=5^2.
$$

El centro es $(-3,-4)$ y el radio $5$.

#### E9. Una ecuación sin soluciones y una circunferencia
Para todo $(x,y)\in\mathbb R^2$, se tiene $x^2+y^2\ge0$; por ello la ecuación $x^2+y^2=-1$ determina el **conjunto vacío**. En cambio, $x^2+y^2=1$ equivale a $(x-0)^2+(y-0)^2=1^2$ y determina una circunferencia de centro $(0,0)$ y radio $1$. Este ejercicio corresponde a la discrepancia documental señalada en el ejemplo 2.

#### E10. Circunferencia desplazada sobre el eje horizontal
$$
\begin{aligned}
x^2+y^2=-2x
&\iff x^2+2x+y^2=0\\
&\iff x^2+2x+1+y^2=1\\
&\iff (x+1)^2+y^2=1.
\end{aligned}
$$

El centro es $(-1,0)$ y el radio es $1$. Cada línea se obtiene mediante una operación reversible, por lo que el lugar queda preservado.

#### E11. Clasificación por dos cuadrados
$$
\begin{aligned}
x^2+y^2-6x+8y+9=0
&\iff (x^2-6x+9)+(y^2+8y+16)=16\\
&\iff (x-3)^2+(y+4)^2=16.
\end{aligned}
$$

Se obtiene una circunferencia con centro $(3,-4)$ y radio $4$. La línea intermedia suma $9$ para completar la primera expresión y $16$ para completar la segunda; se compensan en el otro miembro.

#### E12. Clasificación del caso degenerado
$$
\begin{aligned}
x^2+y^2+2x-4y+5=0
&\iff (x+1)^2+(y-2)^2=0.
\end{aligned}
$$

La suma de dos cuadrados vale cero exactamente cuando cada cuadrado vale cero. Así $x=-1$, $y=2$; el lugar es el punto aislado $\{(-1,2)\}$.

#### E13. Clasificación del caso vacío
$$
x^2+y^2+2x-4y+6=0
\iff (x+1)^2+(y-2)^2=-1.
$$

El lado izquierdo es mayor o igual que cero y el derecho es estrictamente negativo. La condición determina $\varnothing$.

#### E14. Clasificación desde coeficientes generales
Para $A=4$, $B=-6$, $C=4$,

$$
D=A^2+B^2-4C=16+36-16=36>0.
$$

El centro es $(-A/2,-B/2)=(-2,3)$ y el radio es $\sqrt{36}/2=3$. En efecto,

$$
x^2+y^2+4x-6y+4=0
\iff (x+2)^2+(y-3)^2=9.
$$

#### E15. Interior y exterior de una circunferencia
La ecuación $(x-1)^2+(y+2)^2=9$ determina la circunferencia de centro $(1,-2)$ y radio $3$. La inecuación con $\le9$ describe el **disco cerrado**, formado por todos los puntos a distancia menor o igual que $3$ del centro. La inecuación con $>9$ describe la **región exterior abierta**, formada por los puntos a distancia estrictamente mayor que $3$.

#### E16. Una transformación no reversible por cuadratura
La diferencia de cuadrados proporciona

$$
x^2=y^2\iff x^2-y^2=0\iff(x-y)(x+y)=0
\iff(x=y)\lor(x=-y).
$$

En el plano son las rectas $y=x$ y $y=-x$. Por ejemplo, $(x,y)=(-2,2)$ satisface $x^2=y^2=4$ y pertenece a $y=-x$; sus coordenadas son diferentes y por eso el punto no pertenece a $y=x$. La condición cuadrática contiene el lugar original y otro adicional.

### Glosario y próximos pasos

**Geometría analítica.** Estudio de figuras mediante coordenadas y propiedades expresadas por ecuaciones e inecuaciones.

**Plano cartesiano.** Plano equipado con dos ejes orientados y perpendiculares que permiten asociar a cada punto un par ordenado de reales.

**Par ordenado.** Objeto $(x,y)$ determinado por una primera y una segunda coordenada; su igualdad se establece componente a componente.

**Lugar geométrico.** Conjunto de puntos de $\mathbb R^2$ caracterizado mediante una condición compartida.

**Distancia euclidiana.** Valor mayor o igual que cero calculado para dos puntos mediante la raíz de la suma de los cuadrados de las diferencias de coordenadas.

**Circunferencia.** Lugar de los puntos cuya distancia a un centro dado es exactamente un radio fijo positivo.

**Ecuación canónica.** Escritura $(x-x_0)^2+(y-y_0)^2=r^2$ que presenta explícitamente el centro y el radio.

**Ecuación general.** Escritura $x^2+y^2+Ax+By+C=0$ a partir de la expansión de los cuadrados; el signo de $A^2+B^2-4C$ determina el tipo de lugar.

**Completación de cuadrados.** Identidad algebraica que expresa un trinomio cuadrático como cuadrado de un binomio más una constante; permite identificar centros, radios y casos degenerados.

**Equivalencia de condiciones.** Relación lógica bidireccional que garantiza igualdad de conjuntos solución.

**Fuentes y límite documental.** Jorge San Martín, *IC21: Cátedra 3.1 (lunes 29 de marzo de 2021, 12:00)*, grabación en YouTube y transcripción automática disponible en la página del video. El registro oral se interrumpe brevemente por un problema técnico en torno a 1:03:40 y se reanuda aproximadamente en 1:08:56. Los dos posibles lapsus señalados al comienzo requieren cotejo visual de la pizarra para establecer qué se mostró exactamente; su diagnóstico algebraico es independiente de esa verificación. Las demostraciones y los ejercicios de ampliación se identifican editorialmente y se han contrastado con los resultados algebraicos.

**Continuación del curso:** la siguiente cátedra aborda las **rectas** en el plano. La distancia euclidiana y la ecuación de la circunferencia proporcionan el primer modelo completo de traducción entre un lugar geométrico y una ecuación en $\mathbb R^2$.

*Procedencia de este tramo: cátedra 3.2.*

### La recta como lugar geométrico

**En la cátedra (07:42–18:57).** La geometría clásica caracteriza una recta mediante sus propiedades, entre ellas la existencia de una única recta por cada par de puntos distintos. La geometría analítica utiliza una ecuación para caracterizar el conjunto de sus puntos. Fijados $A,B,C\in\mathbb R$ tales que

$$
A^2+B^2>0,
$$

se define el lugar geométrico

$$
\boxed{L_{A,B,C}=\{(x,y)\in\mathbb R^2:Ax+By+C=0\}.}
$$

La condición $A^2+B^2>0$ asegura que el par $(A,B)$ aporta una dirección normal bien determinada. Puesto que los cuadrados son no negativos, equivale a la disyunción

$$
\boxed{(A\ne0)\ \lor\ (B\ne0).}
$$

**Desarrollo lógico de la clase.** La identidad $A^2+B^2=0$ equivale a $(A=0)\land(B=0)$. Al negar ambas expresiones se obtiene, mediante las leyes de De Morgan, la disyunción anterior. El profesor insiste en que **al menos uno** de $A,B$ es distinto de cero; son admisibles los tres casos $(0,B)$ con $B\ne0$, $(A,0)$ con $A\ne0$, y $(A,B)$ con ambos distintos de cero.

#### Tres familias de rectas
**En la cátedra (19:14–22:50).** La ecuación general produce tres tipos geométricos:

- Con $A=0$, tenemos $B\ne0$ y $By+C=0$, equivalente a $y=-C/B$: **recta horizontal**.
- Con $B=0$, tenemos $A\ne0$ y $Ax+C=0$, equivalente a $x=-C/A$: **recta vertical**.
- Con $A\ne0$ y $B\ne0$, la recta presenta variación de ambas coordenadas y se denomina **oblicua**.

En los dos primeros casos el despeje utiliza el coeficiente cuya condición garantiza que es distinto de cero. Las tres familias pertenecen a la misma definición de lugar geométrico.

![Rectas horizontales, verticales y oblicuas identificadas por las constantes A y B.](figuras/IC2021_Catedra_3_2/01_familias_rectas.png)

*Figura 1. La clasificación procede de los coeficientes de la ecuación general.*

#### Construcción de dos puntos distintos
**En la cátedra (22:51–31:13).** Cuando $A,B\ne0$, las intersecciones con los ejes proporcionan candidatos inmediatos:

$$
P=\left(0,-\frac CB\right),\qquad Q=\left(-\frac CA,0\right).
$$

Al sustituirlos en $Ax+By+C$ se obtiene cero. Si $C\ne0$, las abscisas de $P,Q$ son distintas y sus ordenadas también. Si $C=0$, ambos candidatos coinciden en el origen y el profesor propone otra construcción:

$$
P=(0,0),\qquad Q=(B,-A).
$$

En efecto, $A\cdot B+B\cdot(-A)=0$, y las dos coordenadas de $Q$ son distintas de cero porque $A,B\ne0$. Esta separación de casos evita concluir unicidad o distinción a partir de dos puntos que podrían coincidir.

![Intersecciones con los ejes de una recta oblicua y caso de recta que pasa por el origen.](figuras/IC2021_Catedra_3_2/02_interceptos.png)

*Figura 2. Los interceptos son distintos si $C\ne0$; cuando $C=0$, el punto $(B,-A)$ proporciona un segundo punto.*

### Teorema fundamental: la pendiente

**En la cátedra (34:08–49:30).** Para una recta no vertical $Ax+By+C=0$ se tiene $B\ne0$. Si $P_1=(x_1,y_1)$ y $P_2=(x_2,y_2)$ son dos puntos distintos de la recta, su **pendiente** queda caracterizada por

$$
\boxed{m=\frac{y_2-y_1}{x_2-x_1}=-\frac AB.}
$$

El resultado afirma que el cociente de incrementos es el mismo para cualquier elección de dos puntos distintos. La demostración justifica simultáneamente la independencia de los puntos y la existencia del denominador.

#### Demostración algebraica paso a paso
Como ambos puntos pertenecen al lugar geométrico, cumplen

$$
Ax_1+By_1+C=0,\qquad Ax_2+By_2+C=0.
$$

Restamos la primera identidad de la segunda; la constante $C$ desaparece:

$$
A(x_2-x_1)+B(y_2-y_1)=0.
$$

El despeje de las ordenadas es legítimo porque $B\ne0$:

$$
\boxed{y_2-y_1=-\frac AB(x_2-x_1).}
$$

**Justificación del divisor $x_2-x_1$.** Si $x_2=x_1$, la igualdad recién obtenida da $y_2-y_1=0$; entonces $y_2=y_1$. Ambos puntos tendrían las mismas coordenadas, contrariamente a que fueron escogidos distintos. Luego $x_2-x_1\ne0$, y dividimos:

$$
\frac{y_2-y_1}{x_2-x_1}=-\frac AB.
$$

El miembro derecho depende de los coeficientes de la recta y permanece fijo al elegir cualquier par de puntos. Queda demostrada la propiedad y legitimado el nombre *pendiente* para ese número único.

#### Significado geométrico: triángulos semejantes
**En la cátedra (52:12–54:18).** Si tres puntos distintos están en una recta no vertical, sus incrementos horizontales y verticales forman triángulos rectángulos semejantes. Cada triángulo cumple la proporción altura/base igual a $m$ (con signo si el sentido de desplazamiento importa). La constancia del cociente es, por tanto, una expresión algebraica de la alineación de los puntos.

![Dos triángulos rectángulos sobre una misma recta muestran la constancia de Delta y dividido por Delta x.](figuras/IC2021_Catedra_3_2/03_pendiente_semejanza.png)

*Figura 3. Dos desplazamientos distintos proporcionan el mismo cociente $\Delta y/\Delta x$.*

#### Incrementos e interpretación del signo
**En la cátedra (54:32 y siguientes: comienzo comprobado).** La ecuación anterior puede escribirse $\Delta y=m\Delta x$. Cuando $\Delta x>0$, el signo de $m$ determina si el desplazamiento correspondiente en $y$ es ascendente, horizontal o descendente. Este hecho se aprecia en las tres gráficas siguientes.

![Pendientes positiva, cero y negativa para aumentos de abscisa.](figuras/IC2021_Catedra_3_2/04_signo_pendiente.png)

*Figura 4. El signo de la pendiente describe el cambio de ordenadas ante un incremento positivo de abscisas.*

### Formas equivalentes de la ecuación de una recta

**Ampliación editorial de sistematización.** Las identidades siguientes se deducen del teorema de la pendiente y de la ecuación general; se incluyen para practicar el tránsito de la descripción geométrica a las ecuaciones.

#### Forma explícita o pendiente–ordenada
Como $B\ne0$, dividimos la ecuación $Ax+By+C=0$ por $B$:

$$
\boxed{y=mx+n,\qquad m=-\frac AB,\quad n=-\frac CB.}
$$

El número $n$ es la ordenada del punto de intersección con el eje vertical: cuando $x=0$, $y=n$. La pendiente expresa el cambio $m$ de la ordenada por cada unidad de incremento horizontal.

#### Forma punto–pendiente
Si $P_0=(x_0,y_0)$ pertenece a una recta con pendiente $m$, todo punto $(x,y)$ de ella satisface

$$
\boxed{y-y_0=m(x-x_0).}
$$

Para verificar su equivalencia, se sustituye $y_0=mx_0+n$ en $y=mx+n$ y se resta: $y-y_0=m(x-x_0)$. Recíprocamente, distribuir la última igualdad produce una ecuación explícita con $n=y_0-mx_0$.

#### Recta determinada por dos puntos
Para $P_1=(x_1,y_1)$ y $P_2=(x_2,y_2)$ con $x_1\ne x_2$, la pendiente calculada por sus coordenadas conduce a

$$
\boxed{y-y_1=\frac{y_2-y_1}{x_2-x_1}(x-x_1).}
$$

Para admitir también una recta vertical, puede emplearse la forma general sin cocientes:

$$
\boxed{(y_2-y_1)(x-x_1)-(x_2-x_1)(y-y_1)=0.}
$$

Si $x_1=x_2$, esta ecuación representa la recta $x=x_1$; si $y_1=y_2$, representa $y=y_1$. La condición de puntos distintos asegura que ambos incrementos no se anulan simultáneamente.

![La forma punto-pendiente describe una recta a partir de un punto conocido y una razón entre incrementos.](figuras/IC2021_Catedra_3_2/05_punto_pendiente.png)

*Figura 5. La ecuación $y-y_0=m(x-x_0)$ es una relación entre el desplazamiento desde $P_0$ y la pendiente.*

### Propiedades y aplicaciones geométricas

**Ampliación editorial.** Se completan las consecuencias algebraicas más útiles de la definición de pendiente.

#### Rectas paralelas y perpendiculares
Dos rectas no verticales con pendientes $m_1,m_2$ son paralelas cuando tienen igual pendiente. La igualdad $m_1=m_2$ determina la misma dirección; para que sean rectas distintas sus ordenadas al origen deben diferir.

Dos rectas con pendientes finitas y distintas de cero son perpendiculares cuando

$$
\boxed{m_1m_2=-1.}
$$

Una demostración usa los vectores directores $u_1=(1,m_1)$ y $u_2=(1,m_2)$: su producto escalar es $1+m_1m_2$, que vale cero exactamente en el caso perpendicular. La pareja vertical $x=k$ y horizontal $y=h$ es también perpendicular.

![Rectas paralelas y rectas perpendiculares en el plano cartesiano.](figuras/IC2021_Catedra_3_2/06_paralelas_perpendiculares.png)

*Figura 6. Igualdad de pendientes y ortogonalidad de direcciones.*

#### Intersección de dos rectas
Sean $L_i:A_ix+B_iy+C_i=0$, $i=1,2$, y defínase

$$
D=A_1B_2-A_2B_1.
$$

Si $D\ne0$, las ecuaciones tienen un punto común único. Por eliminación (o por la regla de Cramer):

$$
\boxed{x=\frac{B_1C_2-B_2C_1}{D},\qquad y=\frac{A_2C_1-A_1C_2}{D}.}
$$

Si $D=0$, los vectores normales $(A_1,B_1)$ y $(A_2,B_2)$ son proporcionales. Las rectas tienen entonces la misma dirección; serán coincidentes cuando la proporción incluya las constantes $C_i$, y paralelas distintas cuando estas definan lugares diferentes.

#### Distancia de un punto a una recta
Para $P=(p,q)$ y $L:Ax+By+C=0$, con $A^2+B^2>0$, la distancia euclidiana es

$$
\boxed{d(P,L)=\frac{|Ap+Bq+C|}{\sqrt{A^2+B^2}}.}
$$

Esta fórmula se obtiene proyectando el vector que une $P$ con un punto de $L$ sobre el vector normal $(A,B)$. Se incorpora como aplicación avanzada y conserva la conexión con la distancia euclidiana estudiada en la Cátedra 3.1.

### Síntesis de estudio

La cátedra transforma una ecuación lineal en un objeto geométrico. El encadenamiento conceptual comienza con $A^2+B^2>0$, pasa por la clasificación de rectas, construye puntos pertenecientes al lugar, demuestra que el cociente $\Delta y/\Delta x$ es constante para rectas no verticales y asocia a ese número el nombre pendiente. La similitud de triángulos aporta la lectura geométrica de la misma propiedad algebraica.

En las ampliaciones, las fórmulas $y=mx+n$, $y-y_0=m(x-x_0)$ y la ecuación por dos puntos permiten invertir la dirección del razonamiento: datos geométricos determinan ecuaciones concretas. Paralelismo, perpendicularidad e intersecciones se describen mediante relaciones entre coeficientes.

**Control de rigor.** Toda división se realiza después de constatar que el denominador es distinto de cero. La distinción entre implicación y equivalencia preserva el conjunto solución cuando se transforman ecuaciones. Las fórmulas de pendiente finita corresponden a rectas no verticales; la ecuación general incluye también las verticales.

**Fuente principal:** [Jorge San Martín, *IC21: Cátedra 3.2* (31 de marzo de 2021)](https://www.youtube.com/watch?v=h-eNbC2gUpw), lista *Introducción al Cálculo (base 2021)*. La reconstrucción de la primera parte se apoya en la transcripción automática recuperada. Las secciones expresamente tituladas *ampliación editorial* contienen sistematizaciones y problemas añadidos para el estudio.

### Taller de problemas y soluciones

Los ejercicios se presentan a continuación según la fuente de origen; las ampliaciones editoriales de cada apuntes permanecen expresamente identificadas.

#### Ejercicios propuestos para el estudio — cátedra 3.1

Los dieciséis ejercicios siguientes son una **elaboración editorial**. Algunos retoman ejemplos del profesor y otros consolidan y extienden los métodos estudiados; sus soluciones aparecen íntegramente a continuación. Se recomienda intentar cada problema antes de leer el solucionario.

**E1.** Determinar cuáles de los pares $(3,2)$, $(2,3)$ y $(-3,2)$ coinciden e interpretar sus coordenadas.

**E2.** Identificar los lugares de $x=0$, $y=0$, $xy=0$ y $x=0\land y=0$, justificando las relaciones de conjuntos.

**E3.** Describir el lugar $xy>0$ y decidir qué ocurre con los ejes.

**E4.** Interpretar geométricamente $(x-1)(y+2)=0$.

**E5.** Calcular la distancia entre $(-2,1)$ y $(4,9)$; verificar su invariancia al permutar los puntos.

**E6.** Probar que $d(A,B)=0$ si y solo si $A=B$, usando la fórmula euclidiana.

**E7.** Hallar la ecuación de la circunferencia de centro $(1,2)$ y radio $3$; comprobar si $(1,5)$ y $(0,0)$ pertenecen a ella.

**E8.** Encontrar centro y radio de $(x+3)^2+(y+4)^2=25$.

**E9.** Clasificar el lugar $x^2+y^2=-1$ y comparar con $x^2+y^2=1$.

**E10.** Llevar $x^2+y^2=-2x$ a la forma canónica y señalar centro y radio.

**E11.** Clasificar el lugar $x^2+y^2-6x+8y+9=0$.

**E12.** Clasificar $x^2+y^2+2x-4y+5=0$.

**E13.** Clasificar $x^2+y^2+2x-4y+6=0$.

**E14.** Para $A=4$, $B=-6$, $C=4$, determinar centro y radio del lugar $x^2+y^2+Ax+By+C=0$.

**E15.** Describir en $\mathbb R^2$ los lugares $(x-1)^2+(y+2)^2\le9$ y $(x-1)^2+(y+2)^2>9$.

**E16.** Justificar que la ecuación $x^2=y^2$ describe dos rectas y construir un punto que satisfaga esa ecuación y no $x=y$.

#### Ejercicios propuestos y soluciones detalladas — cátedra 3.2

Los ejercicios E1–E16 son una colección de práctica editorial: retoman los resultados demostrados en clase y sus consecuencias. La fuente de la cátedra se identifica cuando se usa una construcción efectivamente explicada por el profesor. Los dibujos acompañan la interpretación, mientras que las pruebas algebraicas determinan los resultados.

#### E1. Clasificar una recta por sus coeficientes
**Problema.** Identificar el tipo de recta dado por $3x-6=0$, por $-2y+8=0$ y por $2x+3y-12=0$.

**Solución.** En $3x-6=0$ el coeficiente de $y$ es cero y el de $x$ vale $3$: la recta vertical es $x=2$. En $-2y+8=0$ el coeficiente de $x$ es cero y el de $y$ vale $-2$: la recta horizontal es $y=4$. En $2x+3y-12=0$ ambos coeficientes son distintos de cero: es oblicua y su pendiente vale $-2/3$. La clasificación procede directamente del análisis de los tres casos de la cátedra.

#### E2. Interpretar correctamente $A^2+B^2>0$
**Problema.** Demostrar que $A^2+B^2>0$ equivale a $A\ne0$ o $B\ne0$.

**Solución.** La propiedad de orden establece $A^2,B^2\ge0$. Si al menos uno de los dos números es distinto de cero, su cuadrado es positivo, y al sumar el otro cuadrado (no negativo) se obtiene una suma positiva. Recíprocamente, si la suma es positiva, al menos uno de sus sumandos es positivo: el correspondiente real tiene cuadrado positivo y es distinto de cero. Así quedan demostradas ambas implicaciones. La disyunción es inclusiva: abarca también el caso donde ambos son distintos de cero.

#### E3. Dos puntos en el caso $C=0$
**Problema.** Para $Ax+By=0$, con $A,B\ne0$, comprobar que $(0,0)$ y $(B,-A)$ pertenecen a la recta y son distintos.

**Solución.** Sustituir $(0,0)$ produce $A\cdot0+B\cdot0=0$. En el segundo punto la expresión es $AB+B(-A)=AB-AB=0$. Como $B\ne0$, la abscisa del segundo punto difiere de la del origen; asimismo $-A\ne0$ asegura distinta ordenada. Ambos puntos son miembros distintos del lugar geométrico. Esta es la construcción utilizada en la clase alrededor de [29:18](https://www.youtube.com/watch?v=h-eNbC2gUpw&t=1758s).

#### E4. Interceptos de una recta oblicua
**Problema.** Encontrar los puntos donde $2x+3y-12=0$ corta los ejes.

**Solución.** En el eje $x$ se tiene $y=0$, de modo que $2x-12=0$ y $x=6$. La intersección es $(6,0)$. En el eje $y$ se tiene $x=0$, de modo que $3y-12=0$ y $y=4$. La segunda intersección es $(0,4)$. Verificación: $2(6)+3(0)-12=0$ y $2(0)+3(4)-12=0$. La recta pasa por esos dos puntos distintos.

#### E5. Calcular la pendiente desde dos puntos
**Problema.** Hallar la pendiente de la recta por $P=(-1,2)$ y $Q=(3,6)$.

**Solución.** La diferencia de ordenadas es $6-2=4$ y la de abscisas es $3-(-1)=4$. Por lo tanto $m=4/4=1$. Si intercambiamos el orden de los puntos, $m=(2-6)/(-1-3)=(-4)/(-4)=1$. El valor se conserva porque numerador y denominador cambian de signo simultáneamente.

#### E6. Pendiente de una ecuación general
**Problema.** Para $6x-4y+7=0$, calcular la pendiente y la forma explícita.

**Solución.** Como $B=-4\ne0$, la recta posee pendiente $m=-A/B=-6/(-4)=3/2$. Despejando: $-4y=-6x-7$ y, al dividir por $-4$, $y=(3/2)x+7/4$. Ambas expresiones coinciden en el coeficiente de $x$ y son equivalentes para todos los puntos del plano.

#### E7. Recuperar la ecuación desde punto y pendiente
**Problema.** Determinar la recta de pendiente $-2$ que pasa por $(1,3)$.

**Solución.** Por la forma punto–pendiente, $y-3=-2(x-1)$. Distribuyendo: $y-3=-2x+2$ y luego $y=-2x+5$. Su forma general es $2x+y-5=0$. El punto dado satisface $2(1)+3-5=0$, y el coeficiente de $x$ en la forma explícita es la pendiente prescrita.

#### E8. Recta por dos puntos sin dividir por cero
**Problema.** Determinar la recta que pasa por $(2,-1)$ y $(2,5)$.

**Solución.** Ambos puntos comparten abscisa $x=2$, por lo que el lugar es la recta vertical $x=2$. Su ecuación general es $x-2=0$. El cociente $(5-(-1))/(2-2)$ tiene denominador cero y, por esa razón, la fórmula de pendiente finita queda fuera de su dominio de aplicación. La representación general cubre el caso sin introducir una división.

#### E9. Recta horizontal
**Problema.** Encontrar la recta que pasa por $(-3,4)$ y $(2,4)$.

**Solución.** Los puntos comparten ordenada $y=4$. La recta es horizontal y satisface $y-4=0$. Su pendiente es $m=(4-4)/(2-(-3))=0/5=0$, en concordancia con $A=0$ en la ecuación general.

#### E10. Forma de dos puntos
**Problema.** Obtener la ecuación por $P=(1,2)$ y $Q=(4,-1)$.

**Solución.** Puesto que las abscisas difieren, $m=(-1-2)/(4-1)=-3/3=-1$. Por tanto $y-2=-(x-1)$, de donde $y=-x+3$ o $x+y-3=0$. Las comprobaciones son $1+2-3=0$ y $4+(-1)-3=0$.

#### E11. Paralela por un punto
**Problema.** Construir la recta paralela a $2x-3y+6=0$ que pasa por $(3,-1)$.

**Solución.** Toda recta con la misma dirección normal puede escribirse $2x-3y+C=0$. Se impone el punto: $2(3)-3(-1)+C=0$, esto es, $9+C=0$, de modo que $C=-9$. La recta pedida es $2x-3y-9=0$. Sus pendientes coinciden y son $2/3$, mientras que las constantes distintas distinguen ambos lugares.

#### E12. Perpendicular por un punto
**Problema.** Obtener la recta perpendicular a $y=2x+1$ que pasa por $(2,0)$.

**Solución.** La pendiente de la primera es $2$. La perpendicular tiene pendiente $-1/2$ porque $2(-1/2)=-1$. Aplicando punto–pendiente: $y-0=-(1/2)(x-2)$, de modo que $y=-x/2+1$ o $x+2y-2=0$. Su dirección forma ángulo recto con la dirección $(1,2)$.

#### E13. Intersección de dos rectas
**Problema.** Resolver el sistema $2x+y=5$, $x-y=1$ e interpretar el resultado.

**Solución.** De la segunda ecuación $y=x-1$. Sustituimos en la primera: $2x+(x-1)=5$, de donde $3x=6$ y $x=2$. Entonces $y=1$. El punto común es $(2,1)$ y satisface las dos igualdades. El determinante de los coeficientes es $2(-1)-1(1)=-3\ne0$, por lo que la intersección es única.

#### E14. Distinguir paralelismo y coincidencia
**Problema.** Comparar $2x+4y-6=0$ con $x+2y-3=0$ y con $x+2y+1=0$.

**Solución.** Multiplicar la segunda ecuación por $2$ reproduce exactamente la primera; ambas definen el mismo conjunto y son rectas coincidentes. La tercera tiene los coeficientes $x,y$ proporcionales a los de la primera y diferente término libre proporcional: representa una recta paralela distinta. Las pendientes de las tres ecuaciones son $-1/2$.

#### E15. Distancia a una recta (aplicación avanzada)
**Problema.** Calcular la distancia desde $P=(1,2)$ hasta $3x+4y-5=0$.

**Solución.** El numerador es $|3(1)+4(2)-5|=|6|=6$. El denominador es $\sqrt{3^2+4^2}=\sqrt{25}=5$. Por tanto $d(P,L)=6/5$. La elección de $3,4$ permite comprobar explícitamente la norma del vector normal; la distancia es un número no negativo.

#### E16. Reconstruir el teorema de la pendiente con todas las hipótesis
**Problema.** Justificar que todo par de puntos distintos de $Ax+By+C=0$, con $B\ne0$, determina el mismo cociente de diferencias.

**Solución.** Para cada punto $P_i$ vale $Ax_i+By_i+C=0$. La resta de estas ecuaciones da $A\Delta x+B\Delta y=0$. Como $B\ne0$, despejamos $\Delta y=-(A/B)\Delta x$. Si $\Delta x=0$, entonces también $\Delta y=0$, y ambos puntos serían iguales. Por hipótesis son distintos; por tanto $\Delta x\ne0$. Dividir da $\Delta y/\Delta x=-A/B$, expresión independiente de $P_1$ y $P_2$. La existencia de un valor constante y su unicidad se siguen de que todos los cocientes posibles coinciden con ese real.

---

## Cónicas y curvas cuadráticas

Las parábolas, elipses e hipérbolas se describen mediante condiciones geométricas que conducen a ecuaciones. Las traslaciones, la completación de cuadrados y el discriminante permiten interpretar dichas ecuaciones.

**Grabaciones de referencia:** [grabación de la cátedra 4.1](https://www.youtube.com/watch?v=7qlkE41AITo), [grabación de la cátedra 4.2](https://www.youtube.com/watch?v=E2KL0qm2vIg).

*Procedencia de este tramo: cátedra 4.1.*

### Cónicas: foco, directriz y excentricidad

#### Lugar geométrico asociado a una razón de distancias
**En la cátedra (09:59–13:30).** Se fija una recta $d$ del plano, denominada **directriz**, un punto $F$ exterior a dicha recta, denominado **foco**, y un real $e>0$, denominado **excentricidad**. La cónica correspondiente es el lugar geométrico

$$
\boxed{\mathcal C(F,d,e)=\{P\in\mathbb R^2: d(P,F)=e\,d(P,d)\}.}
$$

Aquí $d(P,F)$ representa la distancia euclidiana entre dos puntos, mientras que $d(P,d)$ es la distancia perpendicular desde $P$ a la recta $d$. La igualdad describe todos los puntos para los que la razón entre las distancias al foco y a la directriz vale $e$. El requisito $F\notin d$ hace que el foco y la recta fijen una configuración geométrica bien determinada.

El profesor menciona también $e=0$: la igualdad se reduce a $d(P,F)=0$, cuyo lugar es el punto $\{F\}$. En estas notas, siguiendo la convención de la clase, trabajamos con $e>0$.

#### Los tres casos de la excentricidad
| Excentricidad | Nombre del lugar | Lectura de las distancias |
|:--|:--|:--|
| $0<e<1$ | **Elipse** | $d(P,F)<d(P,d)$ para cada punto del lugar. |
| $e=1$ | **Parábola** | $d(P,F)=d(P,d)$. |
| $e>1$ | **Hipérbola** | $d(P,F)>d(P,d)$. |

La clase se concentra en $e=1$. El desarrollo formal de la elipse y de la hipérbola queda anunciado para el viernes de la semana 4. Esta clasificación procede de la definición mediante foco y directriz que utiliza el docente.

### El vértice y la elección de coordenadas

#### Vértice: el punto de equidistancia sobre el eje focal
**En la cátedra (18:02–21:44).** Sea $F'$ la proyección perpendicular del foco $F$ sobre la directriz. En el segmento $FF'$ existe un punto que dista lo mismo de $F$ que de $F'$: su punto medio $V$. Como $d(V,d)=d(V,F')$ y $d(V,F)=d(V,F')$, el punto $V$ pertenece a la parábola. Recibe el nombre de **vértice**.

El segmento $FF'$ fija asimismo una recta, perpendicular a la directriz, que constituye el **eje de simetría**. Elegir el origen en $V$ y uno de los ejes coordenados sobre esa recta simplifica la ecuación y hace visible su geometría.

#### Normalización horizontal
Colocamos el vértice en $O=(0,0)$ y el eje focal sobre el eje $x$. Escribimos

$$
\boxed{F=(p,0),\qquad d:\ x=-p,\qquad p\in\mathbb R\setminus\{0\}.}
$$

La condición $p\ne0$ expresa que el foco se encuentra a distancia $|p|$ del vértice. El pie de la perpendicular desde $F$ a la directriz es $F'=(-p,0)$, cuyo punto medio con $F$ es efectivamente el origen. Para $p>0$ el foco está a la derecha del vértice; para $p<0$ está a la izquierda. En ambos casos las distancias $d(O,F)$ y $d(O,d)$ valen $|p|$.

![Foco, directriz y distancias iguales de un punto de la parábola.](figuras/IC2021_Catedra_4_1/01_foco_directriz.png)

*Figura 1. El punto $P=(x,y)$ tiene la misma distancia al foco $F=(p,0)$ que a su proyección $Q=(-p,y)$ sobre la directriz. Se ilustra el caso $p>0$.*

### Deducción de la ecuación canónica

**Demostración de la cátedra (26:24–33:12), reconstruida.** Sea $P=(x,y)$. La igualdad de distancias que define la parábola es

$$
d(P,F)=d(P,d).
$$

Para determinar la distancia a la recta $d:x=-p$, tomamos $Q=(-p,y)$, el pie de la perpendicular a la directriz. Por la fórmula de Pitágoras y la igualdad de las ordenadas de $P$ y $Q$,

$$
\begin{aligned}
d(P,F)^2&=(x-p)^2+y^2,\\
d(P,d)^2=d(P,Q)^2&=(x+p)^2.
\end{aligned}
$$

Las dos distancias son reales mayores o iguales que cero. Por consiguiente, la igualdad entre ellas equivale a la igualdad entre sus cuadrados. Sustituyendo y desarrollando,

$$
\begin{aligned}
d(P,F)=d(P,d)
&\iff (x-p)^2+y^2=(x+p)^2\\
&\iff x^2-2px+p^2+y^2=x^2+2px+p^2\\
&\iff y^2=4px.
\end{aligned}
$$

Todos los pasos son equivalencias algebraicas válidas, y el paso de las distancias a los cuadrados preserva la equivalencia porque ambas son no negativas. Queda así probado el resultado en **ambos sentidos**:

$$
\boxed{P=(x,y)\in\mathcal P\iff y^2=4px,\quad p\ne0.}
$$

El parámetro $p$ tiene significado geométrico: la distancia del vértice al foco, y también del vértice a la directriz, es $|p|$. La fórmula $y^2=4px$ es la **ecuación canónica de la parábola de eje horizontal con vértice en el origen**.

### La geometría contenida en la ecuación

#### Región donde se encuentra la parábola
**En la cátedra (37:00–40:54).** Todo cuadrado es mayor o igual que cero. Si $(x,y)$ satisface $y^2=4px$, entonces $4px\ge0$. Como $4>0$, la posición de cada punto depende del signo de $p$:

$$
\begin{cases}
p>0\ \Longrightarrow\ x\ge0,\\
p<0\ \Longrightarrow\ x\le0.
\end{cases}
$$

De este modo, la parábola se abre hacia la derecha cuando $p>0$ y hacia la izquierda cuando $p<0$. El vértice $(0,0)$ pertenece a ambas configuraciones; para $x=0$, la ecuación exige $y=0$.

#### Simetría respecto del eje horizontal
**En la cátedra (41:30–46:59).** Si $(x_0,y_0)$ pertenece a la parábola, $y_0^2=4px_0$. Como $(-y_0)^2=y_0^2$, también $(x_0,-y_0)$ pertenece. La transformación

$$
(x,y)\longmapsto(x,-y)
$$

conserva el lugar geométrico; es la reflexión respecto del eje de las abscisas. Por tanto, **el eje $x$ es eje de simetría de $y^2=4px$**.

![Parábolas horizontales de signos opuestos del parámetro p.](figuras/IC2021_Catedra_4_1/02_aperturas_horizontales.png)

*Figura 2. El signo de $p$ determina el sentido de apertura; ambos lugares tienen vértice en el origen y simetría respecto del eje $x$.*

#### Crecimiento de una rama y forma del gráfico
**En la cátedra (56:59–1:02:24).** Si $p>0$, en el primer cuadrante el parámetro $y$ es positivo y la ecuación puede expresarse como

$$
y=\sqrt{4px}=2\sqrt{px}.
$$

Consideremos $0\le x_1<x_2$ y las alturas correspondientes $y_1,y_2\ge0$. Entonces $4px_1<4px_2$, de donde $y_1^2<y_2^2$. Como la función cuadrado preserva el orden de los números no negativos, $y_1<y_2$. La rama superior crece cuando avanzamos hacia la derecha. La inferior es su reflejo respecto del eje horizontal.

El docente propone un argumento adicional mediante las intersecciones con rectas, que desarrollamos en la sección siguiente. Dicho argumento establece una cota de dos puntos de corte y permite descartar los dibujos oscilatorios considerados provisionalmente en la pizarra.

### Intersecciones con rectas: a lo sumo dos puntos

#### Una recta no vertical
**En la cátedra (49:22–55:55).** Para estudiar las intersecciones con una recta $r:y=mx+n$, sustituimos su ecuación en $y^2=4px$:

$$
(mx+n)^2=4px.
$$

Al desarrollar y ordenar se obtiene la ecuación en $x$

$$
\boxed{m^2x^2+(2mn-4p)x+n^2=0.}\tag{I}
$$

Si $m=0$, la recta es horizontal: $y=n$. La ecuación (I) se convierte en $-4px+n^2=0$. Como $p\ne0$, tiene una única solución,

$$
\boxed{(x,y)=\left(\frac{n^2}{4p},n\right).}
$$

Si $m\ne0$, el coeficiente de $x^2$ es $m^2>0$ y la ecuación es cuadrática. Su discriminante decide el número de soluciones reales: cero, una o dos. Cada raíz $x$ determina un único valor $y=mx+n$. Por ello, una recta de pendiente finita intersecta la parábola en **a lo sumo dos puntos**.

#### Una recta vertical — ampliación editorial
Para cubrir todas las rectas del plano consideremos $x=c$. Sustituyendo en la parábola,

$$
y^2=4pc.
$$

Si $pc>0$, hay dos puntos $(c,\pm2\sqrt{pc})$; si $c=0$, el único punto de corte es el vértice; si $pc<0$, el conjunto de cortes es vacío. Así, las rectas verticales también tienen a lo sumo dos intersecciones. La prueba completa incluye, por tanto, **toda recta del plano**, horizontal, oblicua o vertical.

La cátedra utiliza esta restricción de intersecciones para explicar la forma regular de la parábola. La conclusión formal que hemos demostrado es la cota de cardinalidad de las intersecciones; la descripción de una curva «sin oscilaciones» es su interpretación geométrica en la exposición.

### El discriminante y las tangentes

#### La clasificación por el discriminante
**En la cátedra (1:10:55–1:17:45).** Supongamos ahora $m\ne0$. Para la ecuación (I), el discriminante es

$$
\begin{aligned}
\Delta
&=(2mn-4p)^2-4m^2n^2\\
&=4m^2n^2-16mnp+16p^2-4m^2n^2\\
&=\boxed{16p(p-mn)}.
\end{aligned}
$$

| Condición | Intersección de la recta con la parábola |
|:--|:--|
| $p(p-mn)>0$ | Dos puntos distintos: secante. |
| $p(p-mn)=0$ | Un punto con raíz cuadrática doble: tangente. |
| $p(p-mn)<0$ | Conjunto vacío: recta exterior. |

Como $p\ne0$, la condición de tangencia se reduce a

$$
\boxed{mn=p.}
$$

Esta condición relaciona la pendiente $m$ con la ordenada al origen $n$. Es válida para todo $p\ne0$; si $m\ne0$, equivale a $n=p/m$. La familia de tangentes con pendiente finita queda expresada por

$$
\boxed{y=mx+\frac{p}{m},\qquad m\ne0.}\tag{T1}
$$

**Precisión de signos.** La clasificación de intersecciones se hace con el signo de $p(p-mn)$, de modo que funciona para $p>0$ y $p<0$. Al despejar $n$ mediante una desigualdad, debe examinarse además el signo de $m$.

![Una recta secante, una tangente y una exterior para la parábola y al cuadrado igual a 4x.](figuras/IC2021_Catedra_4_1/03_secante_tangente_exterior.png)

*Figura 3. Tres rectas de pendiente $m=1$ con interceptos $n=0$, $n=1$ y $n=2$, respectivamente; su discriminante es positivo, cero o negativo.*

#### Coordenadas del punto de tangencia
**En la cátedra (1:17:50–1:24:50).** Bajo la condición $mn=p$, la raíz doble de la ecuación (I) es

$$
\begin{aligned}
x_0&=-\frac{2mn-4p}{2m^2}
=\frac{4p-2p}{2m^2}
=\boxed{\frac{p}{m^2}},\\
y_0&=mx_0+\frac pm
=\frac pm+\frac pm
=\boxed{\frac{2p}{m}}.
\end{aligned}
$$

La identidad $m=y_0/(2x_0)$ se obtiene sustituyendo las fórmulas anteriores, porque en esta sección $x_0\ne0$. Equivalentemente, $m=2p/y_0$.

Con $x_0=p/m^2$ se tiene $p/m=mx_0$. Reescribimos (T1) como $y=m(x+x_0)$ y luego sustituimos $m=2p/y_0$:

$$
\boxed{yy_0=2p(x+x_0).}\tag{T2}
$$

Esta es la ecuación de la **tangente en el punto $(x_0,y_0)$ de la parábola**. Se obtiene en la clase mediante el discriminante, antes de disponer de derivadas.

#### La tangente en el vértice — precisión editorial
La deducción mediante una pendiente finita utiliza $m\ne0$ y $y_0\ne0$ para dividir. La fórmula final (T2), sin embargo, también puede evaluarse en el vértice $(x_0,y_0)=(0,0)$:

$$
0=2px \quad\Longleftrightarrow\quad\boxed{x=0}\qquad(p\ne0).
$$

Esta recta **vertical** es la tangente en el vértice. La justificación algebraica es exacta: la intersección de $x=0$ con $y^2=4px$ se reduce a $y^2=0$, raíz doble $y=0$. Por ello, la ecuación desdoblada extiende correctamente el resultado a un caso que la parametrización por $m$ deja pendiente.

![Tangentes a una parábola: punto ordinario y vértice.](figuras/IC2021_Catedra_4_1/04_tangentes_y_vertice.png)

*Figura 4. Tangente $y=x+1$ en $(1,2)$ para $y^2=4x$ y tangente vertical $x=0$ en el vértice.*

### La «desdoblada» de una ecuación cuadrática

#### Regla introducida en la cátedra
**En la cátedra (1:26:58–1:35:37).** El profesor llama **desdoblada** a una transformación de la ecuación de una curva cuadrática en una ecuación lineal, relativa a un punto $(x_0,y_0)$ de la curva. Para los términos que aparecen en la exposición:

$$
\begin{aligned}
x^2&\ \longmapsto\ xx_0,\\
y^2&\ \longmapsto\ yy_0,\\
x&\ \longmapsto\ \frac{x+x_0}{2},\\
y&\ \longmapsto\ \frac{y+y_0}{2},\\
\text{constantes}&\ \longmapsto\ \text{las mismas constantes}.
\end{aligned}
$$

Por ejemplo, la parábola $y^2=4px$ produce

$$
\boxed{yy_0=4p\frac{x+x_0}{2}=2p(x+x_0),}
$$

exactamente la tangente (T2). El punto $(x_0,y_0)$ satisface siempre la ecuación de la parábola.

Para la circunferencia con centro en el origen, $x^2+y^2=r^2$, la desdoblada es

$$
\boxed{xx_0+yy_0=r^2},
$$

la tangente en un punto $(x_0,y_0)$ de esa circunferencia. Asimismo, la circunferencia $x^2+y^2-2x=0$ produce

$$
xx_0+yy_0-(x+x_0)=0.
$$

Cuando se aplica a la ecuación $ax+by+c=0$ de una recta y se simplifica utilizando que $(x_0,y_0)$ pertenece a ella, se recupera la propia recta.

#### La fórmula completa y su justificación — ampliación editorial
Para una ecuación cuadrática general, incluidos los términos mixtos,

$$
F(x,y)=Ax^2+Bxy+Cy^2+Dx+Ey+G=0,
$$

la desdoblada relativa a un punto $(x_0,y_0)$ del lugar es

$$
\boxed{
Axx_0+\frac B2(xy_0+x_0y)+Cyy_0+
\frac D2(x+x_0)+\frac E2(y+y_0)+G=0.
}
$$

Esta regla se obtiene al **polarizar** cada término de la expresión cuadrática. Su conexión con la recta tangente puede comprobarse directamente mediante la linealización algebraica. Como $F(x_0,y_0)=0$, al multiplicar la fórmula desdoblada por $2$ y agrupar términos queda

$$
F_x(x_0,y_0)(x-x_0)+F_y(x_0,y_0)(y-y_0)=0,
$$

con $F_x=2Ax+By+D$ y $F_y=Bx+2Cy+E$. Aquí se presentan estas expresiones como identidades polinómicas; el curso explicará su interpretación mediante derivadas más adelante.

Si $(F_x(x_0,y_0),F_y(x_0,y_0))\ne(0,0)$, la ecuación representa una recta tangente bien determinada. La condición caracteriza un **punto regular** del lugar. Una ecuación cuadrática degenerada puede presentar puntos singulares que requieren un análisis adicional; por eso las notas especifican la hipótesis de regularidad al generalizar la regla.

![Desdoblada de la circunferencia: radio y tangente.](figuras/IC2021_Catedra_4_1/05_desdoblada_circunferencia.png)

*Figura 5. En $x^2+y^2=4$, la desdoblada en $(2,0)$ es $2x=4$, esto es, la tangente $x=2$.*

### La parábola de eje vertical

**En la cátedra (1:35:37–1:42:13).** Intercambiar las funciones de $x$ y $y$ en la construcción anterior conduce a

$$
\boxed{x^2=4py,\qquad p\ne0,}
$$

cuya geometría se caracteriza por

$$
F=(0,p),\qquad d:\ y=-p,\qquad V=(0,0).
$$

El eje de simetría es el eje $y$. Para $p>0$ los puntos cumplen $y\ge0$ y la parábola se abre hacia arriba; para $p<0$ cumplen $y\le0$ y se abre hacia abajo.

![Parábolas verticales abiertas hacia arriba o hacia abajo.](figuras/IC2021_Catedra_4_1/06_aperturas_verticales.png)

*Figura 6. En $x^2=4py$ el signo de $p$ determina la apertura superior o inferior; el eje $y$ es eje de simetría.*

La **desdoblada** de $x^2=4py$ en $(x_0,y_0)$ es

$$
\boxed{xx_0=2p(y+y_0),}
$$

que también incluye la tangente horizontal en su vértice: si $(x_0,y_0)=(0,0)$, la ecuación se reduce a $y=0$.

**Ejemplos numéricos de la clase.** Para $x^2=y$ se tiene $4p=1$, luego $p=1/4$ y $F=(0,1/4)$. Para $y=5x^2$ se escribe $x^2=\tfrac15y=4(\tfrac1{20})y$; por tanto $p=1/20$. El profesor anuncia que la clase siguiente estudiará traslaciones y parábolas con vértice arbitrario. La forma

$$
(x-h)^2=4p(y-k)
$$

con vértice $(h,k)$ se registra aquí únicamente como **anticipo editorial** de ese próximo desarrollo.

*Procedencia de este tramo: cátedra 4.2.*

### Las parábolas canónicas y el signo de sus parámetros

#### Apertura horizontal
**En la cátedra (03:09–05:10).** Para $p\in\mathbb R\setminus\{0\}$, la ecuación

$$
\boxed{y^2=4px}
$$

describe la parábola de vértice $V=(0,0)$, foco $F=(p,0)$ y directriz $x=-p$. Su eje de simetría es el eje $x$. Si $p>0$ se abre hacia la derecha; si $p<0$, hacia la izquierda. La distancia del vértice al foco es $|p|$. La condición $p\ne0$ mantiene separados el foco y la directriz. Al sustituir $p=0$, la ecuación se convierte en $y^2=0$, que describe la recta $y=0$.

#### Apertura vertical y la constante $a$
**En la cátedra (05:10–12:40).** Intercambiar el papel de las coordenadas produce

$$
\boxed{x^2=4py,\qquad F=(0,p),\qquad d:\ y=-p.}
$$

Al despejar $y$ se obtiene $y=ax^2$, con

$$
\boxed{a=\frac{1}{4p},\qquad p=\frac{1}{4a},\qquad a\ne0.}
$$

El signo de $a$ coincide con el de $p$: una parábola con $a>0$ se abre hacia arriba y una con $a<0$ hacia abajo. En ambos casos el foco conserva las coordenadas $(0,1/(4a))$, y la directriz tiene ecuación $y=-1/(4a)$. Por ejemplo, para $y=x^2$, $a=1$ y $p=1/4$.

![Aperturas de parábolas horizontales y verticales según el signo de p.](figuras/IC2021_Catedra_4_2/01_cuatro_aperturas.png)

*Figura 1. Cuatro aperturas canónicas: cada foco se sitúa en el sentido de apertura de la parábola. Se ilustran parámetros de igual magnitud y signos opuestos.*

### Una traslación cambia el origen de las coordenadas

#### Dos sistemas para un mismo punto
**En la cátedra (13:09–23:17).** La parábola $y'=a(x')^2$ está escrita en un sistema cuyo origen coincide con su vértice. Si ese vértice tiene coordenadas globales $V=(x_0,y_0)$, un mismo punto $P=(x,y)$ tiene coordenadas locales

$$
\boxed{x'=x-x_0,\qquad y'=y-y_0.}
$$

La primera diferencia mide el desplazamiento horizontal de $P$ respecto de $V$; la segunda mide el desplazamiento vertical. Ambas son cantidades orientadas, por lo que conservan su signo. Sustituyendo las dos coordenadas locales en la ecuación conocida, obtenemos

$$
\boxed{y-y_0=a(x-x_0)^2.}\tag{1}
$$

Este es el **modelo canónico de una parábola vertical trasladada**: el vértice es $(x_0,y_0)$ y el eje de simetría es la recta $x=x_0$. La constante $a$ regula el sentido de apertura y la escala de la curva. El desplazamiento modifica la posición del vértice y conserva la forma geométrica.

![Coordenadas globales y locales sobre una parábola trasladada.](figuras/IC2021_Catedra_4_2/02_coordenadas_trasladadas.png)

*Figura 2. El punto de coordenadas globales $(x,y)$ tiene coordenadas locales $(x-x_0,y-y_0)$ respecto del origen trasladado $V=(x_0,y_0)$.*

#### Foco y directriz después de la traslación
**En la cátedra (27:52–30:16).** En el sistema local el foco es $(0,p)$ y la directriz es $y'=-p$, con $p=1/(4a)$. Al convertir estas expresiones al sistema global, el foco se desplaza con el vértice, al igual que la directriz:

$$
\boxed{F=\left(x_0,y_0+\frac{1}{4a}\right),\qquad d:\ y=y_0-\frac{1}{4a}.}\tag{2}
$$

La distancia entre el vértice y el foco es $|1/(4a)|$. El signo de $a$ determina cuál de los dos lados del vértice ocupa el foco, mientras la directriz se ubica en el lado opuesto.

![Vértice foco y directriz de una parábola trasladada.](figuras/IC2021_Catedra_4_2/03_foco_directriz_trasladada.png)

*Figura 3. El foco está a distancia $|p|$ del vértice; la directriz se encuentra a esa misma distancia, sobre el lado opuesto.*

#### Continuidad con rectas y circunferencias
La clase compara tres escrituras. La recta $y=mx$ adquiere la forma $y-y_0=m(x-x_0)$ cuando pasa por un punto $(x_0,y_0)$; la circunferencia $x^2+y^2=r^2$ se escribe $(x-x_0)^2+(y-y_0)^2=r^2$ cuando su centro se traslada; la parábola $y=ax^2$ pasa a (1) cuando se traslada su vértice. La sustitución $(x,y)\mapsto(x-x_0,y-y_0)$ expresa la misma operación geométrica en los tres casos.

### De la función cuadrática a su vértice

#### Completar cuadrados
**Demostración de la cátedra (33:42–39:35), reconstruida.** Sea $a\ne0$ y considérese

$$
y=ax^2+bx+c.
$$

Al factorizar $a$ en los dos primeros términos, agregar y retirar el mismo cuadrado, obtenemos una cadena de igualdades:

$$
\begin{aligned}
y&=a\left(x^2+\frac ba x\right)+c\\
 &=a\left[x^2+2\frac{b}{2a}x+\left(\frac{b}{2a}\right)^2-\left(\frac{b}{2a}\right)^2\right]+c\\
 &=a\left(x+\frac{b}{2a}\right)^2-\frac{b^2}{4a}+c.
\end{aligned}
$$

La expresión constante del último miembro contiene el discriminante $\Delta=b^2-4ac$:

$$
\boxed{y=a\left(x+\frac{b}{2a}\right)^2-\frac{\Delta}{4a},\qquad\Delta=b^2-4ac.}\tag{3}
$$

La comparación de (3) con (1) identifica las coordenadas del vértice:

$$
\boxed{x_0=-\frac{b}{2a},\qquad y_0=-\frac{\Delta}{4a}.}\tag{4}
$$

La ecuación (3) muestra, además, que el eje de simetría es $x=-b/(2a)$ y permite recuperar los datos focales mediante (2):

$$
\boxed{F=\left(-\frac b{2a},\frac{1-\Delta}{4a}\right),\qquad d:\ y=-\frac{\Delta+1}{4a}.}\tag{5}
$$

La forma canónica y la ecuación desarrollada describen exactamente el mismo conjunto de puntos porque todas las transformaciones son igualdades algebraicas reversibles.

#### El discriminante en el gráfico de una cuadrática
**En la cátedra (43:35–50:55).** Los puntos donde la parábola corta el eje de las abscisas satisfacen $y=0$, es decir, $ax^2+bx+c=0$. Completando el cuadrado o aplicando la fórmula cuadrática se obtienen tres casos exclusivos:

| Discriminante | Intersecciones con el eje $x$ | Lectura geométrica |
|:--|:--|:--|
| $\Delta>0$ | Dos puntos $x_{1,2}=\dfrac{-b\pm\sqrt\Delta}{2a}$ | La parábola atraviesa el eje en dos abscisas. |
| $\Delta=0$ | Un punto $x_0=-\dfrac b{2a}$ | El vértice pertenece al eje horizontal. |
| $\Delta<0$ | Conjunto vacío de intersecciones | La curva se mantiene del lado del eje que determina el signo de $a$. |

Con $a>0$, la función tiene su valor mínimo en el vértice. Si $\Delta>0$, es positiva en $(-\infty,x_1)\cup(x_2,\infty)$ y negativa en $(x_1,x_2)$, suponiendo $x_1<x_2$. Si $\Delta<0$, es estrictamente positiva para todo $x$. Si $\Delta=0$, toma el valor cero en $x_0$ y valores positivos en las restantes abscisas. Para $a<0$, el vértice es máximo y las direcciones de las desigualdades se invierten.

![Tres casos del discriminante para parábolas orientadas hacia arriba.](figuras/IC2021_Catedra_4_2/04_discriminante_cuadraticas.png)

*Figura 4. Para $a>0$, los tres signos del discriminante corresponden respectivamente a dos, uno y cero puntos de corte con el eje horizontal.*

**Precisión de rigor.** El discriminante se utiliza aquí para contar intersecciones y analizar signos, como hace el profesor en relación con el primer control. La fórmula del vértice explica geométricamente esas mismas propiedades: $y_0=-\Delta/(4a)$.

### Elipse e hipérbola desde un foco y una directriz

#### Planteamiento común
**En la cátedra (59:58–1:11:20).** En la segunda parte se consideran un foco $F=(f,0)$ y una directriz vertical $d:\ x=d$, donde la letra $d$ designa ahora la abscisa constante de esa recta y se exige $f\ne d$. Se fija una excentricidad $e>0$ que satisface $e\ne1$. Por definición, el punto $P=(x,y)$ pertenece a la cónica exactamente cuando

$$
\boxed{d(P,F)=e\,d(P,d).}
$$

Como las distancias y $e$ son mayores o iguales que cero, se pueden elevar al cuadrado conservando la equivalencia:

$$
(x-f)^2+y^2=e^2(x-d)^2.
$$

Al desarrollar los cuadrados y reagrupar los términos, se obtiene

$$
\boxed{(1-e^2)x^2+y^2+2(e^2d-f)x=e^2d^2-f^2.}\tag{6}
$$

La parábola de excentricidad $1$ ya fue estudiada en la Cátedra 4.1. En la sesión actual el coeficiente $1-e^2$ permite distinguir elipse e hipérbola.

#### Elegir el origen de forma que desaparezca el término lineal
**En la cátedra (1:11:32–1:19:00).** El profesor utiliza una elección estratégica del origen: dispone los datos focales respecto del sistema de coordenadas de manera que

$$
\boxed{f=e^2d.}\tag{7}
$$

Así desaparece el coeficiente de $x$ en (6), y el centro de la cónica queda en el origen. Esta normalización es posible mediante una traslación cuando $e\ne1$: si las coordenadas iniciales del foco y la directriz son $f_{\mathrm{ini}}$ y $d_{\mathrm{ini}}$, basta trasladar el origen a

$$
h=\frac{f_{\mathrm{ini}}-e^2d_{\mathrm{ini}}}{1-e^2}.
$$

En las nuevas coordenadas $f=f_{\mathrm{ini}}-h$ y $d=d_{\mathrm{ini}}-h$, y por construcción $f=e^2d$. Esta última fórmula para $h$ es una **demostración completada editorialmente** de la posibilidad de elegir el origen que el profesor ilustra mediante dibujos.

Sustituyendo (7) en el segundo miembro de (6):

$$
e^2d^2-f^2=e^2d^2-e^4d^2=e^2d^2(1-e^2).
$$

Por tanto,

$$
(1-e^2)x^2+y^2=e^2d^2(1-e^2).
$$

Se deduce $d\ne0$, pues $d=0$ implicaría $f=0$ e identificaría el foco con un punto de la directriz. Podemos dividir por cantidades distintas de cero y escribir

$$
\boxed{\frac{x^2}{e^2d^2}+\frac{y^2}{e^2d^2(1-e^2)}=1.}\tag{8}
$$

En (8), la magnitud $e^2d^2$ es estrictamente positiva. El signo del segundo denominador está determinado por $1-e^2$.

![Foco y directriz en la normalización central de una cónica.](figuras/IC2021_Catedra_4_2/05_conica_foco_directriz.png)

*Figura 5. Una configuración con $f=e^2d$, ilustrada para $0<e<1$: las distancias se toman al foco y perpendicularmente a la directriz.*

### La elipse y sus parámetros

#### Ecuación canónica y semiejes
**En la cátedra (1:21:29–1:29:35).** Si $0<e<1$, el número $1-e^2$ es estrictamente positivo. Se definen los semiejes positivos

$$
\boxed{a=e|d|,\qquad b=e|d|\sqrt{1-e^2}=a\sqrt{1-e^2}.}\tag{9}
$$

La ecuación (8) se convierte en

$$
\boxed{\frac{x^2}{a^2}+\frac{y^2}{b^2}=1,\qquad a>b>0.}\tag{10}
$$

Este es el modelo de una elipse centrada en el origen, con eje mayor horizontal. Sus vértices sobre el eje horizontal son $(\pm a,0)$ y los extremos del eje menor son $(0,\pm b)$. La ecuación (10) implica $|x|\le a$ y $|y|\le b$, y es simétrica respecto de ambos ejes porque contiene las dos coordenadas elevadas al cuadrado.

#### La identidad pitagórica y la excentricidad
La relación $b=a\sqrt{1-e^2}$ implica

$$
 b^2=a^2(1-e^2)=a^2-a^2e^2.
$$

En la normalización (7), $f=e^2d$, por lo que $|f|=ea$. Se obtiene así la relación que el profesor presenta mediante un triángulo rectángulo:

$$
\boxed{a^2=b^2+f^2,\qquad e=\frac{|f|}{a}=\frac{\sqrt{a^2-b^2}}a.}\tag{11}
$$

En (11), $|f|$ es la distancia desde el centro hasta cada foco. El semieje mayor $a$ es la hipotenusa del triángulo cuyos catetos son $b$ y $|f|$.

![Elipse con ejes, focos y directrices verticales.](figuras/IC2021_Catedra_4_2/06_elipse_parametros.png)

*Figura 6. Elipse horizontal: los dos focos están en $(\pm|f|,0)$ y las directrices en $x=\pm a/e$, equivalentes a $x=\pm a^2/|f|$.*

![Triángulo de lados a b y distancia focal.](figuras/IC2021_Catedra_4_2/07_triangulo_elipse.png)

*Figura 7. Interpretación pitagórica de $a^2=b^2+|f|^2$; en el esquema se usa la proporción numérica $3$–$4$–$5$.*

#### Los dos focos y las dos directrices
**En la cátedra (1:31:25–1:33:54).** La magnitud del parámetro focal satisface $|f|=ae$. Como la elipse es simétrica respecto del eje vertical, ambos puntos

$$
F_1=(ae,0),\qquad F_2=(-ae,0)
$$

son sus focos. De (9) resulta $|d|=a/e$, por lo que tiene dos directrices verticales:

$$
\boxed{x=\frac ae\qquad\text{y}\qquad x=-\frac ae.}\tag{12}
$$

**Ampliación editorial — verificación directa.** Partiendo de (10), se obtiene $y^2=b^2(1-x^2/a^2)$. Tomemos $f=ae$ y $d=a/e$. Entonces, para cualquier punto de la elipse,

$$
\begin{aligned}
(x-f)^2+y^2
&=x^2-2aex+a^2e^2+a^2(1-e^2)-x^2(1-e^2)\\
&=e^2x^2-2aex+a^2=(ex-a)^2\\
&=e^2\left(x-\frac ae\right)^2.
\end{aligned}
$$

Las distancias son no negativas, así que $d(P,F_1)=e\,d(P,x=a/e)$. El reemplazo $(x,y)\mapsto(-x,y)$ demuestra la segunda configuración focal.

### La hipérbola: desarrollo algebraico complementario

**En la cátedra (1:21:40–1:24:05).** El profesor obtiene la diferencia esencial en el signo: si $e>1$, el número $1-e^2$ es negativo. Su exposición establece la forma con un término positivo y otro negativo y deja las propiedades completas de la hipérbola para la lectura del apunte.

**Ampliación editorial.** Definimos los parámetros positivos

$$
 a=e|d|,\qquad b=a\sqrt{e^2-1}.
$$

Reescribiendo (8) como diferencia de cuadrados se obtiene

$$
\boxed{\frac{x^2}{a^2}-\frac{y^2}{b^2}=1.}\tag{13}
$$

La ecuación describe dos ramas simétricas con vértices $(a,0)$ y $(-a,0)$. De (13) se sigue $|x|\ge a$, por lo que la rama derecha tiene $x\ge a$ y la izquierda $x\le-a$. Las rectas

$$
\boxed{y=\pm\frac ba x}
$$

son las asíntotas, en el sentido de que las ramas se aproximan a ellas cuando $|x|$ crece. Una verificación algebraica se obtiene despejando

$$
 y=\pm\frac ba\sqrt{x^2-a^2},\qquad |x|\ge a,
$$

y comparando $\sqrt{x^2-a^2}$ con $|x|$ para valores grandes de $|x|$.

La distancia focal es $|f|=ae$ y satisface

$$
\boxed{f^2=a^2+b^2,\qquad e=\frac{|f|}{a}=\sqrt{1+\frac{b^2}{a^2}}.}\tag{14}
$$

Los focos se ubican en $(\pm|f|,0)$ y las directrices en $x=\pm a/e$.

![Hipérbola horizontal y sus asíntotas.](figuras/IC2021_Catedra_4_2/08_hiperbola_asintotas.png)

*Figura 8. Hipérbola horizontal con dos ramas, vértices, focos y asíntotas oblicuas; figura de ampliación editorial.*

#### Cuadro de relaciones para elipse e hipérbola
| Propiedad | Elipse horizontal | Hipérbola horizontal |
|:--|:--|:--|
| Excentricidad | $0<e<1$ | $e>1$ |
| Ecuación | $x^2/a^2+y^2/b^2=1$ | $x^2/a^2-y^2/b^2=1$ |
| Semiejes | $a>b>0$ | $a,b>0$ |
| Distancia focal | $|f|=\sqrt{a^2-b^2}$ | $|f|=\sqrt{a^2+b^2}$ |
| Focos | $(\pm |f|,0)$ | $(\pm |f|,0)$ |
| Directrices | $x=\pm a/e$ | $x=\pm a/e$ |
| Excentricidad desde semiejes | $e=\sqrt{1-b^2/a^2}$ | $e=\sqrt{1+b^2/a^2}$ |

**Precisión terminológica.** En las secciones de elipse e hipérbola, $a$ y $b$ designan longitudes positivas de semiejes. En la ecuación cuadrática de la parábola, $a$ designa el coeficiente principal. Cada significado queda fijado por el contexto de su sección.

### Preguntas de cierre, rigor y continuidad

La exposición termina el desarrollo de elipses y remite al apunte para las propiedades de la hipérbola. En las preguntas finales, el profesor retoma el ejercicio clásico del **lugar geométrico de los puntos desde los que dos segmentos hacia puntos fijos forman un ángulo recto**: la circunferencia que tiene por diámetro el segmento que une los puntos fijos. Su centro es el punto medio y su radio es la mitad de la distancia entre ambos extremos. Esta observación pertenece a la sección de consultas, posterior a la exposición principal sobre cónicas, y conecta con la tercera clase de ejercicios de geometría analítica.

**Puntos a comprobar al estudiar:** las formas $y-y_0=a(x-x_0)^2$ y $y=ax^2+bx+c$ se relacionan por una igualdad algebraica; las expresiones del foco y la directriz dependen de $p=1/(4a)$; el discriminante cuenta los cortes reales con el eje horizontal; la ecuación $f=e^2d$ corresponde a un origen elegido para centrar elipse e hipérbola; el signo de $1-e^2$ selecciona la ecuación de cada cónica; los focos y las directrices aparecen por pares simétricos en la normalización de centro en el origen.

**Fuente y procedencia.** Jorge San Martín, «IC2021: Cátedra 4.2. Viernes 12:00», [YouTube, video E2KL0qm2vIg](https://www.youtube.com/watch?v=E2KL0qm2vIg). Se ha revisado la transcripción automática en español de la grabación completa, incluidas las preguntas finales. La letra «hipérbola» se emplea en los apartados donde el reconocimiento automático presenta variantes fonéticas; las fórmulas se normalizan y se han comprobado mediante sustitución. Las figuras y los dieciséis ejercicios resueltos son elaboración editorial para el estudio.

**Continuación:** elipse e hipérbola completan la introducción de la semana 4. El siguiente bloque puede estudiar sus aplicaciones, ecuaciones trasladadas y problemas geométricos, manteniendo las relaciones focales y la lectura algebraica aprendida aquí.

### Taller de problemas y soluciones

Los ejercicios se presentan a continuación según la fuente de origen; las ampliaciones editoriales de cada apuntes permanecen expresamente identificadas.

#### Ejercicios de consolidación y solucionario — cátedra 4.1

Los problemas **E1–E14** son ampliaciones originales para el estudio. Algunos reproducen los ejemplos numéricos de la clase y otros examinan las hipótesis que se utilizan al calcular intersecciones y tangentes. Se proporciona inmediatamente una solución razonada de cada uno.

#### E1. Excentricidad y distancias
Si $e=1/2$ y la distancia a la directriz de un punto de la cónica es $12$, determinar la distancia al foco. Repetir para $e=1$ y $e=3$.

**Solución.** La definición exige $d(P,F)=e\,d(P,d)$. En consecuencia, las distancias al foco son $6$, $12$ y $36$, respectivamente. Los tres valores corresponden a una elipse, una parábola y una hipérbola para las configuraciones admitidas.

#### E2. Foco y directriz a partir de la ecuación
Determinar el foco, la directriz, el vértice y la apertura de $y^2=12x$.

**Solución.** Comparar con $y^2=4px$ da $4p=12$, luego $p=3$. El foco es $(3,0)$, la directriz $x=-3$ y el vértice $(0,0)$. Como $p>0$, la curva se abre hacia la derecha.

#### E3. Parábola horizontal de parámetro negativo
Analizar $y^2=-8x$.

**Solución.** La igualdad $4p=-8$ conduce a $p=-2$. Su foco es $(-2,0)$ y su directriz es $x=2$. Todo punto satisface $-8x=y^2\ge0$, por lo que $x\le0$: se abre hacia la izquierda. El eje de simetría es $y=0$.

#### E4. Pertenencia y simetría
Determinar si $(2,4)$ y $(2,-4)$ pertenecen a $y^2=8x$.

**Solución.** Para ambos puntos, $y^2=16$ y $8x=16$. Son puntos de la parábola y constituyen un par simétrico respecto del eje horizontal. En cambio, $(1,4)$ produce $16$ frente a $8$ y queda fuera del lugar.

#### E5. Una recta horizontal
Calcular la intersección de $y=3$ con $y^2=8x$.

**Solución.** Sustituyendo $y=3$ se obtiene $9=8x$; la única solución es $x=9/8$. El punto de corte es $(9/8,3)$. Una recta horizontal corta este lugar exactamente una vez.

#### E6. Dos secantes de distinta posición
Para $y^2=4x$ estudiar las rectas $y=x$ y $y=x+2$.

**Solución.** La primera produce $x^2=4x$, equivalente a $x(x-4)=0$, de donde $x=0$ o $x=4$; los puntos de corte son $(0,0)$ y $(4,4)$. La segunda da $(x+2)^2=4x$, es decir $x^2+4=0$, cuyo miembro izquierdo es estrictamente positivo. Por ello su conjunto de intersecciones es vacío.

#### E7. Tangente por el método del discriminante
Decidir si $y=x+1$ es tangente a $y^2=4x$ y hallar el contacto.

**Solución.** Se tiene $p=1$, $m=1$, $n=1$. Como $mn=p$, el discriminante vale cero. De las fórmulas $x_0=p/m^2$ y $y_0=2p/m$ se obtiene $(x_0,y_0)=(1,2)$. Comprobación: $(x+1)^2=4x$ equivale a $(x-1)^2=0$.

#### E8. Una recta que corta dos veces
Determinar las intersecciones de $y=x+1$ con $y^2=8x$.

**Solución.** Sustituimos para obtener $(x+1)^2=8x$, o $x^2-6x+1=0$. Su discriminante es $36-4=32>0$; las raíces son $x=3\pm2\sqrt2$. La ordenada correspondiente es $y=x+1=4\pm2\sqrt2$. Los dos puntos son distintos, como predice $16p(p-mn)=16\cdot2(2-1)>0$.

#### E9. Tangente en un punto conocido
Encontrar la tangente a $y^2=8x$ en $(2,4)$.

**Solución.** Primero verificamos pertenencia: $4^2=16=8\cdot2$. Con $p=2$, la fórmula desdoblada es $4y=4(x+2)$; por tanto $\boxed{y=x+2}$. La recta contiene $(2,4)$ y al sustituirse en la parábola produce $(x-2)^2=0$.

#### E10. Tangente en el vértice
Hallar la tangente a $y^2=-12x$ en el origen.

**Solución.** La forma desdoblada es $yy_0=2p(x+x_0)$. En $(0,0)$ queda $0=2px$. Como $p=-3$, resulta $\boxed{x=0}$. La recta es vertical; al intersectarla con la parábola se obtiene $y^2=0$, con única raíz doble $y=0$.

#### E11. Parábola de eje vertical
Determinar foco, directriz y sentido de apertura de $x^2=-12y$.

**Solución.** Es $4p=-12$, luego $p=-3$. El foco es $(0,-3)$; la directriz, $y=3$; el vértice, $(0,0)$. Como $x^2=-12y\ge0$, se tiene $y\le0$ y la apertura es hacia abajo.

#### E12. Tangente a una parábola vertical
Encontrar la tangente a $x^2=4y$ en $(2,1)$.

**Solución.** El punto verifica $2^2=4\cdot1$. Con $p=1$, la desdoblada es $2x=2(y+1)$. Al simplificar queda $\boxed{y=x-1}$. La sustitución en $x^2=4y$ da $x^2=4(x-1)$ y, por tanto, $(x-2)^2=0$.

#### E13. Tangente a una circunferencia mediante desdoblada
Sea $\mathcal C:x^2+y^2-2x=0$. Encontrar la tangente en $(2,0)$.

**Solución.** Verificación de pertenencia: $2^2+0^2-2(2)=0$. Aplicamos la regla: $xx_0+yy_0-(x+x_0)=0$. En el punto indicado, $2x-(x+2)=0$, de donde $\boxed{x=2}$. Es la recta vertical por el extremo derecho de la circunferencia de centro $(1,0)$ y radio $1$.

#### E14. El parámetro y la degeneración
Analizar qué describe la ecuación formal $y^2=4px$ si se fija $p=0$.

**Solución.** La ecuación queda $y^2=0$, equivalente a $y=0$: una recta de multiplicidad algebraica dos. La construcción de la parábola de esta clase exige $p\ne0$, pues así el foco $F=(p,0)$ queda separado de la directriz $x=-p$. El caso $p=0$ muestra por qué debe preservarse esta hipótesis al utilizar las fórmulas canónicas.

#### Ejercicios de estudio y soluciones desarrolladas — cátedra 4.2

Las siguientes actividades son una **ampliación editorial**. Retoman los cálculos y situaciones geométricas presentados durante la clase, incorporan aplicaciones numéricas y completan el estudio introductorio de la hipérbola. Se distinguen de los ejemplos concretos pronunciados por el profesor.

#### E1. Parábola $y=x^2$
**Enunciado.** Determinar vértice, foco y directriz.

**Solución.** Al comparar con $y=ax^2$ se identifica $a=1$. Por la relación $p=1/(4a)$, $p=1/4>0$. El vértice es $(0,0)$, el foco $(0,1/4)$ y la directriz $y=-1/4$. La ecuación en forma focal es $x^2=4(1/4)y=y$. La apertura es hacia arriba.

#### E2. Parábola $y=-2x^2$
**Enunciado.** Hallar los elementos focales e interpretar su orientación.

**Solución.** Aquí $a=-2$ y $p=1/(4(-2))=-1/8$. El vértice es el origen, el foco es $(0,-1/8)$ y la directriz la horizontal $y=1/8$. El signo negativo de $p$ expresa apertura hacia abajo, con distancias focal y directriz iguales a $1/8$ desde el vértice.

#### E3. Parábola horizontal $y^2=-12x$
**Enunciado.** Determinar el foco y la directriz.

**Solución.** La comparación con $y^2=4px$ da $4p=-12$ y $p=-3$. Por tanto, foco $(-3,0)$ y directriz $x=3$. El eje de simetría es $y=0$ y la parábola se abre hacia la izquierda.

#### E4. Parábola $x^2=8y$
**Enunciado.** Calcular sus parámetros.

**Solución.** De $4p=8$ se deduce $p=2$. El foco es $(0,2)$, la directriz es $y=-2$, el vértice es $(0,0)$ y el eje de simetría es el eje $y$. Para verificar un punto, $(4,2)$ satisface $4^2=8\cdot2$.

#### E5. Foco de una parábola trasladada
**Enunciado.** Hallar vértice, foco y directriz de $y=2(x-3)^2-1$.

**Solución.** La ecuación presenta directamente el vértice $V=(3,-1)$ y el coeficiente $a=2$. El parámetro es $p=1/(4a)=1/8$. A la ordenada del vértice se suma $p$ para el foco y se resta $p$ para la directriz: $F=(3,-7/8)$ y $d:y=-9/8$.

#### E6. Traslación de $y=x^2$
**Enunciado.** Estudiar la parábola $y=(x+1)^2+4$.

**Solución.** Escribiendo $(x+1)^2=(x-(-1))^2$ se identifica $V=(-1,4)$, $a=1$ y $p=1/4$. El foco es $(-1,17/4)$, la directriz es $y=15/4$ y el eje es $x=-1$. La curva conserva la apertura hacia arriba de $y=x^2$ y se traslada una unidad a la izquierda y cuatro hacia arriba.

#### E7. Completar cuadrados
**Enunciado.** Analizar $y=2x^2-8x+5$.

**Solución.** Factorizando el coeficiente principal e introduciendo el cuadrado adecuado:

$$
\begin{aligned}
y&=2(x^2-4x)+5\\
 &=2[(x-2)^2-4]+5\\
 &=2(x-2)^2-3.
\end{aligned}
$$

El vértice es $(2,-3)$; como $p=1/8$, el foco es $(2,-23/8)$ y la directriz $y=-25/8$. También $\Delta=(-8)^2-4(2)(5)=24$, y la fórmula $-\Delta/(4a)=-24/8=-3$ confirma la ordenada del vértice.

#### E8. Parábola abierta hacia abajo
**Enunciado.** Completar cuadrados en $y=-x^2+4x-1$.

**Solución.**

$$
 y=-(x^2-4x)-1=-[(x-2)^2-4]-1=-(x-2)^2+3.
$$

El vértice es $(2,3)$, el eje $x=2$ y $p=1/(4(-1))=-1/4$. Se obtiene el foco $(2,11/4)$ y la directriz $y=13/4$. El vértice es un máximo por ser negativo el coeficiente del cuadrado.

#### E9. Dos raíces y mínimo
**Enunciado.** Hallar los cortes con el eje $x$ y el vértice de $y=x^2-6x+8$.

**Solución.** El trinomio factoriza como $(x-2)(x-4)$, así que las raíces son $x_1=2$ y $x_2=4$. Además,

$$
 y=(x-3)^2-1.
$$

El vértice es $(3,-1)$ y $\Delta=36-32=4>0$. El trinomio toma valores negativos exactamente en $(2,4)$ y positivos fuera del intervalo cerrado $[2,4]$; en $2$ y $4$ vale cero.

#### E10. Cuadrática de coeficiente negativo
**Enunciado.** Analizar el signo de $-x^2+2x+3$.

**Solución.** Multiplicar la ecuación $-x^2+2x+3=0$ por $-1$ produce $x^2-2x-3=0=(x-3)(x+1)$. Sus ceros son $-1$ y $3$. Como el coeficiente principal es negativo, la cuadrática es positiva para $-1<x<3$ y negativa para $x<-1$ y $x>3$. La forma canónica es $-(x-1)^2+4$, cuyo vértice $(1,4)$ confirma el máximo.

#### E11. Elipse de semiejes 5 y 3
**Enunciado.** Para $x^2/25+y^2/9=1$, hallar distancia focal, excentricidad y directrices.

**Solución.** Identificamos $a=5$, $b=3$. La identidad pitagórica da $|f|=\sqrt{a^2-b^2}=\sqrt{25-9}=4$. Por tanto, $e=4/5$, los focos están en $(\pm4,0)$ y las directrices en $x=\pm a/e=\pm25/4$. Los vértices son $(\pm5,0)$ y los extremos del eje menor $(0,\pm3)$.

#### E12. Elipse con excentricidad $1/2$
**Enunciado.** Hallar los focos y directrices de $x^2/16+y^2/12=1$.

**Solución.** Tomamos $a=4$ y $b=\sqrt{12}=2\sqrt3$. Entonces $|f|=\sqrt{16-12}=2$, de donde $e=|f|/a=1/2$. Los focos son $(\pm2,0)$ y las directrices $x=\pm8$. La igualdad $a^2=b^2+f^2$ se comprueba como $16=12+4$.

#### E13. Elipse desde foco y directriz
**Enunciado.** Fijar $F=(3,0)$, directriz $x=12$ y excentricidad $e=1/2$. Determinar la cónica.

**Solución.** Se cumple $f=e^2d=(1/4)(12)=3$, de modo que el sistema ya está centrado. Las constantes son $a=e|d|=(1/2)(12)=6$ y $b=a\sqrt{1-e^2}=6\sqrt{3/4}=3\sqrt3$. La ecuación buscada es

$$
\boxed{\frac{x^2}{36}+\frac{y^2}{27}=1.}
$$

Sus otros elementos focales son $F_2=(-3,0)$ y la directriz $x=-12$.

#### E14. Hipérbola pitagórica 3–4–5
**Enunciado.** Analizar $x^2/9-y^2/16=1$.

**Solución.** Los parámetros son $a=3$, $b=4$. La distancia focal vale $|f|=\sqrt{a^2+b^2}=5$ y la excentricidad $e=5/3>1$. Los focos están en $(\pm5,0)$, los vértices en $(\pm3,0)$ y las directrices en $x=\pm a/e=\pm9/5$. Las asíntotas son $y=\pm(4/3)x$.

#### E15. Hipérbola construida desde una excentricidad
**Enunciado.** Una hipérbola centrada en el origen tiene focos $(\pm4,0)$ y excentricidad $e=2$. Hallar su ecuación.

**Solución.** Como $e=|f|/a$, obtenemos $a=4/2=2$. De $f^2=a^2+b^2$ se sigue $b^2=16-4=12$. La ecuación es

$$
\boxed{\frac{x^2}{4}-\frac{y^2}{12}=1.}
$$

Sus vértices son $(\pm2,0)$ y sus directrices $x=\pm a/e=\pm1$.

#### E16. Verificación de la ecuación focal de una elipse
**Enunciado.** Verificar que $(x,y)=(1,3/2)$ satisface la razón de distancias de la elipse con $F=(1,0)$, directriz $x=4$ y $e=1/2$.

**Solución.** La distancia al foco es

$$
 d(P,F)=\sqrt{(1-1)^2+(3/2)^2}=\frac32.
$$

La distancia a la directriz vertical es $d(P,d)=|1-4|=3$. Multiplicar por la excentricidad produce $e\,d(P,d)=(1/2)3=3/2$, exactamente la distancia al foco. Además, $f=e^2d=1$, y la elipse asociada tiene $a=2$, $b=\sqrt3$ y ecuación $x^2/4+y^2/3=1$. Al sustituir el punto se obtiene $1/4+(9/4)/3=1/4+3/4=1$, segunda verificación independiente.

---

# Parte II. Funciones y trigonometría

## El lenguaje de las funciones

El dominio, la imagen y el gráfico determinan el objeto de estudio del cálculo. Las simetrías, la periodicidad, la monotonía y las operaciones con funciones preparan el análisis de su variación.

**Grabaciones de referencia:** [grabación de la cátedra 5.1](https://www.youtube.com/watch?v=qbH2dSX-oYk), [grabación de la cátedra 5.2](https://www.youtube.com/watch?v=NEYH4Qw4QK4).

*Procedencia de este tramo: cátedra 5.1.*

### De las funciones generales a las funciones reales de variable real

#### Correspondencia e imagen única
**En la cátedra (03:33–06:51).** Dados dos conjuntos $A$ y $B$, una **función** $f:A\to B$ es una asignación que, a cada $x\in A$, hace corresponder exactamente un elemento $f(x)\in B$. La condición puede expresarse mediante

$$
\boxed{\forall x\in A\ \exists!y\in B\quad y=f(x).}
$$

El conjunto $A$ es el **dominio** y $B$ el **codominio**. La imagen de un elemento $x$ es el valor único $f(x)$ que le corresponde. La notación $f:A\to B$ expresa la elección de estos conjuntos junto con la ley de asignación. El conjunto de valores realmente obtenidos es la **imagen** o recorrido: $f(A)=\{f(x):x\in A\}$.

La especificidad del cálculo de este curso es trabajar con $A\subseteq\mathbb R$ y habitualmente $B=\mathbb R$. Escribiremos

$$
\boxed{f:A\subseteq\mathbb R\longrightarrow\mathbb R,\qquad x\longmapsto f(x).}
$$

El profesor vincula la *unicidad* con la posibilidad de dar nombre a los valores asignados y recuerda que, en álgebra, el dominio y el codominio pueden ser conjuntos de naturaleza arbitraria.

![La función asocia una imagen a cada entrada del dominio.](figuras/IC2021_Catedra_5_1/01_correspondencia.png)

*Figura 1. Una asignación funcional da una imagen a cada entrada; la segunda correspondencia ilustra cómo pueden intervenir varias imágenes de una misma entrada en una relación general.*

#### El dominio natural de una fórmula
**En la cátedra (06:51–10:32).** En numerosos ejercicios se proporciona solamente una ley $f(x)$ y se pide determinar **todos los números reales en los que la expresión produce un valor real definido**. Este conjunto es el dominio natural de la fórmula, teniendo en cuenta las operaciones utilizadas.

Las condiciones aparecen simultáneamente y se resuelven como un sistema lógico: los radicandos de raíces cuadradas deben ser mayores o iguales que cero; los denominadores deben tener inverso multiplicativo, es decir, ser distintos de cero. Cuando coinciden radicales y cocientes, se imponen ambas condiciones.

**Primer ejemplo: raíz cuadrada.** Para $f(x)=\sqrt{x}$, el radicando es real no negativo exactamente en el intervalo

$$\boxed{\operatorname{Dom}(f)=[0,\infty).}$$

**Segundo ejemplo: raíz de una cuadrática.** Sea $g(x)=\sqrt{1-x^2}$. Su dominio se obtiene resolviendo una inecuación estudiada durante la segunda semana:

$$
1-x^2\geq0\ \Longleftrightarrow\ x^2\leq1
\ \Longleftrightarrow\ -1\leq x\leq1.
$$

Por consiguiente,

$$\boxed{\operatorname{Dom}(g)=[-1,1].}$$

El número $0$ pertenece a ese dominio y $g(0)=1$, como aclara el profesor a raíz de una pregunta. Los extremos pertenecen también porque la raíz cuadrada de cero está definida.

![Gráfico de la raíz de uno menos x al cuadrado con dominio cerrado.](figuras/IC2021_Catedra_5_1/02_dominios.png)

*Figura 2. El dominio de $g(x)=\sqrt{1-x^2}$ es $[-1,1]$; su grafo describe la semicircunferencia superior de radio uno.*

**Tercer ejemplo: denominadores.** La clase examina una expresión cuyo denominador se anula en $x=1$. En cualquier función racional de la forma $h(x)=u(x)/(x-1)$, la condición de definición incluye $x\ne1$; si $u$ está definida en todo $\mathbb R$, el dominio será $\mathbb R\setminus\{1\}$. El numerador exacto de ese ejemplo no queda suficientemente establecido por el reconocimiento oral; esta escritura es una formulación editorial del criterio explicado.

#### Simplificar una fórmula y conservar su dominio
**En la cátedra (10:38–14:23).** Compare las asignaciones naturales

$$
f(x)=\frac{x+1}{x+1},\qquad g(x)=1.
$$

Sus dominios son respectivamente

$$
\operatorname{Dom}(f)=\mathbb R\setminus\{-1\},\qquad
\operatorname{Dom}(g)=\mathbb R.
$$

En cada $x\in\operatorname{Dom}(f)$ se tiene $f(x)=g(x)=1$. La distinción esencial reside en el dominio: ambas fórmulas definen **funciones diferentes** cuando se les asignan sus dominios naturales. La simplificación cancela un factor que tiene inverso para $x\ne-1$ y conserva el valor en esos puntos.

Formalmente, si $g|_{\operatorname{Dom}(f)}$ denota la restricción de $g$ al dominio de $f$, entonces

$$
\boxed{f=g|_{\mathbb R\setminus\{-1\}}.}
$$

Esta igualdad expresa exactamente en qué sentido puede utilizarse la fórmula simplificada dentro de una ecuación o inecuación sin alterar la condición original.

![Dos gráficas con la misma altura y dominios diferentes.](figuras/IC2021_Catedra_5_1/03_agujero.png)

*Figura 3. La expresión $(x+1)/(x+1)$ presenta un punto excluido sobre la recta $y=1$. La función constante $g(x)=1$ contiene ese punto.*

#### Una raíz con valor absoluto en el denominador
**En la cátedra (14:23–16:19).** El profesor presenta un cuarto problema de dominio cuyo radicando se describe oralmente como $(x+1)/|x-2|-2$. Lo deja a los estudiantes como aplicación de inecuaciones con módulo. Bajo esa lectura del enunciado,

$$
F(x)=\sqrt{\frac{x+1}{|x-2|}-2}
$$

requiere, simultáneamente, $x\ne2$ y $(x+1)/|x-2|\geq2$. El docente **plantea** esta inecuación durante la sesión; el cálculo siguiente es una **demostración editorial** de la tarea.

Como $|x-2|>0$ para $x\ne2$, la desigualdad equivale a $x+1\geq2|x-2|$. Dividimos por el punto de cambio de signo de $x-2$:

- Para $x<2$, tenemos $|x-2|=2-x$ y $x+1\geq4-2x$, que equivale a $x\geq1$. La solución de este caso es $[1,2)$.
- Para $x>2$, $|x-2|=x-2$ y $x+1\geq2x-4$, equivalente a $x\leq5$. La solución de este caso es $(2,5]$.

De ahí se obtiene

$$
\boxed{\operatorname{Dom}(F)=[1,2)\cup(2,5].}
$$

Este ejemplo hace visible la naturaleza **acumulativa** del cálculo: estudiar una función puede exigir volver a resolver una inecuación de semanas anteriores.

### Grafo, ceros y signo de una función

#### Del dominio al plano
**En la cátedra (16:20–21:15).** El **grafo** de una función real $f:A\to\mathbb R$ es el conjunto de pares ordenados

$$
\boxed{G_f=\{(x,f(x)):x\in A\}\subseteq\mathbb R^2.}
$$

Este conjunto traduce la ley de la función a la geometría analítica: cada abscisa $x\in A$ señala una altura $y=f(x)$. Por ejemplo, $f(x)=x^2$ tiene dominio $\mathbb R$ y grafo parabólico.

La ecuación $y^2=x$ representa una parábola horizontal. Para $x=4$ admite las ordenadas $y=2$ y $y=-2$; por ello, la curva completa corresponde a un **lugar geométrico con dos puntos de igual abscisa**. Las ramas $y=\sqrt x$ e $y=-\sqrt x$ son, cada una por separado, grafos de funciones definidas en $[0,\infty)$.

Una recta vertical $x=c$ corta al grafo de una función exactamente en un punto cuando $c\in A$. Es la **prueba de la recta vertical**, deducida directamente de la unicidad de la imagen.

![Una parábola vertical es grafo de función y una horizontal requiere separar ramas.](figuras/IC2021_Catedra_5_1/04_prueba_vertical.png)

*Figura 4. La recta vertical auxiliar cruza una vez el grafo de $y=x^2$ y dos veces el lugar $y^2=1.5x$ para determinadas abscisas.*

#### Ceros y regiones de signo
**En la cátedra (21:16–29:47).** Los **ceros** de $f$ son los elementos del dominio con imagen igual a cero:

$$
\boxed{Z(f)=\{x\in A:f(x)=0\}.}
$$

Geométricamente son las abscisas de las intersecciones entre $G_f$ y el eje horizontal. Los conjuntos de positividad y negatividad son, respectivamente,

$$
\boxed{P(f)=\{x\in A:f(x)>0\},\quad N(f)=\{x\in A:f(x)<0\}.}
$$

Los tres conjuntos $P(f)$, $Z(f)$ y $N(f)$ dividen el dominio según la tricotomía del valor real $f(x)$. También se pueden estudiar $f(x)\geq0$ y $f(x)\leq0$, incorporando los ceros a las regiones respectivas.

Para la función cuadrática $q(x)=ax^2+bx+c$, determinar los ceros equivale a resolver la **ecuación cuadrática** $ax^2+bx+c=0$. Determinar dónde es positiva o negativa lleva a las **inecuaciones cuadráticas**. La clase recuerda que el discriminante $\Delta=b^2-4ac$ permite clasificar las raíces cuando $a\ne0$.

**Ejemplo de consolidación.** Para $q(x)=x^2-1$,

$$
q(x)=(x-1)(x+1),\qquad Z(q)=\{-1,1\}.
$$

La regla de los signos proporciona

$$
P(q)=(-\infty,-1)\cup(1,\infty),\qquad
N(q)=(-1,1).
$$

![Ceros y regiones de signo de la cuadrática x al cuadrado menos uno.](figuras/IC2021_Catedra_5_1/05_ceros_signos.png)

*Figura 5. La parábola corta el eje horizontal en $-1$ y $1$. Su signo es positivo en las dos zonas exteriores y negativo en el intervalo central.*

El profesor insiste en que las herramientas algebraicas permiten determinar ceros que pueden resultar poco visibles en un gráfico digital. El grafo constituye el resultado del análisis, y la fórmula es el medio para justificarlo.

### Paridad e imparidad

#### Funciones pares
**En la cátedra (29:47–34:21).** La paridad combina una simetría del dominio con una igualdad entre imágenes. Una función $f:A\to\mathbb R$ es **par** cuando se cumplen

$$
\boxed{\begin{aligned}
&x\in A\ \Longrightarrow\ -x\in A,\\
&f(-x)=f(x)\quad\text{para todo }x\in A.
\end{aligned}}
$$

La primera propiedad establece que el dominio es simétrico respecto de cero. La segunda refleja cada punto $(x,f(x))$ del grafo en el punto $(-x,f(x))$. **El grafo de una función par es simétrico respecto del eje vertical**.

#### Funciones impares
**En la cátedra (34:21–36:40).** Una función $f:A\to\mathbb R$ es **impar** cuando su dominio es simétrico y

$$
\boxed{f(-x)=-f(x)\quad\text{para cada }x\in A.}
$$

Por tanto, junto al punto $(x,f(x))$ aparece $(-x,-f(x))$. La simetría se realiza respecto del **origen**, mediante un giro de $180^\circ$ en el plano. Si $0\in A$, la igualdad $f(0)=-f(0)$ implica necesariamente $f(0)=0$.

![Simetría de una función par respecto del eje y y de una impar respecto del origen.](figuras/IC2021_Catedra_5_1/06_paridad.png)

*Figura 6. A la izquierda, la simetría axial de $x^2$; a la derecha, la simetría central de $x^3$.*

#### Ejemplos con potencias y módulo
**En la cátedra (36:41–43:13).** La primera función considerada es

$$
f(x)=x^8+x^2+|x|+1,\qquad\operatorname{Dom}(f)=\mathbb R.
$$

Sustituyendo $-x$ por $x$ en la ley y usando las propiedades de las potencias y el valor absoluto,

$$
\begin{aligned}
f(-x)&=(-x)^8+(-x)^2+|-x|+1\\
&=x^8+x^2+|x|+1=f(x).
\end{aligned}
$$

Así, $f$ es par. El profesor relaciona la denominación con el comportamiento de las potencias de exponente par y recuerda que $|x|$ también satisface esa simetría.

El segundo ejemplo es

$$
g(x)=x^9+x^3+x,\qquad\operatorname{Dom}(g)=\mathbb R.
$$

En este caso,

$$
\begin{aligned}
g(-x)&=(-x)^9+(-x)^3+(-x)\\
&=-x^9-x^3-x=-g(x).
\end{aligned}
$$

Por ello $g$ es impar. **El tercer ejemplo, un cociente de expresiones impares, se deja en la clase como ejercicio**: los signos que aparecen al sustituir $-x$ se cancelan en el cociente, siempre sobre un dominio simétrico que permita dividir.

**Demostración desarrollada.** Si $f$ y $g$ son impares en un dominio común simétrico $A$ y $g(x)\ne0$ en un subconjunto simétrico $D\subseteq A$, entonces

$$
\frac{f(-x)}{g(-x)}=\frac{-f(x)}{-g(x)}=\frac{f(x)}{g(x)}\quad(x\in D).
$$

El cociente es par. Análogamente, la suma de funciones pares es par, la de impares es impar, y el producto de dos funciones impares es par. La simetría del dominio común debe comprobarse en cada caso.

#### Un teorema anunciado: descomposición par–impar
**En la cátedra (43:13–43:35).** San Martín propone estudiar el hecho de que una función con dominio $\mathbb R$ admite una descomposición única en la suma de una función par y otra impar. La demostración siguiente es **ampliación editorial**.

Sea $f:\mathbb R\to\mathbb R$ y definamos

$$
\boxed{f_{\mathrm{par}}(x)=\frac{f(x)+f(-x)}2,\qquad
f_{\mathrm{impar}}(x)=\frac{f(x)-f(-x)}2.}
$$

Sustituir $-x$ en las fórmulas prueba que la primera es par y la segunda impar. Sumando,

$$f_{\mathrm{par}}(x)+f_{\mathrm{impar}}(x)=f(x).$$

Para verificar la unicidad, suponga $f=u+v$ con $u$ par y $v$ impar. Entonces $f(-x)=u(x)-v(x)$. Al sumar o restar estas igualdades se determina forzosamente $u=f_{\mathrm{par}}$ y $v=f_{\mathrm{impar}}$.

### Periodicidad

#### Repetición de los valores de la función
**En la cátedra (43:43–51:28).** El profesor define la periodicidad hacia adelante: una función $f:A\to\mathbb R$ tiene **periodo positivo** $p>0$ cuando

$$
\boxed{\forall x\in A:\quad x+p\in A\quad\text{y}\quad f(x+p)=f(x).}
$$

La condición del dominio permite reiterar la igualdad. Si $x\in A$, entonces $x+p$, $x+2p$, $x+3p$, etc., pertenecen también a $A$, y

$$
\boxed{f(x+np)=f(x)\qquad(n\in\mathbb N_0).}
$$

El gráfico repite horizontalmente el mismo tramo cada $p$ unidades. San Martín compara este fenómeno con los diarios que vuelven a aparecer después de un intervalo fijo, aunque señala que la repetición matemática exige **igualdad exacta de los valores**.

![Función periódica por repetición de un mismo tramo cada dos unidades.](figuras/IC2021_Catedra_5_1/07_periodicidad.png)

*Figura 7. Una función periódica de periodo $2$ definida desde $x=0$; se repite la figura triangular hacia los valores crecientes de $x$.*

**Precisión editorial sobre convenciones.** Esta formulación de la clase es deliberadamente **unilateral**: asegura la repetición para $x+np$ con $n\geq0$. Es habitual en otros textos exigir que el dominio sea invariante bajo traslaciones en ambos sentidos, $x\in A\iff x+p\in A$, y que la igualdad de imágenes valga en todo $A$. Esta segunda convención se usa, por ejemplo, para funciones definidas en $\mathbb R$. En estas notas se conserva la definición dada en la grabación y se indica cuándo se emplea otra.

**Ejemplo editorial.** Una función triangular de periodo $2$, definida en $[0,\infty)$, se puede expresar para cada entero $k\geq0$ mediante

$$
f(x)=\begin{cases}
x-2k,&2k\leq x\leq2k+1,\\
2k+2-x,&2k+1\leq x\leq2k+2.
\end{cases}
$$

La fórmula reproduce exactamente los mismos valores cuando la variable aumenta dos unidades.

### Crecimiento y decrecimiento

#### Comparación de imágenes en un subconjunto
**En la cátedra (56:36–1:08:40).** Sea $f:A\to\mathbb R$ y $I\subseteq A$, usualmente un intervalo. La función es **creciente en $I$** si

$$
\boxed{\forall x_1,x_2\in I:\quad x_1<x_2\ \Longrightarrow\ f(x_1)\leq f(x_2).}
$$

Es **decreciente en $I$** si

$$
\boxed{\forall x_1,x_2\in I:\quad x_1<x_2\ \Longrightarrow\ f(x_1)\geq f(x_2).}
$$

Las dos comparaciones parten de **la misma hipótesis $x_1<x_2$**. Al avanzar en la variable hacia valores mayores, la imagen de una función creciente conserva o aumenta su valor; la de una decreciente conserva o disminuye su valor. Si las desigualdades entre las imágenes son estrictas para $x_1<x_2$, hablamos de *creciente estricta* y *decreciente estricta*, respectivamente.

Una función constante en $I$ satisface simultáneamente las dos definiciones porque $f(x_1)=f(x_2)$ para todos los pares. Por ejemplo, una recta $f(x)=mx+n$ es creciente cuando $m\geq0$ y decreciente cuando $m\leq0$. Las funciones de pendiente cero realizan ambas propiedades.

![Comparación de imágenes en funciones crecientes y decrecientes.](figuras/IC2021_Catedra_5_1/08_crecimiento.png)

*Figura 8. Para $x_1<x_2$, la comparación de las dos ordenadas determina el sentido de la monotonía.*

San Martín enfatiza que muchas funciones son crecientes **en ciertos intervalos** y decrecientes **en otros**. Una descomposición del dominio en intervalos adecuados permite estudiar estas propiedades localmente.

#### Ejemplo fácil: $f(x)=x^3+x$
**En la cátedra (1:09:21–1:17:52).** La función

$$f(x)=x^3+x$$

está definida en $\mathbb R$, tiene un único cero en $x=0$, pues $x^3+x=x(x^2+1)$ y $x^2+1>0$, y es impar: $f(-x)=-f(x)$. El profesor demuestra su crecimiento en $[0,\infty)$ mediante reglas elementales de las desigualdades.

Para $0\leq x_1<x_2$, las propiedades del orden aseguran

$$
x_1^3<x_2^3\qquad\text{y}\qquad x_1<x_2.
$$

Sumando ambas desigualdades miembro a miembro,

$$
x_1^3+x_1<x_2^3+x_2,
$$

es decir,

$$\boxed{f(x_1)<f(x_2).}$$

La clase utiliza después la simetría impar para trazar el resto del grafo. **Demostración desarrollada para todo $\mathbb R$:** dados cualesquiera $x_1<x_2$, factorizar la diferencia ofrece una prueba global directa:

$$
\begin{aligned}
f(x_2)-f(x_1)
&=(x_2-x_1)\bigl(x_2^2+x_1x_2+x_1^2+1\bigr),\\
x_2^2+x_1x_2+x_1^2
&=\tfrac12\bigl((x_1+x_2)^2+x_1^2+x_2^2\bigr)\geq0.
\end{aligned}
$$

Ambos factores de la primera línea son positivos, por lo que $f$ es **estrictamente creciente en $\mathbb R$**.

#### Ejemplo difícil: $g(x)=x^3-x$
**En la cátedra (1:18:04–1:23:40).** Ahora la función

$$g(x)=x^3-x=x(x-1)(x+1)$$

es también impar y tiene dominio $\mathbb R$, pero sus ceros son $-1$, $0$ y $1$. El intento de probar crecimiento a partir de las dos desigualdades $x_1^3<x_2^3$ y $x_1<x_2$ tropieza con la necesidad de **restarlas**: la resta de desigualdades con el mismo sentido produce comparaciones cruzadas y no determina directamente el signo de $g(x_2)-g(x_1)$.

El profesor analiza explícitamente esa dificultad y presenta una técnica general que permite estudiar su signo.

#### La técnica especial: diferencia de imágenes y pendiente secante
**En la cátedra (1:23:43–1:31:20).** Para $x_1<x_2$ en un intervalo de estudio, el denominador $x_2-x_1$ es positivo. Por eso la diferencia $f(x_2)-f(x_1)$ y el cociente

$$
\boxed{Q_f(x_1,x_2)=\frac{f(x_2)-f(x_1)}{x_2-x_1}}
$$

poseen el mismo signo. El profesor lo reconoce como la **pendiente de la recta secante** al grafo de la función por los puntos $(x_1,f(x_1))$ y $(x_2,f(x_2))$. Así se vincula la teoría de las funciones con la geometría analítica de la Cátedra 3.2.

![Recta secante al grafo de una función y cociente incremental.](figuras/IC2021_Catedra_5_1/09_secante.png)

*Figura 9. El cociente de diferencias es la pendiente de la secante. Su signo permite determinar el orden entre las imágenes.*

Aplicando la técnica a $g(x)=x^3-x$:

$$
\begin{aligned}
Q_g(x_1,x_2)
&=\frac{(x_2^3-x_2)-(x_1^3-x_1)}{x_2-x_1}\\
&=\frac{(x_2^3-x_1^3)-(x_2-x_1)}{x_2-x_1}\\
&=\frac{(x_2-x_1)(x_2^2+x_1x_2+x_1^2-1)}{x_2-x_1}\\
&=\boxed{x_1^2+x_1x_2+x_2^2-1.}
\end{aligned}
$$

**Este es el resultado al que llega la demostración oral.** El signo de $Q_g$ depende de las dos abscisas, y el profesor deja como **tarea explícita** demostrar que $g$ es creciente en $[1,\infty)$, anunciando que la clase siguiente determinará con mayor precisión dónde cambia el crecimiento.

![Comparación de los grafos de x al cubo más x y x al cubo menos x.](figuras/IC2021_Catedra_5_1/10_cubicas.png)

*Figura 10. $x^3+x$ asciende en toda la recta; $x^3-x$ presenta tres ceros y diferentes tramos de monotonía.*

#### La tarea del profesor y su solución
**Tarea de la clase (1:31:20).** Probar que $g(x)=x^3-x$ es creciente en $[1,\infty)$.

**Solución editorial.** Si $1\leq x_1<x_2$, entonces $x_1^2\geq1$, $x_1x_2>1$ y $x_2^2>1$. En consecuencia,

$$
Q_g(x_1,x_2)=x_1^2+x_1x_2+x_2^2-1>0.
$$

Como $x_2-x_1>0$, obtenemos $g(x_2)>g(x_1)$. Por lo tanto, $g$ es **estrictamente creciente** en todo $[1,\infty)$, tal como se solicitaba.

#### Los intervalos exactos — ampliación editorial
La pregunta que el docente reserva para la siguiente clase se puede resolver también con las herramientas algebraicas ya disponibles, sin recurrir a derivadas. Sea

$$c=\frac1{\sqrt3}>0.$$

Para $c\leq x_1<x_2$, cada uno de los productos $x_1^2$, $x_1x_2$ y $x_2^2$ es al menos $c^2=1/3$, y alguno lo supera. Por tanto, $Q_g(x_1,x_2)>0$. El mismo argumento se aplica a $x_1<x_2\leq-c$, porque las dos abscisas son negativas y sus cuadrados y producto son positivos.

En el intervalo central $[-c,c]$ se cumple

$$
x_1^2+x_1x_2+x_2^2\leq 3c^2=1,
$$

con igualdad únicamente cuando ambos números coinciden en uno de los extremos con el mismo signo. Como el estudio exige $x_1<x_2$, la desigualdad es estricta: $Q_g(x_1,x_2)<0$. En consecuencia,

$$
\boxed{\begin{aligned}
&g\text{ es estrictamente creciente en }(-\infty,-c]\text{ y }[c,\infty),\\
&g\text{ es estrictamente decreciente en }[-c,c],\quad c=1/\sqrt3.
\end{aligned}}
$$

En los puntos de transición, $g(-c)=2/(3\sqrt3)$ y $g(c)=-2/(3\sqrt3)$. Esta solución exacta es una **anticipación editorial**: se incluye para completar el método, aunque la sesión termina antes de desarrollarla.

### Solucionario completo

#### E1. Radicando lineal
La raíz cuadrada está definida cuando $x+3\geq0$, condición equivalente a $x\geq-3$. Por tanto, $\boxed{\operatorname{Dom}(f)=[-3,\infty)}$. El extremo pertenece al dominio y $f(-3)=0$.

#### E2. Radicando cuadrático
Se impone $9-x^2\geq0$, es decir, $x^2\leq9$. Por la factorización $9-x^2=(3-x)(3+x)$, la solución es $-3\leq x\leq3$. Así $\boxed{\operatorname{Dom}(g)=[-3,3]}$. Además, si $y=g(x)$, entonces $y\geq0$ y $x^2+y^2=9$, de donde el grafo es la semicircunferencia superior de radio $3$.

#### E3. Denominador de segundo grado
La factorización $x^2-4=(x-2)(x+2)$ localiza los ceros del denominador en $2$ y $-2$. Los demás valores del denominador tienen inverso. Por tanto,

$$\boxed{\operatorname{Dom}(h)=(-\infty,-2)\cup(-2,2)\cup(2,\infty).}$$

#### E4. Simplificación y restricción
Factorizamos $x^2-1=(x-1)(x+1)$. Para $x\ne1$,

$$f(x)=\frac{(x-1)(x+1)}{x-1}=x+1=g(x).$$

Sin embargo, $\operatorname{Dom}(f)=\mathbb R\setminus\{1\}$ y $\operatorname{Dom}(g)=\mathbb R$. Las funciones coinciden en el dominio de $f$, y su relación precisa es $f=g|_{\mathbb R\setminus\{1\}}$. En el grafo de $f$ el punto $(1,2)$ está excluido.

#### E5. Radicando con módulo
Se exige $|x-2|>0$ y $(x+1)/|x-2|-2\geq0$. Al multiplicar por el denominador positivo se llega a $x+1\geq2|x-2|$. En $x<2$ resulta $3x\geq3$, es decir $x\in[1,2)$; en $x>2$ resulta $x\leq5$, de donde $x\in(2,5]$. La unión proporciona $\boxed{[1,2)\cup(2,5]}$.

#### E6. Dos ramas de una parábola
Para $x=4$, la condición $x=y^2$ da $y^2=4$, con $y=2$ y $y=-2$. Por tanto, el lugar contiene los dos puntos $(4,2)$ y $(4,-2)$. Las dos funciones $f_+(x)=\sqrt x$ y $f_-(x)=-\sqrt x$, ambas de dominio $[0,\infty)$, generan dos grafos cuya unión es exactamente el lugar geométrico original.

#### E7. Ceros y signo
$\,q(x)=x^2-4=(x-2)(x+2)$, luego los ceros son $-2$ y $2$. El producto es positivo cuando $x<-2$ o $x>2$ y negativo cuando $-2<x<2$. Así,

$$\boxed{Z(q)=\{-2,2\},\quad P(q)=(-\infty,-2)\cup(2,\infty),\quad N(q)=(-2,2).}$$

#### E8. Dos paridades
Los dominios son $\mathbb R$. La sustitución $-x$ da $(-x)^6+|-x|+3=x^6+|x|+3$, de modo que $f$ es par. Para $g$, $(-x)^5+(-x)=-(x^5+x)$, luego $g$ es impar. En cada prueba se comprueba tanto la simetría del dominio como la igualdad requerida.

#### E9. Cero de una función impar
Puesto que $0\in\mathbb R$ y la función es impar, $f(0)=-f(0)$. Sumando $f(0)$ a ambos miembros obtenemos $2f(0)=0$ y, al dividir por $2\ne0$, concluimos $\boxed{f(0)=0}$.

#### E10. Cociente de impares
Si $f(-x)=-f(x)$ y $g(-x)=-g(x)$, para todo $x$ con $g(x)\ne0$ tenemos $f(-x)/g(-x)=f(x)/g(x)$; además, $g(-x)\ne0$ simultáneamente. La razón es par. En el ejemplo $h(x)=x^3/(x|x|)$, se requiere $x\ne0$ y se simplifica a $x^2/|x|=|x|$ sobre ese dominio. Por tanto, $h$ es par en $\mathbb R\setminus\{0\}$ y su grafo tiene el origen excluido.

#### E11. Descomposición par e impar
$\,f(-x)=x^2-3x+2$. Así,

$$f_{\mathrm{par}}(x)=\frac{f(x)+f(-x)}2=x^2+2,\qquad f_{\mathrm{impar}}(x)=\frac{f(x)-f(-x)}2=3x.$$

La suma recupera $x^2+3x+2$; el primer término es par y el segundo impar. La fórmula prueba su unicidad.

#### E12. Repetición de un tramo
Si $x\in[2k,2k+1]$, entonces $x+2\in[2(k+1),2(k+1)+1]$ y ambas fórmulas dan $f(x+2)=(x+2)-2(k+1)=x-2k=f(x)$. Si $x\in[2k+1,2k+2]$, $f(x+2)=2(k+1)+2-(x+2)=2k+2-x=f(x)$. En ambos casos $x+2\in[0,\infty)$, de manera que $2$ es un periodo en el sentido de la clase.

#### E13. Rectas y monotonía
Para $x_1<x_2$ se tiene $f(x_2)-f(x_1)=m(x_2-x_1)$. Como $x_2-x_1>0$, la diferencia comparte el signo de $m$. Si $m>0$, la función es estrictamente creciente; si $m<0$, estrictamente decreciente. Cuando $m=0$, la función es constante y satisface ambas definiciones no estrictas. Por consiguiente, es creciente para $m\geq0$ y decreciente para $m\leq0$.

#### E14. Crecimiento global de $x^3+x$
Si $x_1<x_2$, entonces

$$f(x_2)-f(x_1)=(x_2-x_1)(x_2^2+x_1x_2+x_1^2+1).$$

El primer factor es positivo. Para el segundo, $x_1^2+x_1x_2+x_2^2=\tfrac12((x_1+x_2)^2+x_1^2+x_2^2)\geq0$, así que el segundo factor es al menos $1$. El producto es estrictamente positivo. Esta prueba algebraica vale en todo $\mathbb R$.

#### E15. La tarea de la clase
La factorización de diferencias de cubos lleva a

$$Q_g(x_1,x_2)=x_1^2+x_1x_2+x_2^2-1.$$

Para $1\leq x_1<x_2$, tenemos $x_1^2\geq1$, $x_1x_2>1$ y $x_2^2>1$, por lo que $Q_g>0$. El denominador original $x_2-x_1$ es positivo y por tanto $g(x_2)-g(x_1)>0$. La función es estrictamente creciente en $[1,\infty)$.

#### E16. Monotonía exacta sin derivadas
Sea $c=1/\sqrt3$. De la fórmula anterior, para $c\leq x_1<x_2$ cada término cuadrático o producto es al menos $c^2$, con alguno estrictamente mayor, por lo que $Q_g>0$. El mismo razonamiento vale para $x_1<x_2\leq-c$: los cuadrados y el producto de negativos son positivos, con magnitud al menos $c^2$. En $[-c,c]$, cada cuadrado es a lo más $c^2$ y el producto es a lo más $c^2$, de modo que $Q_g\leq0$; la igualdad exigiría $x_1=x_2=c$ o $x_1=x_2=-c$, excluidos por $x_1<x_2$. Se concluye

$$\boxed{\begin{gathered}
\text{Crecimiento estricto: }(-\infty,-1/\sqrt3],\ [1/\sqrt3,\infty),\\
\text{Decrecimiento estricto: }[-1/\sqrt3,1/\sqrt3].
\end{gathered}}$$

*Procedencia de este tramo: cátedra 5.2.*

### Una pregunta que continúa la clase anterior

**En la cátedra (09:12–11:29).** La clase anterior terminó con la función

$$\boxed{f(x)=x^3-x,\qquad\operatorname{Dom}(f)=\mathbb R.}$$

Se identificaron sus ceros $-1,0,1$, su carácter impar y una estrategia para estudiar el crecimiento a partir de dos puntos del dominio $x_1<x_2$. La pendiente de la recta secante que une $(x_1,f(x_1))$ con $(x_2,f(x_2))$ es

$$S_f(x_1,x_2)=\frac{f(x_2)-f(x_1)}{x_2-x_1}.$$

El denominador es **estrictamente positivo**, de modo que $S_f$ tiene el mismo signo que $f(x_2)-f(x_1)$. La factorización de la diferencia de cubos conduce a

$$
\begin{aligned}
S_f(x_1,x_2)
&=\frac{x_2^3-x_1^3-(x_2-x_1)}{x_2-x_1}\\
&=\frac{(x_2-x_1)(x_2^2+x_1x_2+x_1^2-1)}{x_2-x_1}\\
&=\boxed{x_1^2+x_1x_2+x_2^2-1}.
\end{aligned}
$$

Para demostrar que $f$ es estrictamente creciente en un intervalo $I$, basta establecer $S_f(x_1,x_2)>0$ para **cada par** $x_1,x_2\in I$ con $x_1<x_2$; para el decrecimiento estricto, se busca $S_f(x_1,x_2)<0$. Esta es la «técnica especial» de San Martín: una comparación de imágenes transformada en un problema de signos mediante factorización.

### La ubicación exacta de los intervalos de crecimiento

#### Un intervalo inicial: $[1,\infty)$
**En la cátedra (11:29–17:01).** Sean $1\le x_1<x_2$. Por las reglas del orden,

$$x_1^2\ge1,\qquad x_2^2>1,\qquad x_1x_2>1.$$

Al sumar, $x_1^2+x_1x_2+x_2^2-1>2>0$. Por tanto, $f$ es **estrictamente creciente en $[1,\infty)$**. La prueba retoma la tarea formulada al final de la Cátedra 5.1 y enseña a conservar la desigualdad estricta durante productos y sumas.

#### Afinar el umbral
**En la cátedra (17:03–23:02).** La elección $1$ funciona, pero podemos estudiar intervalos que comiencen antes. Sea $a>0$ y consideremos $a\le x_1<x_2$. Entonces

$$x_1^2\ge a^2,\qquad x_2^2>a^2,\qquad x_1x_2>a^2,$$

por lo que

$$S_f(x_1,x_2)>3a^2-1.$$

Para que esta última cota asegure positividad, el profesor busca el valor límite que satisface $3a^2-1=0$. Se obtiene

$$\boxed{a=\frac1{\sqrt3}=\frac{\sqrt3}{3}.}$$

Si $x_1<x_2$ pertenecen a $[a,\infty)$, la desigualdad precedente es estricta aun si $x_1=a$; así, $S_f>0$. Concluimos que $f$ es **estrictamente creciente en $[1/\sqrt3,\infty)$**. Se ha ampliado el intervalo inicial.

#### El intervalo de decrecimiento
**En la cátedra (23:04–29:51).** Ahora sean $0\le x_1<x_2\le a$. Se verifican las cotas

$$x_1^2<a^2,\qquad x_2^2\le a^2,\qquad x_1x_2<a^2.$$

Se sigue que

$$S_f(x_1,x_2)<3a^2-1=0.$$

Por consiguiente, $f$ es **estrictamente decreciente en $[0,1/\sqrt3]$**. El valor $a$ es un extremo incluido en dos intervalos diferentes; cada afirmación de monotonía compara *pares de puntos* del intervalo correspondiente.

#### Simetría y panorama global
**Demostración desarrollada y ampliación editorial.** Como $f(-x)=-f(x)$, su gráfica es simétrica respecto del origen. Esta simetría transporta el decrecimiento de $[0,a]$ a $[-a,0]$ y el crecimiento de $[a,\infty)$ a $(-\infty,-a]$. Juntando los tramos contiguos,

$$
\boxed{\begin{array}{ll}
\text{estrictamente creciente}&\text{en }(-\infty,-a]\text{ y }[a,\infty),\\
\text{estrictamente decreciente}&\text{en }[-a,a].
\end{array}}
$$

Los valores extremos se calculan directamente, **sin derivadas**:

$$f(a)=a\left(\frac13-1\right)=-\frac{2}{3\sqrt3},\qquad
f(-a)=\frac{2}{3\sqrt3}.$$

En consecuencia, la gráfica tiene un **máximo local** en $(-a,2/(3\sqrt3))$ y un **mínimo local** en $(a,-2/(3\sqrt3))$. El profesor describe su gráfico y anticipa el nexo con la derivada; la terminología y verificación algebraica explícita de los extremos se incluyen aquí como ampliación editorial.

![Gráfica de la cúbica x al cubo menos x, con ceros y cambios de monotonía.](figuras/IC2021_Catedra_5_2/01_cubica_monotonia.png)

*Figura 1. Tres ceros y los dos umbrales $\pm1/\sqrt3$ que delimitan tramos de crecimiento y decrecimiento.*

#### Una fórmula que anticipa la derivada
**En la cátedra (35:56–40:02).** El profesor observa que la ecuación $3x^2-1=0$ determina precisamente las abscisas de cambio de crecimiento. Compara esta expresión con el polinomio original $x^3-x$ y con el ejemplo $x^2-x$, cuyo vértice tiene abscisa $1/2$ y cuya ecuación asociada es $2x-1=0$. La clase **anuncia** que la teoría de derivadas permitirá estudiar sistemáticamente esta relación; todavía no define ni utiliza la derivada.

**Ampliación editorial.** Al aproximar algebraicamente el cociente secante $S_f(x,x+h)$, con $h\ne0$, se obtiene

$$S_f(x,x+h)=3x^2+3xh+h^2-1.$$

Su parte que persiste cuando $h$ se hace arbitrariamente pequeño es $3x^2-1$. Esta comprobación motiva la expresión anunciada y preserva el orden del curso: la definición formal de derivada se estudiará más adelante.

![Dos secantes de una función con pendientes de signos diferentes.](figuras/IC2021_Catedra_5_2/02_secantes.png)

*Figura 2. El signo de la pendiente secante detecta el crecimiento en el intervalo correspondiente.*

### Primeras familias de funciones conocidas

#### Funciones constantes
**En la cátedra (40:10–42:12).** Dado $c\in\mathbb R$, la función constante $f(x)=c$ tiene dominio $\mathbb R$, imagen $\{c\}$ y grafo la recta horizontal $y=c$. Es **par** porque $f(-x)=f(x)$; para $c=0$ es también **impar**, dado que $f(-x)=-f(x)=0$. Como toda pareja de imágenes coincide, es creciente y decreciente en sentido débil, y satisface ambas desigualdades por igualdad.

#### Potencias de exponente natural positivo
**En la cátedra (42:12–48:55).** Para $n\in\{1,2,3,\ldots\}$ consideramos

$$\boxed{p_n(x)=x^n,\qquad\operatorname{Dom}(p_n)=\mathbb R.}$$

Si $n$ es par, $p_n(-x)=p_n(x)$, y su imagen es $[0,\infty)$. Si $n$ es impar, $p_n(-x)=-p_n(x)$, y su imagen es $\mathbb R$. Todas las potencias son estrictamente crecientes en $[0,\infty)$. Para los exponentes impares el crecimiento se prolonga a toda la recta real; para los pares, la función es estrictamente decreciente en $(-\infty,0]$.

**Demostración desarrollada.** Si $0\le x_1<x_2$, y $n$ es natural positivo, entonces $x_1^n<x_2^n$: se puede usar la factorización

$$x_2^n-x_1^n=(x_2-x_1)\sum_{j=0}^{n-1}x_2^{n-1-j}x_1^j>0,$$

pues el primer factor es positivo y la suma contiene el término $x_2^{n-1}>0$ (para $n=1$, la suma es $1$). El profesor obtiene esa misma comparación por multiplicaciones sucesivas de desigualdades positivas.

![Funciones x, x al cuadrado, x al cubo y x a la cuarta.](figuras/IC2021_Catedra_5_2/03_potencias.png)

*Figura 3. Potencias pares e impares: distinta simetría respecto del eje vertical y del origen.*

#### Raíces de índice par e impar
**En la cátedra (48:55–56:42).** El problema $x^n=y$ se aborda según la paridad de $n$. Para $n$ par y $y>0$, aparecen dos soluciones reales opuestas; para $y=0$, la solución es $x=0$. La **raíz enésima principal** $\sqrt[n]{y}$ designa la solución **no negativa**. Para $n$ impar, la función potencia es biyectiva de $\mathbb R$ en $\mathbb R$ y cada $y$ tiene una única raíz real.

Por tanto, para $n\ge2$,

$$\operatorname{Dom}(\sqrt[n]{\cdot})=
\begin{cases}
[0,\infty),&n\text{ par},\\
\mathbb R,&n\text{ impar}.
\end{cases}$$

La ecuación $y=\sqrt[n]{x}$ equivale a $x=y^n$ junto con la condición $y\ge0$ cuando $n$ es par. La representación gráfica se obtiene intercambiando las coordenadas: la función inversa refleja el grafo respecto de $y=x$, con la restricción correspondiente para las potencias pares.

![Gráficos de raíz cuadrada y raíz cúbica y su relación con la diagonal y igual x.](figuras/IC2021_Catedra_5_2/04_raices.png)

*Figura 4. La reflexión respecto de $y=x$ relaciona la potencia y la raíz correspondiente.*

### Álgebra de funciones y dominios

#### Suma, resta y producto
**En la cátedra (56:56–1:02:06).** Sean $f:A\to\mathbb R$ y $g:B\to\mathbb R$, con $A,B\subseteq\mathbb R$. La suma se define mediante

$$(f+g)(x)=f(x)+g(x).$$

Para evaluar esta expresión es necesario disponer simultáneamente de $f(x)$ y $g(x)$; ello ocurre exactamente cuando $x\in A\cap B$. Se obtiene

$$\boxed{\operatorname{Dom}(f+g)=A\cap B.}$$

Con el mismo criterio se define la resta $f-g$ y el producto $fg$, ambos sobre $A\cap B$. El profesor destaca el valor lógico de la conjunción «$x\in A$ **y** $x\in B$» frente a una unión de dominios.

**Ejemplo de la cátedra.** Si $f(x)=\sqrt{x}$ y $g(x)=\sqrt{-x}$, entonces

$$A=[0,\infty),\qquad B=(-\infty,0],\qquad A\cap B=\{0\}.$$

Así, $f+g$ está definida únicamente en $\{0\}$ y $(f+g)(0)=0$.

![Intersección de dominios de raíz de x y raíz de menos x.](figuras/IC2021_Catedra_5_2/05_interseccion_dominios.png)

*Figura 5. La intersección de los semiejes de definición es el origen.*

#### Cociente y ceros del denominador
**En la cátedra (1:02:14–1:06:46).** El cociente de dos funciones se define sobre los puntos de $A\cap B$ donde $g(x)$ es un real distinto de cero:

$$\left(\frac fg\right)(x)=\frac{f(x)}{g(x)},\qquad
\boxed{\operatorname{Dom}(f/g)=(A\cap B)\setminus Z_g},$$

siendo $Z_g=\{x\in B:g(x)=0\}$ el **conjunto de ceros de $g$**. Esta expresión diferencia dos operaciones: comprobar que el denominador tiene una imagen y comprobar que dicha imagen admite inverso multiplicativo.

**Ejemplo de la cátedra.** Para $h(x)=\sqrt{x}/(x-1)$, el dominio del numerador es $[0,\infty)$, el del denominador considerado como función $x\mapsto x-1$ es $\mathbb R$, y su conjunto de ceros es $\{1\}$. En consecuencia,

$$\boxed{\operatorname{Dom}(h)=[0,1)\cup(1,\infty).}$$

**Ampliación editorial.** La ley obtenida tras una simplificación algebraica se interpreta sobre el dominio original de la función. Por ejemplo, $r(x)=(x^2-1)/(x-1)$ tiene dominio $\mathbb R\setminus\{1\}$ y coincide con $x+1$ para $x\ne1$; la función lineal $x+1$ tiene dominio $\mathbb R$. Sus grafos difieren en el punto $(1,2)$.

![Función racional simplificable y punto excluido.](figuras/IC2021_Catedra_5_2/06_punto_excluido.png)

*Figura 6. Un factor algebraico común puede simplificarse manteniendo la exclusión del punto del dominio original.*

#### La composición como continuidad temática
La clase anuncia que las funciones pueden combinarse mediante sumas, restas, productos, cocientes y **composición**. El desarrollo sistemático de esta última operación **no se realiza en el fragmento estudiado**; por fidelidad a la fuente, queda señalado como contenido posterior, sin atribuirle una demostración al profesor.

### Polinomios y funciones racionales

**En la cátedra (1:12:24–1:18:19).** Una **función polinómica** posee ley

$$P(x)=a_0+a_1x+\cdots+a_nx^n,\qquad a_j\in\mathbb R,$$

con dominio $\mathbb R$. La función de grado uno proporciona una recta; la de grado dos, una parábola; y la de grado tres puede presentar tramos de crecimiento distintos, como el ejemplo $x^3-x$.

Una **función racional** se obtiene como cociente de dos polinomios:

$$R(x)=\frac{P(x)}{Q(x)},\qquad Q\not\equiv0,
\qquad\boxed{\operatorname{Dom}(R)=\mathbb R\setminus\{x:Q(x)=0\}.}$$

El denominador puede ser un polinomio de grado diferente del numerador. Un estudio gráfico riguroso empieza por dominio y ceros, continúa con signos y crecimiento y examina el comportamiento cerca de los puntos excluidos y para abscisas muy grandes.

### Estudio completo de la función $\boldsymbol{2x/(x+1)}$

**En la cátedra (1:18:19–1:43:18).** El ejemplo final retoma simultáneamente las herramientas adquiridas:

$$\boxed{F(x)=\frac{2x}{x+1}.}$$

#### Dominio, cero, paridad y signo
El denominador se anula en $x=-1$, de modo que

$$\boxed{\operatorname{Dom}(F)=(-\infty,-1)\cup(-1,\infty).}$$

El numerador se anula en $x=0$, que pertenece al dominio. Así, el único cero es $0$. La función es positiva cuando numerador y denominador tienen el mismo signo, y negativa cuando sus signos son diferentes:

$$
\boxed{\begin{aligned}
F(x)>0&\iff x\in(-\infty,-1)\cup(0,\infty),\\
F(x)<0&\iff x\in(-1,0),\\
F(x)=0&\iff x=0.
\end{aligned}}
$$

La función es **ni par ni impar**: el dominio contiene $1$ y excluye $-1$, por lo cual carece de la simetría necesaria para cualquiera de las dos paridades. El profesor propone verificar esa condición antes de invertir tiempo en la sustitución algebraica $x\mapsto-x$.

![Tabla de signos de dos x sobre x más uno.](figuras/IC2021_Catedra_5_2/07_signos_racional.png)

*Figura 7. Puntos relevantes $-1$ (excluido) y $0$ (cero); signos positivos y negativos en los intervalos correspondientes.*

#### Crecimiento en cada componente del dominio
**En la cátedra (1:24:45–1:32:41).** Sean $x_1<x_2$ pertenecientes al dominio. La diferencia de imágenes tiene cociente

$$
\begin{aligned}
\frac{F(x_2)-F(x_1)}{x_2-x_1}
&=\frac{\frac{2x_2}{x_2+1}-\frac{2x_1}{x_1+1}}{x_2-x_1}\\
&=\frac{2x_2(x_1+1)-2x_1(x_2+1)}{(x_2-x_1)(x_2+1)(x_1+1)}\\
&=\boxed{\frac{2}{(x_1+1)(x_2+1)}}.
\end{aligned}
$$

Si ambos puntos pertenecen a $(-1,\infty)$, los dos factores del denominador son positivos y el cociente es positivo. Si ambos pertenecen a $(-\infty,-1)$, los dos factores son negativos y su producto vuelve a ser positivo. Por tanto,

$$\boxed{F\text{ es estrictamente creciente en cada intervalo }(-\infty,-1)\text{ y }(-1,\infty).}$$

**Precisión editorial.** La propiedad es una afirmación sobre **cada componente**, y no sobre la totalidad de $\mathbb R\setminus\{-1\}$. Por ejemplo, $-2<0$, pero $F(-2)=4>0=F(0)$. Es decir, $F$ no es creciente sobre su dominio completo según la definición con comparación de todos los pares.

#### Forma equivalente y asíntota horizontal
**En la cátedra (1:33:24–1:37:23).** La identidad

$$\boxed{F(x)=\frac{2(x+1)-2}{x+1}=2-\frac{2}{x+1}}$$

hace visible la proximidad de la función a la altura $2$ para abscisas de gran valor absoluto. Si $x>-1$, la cantidad $2/(x+1)$ es positiva y $F(x)<2$. Si $x<-1$, es negativa y $F(x)>2$. En ambos extremos del eje horizontal, la diferencia $|F(x)-2|=2/|x+1|$ puede hacerse tan pequeña como se desee eligiendo $|x+1|$ suficientemente grande.

Se dice que

$$\boxed{y=2\quad\text{es una asíntota horizontal de }F.}$$

En esta sesión el profesor explica el comportamiento por números grandes; la teoría general de **límites** queda para más adelante. La igualdad $F(x)=2$ implicaría $-2/(x+1)=0$, imposible para todo $x$ del dominio; la altura $2$ es también el único valor real excluido de la imagen de $F$.

#### Aproximación a $x=-1$ y asíntota vertical
**En la cátedra (1:38:21–1:41:08).** Escribimos $x=-1+\delta$, donde $\delta\ne0$. Entonces

$$\boxed{F(-1+\delta)=2-\frac2\delta.}$$

Cuando $\delta$ es positivo y muy pequeño, $-2/\delta$ es negativo de magnitud muy grande; cuando $\delta$ es negativo y de pequeña magnitud, el cociente $-2/\delta$ es positivo y de magnitud muy grande. Por ello la rama derecha desciende indefinidamente y la rama izquierda asciende indefinidamente al aproximarse a $-1$:

$$\boxed{x=-1\quad\text{es una asíntota vertical de }F.}$$

**Ampliación editorial.** Las afirmaciones se podrán formalizar mediante los límites laterales

$$\lim_{x\to-1^-}F(x)=+\infty,\qquad
\lim_{x\to-1^+}F(x)=-\infty,\qquad
\lim_{x\to\pm\infty}F(x)=2.$$

Se incluyen como notación anticipatoria: los límites no son todavía parte de la teoría desarrollada en la clase.

![Gráfico completo de la racional con sus dos asíntotas.](figuras/IC2021_Catedra_5_2/08_asintotas.png)

*Figura 8. La función atraviesa el origen, tiene asíntotas $x=-1$ e $y=2$ y crece estrictamente a ambos lados del punto excluido.*

#### Advertencia sobre los ceros del denominador
**En la cátedra (1:41:08–1:43:18).** El profesor anuncia criterios para estudiar funciones racionales más generales y observa que una raíz del denominador conduce al comportamiento típico de una asíntota vertical cuando el numerador conserva allí un valor distinto de cero. Un factor común puede modificar ese diagnóstico.

**Ampliación editorial.** Si $P$ y $Q$ tienen un factor común $(x-a)$, el cociente puede tener en $a$ una **discontinuidad removible**, como en $(x^2-1)/(x-1)$. Si, después de simplificar factores comunes, el denominador conserva $(x-a)$ y el numerador vale un número distinto de cero en $a$, entonces existe una asíntota vertical en $x=a$. La distinción previene la generalización indebida de que todo cero del denominador causa necesariamente una asíntota vertical.

### Síntesis, dificultades técnicas y continuidad

En esta clase confluyen el lenguaje de las funciones, la lógica de los dominios y la geometría analítica. Para el crecimiento, comparar $f(x_1)$ con $f(x_2)$ equivale a estudiar una pendiente secante. Para construir funciones nuevas mediante operaciones, la intersección de dominios es la condición constitutiva del cálculo simultáneo; el cociente añade la exigencia de un denominador con inverso. Para las funciones racionales, el estudio de signos, del crecimiento y de las asíntotas se apoya en una reescritura algebraica apropiada.

El profesor anuncia dos desarrollos posteriores: **derivadas**, que formalizarán el comportamiento de las pendientes cuando los puntos se acercan, y **límites**, que permitirán dar una definición precisa a la proximidad a las asíntotas. La siguiente semana del curso se dedica a **trigonometría**. Esos anticipos se conservan como tales, manteniendo la distinción entre conocimiento previo, resultados efectivamente desarrollados y herramientas por estudiar.

**Referencia:** Jorge San Martín, «IC2021: Cátedra 5.2. Viernes 12:00», grabación [NEYH4Qw4QK4](https://www.youtube.com/watch?v=NEYH4Qw4QK4). Edición monocromática IC2021, A4, 11 puntos, Latin Modern, márgenes 2,35 cm. Las ilustraciones se preparan en TikZ vectorial y sus equivalentes PNG se integran en la bóveda mediante enlaces relativos `figuras/IC2021_Catedra_5_2/`.

### Taller de problemas y soluciones

Los ejercicios se presentan a continuación según la fuente de origen; las ampliaciones editoriales de cada apuntes permanecen expresamente identificadas.

#### Ejercicios de consolidación — cátedra 5.1

Los dieciséis enunciados siguientes son **ejercicios editoriales**, seleccionados para practicar los conceptos de la sesión y sus relaciones. Incluyen soluciones completas. Los ejemplos de la grabación que se reutilizan se indican en la solución, distinguiendo el razonamiento original de los pasos añadidos.

**E1.** Hallar el dominio de $f(x)=\sqrt{x+3}$ y expresar el resultado como intervalo.

**E2.** Determinar el dominio de $g(x)=\sqrt{9-x^2}$ y describir su grafo.

**E3.** Resolver el dominio de $h(x)=1/(x^2-4)$.

**E4.** Establecer los dominios naturales de $f(x)=(x^2-1)/(x-1)$ y $g(x)=x+1$; explicar su relación.

**E5.** Determinar el dominio de $r(x)=\sqrt{(x+1)/|x-2|-2}$.

**E6.** Demostrar por qué el conjunto $\{(x,y):x=y^2\}$ contiene dos puntos con abscisa $4$ y construir dos funciones cuyas gráficas cubran el lugar.

**E7.** Hallar ceros, conjunto de positividad y conjunto de negatividad de $q(x)=x^2-4$.

**E8.** Clasificar la paridad de $f(x)=x^6+|x|+3$ y de $g(x)=x^5+x$.

**E9.** Justificar que una función impar definida en $\mathbb R$ tiene al cero como uno de sus ceros.

**E10.** Demostrar que el cociente de dos funciones impares es par sobre su dominio común de definición, y encontrar el dominio de $h(x)=x^3/(x|x|)$.

**E11.** Construir la descomposición par e impar de $f(x)=x^2+3x+2$.

**E12.** Comprobar que la función triangular descrita en la sección 4 tiene periodo $2$ en $[0,\infty)$.

**E13.** Decidir cuándo la función lineal $f(x)=mx+n$ es creciente, decreciente o ambas en $\mathbb R$.

**E14.** Demostrar que $f(x)=x^3+x$ es estrictamente creciente en $\mathbb R$ sin utilizar derivadas.

**E15.** Para $g(x)=x^3-x$, factorizar $Q_g(x_1,x_2)$ y demostrar estrictamente el crecimiento en $[1,\infty)$.

**E16.** Determinar, sin derivadas, los intervalos exactos de crecimiento y decrecimiento de $g(x)=x^3-x$.

#### Ejercicios complementarios con soluciones — cátedra 5.2

Los dieciocho ejercicios siguientes son **material editorial de estudio**, preparado a partir de los conceptos de la sesión. Sus enunciados y resoluciones se diferencian de las preguntas de la pizarra de San Martín.

#### E1. Calcular tres pendientes secantes de $x^3-x$
Para $f(x)=x^3-x$, calcular $S_f(0,1)$, $S_f(0,1/2)$ y $S_f(1,2)$.

**Solución.** $f(0)=0$, $f(1)=0$, $f(1/2)=1/8-1/2=-3/8$, $f(2)=6$. Así

$$S_f(0,1)=0,\qquad S_f(0,1/2)=-\frac34,\qquad S_f(1,2)=6.$$

La existencia de secantes con pendientes distintas confirma la necesidad de estudiar la monotonía por intervalos.

#### E2. Determinar el umbral positivo de $x^3-x$
Resolver $3a^2-1=0$ para $a>0$.

**Solución.** $a^2=1/3$, de donde $a=1/\sqrt3$. El signo de $a$ selecciona la solución positiva y proporciona el extremo de los intervalos de crecimiento analizados en la clase.

#### E3. Verificar los valores extremos de la cúbica
Calcular $f(\pm1/\sqrt3)$ para $f(x)=x^3-x$.

**Solución.** $f(a)=a(a^2-1)=-2a/3=-2/(3\sqrt3)$. Por imparidad, $f(-a)=2/(3\sqrt3)$.

#### E4. Demostrar crecimiento de una potencia impar
Probar sin derivadas que $x\mapsto x^3$ es estrictamente creciente en $\mathbb R$.

**Solución.** Para $u<v$,

$$v^3-u^3=(v-u)(u^2+uv+v^2).$$

El primer factor es positivo. El segundo se puede escribir como $(u+v/2)^2+3v^2/4\ge0$ y solo vale cero cuando $u=v=0$, incompatible con $u<v$. Luego $v^3-u^3>0$.

#### E5. Paridad de potencias
Clasificar $p_4(x)=x^4$ y $p_5(x)=x^5$.

**Solución.** Los dominios son $\mathbb R$. $p_4(-x)=p_4(x)$, luego $p_4$ es par. $p_5(-x)=-p_5(x)$, luego $p_5$ es impar.

#### E6. Raíz cuarta de un número positivo
Resolver $x^4=16$ en $\mathbb R$ e indicar la raíz cuarta principal.

**Solución.** $x^4=16$ equivale a $|x|=2$, de modo que el conjunto solución es $\{-2,2\}$. La raíz cuarta principal $\sqrt[4]{16}=2$.

#### E7. Raíz cúbica de un real negativo
Resolver $x^3=-27$ e identificar el dominio de $x\mapsto\sqrt[3]{x}$.

**Solución.** $x=-3$ es la única solución real por el crecimiento estricto de la función cúbica. El dominio de la raíz cúbica es $\mathbb R$.

#### E8. Dominio de la suma de dos radicales
Determinar el dominio natural de $h(x)=\sqrt{x-1}+\sqrt{5-x}$.

**Solución.** Ambas expresiones están definidas simultáneamente cuando $x\ge1$ y $x\le5$, por lo cual $\operatorname{Dom}(h)=[1,5]$.

#### E9. Intersección de dominios en un solo punto
Determinar $\operatorname{Dom}(\sqrt{x}+\sqrt{-x})$.

**Solución.** El primer radicando exige $x\ge0$ y el segundo $x\le0$. La intersección contiene exactamente $x=0$, así que $\operatorname{Dom}=\{0\}$.

#### E10. Dominio de un cociente con raíz
Determinar el dominio de $h(x)=\sqrt{x}/(x-1)$.

**Solución.** Se requiere $x\ge0$ y $x-1\ne0$. Por tanto, $\operatorname{Dom}(h)=[0,1)\cup(1,\infty)$.

#### E11. Simplificación y dominio original
Estudiar $r(x)=(x^2-9)/(x-3)$.

**Solución.** $\operatorname{Dom}(r)=\mathbb R\setminus\{3\}$, y para esos valores $r(x)=x+3$. En $(3,6)$ el grafo de la recta resultante presenta un punto excluido; la función $x\mapsto x+3$ con dominio $\mathbb R$ es una extensión de $r$.

#### E12. Signos de la función racional de clase
Resolver $2x/(x+1)\ge0$.

**Solución.** El cociente es positivo en $(-\infty,-1)\cup(0,\infty)$ y vale cero en $x=0$. El punto $-1$ está excluido. Luego

$$\boxed{S=(-\infty,-1)\cup[0,\infty).}$$

#### E13. Una desigualdad racional estricta
Resolver $2x/(x+1)<0$.

**Solución.** Los signos de numerador y denominador difieren únicamente para $-1<x<0$. El conjunto solución es $(-1,0)$.

#### E14. Cociente de diferencias de la racional
Calcular $[F(v)-F(u)]/(v-u)$ para $F(x)=2x/(x+1)$ y $u<v$ dentro de su dominio.

**Solución.** Unificando denominadores,

$$\frac{F(v)-F(u)}{v-u}=\frac{2v(u+1)-2u(v+1)}{(v-u)(v+1)(u+1)}=\frac{2}{(u+1)(v+1)}.$$

El signo depende de los lados de $-1$ en que se sitúen $u$ y $v$.

#### E15. Monotonía local versus comparación global
Comprobar que $F$ es creciente en cada componente de su dominio y dar un par que descarte crecimiento global.

**Solución.** Para puntos de una misma componente, $(u+1)(v+1)>0$; así $F(v)>F(u)$. Sin embargo, $-2<0$ y $F(-2)=4>F(0)=0$. Por tanto, la propiedad no se extiende a toda la unión del dominio.

#### E16. Dos asíntotas a partir de una identidad exacta
Para $F(x)=2-2/(x+1)$, determinar las rectas a las que se aproxima la gráfica cuando $|x|$ aumenta y cuando $x$ se aproxima a $-1$.

**Solución.** La distancia vertical a $y=2$ vale $2/|x+1|$ y se hace pequeña si $|x+1|$ aumenta; la asíntota horizontal es $y=2$. Cuando $x=-1+\delta$, la expresión $2-2/\delta$ crece ilimitadamente en magnitud al reducir $|\delta|$; la asíntota vertical es $x=-1$.

#### E17. Calcular la imagen de la racional
Hallar el conjunto imagen de $F(x)=2x/(x+1)$.

**Solución.** La igualdad $y=2x/(x+1)$ equivale a $(y-2)x=-y$. Para $y\ne2$, existe una única solución $x=-y/(y-2)$, que nunca vale $-1$ (esa igualdad forzaría $0=2$). Para $y=2$, la ecuación resulta imposible. En consecuencia, $\operatorname{Im}(F)=\mathbb R\setminus\{2\}$.

#### E18. Distinguir un punto excluido y una asíntota
Comparar $r(x)=(x^2-1)/(x-1)$ y $s(x)=1/(x-1)$ cerca de $x=1$.

**Solución.** Para $x\ne1$, $r(x)=x+1$ y se aproxima al valor finito $2$, conservando el punto $(1,2)$ excluido; su grafo tiene un **agujero**. La función $s$ posee un numerador constante distinto de cero, y su valor absoluto $1/|x-1|$ puede crecer cuanto se quiera al acercarse a $1$; $x=1$ es una **asíntota vertical** de $s$.

---

## El círculo trigonométrico y sus identidades

La medida de ángulos en radianes conduce a las funciones seno, coseno y tangente. La geometría del círculo unitario explica sus signos, dominios e identidades fundamentales.

**Grabaciones de referencia:** [grabación de la cátedra 6.1](https://www.youtube.com/watch?v=Omn6hikVwIc), [grabación de la cátedra 6.2](https://www.youtube.com/watch?v=bkh-hjyrE_o).

*Procedencia de este tramo: cátedra 6.1.*

### La medida de los ángulos

#### Medición sexagesimal y centesimal
**En la cátedra (04:35–08:55).** Dos rayos $OA$ y $OB$ con origen común determinan una apertura angular. El sistema **sexagesimal** divide la vuelta completa en $360$ grados; el ángulo recto mide $90^\circ$ y el llano, $180^\circ$. Cada grado contiene $60$ minutos de arco y cada minuto, $60$ segundos de arco:

$$90^\circ=\text{ángulo recto},\qquad 1^\circ=60',\qquad 1'=60''.$$

En el sistema **centesimal** el ángulo recto mide $100$ grados centesimales, denotados aquí por $\mathrm{gon}$, y la vuelta completa mide $400\,\mathrm{gon}$. Los submúltiplos se organizan en base cien. Su división facilita ciertos cálculos decimales, especialmente en topografía.

$$\boxed{90^\circ=100\,\mathrm{gon},\qquad 360^\circ=400\,\mathrm{gon}.}$$

![Un ángulo recto equivale a 90 grados sexagesimales, 100 gon o pi medios radianes.](figuras/IC2021_Catedra_6_1/01_sistemas_angulares.png)

*Figura 1. Tres representaciones de la medida de una misma apertura.*

#### La razón arco-radio: medida circular
**En la cátedra (08:55–16:50).** Para un ángulo central dado, trazamos arcos de circunferencia de radios distintos $r_1,r_2>0$. Sus longitudes $s_1,s_2$ crecen en la misma proporción que los radios; por semejanza de sectores circulares,

$$\frac{s_1}{r_1}=\frac{s_2}{r_2}.$$

La razón común mide el ángulo en el **sistema circular**:

$$\boxed{\alpha=\frac{s}{r}\quad\text{(radianes)},\qquad s=r\alpha.}$$

En una misma unidad de longitud, $s$ y $r$ producen una razón sin dimensión física. El *radián* es el nombre de esa unidad angular y se escribe $\mathrm{rad}$. Un ángulo de un radián subtiende un arco de longitud igual al radio. La independencia respecto de $r$ explica que sea posible usar una circunferencia de radio $1$.

![Dos arcos de radios diferentes que subtienen el mismo ángulo y mantienen constante la razón entre arco y radio.](figuras/IC2021_Catedra_6_1/02_arco_radio.png)

*Figura 2. Para una apertura fija, el cociente $s/r$ permanece constante.*

**Precisión editorial.** En el SI, el radián posee un símbolo propio para identificar una medida angular, aunque su expresión en términos de unidades básicas es $\mathrm{m}/\mathrm{m}=1$. La ausencia de dimensión explica la simplificación del cociente; la palabra «radián» conserva una función importante de identificación del tipo de magnitud.

#### Los ángulos fundamentales en radianes
**En la cátedra (16:50–24:00).** Una circunferencia de radio $r$ tiene longitud $2\pi r$. Una vuelta completa mide, por consiguiente,

$$\frac{2\pi r}{r}=2\pi\;\mathrm{rad}.$$

Un cuarto de vuelta mide $\pi/2$ y media vuelta mide $\pi$. La conversión universal es

$$\boxed{180^\circ=\pi\;\mathrm{rad},\qquad \alpha_{\mathrm{rad}}=\alpha_{^\circ}\frac{\pi}{180}.}$$

| Apertura | Grados | Radianes |
|:---|---:|---:|
| Sexta parte de una vuelta | $60^\circ$ | $\pi/3$ |
| Duodécima parte | $30^\circ$ | $\pi/6$ |
| Octava parte | $45^\circ$ | $\pi/4$ |
| Cuarta parte | $90^\circ$ | $\pi/2$ |
| Media vuelta | $180^\circ$ | $\pi$ |
| Vuelta completa | $360^\circ$ | $2\pi$ |

#### Ángulos orientados y vueltas sucesivas
**En la cátedra (24:00–30:15).** Fijamos como lado inicial el rayo horizontal positivo. La rotación antihoraria asigna medidas **positivas**; la rotación horaria asigna medidas **negativas**. La medida angular orientada toma valores reales y registra vueltas sucesivas; por ejemplo, $5\pi/2$ representa una vuelta completa más $\pi/2$.

![Giros positivos antihorarios y negativos horarios desde el eje horizontal positivo.](figuras/IC2021_Catedra_6_1/03_angulos_orientados.png)

*Figura 3. El signo registra el sentido del giro y las vueltas completas acumulan $2\pi$ radianes.*

El extremo final sobre la circunferencia coincide después de cada vuelta completa. Así, para cualquier $k\in\mathbb Z$, las medidas $\alpha$ y $\alpha+2k\pi$ designan la misma posición final. Se distinguen por el número de vueltas acumuladas.

**Ampliación editorial.** Para medidas mayores que una vuelta o negativas, la interpretación $s/r$ utiliza la **longitud de arco orientada y acumulada** de la trayectoria. Si se toma únicamente el arco geométrico más corto entre dos rayos, se pierde la información sobre las vueltas completas y el sentido.

### La circunferencia trigonométrica y las funciones seno y coseno

#### La aplicación ángulo-punto
**En la cátedra (30:15–36:55).** Consideramos la circunferencia unitaria

$$\mathbb S^1=\{(x,y)\in\mathbb R^2:x^2+y^2=1\}.$$

El rayo inicial corta a $\mathbb S^1$ en $A=(1,0)$. Cada ángulo orientado $\alpha\in\mathbb R$ determina un punto final único $P_\alpha\in\mathbb S^1$. La aplicación $\alpha\mapsto P_\alpha$ tiene dominio $\mathbb R$ y repite la misma imagen tras una vuelta:

$$\boxed{P_{\alpha+2k\pi}=P_\alpha\quad(k\in\mathbb Z).}$$

La construcción posee una periodicidad de $2\pi$. Los puntos finales corresponden a clases de ángulos que difieren en una cantidad entera de vueltas completas.

#### Definiciones afirmativas del seno y coseno
**En la cátedra (36:55–42:45).** Escribimos las coordenadas cartesianas del punto final como

$$\boxed{P_\alpha=(\cos\alpha,\operatorname{sen}\alpha).}$$

El **coseno** es la función que a cada medida angular $\alpha$ asigna la abscisa del punto $P_\alpha$. El **seno** asigna su ordenada. Ambas funciones tienen dominio $\mathbb R$ e imagen $[-1,1]$.

![La abscisa de un punto del círculo unitario representa coseno y su ordenada representa seno.](figuras/IC2021_Catedra_6_1/04_circulo_seno_coseno.png)

*Figura 4. Proyecciones horizontal y vertical del radio unitario.*

En las posiciones cardinales se obtiene inmediatamente:

| $\alpha$ | $0$ | $\pi/2$ | $\pi$ | $3\pi/2$ | $2\pi$ |
|:---|:---:|:---:|:---:|:---:|:---:|
| $\cos\alpha$ | $1$ | $0$ | $-1$ | $0$ | $1$ |
| $\operatorname{sen}\alpha$ | $0$ | $1$ | $0$ | $-1$ | $0$ |

**En la cátedra.** A cada $\alpha$ le corresponde un único $P_\alpha$, aunque distintos ángulos pueden compartir el mismo punto. Por eso la aplicación ángulo-punto es periódica y presenta múltiples medidas asociadas a una misma posición.

**Ampliación editorial: simetrías.** La reflexión respecto del eje horizontal produce

$$\cos(-\alpha)=\cos\alpha,\qquad \operatorname{sen}(-\alpha)=-\operatorname{sen}\alpha.$$

La primera función es par y la segunda, impar. De la media vuelta se obtiene

$$\cos(\alpha+\pi)=-\cos\alpha,\qquad \operatorname{sen}(\alpha+\pi)=-\operatorname{sen}\alpha.$$

### Las seis funciones trigonométricas y sus dominios

**En la cátedra (42:45–55:50).** Las cuatro funciones adicionales se construyen mediante cocientes de seno y coseno:

$$
\begin{aligned}
\tan\alpha&=\frac{\operatorname{sen}\alpha}{\cos\alpha},
&\cot\alpha&=\frac{\cos\alpha}{\operatorname{sen}\alpha},\\
\sec\alpha&=\frac{1}{\cos\alpha},
&\csc\alpha&=\frac{1}{\operatorname{sen}\alpha}.
\end{aligned}
$$

Para determinar sus dominios, partimos del de seno y coseno, que es $\mathbb R$, y seleccionamos los ángulos cuyo **denominador tiene valor distinto de cero**. Sobre el círculo unitario,

$$\cos\alpha=0\iff\alpha=\frac\pi2+k\pi,\qquad
\operatorname{sen}\alpha=0\iff\alpha=k\pi,\qquad k\in\mathbb Z.$$

![Los puntos cardinales identifican los ceros de seno y coseno utilizados para calcular dominios.](figuras/IC2021_Catedra_6_1/05_ceros_dominios.png)

*Figura 5. Ceros de coseno en los extremos del diámetro vertical; ceros de seno en los extremos del horizontal.*

| Función | Expresión | Dominio natural |
|:---|:---|:---|
| $\operatorname{sen}$ | ordenada de $P_\alpha$ | $\mathbb R$ |
| $\cos$ | abscisa de $P_\alpha$ | $\mathbb R$ |
| $\tan$ | $\operatorname{sen}/\cos$ | $\mathbb R\setminus\{\pi/2+k\pi:k\in\mathbb Z\}$ |
| $\sec$ | $1/\cos$ | $\mathbb R\setminus\{\pi/2+k\pi:k\in\mathbb Z\}$ |
| $\cot$ | $\cos/\operatorname{sen}$ | $\mathbb R\setminus\{k\pi:k\in\mathbb Z\}$ |
| $\csc$ | $1/\operatorname{sen}$ | $\mathbb R\setminus\{k\pi:k\in\mathbb Z\}$ |

La pareja tangente-secante comparte el mismo dominio; la pareja cotangente-cosecante comparte otro dominio. Seno y coseno están definidos para todos los ángulos reales.

#### Cotangente frente a recíproco de tangente
**En la cátedra (50:30–52:10).** Se presenta una distinción de funciones según su dominio. Las expresiones

$$\cot\alpha=\frac{\cos\alpha}{\operatorname{sen}\alpha}
\quad\text{y}\quad \frac1{\tan\alpha}$$

coinciden **en los ángulos donde ambas están definidas**. Sin embargo, sus dominios naturales son diferentes:

$$\operatorname{Dom}(1/\tan)=\mathbb R\setminus\left(\{k\pi\}\cup\{\pi/2+k\pi\}\right)
=\mathbb R\setminus\{k\pi/2:k\in\mathbb Z\}.$$

Por ejemplo, $\cot(\pi/2)=0$ está definido porque $\operatorname{sen}(\pi/2)=1$, mientras $1/\tan(\pi/2)$ requiere evaluar una tangente cuyo denominador se anula. **La ley simplificada y el dominio se consideran conjuntamente al identificar funciones.**

### Las identidades fundamentales

#### La identidad pitagórica
**En la cátedra (55:50–57:42).** El punto $P_\alpha$ satisface la ecuación de la circunferencia unitaria, $x^2+y^2=1$. Al sustituir sus coordenadas, para cada $\alpha\in\mathbb R$,

$$\boxed{\cos^2\alpha+\operatorname{sen}^2\alpha=1.}$$

La identidad expresa el teorema de Pitágoras en el radio unitario y comprende los cuatro cuadrantes.

#### Identidad tangente-secante
**En la cátedra (57:42–59:39).** Para cada $\alpha$ del dominio de $\tan$, es decir, con $\cos\alpha\ne0$, dividimos la identidad anterior por $\cos^2\alpha$:

$$
\frac{\cos^2\alpha}{\cos^2\alpha}+\frac{\operatorname{sen}^2\alpha}{\cos^2\alpha}
=\frac1{\cos^2\alpha}.
$$

Se obtiene

$$\boxed{1+\tan^2\alpha=\sec^2\alpha\quad(\cos\alpha\ne0).}$$

#### Identidad cotangente-cosecante
**En la cátedra (59:39–1:01:10).** Para cada $\alpha$ con $\operatorname{sen}\alpha\ne0$, dividimos por $\operatorname{sen}^2\alpha$:

$$\boxed{1+\cot^2\alpha=\csc^2\alpha\quad(\operatorname{sen}\alpha\ne0).}$$

Las tres identidades proceden de una sola igualdad geométrica. Las hipótesis de los cocientes indican exactamente los dominios donde cada transformación es válida.

### Cálculo geométrico de los ángulos especiales

#### El ángulo $45^\circ=\pi/4$
**En la cátedra (1:06:42–1:09:38).** El rayo que forma $\pi/4$ con el eje horizontal sigue la bisectriz $y=x$ del primer cuadrante. Su intersección con la circunferencia $x^2+y^2=1$ satisface

$$x^2+x^2=1\iff 2x^2=1.$$

Como el punto está en el primer cuadrante, $x=1/\sqrt2=\sqrt2/2$; también $y=x$. Por tanto,

$$\boxed{\cos(\pi/4)=\operatorname{sen}(\pi/4)=\frac{\sqrt2}{2}.}$$

![La bisectriz y igual a x corta el círculo unitario en el punto con ambas coordenadas raíz de dos medios.](figuras/IC2021_Catedra_6_1/06_angulo_cuarenta_cinco.png)

*Figura 6. El triángulo rectángulo isósceles asociado a $\pi/4$.*

#### El ángulo $60^\circ=\pi/3$
**En la cátedra (1:11:40–1:17:22).** Tomamos un triángulo equilátero de lado $1$ con un vértice en el origen y otro en $(1,0)$. Su tercer vértice $P$ pertenece a la circunferencia unitaria y forma un ángulo de $60^\circ$. La altura divide la base en dos partes de longitud $1/2$; por ello $x=1/2$. La ecuación de la circunferencia da

$$y^2=1-\frac14=\frac34,\qquad y=\frac{\sqrt3}{2}.$$

Luego

$$\boxed{\cos(\pi/3)=\frac12,\qquad\operatorname{sen}(\pi/3)=\frac{\sqrt3}{2}.}$$

![El triángulo equilátero de lado uno y su altura permiten obtener los valores exactos de 60 grados.](figuras/IC2021_Catedra_6_1/07_angulo_sesenta.png)

*Figura 7. El triángulo equilátero produce dos triángulos rectángulos de $30^\circ$, $60^\circ$ y $90^\circ$.*

#### El ángulo $30^\circ=\pi/6$
**En la cátedra (1:17:22–1:19:12).** Los ángulos $\pi/6$ y $\pi/3$ son complementarios; al intercambiar las coordenadas horizontal y vertical del triángulo anterior se obtiene

$$\boxed{\cos(\pi/6)=\frac{\sqrt3}{2},\qquad\operatorname{sen}(\pi/6)=\frac12.}$$

La tabla completa de los ángulos fundamentales del primer cuadrante es:

| $\alpha$ | $0$ | $\pi/6$ | $\pi/4$ | $\pi/3$ | $\pi/2$ |
|:---|:---:|:---:|:---:|:---:|:---:|
| Grados | $0^\circ$ | $30^\circ$ | $45^\circ$ | $60^\circ$ | $90^\circ$ |
| $\operatorname{sen}\alpha$ | $0$ | $1/2$ | $\sqrt2/2$ | $\sqrt3/2$ | $1$ |
| $\cos\alpha$ | $1$ | $\sqrt3/2$ | $\sqrt2/2$ | $1/2$ | $0$ |
| $\tan\alpha$ | $0$ | $1/\sqrt3$ | $1$ | $\sqrt3$ | indefinida |

La regla mnemotécnica que muestra el profesor es escribir los valores del seno como $\sqrt n/2$, con $n=0,1,2,3,4$, en orden de ángulos crecientes, y los del coseno en orden inverso. **Su validez está sustentada por los cálculos geométricos anteriores**, además de servir como recordatorio.

### Segmentos trigonométricos y la recta tangente al círculo

**En la cátedra (1:21:45–1:28:55).** Para $\cos\alpha\ne0$, la recta por el origen y $P_\alpha$ tiene pendiente

$$m=\frac{\operatorname{sen}\alpha}{\cos\alpha}=\tan\alpha,$$

y su ecuación es $y=(\tan\alpha)x$. Al intersectarla con la recta vertical **$x=1$**, obtenemos el punto

$$Q_\alpha=(1,\tan\alpha).$$

Por tanto, la tangente puede leerse geométricamente como la ordenada de $Q_\alpha$, medida a partir del eje horizontal. La recta $x=1$ es tangente a la circunferencia unitaria en $(1,0)$; en ella la ordenada conserva el signo de $\tan\alpha$. Cuando $\cos\alpha=0$, la recta radial es vertical y esta construcción carece de un punto de intersección finito con $x=1$.

![La línea radial de pendiente tangente alfa intercepta la recta vertical x igual uno en un punto cuya ordenada es tangente alfa.](figuras/IC2021_Catedra_6_1/08_linea_tangente.png)

*Figura 8. Una representación geométrica de la tangente por intersección de dos rectas.*

**Ampliación editorial.** Para un punto $Q_\alpha$ como el de la figura, la distancia desde el origen es $\sqrt{1+\tan^2\alpha}=|\sec\alpha|$. El valor absoluto refleja que la longitud siempre es no negativa; el signo de $\sec\alpha$ coincide con el del coseno.

### Los gráficos de seno, coseno y tangente

#### Seno y coseno: periodicidad, signos y crecimiento
**En la cátedra (1:28:55–1:34:10).** A medida que el ángulo recorre una vuelta positiva, la coordenada vertical del círculo crece desde $0$ hasta $1$, decrece hasta $0$ y luego hasta $-1$, y vuelve a crecer hasta $0$. Así surge el perfil de la función seno. La coordenada horizontal comienza en $1$, decrece hasta $-1$ y vuelve a crecer hasta $1$, originando el coseno.

![Gráficas de seno y coseno que muestran sus valores entre menos uno y uno y la repetición cada dos pi.](figuras/IC2021_Catedra_6_1/09_graficas_seno_coseno.png)

*Figura 9. Los dos gráficos tienen imagen $[-1,1]$ y periodo $2\pi$.*

En la primera vuelta, el seno crece en $[0,\pi/2]$ y $[3\pi/2,2\pi]$, y decrece en $[\pi/2,3\pi/2]$; el coseno decrece en $[0,\pi]$ y crece en $[\pi,2\pi]$. La periodicidad permite trasladar estos comportamientos por múltiplos de $2\pi$. Estos tramos se deducen geométricamente del movimiento de las proyecciones, sin usar derivadas.

$$\boxed{\operatorname{sen}(\alpha+2\pi)=\operatorname{sen}\alpha,\qquad
\cos(\alpha+2\pi)=\cos\alpha.}$$

#### Tangente: tramos, ceros y asíntotas
**En la cátedra (1:34:10–1:37:25).** Las ordenadas de $Q_\alpha=(1,\tan\alpha)$ crecen a lo largo de cada intervalo delimitado por dos ángulos consecutivos donde el coseno se anula. Al acercarse al extremo derecho $\pi/2$ de $(-\pi/2,\pi/2)$, la ordenada aumenta sin cota; al aproximarse desde la derecha, toma valores negativos de magnitud creciente. La misma configuración se repite en los demás intervalos.

![Gráfica de la tangente con asíntotas verticales en los múltiplos impares de pi medios.](figuras/IC2021_Catedra_6_1/10_grafica_tangente.png)

*Figura 10. La tangente es estrictamente creciente en cada componente de su dominio y tiene asíntotas verticales en $\pi/2+k\pi$.*

La tangente tiene periodo fundamental $\pi$, pues una media vuelta cambia simultáneamente los signos del seno y del coseno, conservando su cociente:

$$\boxed{\tan(\alpha+\pi)=\tan\alpha\qquad(\alpha\in\operatorname{Dom}\tan).}$$

**Ampliación editorial.** Esta comprobación distingue el periodo de la tangente ($\pi$) del periodo común de seno y coseno ($2\pi$). Para cada $k\in\mathbb Z$, las rectas $\alpha=\pi/2+k\pi$ son asíntotas verticales. Los ceros de tangente son los múltiplos enteros de $\pi$.

### Cuestiones finales y precisiones conceptuales

**En la cátedra (1:37:25–1:51:09).** Durante las preguntas el profesor vuelve sobre la acotación, las restricciones de dominio y la interpretación del grafo. Una función puede tener un dominio acotado y una imagen sin cota: la tangente, restringida a $(-\pi/2,\pi/2)$, tiene dominio acotado e imagen $\mathbb R$. Restringir una función significa elegir una parte de su dominio y considerar la misma asignación en esa parte; su imagen puede cambiar según la restricción elegida.

La clase distingue también las expresiones con parte entera cuya lectura verbal puede resultar ambigua según la ubicación de los paréntesis. La condición de dominio procede del denominador **efectivamente escrito**: para $1/\lfloor x\rfloor$ se excluyen los $x$ tales que $\lfloor x\rfloor=0$, esto es, $[0,1)$; para $1/(\lfloor x\rfloor-x)$ se excluyen los enteros. Estas dos expresiones pertenecen al diálogo final y se presentan como aclaración sobre la sintaxis matemática.

#### Verificación y reconstrucción editorial
La prueba de que una función está acotada superiormente consiste en encontrar $M\in\mathbb R$ tal que $f(x)\le M$ para **todos** los puntos de su dominio; está acotada inferiormente cuando existe $m$ con $m\le f(x)$ para todos esos puntos. Por ejemplo, $-1\le\operatorname{sen}\alpha\le1$. La restricción de una función acotada sigue acotada por las mismas constantes.

Para obtener los gráficos se distinguen tres niveles: la geometría del círculo proporciona los valores principales y la simetría; la periodicidad reproduce la información a lo largo de toda $\mathbb R$; el estudio de crecimiento organiza los arcos entre valores cardinales. Los argumentos de la clase son geométricos y preparan la formalización posterior mediante límites y derivadas.

*Procedencia de este tramo: cátedra 6.2.*

### De la trigonometría general a los triángulos rectángulos

**En la cátedra (11:47–17:12).** En el círculo unitario cada ángulo orientado $\alpha\in\mathbb R$ determina el punto

$$P_\alpha=(\cos\alpha,\operatorname{sen}\alpha).$$

El signo de las coordenadas, y con ellas el de las funciones trigonométricas, depende del cuadrante. La tangente se obtiene como $\tan\alpha=\operatorname{sen}\alpha/\cos\alpha$ en los ángulos donde $\cos\alpha\ne0$.

![Signos trigonométricos por cuadrante](figuras/IC2021_Catedra_6_2/01_cuadrantes_y_signos.png)

| Cuadrante | $\cos\alpha$ | $\operatorname{sen}\alpha$ | $\tan\alpha$ |
|:---:|:---:|:---:|:---:|
| I | $+$ | $+$ | $+$ |
| II | $-$ | $+$ | $-$ |
| III | $-$ | $-$ | $+$ |
| IV | $+$ | $-$ | $-$ |

El profesor recuerda una mnemotecnia para los signos positivos: *todos, seno, tangente, coseno* (I–IV). Esta regla resume una propiedad que se obtiene directamente de las coordenadas en el plano.

En un triángulo rectángulo no degenerado, los dos ángulos agudos $\alpha,\beta$ satisfacen

$$\alpha>0,\quad \beta>0,\qquad\alpha+\beta=\frac\pi2.$$

En particular, cada uno pertenece a $(0,\pi/2)$. Aquí se sitúa la **trigonometría de triángulos rectángulos** como aplicación de la trigonometría general definida para ángulos reales.

### Las tres razones trigonométricas mediante semejanza

**En la cátedra (17:12–25:49).** Sea $ABC$ un triángulo rectángulo en $C$, con $\angle A=\alpha$. Se fija un sistema de coordenadas con origen en $A$ y eje horizontal a lo largo de $AC$. El rayo $AB$ intercepta una circunferencia centrada en $A$ y de radio auxiliar $r>0$ en $P=(r\cos\alpha,r\operatorname{sen}\alpha)$. Su proyección vertical al eje horizontal es $H$. El caso $r=1$ recupera exactamente la construcción unitaria empleada por el profesor; la figura utiliza un radio ampliado para distinguir los dos triángulos.

![Dos triángulos rectángulos semejantes](figuras/IC2021_Catedra_6_2/02_semejanza_rectangulos.png)

Los triángulos $ABC$ y $AHP$ tienen un ángulo $\alpha$ común y sendos ángulos rectos. El criterio **ángulo–ángulo** establece su semejanza. Los lados correspondientes son

$$AC\leftrightarrow AH=r\cos\alpha,\quad BC\leftrightarrow HP=r\operatorname{sen}\alpha,\quad AB\leftrightarrow AP=r.$$

**Desarrollo de la demostración.** La proporcionalidad de lados permite escribir

$$\frac{r\cos\alpha}{AC}=\frac{r\operatorname{sen}\alpha}{BC}=\frac r{AB}.$$

Puesto que $r>0$, al simplificar ese factor se obtiene $\cos\alpha/AC=\operatorname{sen}\alpha/BC=1/AB$.

Multiplicando por los lados respectivos se obtienen las fórmulas tradicionales

$$
\boxed{\operatorname{sen}\alpha=\frac{BC}{AB}=\frac{\text{cateto opuesto}}{\text{hipotenusa}},}\qquad
\boxed{\cos\alpha=\frac{AC}{AB}=\frac{\text{cateto adyacente}}{\text{hipotenusa}}.}
$$

Al dividir las dos igualdades, las hipotenusas se simplifican y resulta

$$\boxed{\tan\alpha=\frac{BC}{AC}=\frac{\text{cateto opuesto}}{\text{cateto adyacente}}.}$$

Estas expresiones se refieren siempre al ángulo seleccionado. Si se trabaja con el otro ángulo agudo del triángulo, los papeles de los catetos opuesto y adyacente se intercambian.

### Proyecciones ortogonales y componentes

**En la cátedra (26:04–32:19).** Las igualdades anteriores se utilizan habitualmente despejando el cateto correspondiente. Si un segmento de longitud $L$ forma un ángulo agudo $\alpha$ con la horizontal, entonces sus componentes son

$$\boxed{L_x=L\cos\alpha,\qquad L_y=L\operatorname{sen}\alpha.}$$

![Proyecciones horizontal y vertical de un segmento](figuras/IC2021_Catedra_6_2/03_proyecciones.png)

El cateto adyacente mide $L\cos\alpha$ y el opuesto mide $L\operatorname{sen}\alpha$. Esta lectura aporta una herramienta para interpretar desplazamientos, fuerzas y velocidades en direcciones perpendiculares. En una descripción vectorial más amplia, los signos de las componentes quedan determinados por el ángulo orientado.

**Ampliación editorial.** Para un vector plano de módulo $L$ y ángulo orientado $\alpha$, sus componentes cartesianas se expresan por

$$\vec v=L(\cos\alpha,\operatorname{sen}\alpha).$$

Esta fórmula extiende el dibujo del primer cuadrante a todas las orientaciones y respeta los signos incorporados en seno y coseno.

### Aplicación I: pendiente de una recta

**En la cátedra (32:23–35:23).** Sea una recta de pendiente $m$ que pasa por dos puntos distintos $A=(x_1,y_1)$ y $B=(x_2,y_2)$, con $x_1\ne x_2$. La diferencia vertical $y_2-y_1$ y la horizontal $x_2-x_1$ constituyen los catetos de un triángulo rectángulo cuya hipotenusa pertenece a la recta. Para la configuración ascendente del dibujo,

$$\tan\alpha=\frac{y_2-y_1}{x_2-x_1}.$$

![Pendiente y tangente del ángulo de inclinación](figuras/IC2021_Catedra_6_2/04_pendiente_y_tangente.png)

La razón del lado derecho es la pendiente de la geometría analítica. En consecuencia,

$$\boxed{m=\tan\alpha.}$$

El profesor enfatiza que la fórmula también describe pendientes negativas usando un ángulo orientado coherente. **Precisión editorial:** en el caso de una recta no vertical, es posible tomar el representante de su inclinación en $(-\pi/2,\pi/2)$; entonces $m$ y $\tan\alpha$ poseen el mismo signo. Una recta vertical corresponde a una dirección en la que el cociente que define la pendiente carece de denominador distinto de cero.

### Aplicación II: fuerzas sobre un plano inclinado

**En la cátedra (35:33–51:25).** San Martín considera una partícula de masa $m$ sobre un plano que forma un ángulo agudo $\alpha$ con la horizontal. El peso tiene módulo $mg$ y apunta verticalmente hacia abajo. Elige dos direcciones ortogonales: una paralela al plano y otra perpendicular a él.

![Descomposición del peso y reacción normal](figuras/IC2021_Catedra_6_2/05_plano_inclinado.png)

La geometría de los ángulos del triángulo de fuerzas conduce a

$$\boxed{P_{\parallel}=mg\operatorname{sen}\alpha,\qquad P_{\perp}=mg\cos\alpha.}$$

$P_{\parallel}$ es la magnitud de la componente dirigida cuesta abajo, y $P_{\perp}$ la de la componente dirigida hacia el plano.

#### Reacción normal y sujeción mediante cuerda
En una superficie rígida, sin otras fuerzas perpendiculares, el equilibrio en la dirección normal exige una reacción de magnitud

$$N=mg\cos\alpha.$$

Si una cuerda paralela al plano sostiene el cuerpo en reposo y se omite el roce, la tensión requerida es

$$T=mg\operatorname{sen}\alpha.$$

Las dos expresiones corresponden a balances de fuerzas **en direcciones diferentes**. La normal compensa la componente perpendicular; la cuerda compensa la componente paralela.

#### Resorte y deformación elástica
El profesor reemplaza después la cuerda por un resorte y utiliza la proporcionalidad entre tensión y elongación. Si $k>0$ es la constante elástica y $\Delta\ell$ es el estiramiento respecto de la longitud natural,

$$k\,\Delta\ell=T=mg\operatorname{sen}\alpha
\quad\Longrightarrow\quad
\boxed{\Delta\ell=\frac{mg\operatorname{sen}\alpha}{k}.}$$

Esta relación describe un equilibrio idealizado de un resorte alineado con el plano. El profesor menciona también el hundimiento en soportes deformables como una aplicación conceptual del mismo balance de fuerzas.

#### Roce estático y ángulo crítico
Se considera ahora el equilibrio proporcionado por la fuerza de roce estático. Su magnitud puede ajustarse hasta el máximo $\mu_sN$, donde $\mu_s\ge0$ es el coeficiente de roce estático. La condición para que el cuerpo permanezca en reposo, en el modelo sin otras fuerzas paralelas, es

$$mg\operatorname{sen}\alpha\le\mu_s mg\cos\alpha.$$

Como $m,g,\cos\alpha$ son positivos para $0<\alpha<\pi/2$, al dividir se conserva el sentido de la desigualdad:

$$\boxed{\tan\alpha\le\mu_s.}$$

![Condición geométrica del ángulo crítico](figuras/IC2021_Catedra_6_2/06_roce_critico.png)

Para el umbral de inicio del deslizamiento, la igualdad determina el ángulo crítico $\alpha_c$ mediante $\tan\alpha_c=\mu_s$. La creciente inclinación eleva la componente paralela del peso respecto de la capacidad máxima del roce.

**Precisión editorial.** La ley del roce estático afirma $|F_r|\le\mu_sN$; la igualdad se alcanza en el umbral de deslizamiento. En posiciones de reposo con inclinaciones menores, la magnitud real del roce es $mg\operatorname{sen}\alpha$, determinada por el equilibrio. El análisis presupone un contacto estable y un modelo mecánico ideal.

### Preparación de las identidades: dos puntos del círculo unitario

**En la cátedra (51:53–1:04:47).** Sean $\alpha,\beta\in\mathbb R$ dos ángulos orientados y

$$P_\alpha=(\cos\alpha,\operatorname{sen}\alpha),\qquad
P_\beta=(\cos\beta,\operatorname{sen}\beta).$$

![Cuerda entre dos puntos del círculo unitario](figuras/IC2021_Catedra_6_2/07_cuerda_del_circulo.png)

Las funciones seno y coseno ya incorporan los signos correspondientes a los cuadrantes. El profesor advierte repetidamente que colocar un signo menos adicional delante de una coordenada por estar en un cuadrante determinado cambia el valor calculado y puede invalidar el dibujo. Por ejemplo, si $\cos\alpha<0$, la abscisa es exactamente $\cos\alpha$, un número negativo.

La distancia $d=|P_\alpha P_\beta|$ se calcula por la fórmula de geometría analítica:

$$d^2=(\cos\alpha-\cos\beta)^2+(\operatorname{sen}\alpha-\operatorname{sen}\beta)^2.$$

**Desarrollo de la demostración.** Expandiendo ambos cuadrados,

$$
\begin{aligned}
d^2={}&\cos^2\alpha+\cos^2\beta-2\cos\alpha\cos\beta\\
&+\operatorname{sen}^2\alpha+\operatorname{sen}^2\beta
-2\operatorname{sen}\alpha\operatorname{sen}\beta.
\end{aligned}
$$

Agrupando los términos de un mismo ángulo y aplicando $\cos^2t+\operatorname{sen}^2t=1$ para $t=\alpha,\beta$, queda

$$\boxed{d^2=2-2\big(\cos\alpha\cos\beta+
\operatorname{sen}\alpha\operatorname{sen}\beta\big).}\tag{1}$$

Esta expresión se obtuvo para cualquier par de ángulos reales. Tiene además una verificación geométrica: los dos puntos se encuentran en una circunferencia de diámetro $2$, por lo que su distancia está entre $0$ y $2$ y su cuadrado entre $0$ y $4$.

### El argumento decisivo: rotar simultáneamente los puntos

**En la cátedra (1:10:28–1:19:35).** El profesor mueve $P_\alpha$ y $P_\beta$ simultáneamente alrededor del origen, conservando la distancia entre ellos. Escoge una rotación de ángulo $-\alpha$ para llevar el primero al punto $P_0=(1,0)$. El segundo queda en $P_{\beta-\alpha}$.

![Rotación simultánea de dos puntos y conservación de una cuerda](figuras/IC2021_Catedra_6_2/08_rotacion_conserva_distancia.png)

La rotación rígida preserva distancias, de modo que

$$|P_\alpha P_\beta|=|P_0P_{\beta-\alpha}|.$$

En la fórmula (1) se sustituyen $\alpha\mapsto0$ y $\beta\mapsto\beta-\alpha$. Como $\cos0=1$ y $\operatorname{sen}0=0$,

$$\boxed{d^2=2-2\cos(\beta-\alpha).}\tag{2}$$

Al igualar (1) y (2), restar $2$ de ambos miembros y dividir por $-2$ resulta la **fórmula del coseno de una diferencia**:

$$\boxed{\cos(\beta-\alpha)=\cos\beta\cos\alpha+
\operatorname{sen}\beta\operatorname{sen}\alpha,\qquad
\alpha,\beta\in\mathbb R.}\tag{3}$$

Esta demostración es el núcleo matemático de la segunda mitad de la grabación. El profesor la obtiene a partir de una propiedad geométrica —la conservación de la cuerda bajo una rotación común— traducida a dos expresiones algebraicas de la misma distancia.

### Consecuencias de la identidad de diferencia

#### Primera elección: $\beta=0$. Paridad del coseno
**En la cátedra (1:24:42–1:26:03).** Al sustituir $\beta=0$ en (3) se obtiene

$$\cos(-\alpha)=\cos0\cos\alpha+
\operatorname{sen}0\operatorname{sen}\alpha=\cos\alpha.$$

Por tanto,

$$\boxed{\cos(-\alpha)=\cos\alpha,\qquad\alpha\in\mathbb R.}$$

La función coseno es **par**: su gráfico posee simetría respecto del eje vertical.

#### Segunda elección: $\beta=\pi/2$. Ángulos complementarios
**En la cátedra (1:26:05–1:35:15).** La misma fórmula, ahora con $\beta=\pi/2$, da

$$
\begin{aligned}
\cos\left(\frac\pi2-\alpha\right)
&=\cos\frac\pi2\cos\alpha+
\operatorname{sen}\frac\pi2\operatorname{sen}\alpha\\
&=0\cdot\cos\alpha+1\cdot\operatorname{sen}\alpha
=\operatorname{sen}\alpha.
\end{aligned}
$$

Así se demuestra

$$\boxed{\operatorname{sen}\alpha=\cos\left(\frac\pi2-\alpha\right).}\tag{4}$$

Si $\beta=\pi/2-\alpha$, entonces $\alpha+\beta=\pi/2$ y los ángulos son complementarios. La relación inversa se obtiene aplicando (4) al complemento:

$$\boxed{\cos\alpha=\operatorname{sen}\left(\frac\pi2-\alpha\right).}\tag{5}$$

![Ángulos complementarios de un triángulo rectángulo](figuras/IC2021_Catedra_6_2/09_angulos_complementarios.png)

En un triángulo rectángulo, el cateto opuesto a $\alpha$ es precisamente el adyacente a $\beta$; por ello el seno de $\alpha$ coincide con el coseno de $\beta$. San Martín enfatiza que (4) y (5) fueron demostradas aquí para **todos los ángulos reales** mediante el círculo unitario.

#### Tercera consecuencia: imparidad del seno
**En la cátedra (1:35:24–1:38:33).** Se parte de la fórmula complementaria y se transforma

$$\operatorname{sen}(-\alpha)
=\cos\left(\frac\pi2+\alpha\right)
=\cos\left(\alpha-\left(-\frac\pi2\right)\right).$$

Al aplicar (3) con $\beta=\alpha$ y el segundo ángulo $-\pi/2$, se obtiene

$$
\begin{aligned}
\operatorname{sen}(-\alpha)
&=\cos\alpha\cos\left(-\frac\pi2\right)
 +\operatorname{sen}\alpha\operatorname{sen}\left(-\frac\pi2\right)\\
&=\cos\alpha\cdot0+\operatorname{sen}\alpha\cdot(-1)
=-\operatorname{sen}\alpha.
\end{aligned}
$$

En consecuencia,

$$\boxed{\operatorname{sen}(-\alpha)=-\operatorname{sen}\alpha,\qquad\alpha\in\mathbb R.}$$

La función seno es **impar**: su gráfico posee simetría central respecto del origen.

#### Cuarta consecuencia: coseno de una suma
**En la cátedra (1:38:34–1:40:05).** Se escribe una suma como diferencia:

$$\beta+\alpha=\beta-(-\alpha).$$

Sustituyendo en (3) y aplicando la paridad del coseno y la imparidad del seno,

$$
\begin{aligned}
\cos(\beta+\alpha)
&=\cos\beta\cos(-\alpha)+\operatorname{sen}\beta\operatorname{sen}(-\alpha)\\
&=\cos\beta\cos\alpha-\operatorname{sen}\beta\operatorname{sen}\alpha.
\end{aligned}
$$

La **fórmula del coseno de una suma** es

$$\boxed{\cos(\beta+\alpha)=\cos\beta\cos\alpha-
\operatorname{sen}\beta\operatorname{sen}\alpha.}\tag{6}$$

Obsérvese el contraste entre los signos de (3) y (6): la diferencia de ángulos produce una suma de productos; la suma produce una diferencia de productos.

**Alcance de la grabación.** En el cierre, San Martín anuncia que el seno de la suma y el seno de la diferencia serán desarrollados en la clase siguiente. Por ello esas fórmulas se conservan como **contenido futuro**. Las identidades (3)–(6) y las paridades sí corresponden a argumentos realizados en esta sesión.

### Aplicación: calcular exactamente el coseno de 15 grados

**En la cátedra (1:21:15–1:24:08).** El profesor presenta el ejemplo de $15^\circ$ como diferencia de $45^\circ$ y $30^\circ$, ángulos cuyo seno y coseno fueron calculados en la Cátedra 6.1.

![Los ángulos 30 grados, 45 grados y su diferencia](figuras/IC2021_Catedra_6_2/10_diferencia_15_grados.png)

**Desarrollo editorial del ejemplo indicado.** En radianes, $15^\circ=\pi/4-\pi/6=\pi/12$. Por (3),

$$
\begin{aligned}
\cos\frac\pi{12}
&=\cos\left(\frac\pi4-\frac\pi6\right)\\
&=\cos\frac\pi4\cos\frac\pi6+
\operatorname{sen}\frac\pi4\operatorname{sen}\frac\pi6\\
&=\frac{\sqrt2}{2}\frac{\sqrt3}{2}+
\frac{\sqrt2}{2}\frac12
=\boxed{\frac{\sqrt6+\sqrt2}{4}}.
\end{aligned}
$$

La posibilidad de calcular valores de nuevos ángulos a partir de ángulos elementales constituye una de las aplicaciones inmediatas de las identidades demostradas.

### Próxima etapa del curso

El cierre de la clase, alrededor de [1:39:50](https://www.youtube.com/watch?v=bkh-hjyrE_o&t=5990s), anuncia más identidades para la siguiente sesión: en particular, las fórmulas del **seno de una suma** y del **seno de una diferencia**. El profesor también insiste en la importancia de identificar con claridad cuándo las fórmulas se refieren a ángulos reales generales y cuándo a ángulos agudos de triángulos rectángulos.

La cadena pedagógica de esta clase es, por tanto: **círculo unitario → semejanza de triángulos → proyecciones → aplicaciones mecánicas → distancias entre puntos → invariancia por rotación → identidades de diferencia, paridad, complementos y suma del coseno**.

### Taller de problemas y soluciones

Los ejercicios se presentan a continuación según la fuente de origen; las ampliaciones editoriales de cada apuntes permanecen expresamente identificadas.

#### Banco de ejercicios originales con soluciones — cátedra 6.1

Los siguientes problemas son **ampliación editorial**. Su objetivo es consolidar las técnicas de la cátedra mediante cálculos explícitos, verificaciones y extensiones cuidadosamente acotadas.

#### Ejercicio 1. Conversión sexagesimal
Expresar $135^\circ$, $225^\circ$ y $-90^\circ$ en radianes.

**Solución.** Aplicamos $\alpha_{\mathrm{rad}}=\alpha_{^\circ}\pi/180$: $135\pi/180=3\pi/4$, $225\pi/180=5\pi/4$ y $-90\pi/180=-\pi/2$. Los tres números registran su sentido y amplitud angular.

#### Ejercicio 2. Sistema centesimal
Convertir $50\,\mathrm{gon}$ y $250\,\mathrm{gon}$ a grados y radianes.

**Solución.** Puesto que $100\,\mathrm{gon}=90^\circ=\pi/2$, un grado centesimal mide $\pi/200$ radianes. Así, $50\,\mathrm{gon}=45^\circ=\pi/4$, y $250\,\mathrm{gon}=225^\circ=5\pi/4$.

#### Ejercicio 3. Longitud del arco
Una circunferencia de radio $5$ cm presenta un ángulo central de $\pi/3$. Calcular el arco y comparar con uno de radio $2$ cm.

**Solución.** Por $s=r\alpha$, las longitudes son $s_1=5\pi/3$ cm y $s_2=2\pi/3$ cm. Sus cocientes por el radio coinciden: $s_1/5=s_2/2=\pi/3$.

#### Ejercicio 4. Ángulos con una misma posición final
Encontrar una medida en $[0,2\pi)$ correspondiente a $-7\pi/6$.

**Solución.** Sumamos una vuelta completa: $-7\pi/6+2\pi=5\pi/6$, que pertenece a $[0,2\pi)$. Ambas medidas terminan en el mismo punto de la circunferencia.

#### Ejercicio 5. Medida grande y punto terminal
Determinar $P_{9\pi/2}$.

**Solución.** Como $9\pi/2=4\pi+\pi/2$, se acumulan dos vueltas completas y una cuarta parte de vuelta. Por periodicidad, $P_{9\pi/2}=P_{\pi/2}=(0,1)$.

#### Ejercicio 6. Signos por cuadrantes
Hallar $\operatorname{sen}(4\pi/3)$, $\cos(4\pi/3)$ y $\tan(4\pi/3)$.

**Solución.** El ángulo $4\pi/3=\pi+\pi/3$ termina en el tercer cuadrante. Una media vuelta cambia el signo de ambas coordenadas, de modo que $\operatorname{sen}(4\pi/3)=-\sqrt3/2$ y $\cos(4\pi/3)=-1/2$. Su cociente es $\tan(4\pi/3)=\sqrt3$.

#### Ejercicio 7. El ángulo de $45^\circ$
Demostrar que $\tan(\pi/4)=1$ partiendo de la circunferencia.

**Solución.** El rayo de ángulo $\pi/4$ pertenece a la bisectriz $y=x$. De $2x^2=1$ en el primer cuadrante se obtiene $x=y=\sqrt2/2$. Por tanto, $\tan(\pi/4)=y/x=1$.

#### Ejercicio 8. Un ángulo complementario
Calcular $\tan(\pi/6)$ y racionalizar su denominador.

**Solución.** En el triángulo $30^\circ$–$60^\circ$–$90^\circ$, $\operatorname{sen}(\pi/6)=1/2$ y $\cos(\pi/6)=\sqrt3/2$. La tangente vale $1/\sqrt3=\sqrt3/3$.

#### Ejercicio 9. Identidad en un ángulo concreto
Verificar $\operatorname{sen}^2(\pi/3)+\cos^2(\pi/3)=1$.

**Solución.** Sustituyendo $\sqrt3/2$ y $1/2$ se obtiene $(\sqrt3/2)^2+(1/2)^2=3/4+1/4=1$.

#### Ejercicio 10. Tangente y secante
Demostrar que $1+\tan^2\alpha=\sec^2\alpha$ y enunciar la condición sobre $\alpha$.

**Solución.** Para $\cos\alpha\ne0$, dividimos $\operatorname{sen}^2\alpha+\cos^2\alpha=1$ por $\cos^2\alpha$. Se obtiene $\tan^2\alpha+1=1/\cos^2\alpha=\sec^2\alpha$. El dominio es $\mathbb R\setminus\{\pi/2+k\pi:k\in\mathbb Z\}$.

#### Ejercicio 11. Cotangente y cosecante
Probar $1+\cot^2\alpha=\csc^2\alpha$.

**Solución.** Para $\operatorname{sen}\alpha\ne0$, dividimos la identidad pitagórica por $\operatorname{sen}^2\alpha$. El primer cociente es $\cot^2\alpha$, el segundo vale $1$, y el miembro derecho es $\csc^2\alpha$.

#### Ejercicio 12. Dominio de la tangente
Expresar el dominio de $\tan$ mediante un conjunto excluido y comprobar si $3\pi/2$ pertenece al dominio.

**Solución.** $\operatorname{Dom}\tan=\mathbb R\setminus\{\pi/2+k\pi:k\in\mathbb Z\}$. Al tomar $k=1$ se obtiene $3\pi/2$, ángulo donde $\cos=0$; por ello queda excluido.

#### Ejercicio 13. Cotangente y recíproco
Comparar $\cot(\pi/2)$ con $1/\tan(\pi/2)$.

**Solución.** $\cot(\pi/2)=\cos(\pi/2)/\operatorname{sen}(\pi/2)=0/1=0$. La expresión $\tan(\pi/2)$ requiere dividir $1$ por $0$, así que $1/\tan(\pi/2)$ tampoco está definida. Las dos expresiones representan leyes iguales en su dominio común, y funciones con dominios naturales distintos.

#### Ejercicio 14. Período fundamental de la tangente
Demostrar que $\pi$ es un periodo de $\tan$.

**Solución.** La media vuelta transforma $P_\alpha$ en $-P_\alpha$. Así $\operatorname{sen}(\alpha+\pi)=-\operatorname{sen}\alpha$ y $\cos(\alpha+\pi)=-\cos\alpha$. Para $\cos\alpha\ne0$, el cociente queda inalterado, $\tan(\alpha+\pi)=\tan\alpha$. El patrón de asíntotas y ceros demuestra además que $\pi$ es su menor periodo positivo.

#### Ejercicio 15. Ceros del seno
Determinar todos los $\alpha\in[-2\pi,2\pi]$ tales que $\operatorname{sen}\alpha=0$.

**Solución.** Los ceros de seno son $\alpha=k\pi$ con $k\in\mathbb Z$. La condición $-2\le k\le2$ deja $\{-2\pi,-\pi,0,\pi,2\pi\}$.

#### Ejercicio 16. Ceros del coseno y de la secante
Determinar los ceros de $\cos$ en $[0,2\pi]$. Analizar si $\sec$ tiene ceros.

**Solución.** En una vuelta, $\cos$ se anula para $\pi/2$ y $3\pi/2$. La secante es $1/\cos$ en los puntos con coseno distinto de cero; el inverso multiplicativo de un real no nulo posee valor no nulo. Por tanto, el conjunto de ceros de $\sec$ es vacío.

#### Ejercicio 17. Interpretación de la tangente como segmento
Para $\alpha=\pi/6$, hallar el punto donde el rayo angular corta la recta $x=1$ y calcular su distancia al origen.

**Solución.** La pendiente del rayo es $\tan(\pi/6)=1/\sqrt3$, por lo que la recta es $y=x/\sqrt3$. En $x=1$ se obtiene $Q=(1,1/\sqrt3)$. Entonces $|OQ|=\sqrt{1+1/3}=2/\sqrt3=|\sec(\pi/6)|$.

#### Ejercicio 18. Una imagen acotada y un dominio acotado
Estudiar la imagen de $\tan$ restringida al intervalo $(-\pi/2,\pi/2)$ y compararla con la imagen de $\operatorname{sen}$ en $\mathbb R$.

**Solución.** En el intervalo central, la tangente es continua y estrictamente creciente; su ordenada geométrica toma valores negativos y positivos arbitrariamente grandes al acercarse a las rectas verticales extremas. Por ello su imagen es $\mathbb R$, aunque el dominio indicado sea acotado. En contraste, la ordenada de la circunferencia unitaria siempre pertenece a $[-1,1]$, que es la imagen del seno en $\mathbb R$.

#### Problemas complementarios resueltos — cátedra 6.2

> **Ampliación editorial.** Los ejercicios E1–E18 han sido elaborados para estudiar los conceptos de esta clase. Las resoluciones son originales; se apoyan en las herramientas y fórmulas presentadas en la grabación.

#### E1. Signo en un ángulo del segundo cuadrante
**Problema.** Determinar los signos de $\operatorname{sen}(5\pi/6)$, $\cos(5\pi/6)$ y $\tan(5\pi/6)$.

**Solución.** Como $\pi/2<5\pi/6<\pi$, el punto pertenece al cuadrante II. Su ordenada es positiva y su abscisa negativa. Así, $\operatorname{sen}(5\pi/6)>0$ y $\cos(5\pi/6)<0$; la razón de ambas tiene signo negativo: $\tan(5\pi/6)<0$.

#### E2. Un triángulo rectángulo de lados 3, 4 y 5
**Problema.** En un triángulo rectángulo, el cateto opuesto a $\alpha$ mide $3$, el adyacente mide $4$ y la hipotenusa mide $5$. Calcular las tres razones.

**Solución.** Aplicando las expresiones demostradas por semejanza,

$$\operatorname{sen}\alpha=\frac35,\qquad\cos\alpha=\frac45,\qquad\tan\alpha=\frac34.$$

La identidad fundamental se verifica: $9/25+16/25=1$.

#### E3. Proyección de un segmento
**Problema.** Un segmento de longitud $6$ forma $\pi/4$ con el eje horizontal. Hallar sus componentes.

**Solución.** Como $\cos(\pi/4)=\operatorname{sen}(\pi/4)=\sqrt2/2$,

$$L_x=6\frac{\sqrt2}{2}=3\sqrt2,\qquad L_y=3\sqrt2.$$

Las dos proyecciones poseen la misma longitud por la simetría del ángulo de $45^\circ$.

#### E4. Recuperar la longitud mediante Pitágoras
**Problema.** Demostrar a partir de las componentes $L_x=L\cos\alpha$, $L_y=L\operatorname{sen}\alpha$ que $L_x^2+L_y^2=L^2$.

**Solución.** Se calcula

$$L_x^2+L_y^2=L^2(\cos^2\alpha+\operatorname{sen}^2\alpha)=L^2.$$

La igualdad expresa que la descomposición ortogonal conserva el módulo del segmento.

#### E5. Pendiente y ángulo de inclinación
**Problema.** La recta pasa por $(1,2)$ y $(5,6)$. Determinar su pendiente y un ángulo de inclinación.

**Solución.** Por definición, $m=(6-2)/(5-1)=1$. Entonces $\tan\alpha=1$ y se puede elegir $\alpha=\pi/4$. Esta es la inclinación aguda respecto de la horizontal.

#### E6. Pendiente negativa y ángulo orientado
**Problema.** Hallar la pendiente de la recta que pasa por $(-2,3)$ y $(2,-1)$ y describir una dirección angular.

**Solución.** $m=(-1-3)/(2-(-2))=-4/4=-1$. Un ángulo orientado representativo es $\alpha=-\pi/4$, porque $\tan(-\pi/4)=-1$. La recta geométrica admite también ángulos congruentes módulo $\pi$.

#### E7. Peso y normal de un cuerpo
**Problema.** Un bloque de $5\,\mathrm{kg}$ está en un plano con $\alpha=\pi/6$; tomar $g=9.8\,\mathrm{m/s^2}$. Calcular la magnitud del peso paralelo y perpendicular al plano.

**Solución.** El peso total es $mg=49\,\mathrm N$. Por $\operatorname{sen}(\pi/6)=1/2$ y $\cos(\pi/6)=\sqrt3/2$,

$$P_\parallel=\frac{49}{2}\,\mathrm N=24.5\,\mathrm N,
\quad P_\perp=\frac{49\sqrt3}{2}\,\mathrm N.$$

Si el plano ejerce una reacción normal de equilibrio y no actúan otras fuerzas perpendiculares, $N=P_\perp$.

#### E8. Resorte que mantiene el equilibrio
**Problema.** El bloque de E7 está sujeto a un resorte paralelo al plano de constante $k=100\,\mathrm{N/m}$, sin roce. Hallar el estiramiento de equilibrio.

**Solución.** La tensión requerida es $T=P_\parallel=24.5\,\mathrm N$. Por la ley $T=k\Delta\ell$,

$$\Delta\ell=\frac{24.5}{100}=0.245\,\mathrm m.$$

#### E9. Condición de roce estático
**Problema.** Un cuerpo reposa sobre un plano inclinado con $\mu_s=1/\sqrt3$. Determinar el ángulo máximo de equilibrio en el modelo de la clase.

**Solución.** Se requiere $\tan\alpha\le1/\sqrt3$. En $(0,\pi/2)$ la tangente es creciente y $\tan(\pi/6)=1/\sqrt3$. Por tanto el umbral es $\boxed{\alpha_c=\pi/6=30^\circ}$.

#### E10. Comprobación geométrica de la fórmula de cuerda
**Problema.** Calcular la distancia entre $P_0$ y $P_{\pi/2}$.

**Solución.** Los puntos son $(1,0)$ y $(0,1)$, y la distancia directa es $\sqrt{(1-0)^2+(0-1)^2}=\sqrt2$. La fórmula rotada entrega

$$d^2=2-2\cos(\pi/2)=2\quad\Longrightarrow\quad d=\sqrt2.$$

#### E11. Dos puntos diametralmente opuestos
**Problema.** Calcular $|P_{\pi/3}P_{4\pi/3}|$.

**Solución.** La diferencia angular es $\pi$. Entonces $d^2=2-2\cos\pi=4$; al ser una distancia positiva, $d=2$, el diámetro del círculo unitario.

#### E12. Coseno de una diferencia de 60 grados
**Problema.** Calcular $\cos(\pi/3-\pi/6)$ usando la identidad (3).

**Solución.**

$$\cos\left(\frac\pi3-\frac\pi6\right)
=\frac12\frac{\sqrt3}{2}+
\frac{\sqrt3}{2}\frac12=\frac{\sqrt3}{2}.$$

El argumento del coseno es $\pi/6$, de modo que el resultado concuerda con la tabla de ángulos elementales.

#### E13. Exactitud del coseno de quince grados
**Problema.** Determinar $\cos(15^\circ)$.

**Solución.** Utilizando $15^\circ=45^\circ-30^\circ$,

$$\cos(15^\circ)
=\frac{\sqrt2}{2}\frac{\sqrt3}{2}+
\frac{\sqrt2}{2}\frac12
=\boxed{\frac{\sqrt6+\sqrt2}{4}}.$$

#### E14. El coseno de un suplemento
**Problema.** Demostrar $\cos(\pi-\alpha)=-\cos\alpha$.

**Solución.** Por (3),

$$\cos(\pi-\alpha)=\cos\pi\cos\alpha+
\operatorname{sen}\pi\operatorname{sen}\alpha
=(-1)\cos\alpha+0=-\cos\alpha.$$

#### E15. La paridad del coseno en un valor concreto
**Problema.** Justificar $\cos(-\pi/3)=\cos(\pi/3)$ y determinar su valor.

**Solución.** La función coseno es par, según la deducción de la sección 8.1. Como $\cos(\pi/3)=1/2$, el valor solicitado es $1/2$.

#### E16. El seno de un ángulo complementario
**Problema.** Calcular $\operatorname{sen}(\pi/3)$ a partir de $\cos(\pi/6)$.

**Solución.** Como $\pi/2-\pi/3=\pi/6$, por (4)

$$\operatorname{sen}\frac\pi3
=\cos\left(\frac\pi2-\frac\pi3\right)
=\cos\frac\pi6=\frac{\sqrt3}{2}.$$

#### E17. Coseno de una suma
**Problema.** Calcular $\cos(2\pi/3)$ como coseno de $\pi/3+\pi/3$.

**Solución.** Por (6),

$$\cos\frac{2\pi}{3}
=\cos^2\frac\pi3-\operatorname{sen}^2\frac\pi3
=\frac14-\frac34=-\frac12.$$

#### E18. Una identidad de ángulo doble
**Problema.** Deducir una fórmula para $\cos(2\alpha)$ utilizando el coseno de una suma.

**Solución (ampliación editorial).** Tomamos $\beta=\alpha$ en (6):

$$\boxed{\cos(2\alpha)=\cos^2\alpha-\operatorname{sen}^2\alpha.}$$

De $\cos^2\alpha+\operatorname{sen}^2\alpha=1$ se obtienen también las formas $\cos(2\alpha)=2\cos^2\alpha-1$ y $\cos(2\alpha)=1-2\operatorname{sen}^2\alpha$. Estas identidades se siguen de lo demostrado en la clase, aunque su desarrollo sistemático pertenece al estudio posterior.

---

## Identidades trigonométricas y resolución de triángulos

Las fórmulas de suma, doble ángulo y ángulo medio permiten pasar de relaciones trigonométricas a problemas geométricos. Los teoremas del seno y del coseno unifican la resolución de triángulos.

**Grabaciones de referencia:** [grabación de la cátedra 7.1](https://www.youtube.com/watch?v=VwFUnoxUw3M).

*Procedencia de este tramo: cátedra 7.1.*

### Reanudar las fórmulas de suma y diferencia

**En la cátedra (11:10–23:00).** La clase precedente había obtenido, mediante la invariancia de las distancias entre puntos del círculo unitario, la expresión

$$\boxed{\cos(\beta-\alpha)=\cos\beta\cos\alpha+\operatorname{sen}\beta\operatorname{sen}\alpha.}$$

El profesor recuerda dos propiedades ya demostradas: el coseno es una función **par**, $\cos(-t)=\cos t$, y el seno es **impar**, $\operatorname{sen}(-t)=-\operatorname{sen}t$. Estas propiedades sirven para deducir el coseno de una suma al reemplazar $\alpha$ por $-\alpha$:

$$
\begin{aligned}
\cos(\beta+\alpha)
&=\cos(\beta-(-\alpha))\\
&=\cos\beta\cos(-\alpha)+\operatorname{sen}\beta\operatorname{sen}(-\alpha)\\
&=\cos\beta\cos\alpha-\operatorname{sen}\beta\operatorname{sen}\alpha.
\end{aligned}
$$

![Dos puntos del círculo unitario y el ángulo comprendido](figuras/IC2021_Catedra_7_1/01_formulas_adicion.png)

Para obtener el seno de una suma se usa la relación de complementariedad, igualmente establecida en la cátedra anterior,

$$\operatorname{sen}t=\cos\left(\frac\pi2-t\right).$$

**Desarrollo de la demostración.** Aplicamos la fórmula del coseno de una diferencia:

$$
\begin{aligned}
\operatorname{sen}(\alpha+\beta)
&=\cos\left(\frac\pi2-\alpha-\beta\right)\\
&=\cos\left(\frac\pi2-\alpha\right)\cos\beta
+\operatorname{sen}\left(\frac\pi2-\alpha\right)\operatorname{sen}\beta\\
&=\operatorname{sen}\alpha\cos\beta+\cos\alpha\operatorname{sen}\beta.
\end{aligned}
$$

Después, al sustituir $\beta$ por $-\beta$, la imparidad del seno cambia el signo del segundo sumando y se obtiene la fórmula para una diferencia. El resultado se organiza en cuatro identidades válidas para todos $x,y\in\mathbb R$.

| Función | Identidad de adición |
|:---|:---|
| Coseno de una suma | $\cos(x+y)=\cos x\cos y-\operatorname{sen}x\operatorname{sen}y$ |
| Coseno de una diferencia | $\cos(x-y)=\cos x\cos y+\operatorname{sen}x\operatorname{sen}y$ |
| Seno de una suma | $\operatorname{sen}(x+y)=\operatorname{sen}x\cos y+\cos x\operatorname{sen}y$ |
| Seno de una diferencia | $\operatorname{sen}(x-y)=\operatorname{sen}x\cos y-\cos x\operatorname{sen}y$ |

La tabla admite una comprobación inmediata: tomando $x=y$ en las fórmulas de diferencia se recuperan $\cos0=\cos^2x+\operatorname{sen}^2x=1$ y $\operatorname{sen}0=0$. El profesor utiliza explícitamente este examen para controlar los signos antes de aplicar fórmulas memorizadas.

### Identidades del ángulo doble

**En la cátedra (26:39–29:58).** El caso particular $y=x$ convierte la suma en $2x$. La fórmula del seno da

$$
\boxed{\operatorname{sen}(2x)=2\operatorname{sen}x\cos x.}
$$

Para el coseno se obtiene

$$
\boxed{\cos(2x)=\cos^2x-\operatorname{sen}^2x.}
$$

![Construcción de dos ángulos consecutivos y ángulo doble](figuras/IC2021_Catedra_7_1/02_angulo_doble_medio.png)

**Desarrollo de la demostración.** Por la identidad fundamental $\operatorname{sen}^2x+\cos^2x=1$,

$$
\begin{aligned}
\cos(2x)
&=(1-\operatorname{sen}^2x)-\operatorname{sen}^2x
=1-2\operatorname{sen}^2x,\\
\cos(2x)
&=\cos^2x-(1-\cos^2x)
=2\cos^2x-1.
\end{aligned}
$$

Por tanto, las tres versiones del coseno del ángulo doble son

$$\boxed{\cos(2x)=\cos^2x-\operatorname{sen}^2x=1-2\operatorname{sen}^2x=2\cos^2x-1.}$$

Cada escritura privilegia una familia de términos y permite resolver problemas diferentes. El profesor insiste en que los signos quedan fijados por las identidades de adición: colocar un signo positivo entre los dos cuadrados transformaría erróneamente el coseno del ángulo doble en la constante $1$.

### Cuadrados trigonométricos y ángulo medio

**En la cátedra (29:58–43:53).** Reorganizando las fórmulas anteriores se obtienen

$$
\boxed{\operatorname{sen}^2\left(\frac x2\right)=\frac{1-\cos x}{2}},\qquad
\boxed{\cos^2\left(\frac x2\right)=\frac{1+\cos x}{2}}.
$$

Estas identidades tienen la ventaja de expresar cuadrados trigonométricos mediante un ángulo doble del argumento. El profesor observa que ambos segundos miembros son no negativos porque $-1\leq\cos x\leq1$.

**Una precisión indispensable sobre los signos.** Si conocemos el cuadrado de un número real, su raíz cuadrada principal expresa el valor absoluto de ese número. En particular,

$$
\left|\operatorname{sen}\left(\frac x2\right)\right|
=\sqrt{\frac{1-\cos x}{2}},\qquad
\left|\cos\left(\frac x2\right)\right|
=\sqrt{\frac{1+\cos x}{2}}.
$$

Para hallar el seno o el coseno del ángulo medio, se selecciona el signo correspondiente al cuadrante de $x/2$. Así, por ejemplo, $\cos(2\pi/3)=-1/2$ y la raíz principal de $\cos^2(2\pi/3)$ es $1/2$.

![Signo del coseno según el cuadrante del ángulo medio](figuras/IC2021_Catedra_7_1/03_mitad_signos.png)

El profesor estudia luego la tangente del ángulo medio. Dividiendo las identidades anteriores, en los puntos donde $\cos(x/2)\ne0$, se encuentra

$$\tan^2\left(\frac x2\right)=\frac{1-\cos x}{1+\cos x}.$$

Multiplicar numerador y denominador por $1+\cos x$ permite usar $1-\cos^2x=\operatorname{sen}^2x$:

$$
\tan^2\left(\frac x2\right)
=\frac{\operatorname{sen}^2x}{(1+\cos x)^2}.
$$

El profesor propone comprobar que, en realidad, vale la fórmula **con su signo correspondiente**:

$$
\boxed{\tan\left(\frac x2\right)=\frac{\operatorname{sen}x}{1+\cos x},\qquad x\ne(2k+1)\pi,\ k\in\mathbb Z.}
$$

**Ampliación editorial (demostración de la propuesta).** Escribimos $u=x/2$. Entonces

$$
\frac{\operatorname{sen}(2u)}{1+\cos(2u)}
=\frac{2\operatorname{sen}u\cos u}{2\cos^2u}
=\frac{\operatorname{sen}u}{\cos u}
=\tan u,
$$

siempre que $\cos u\ne0$. Esa condición equivale precisamente a $x\ne(2k+1)\pi$. La demostración conserva directamente el signo, de modo que completa la tarea propuesta al final de esta parte de la grabación.

### Resolver un triángulo cualquiera

**En la cátedra (44:00–46:25).** Sea un triángulo $ABC$, de lados $a=|BC|$, $b=|CA|$, $c=|AB|$ y ángulos interiores $\alpha=\angle A$, $\beta=\angle B$, $\gamma=\angle C$. Resolver el triángulo consiste en determinar sus **tres longitudes y sus tres ángulos** a partir de un conjunto suficiente de datos.

Los ángulos satisfacen

$$\alpha+\beta+\gamma=\pi,$$

mientras que las longitudes de sus lados son positivas y verifican las desigualdades triangulares. La estrategia que utiliza San Martín es construir triángulos rectángulos auxiliares mediante alturas, recuperar razones trigonométricas conocidas y eliminar las longitudes auxiliares.

### Teorema del seno mediante dos alturas

**En la cátedra (46:25–53:04).** Se traza desde $C$ la altura $CM=h$ hasta el lado $AB$. Para el caso en que el pie $M$ pertenece al interior del segmento, aparecen dos triángulos rectángulos. Por las razones trigonométricas

$$h=b\operatorname{sen}\alpha,\qquad h=a\operatorname{sen}\beta.$$

![Triángulo general dividido en dos triángulos rectángulos](figuras/IC2021_Catedra_7_1/04_teorema_seno.png)

Ambos miembros describen la misma altura. Al igualarlos y dividir por $ab>0$ resulta

$$\frac{\operatorname{sen}\alpha}{a}=\frac{\operatorname{sen}\beta}{b}.$$

Una altura trazada desde otro vértice incorpora el tercer lado y el tercer ángulo. Así se obtiene el **teorema del seno**:

$$
\boxed{\frac{\operatorname{sen}\alpha}{a}=\frac{\operatorname{sen}\beta}{b}=\frac{\operatorname{sen}\gamma}{c}.}
$$

Su formulación recíproca, igualmente útil, es $a/\operatorname{sen}\alpha=b/\operatorname{sen}\beta=c/\operatorname{sen}\gamma$.

**Ampliación editorial: demostración para todos los triángulos.** La demostración de la grabación se ilustra con el pie de una altura en el lado. Para un ángulo obtuso, puede ser necesario prolongar ese lado. Una demostración que reúne todos los casos utiliza el área $K$ del triángulo:

$$
K=\frac12bc\operatorname{sen}\alpha
=\frac12ca\operatorname{sen}\beta
=\frac12ab\operatorname{sen}\gamma.
$$

Dado que $a,b,c>0$, al dividir por $abc/2$ se obtienen de nuevo las tres razones iguales. La fórmula de área usa el seno del ángulo comprendido entre dos lados, que es positivo para cualquier ángulo interior de un triángulo no degenerado.

### Datos suficientes y el caso ambiguo lado–lado–ángulo

**En la cátedra (53:04–1:02:45).** Dados dos ángulos y un lado, el tercer ángulo es $\pi$ menos la suma de los dos conocidos. El teorema del seno determina luego los dos lados restantes. Por ejemplo, con $\alpha$, $\beta$ y $a$ conocidos,

$$\gamma=\pi-\alpha-\beta,\qquad
b=\frac{a\operatorname{sen}\beta}{\operatorname{sen}\alpha},\qquad
c=\frac{a\operatorname{sen}\gamma}{\operatorname{sen}\alpha}.$$

El profesor analiza después **dos lados y un ángulo opuesto a uno de ellos**. Supongamos conocidos $a$, $b$ y $\beta$; el teorema del seno entrega

$$\boxed{\operatorname{sen}\alpha=\frac{a\operatorname{sen}\beta}{b}.}$$

La fracción del segundo miembro debe pertenecer a $[0,1]$. Aun cumpliendo esa condición, una ecuación $\operatorname{sen}\alpha=s$ con $0<s<1$ admite, en el intervalo $(0,\pi)$, los dos candidatos $\alpha_1=\arcsin s$ y $\alpha_2=\pi-\arcsin s$. Es necesario además comprobar que $\alpha+\beta<\pi$.

![Construcción de los dos posibles triángulos para un lado y un ángulo opuesto](figuras/IC2021_Catedra_7_1/05_caso_ambiguo.png)

El profesor muestra geométricamente cómo un segmento de longitud fija puede alcanzar una semirrecta en dos posiciones. Esa observación explica el **caso ambiguo**: los datos pueden determinar cero, uno o dos triángulos.

**Ampliación editorial: clasificación para un ángulo agudo dado.** Si $0<\beta<\pi/2$, $a,b>0$ y $h=a\operatorname{sen}\beta$, el número de triángulos posibles es:

| Condición | Triángulos posibles |
|:---|:---:|
| $b<h$ | $0$ |
| $b=h$ | $1$ (triángulo rectángulo) |
| $h<b<a$ | $2$ |
| $b\geq a$ | $1$ |

Para un ángulo dado obtuso, el lado opuesto al ángulo obtuso debe ser el mayor; por eso existe un triángulo si $b>a$, y la construcción es única. Estas precisiones completan la discusión de existencia y multiplicidad iniciada en clase.

### Teorema del coseno: Pitágoras y el término de corrección

**En la cátedra (1:08:11–1:22:20).** Cuando se conocen dos lados $a$, $b$ y su **ángulo comprendido** $\gamma$, el teorema del seno deja dos ángulos desconocidos. Para determinar el tercero, el profesor traza una altura y aplica Pitágoras.

![Teorema del coseno: altura y proyecciones](figuras/IC2021_Catedra_7_1/06_teorema_coseno.png)

En una disposición con proyección horizontal interior, la altura es $a\operatorname{sen}\gamma$ y la distancia horizontal que forma el otro cateto del triángulo de hipotenusa $c$ es $b-a\cos\gamma$. Por tanto,

$$
\begin{aligned}
c^2
&=(a\operatorname{sen}\gamma)^2+(b-a\cos\gamma)^2\\
&=a^2(\operatorname{sen}^2\gamma+\cos^2\gamma)+b^2-2ab\cos\gamma\\
&=\boxed{a^2+b^2-2ab\cos\gamma}.
\end{aligned}
$$

Cuando el ángulo comprendido es obtuso, $\cos\gamma<0$ y la misma expresión para la proyección horizontal incorpora el cambio de orientación. El profesor explica la validez de una única fórmula para los ángulos agudos, rectos y obtusos, y recupera Pitágoras cuando $\gamma=\pi/2$.

Por simetría de las letras del triángulo se obtienen también

$$
\boxed{\begin{aligned}
a^2&=b^2+c^2-2bc\cos\alpha,\\
b^2&=a^2+c^2-2ac\cos\beta,\\
c^2&=a^2+b^2-2ab\cos\gamma.
\end{aligned}}
$$

**Interpretación geométrica.** Si $\gamma<\pi/2$, el término $-2ab\cos\gamma$ disminuye $c^2$ respecto de $a^2+b^2$; si $\gamma=\pi/2$, ese término vale cero; si $\gamma>\pi/2$, aumenta $c^2$. La ley del coseno constituye por tanto una forma general de Pitágoras, con una corrección que mide el ángulo entre los dos lados conocidos.

**Ampliación editorial: tres lados conocidos.** El teorema también permite calcular ángulos:

$$\boxed{\cos\gamma=\frac{a^2+b^2-c^2}{2ab}.}$$

Conociendo los tres lados se calcula cada coseno y después se determina el ángulo interior en $[0,\pi]$. La desigualdad triangular garantiza que esos lados puedan constituir un triángulo no degenerado.

### Aplicación I: altura de una torre desde terreno horizontal

**En la cátedra (1:22:20–1:25:05).** Un observador situado en $A$ mira la parte superior $B$ de una torre vertical cuya base es $C$. Se conoce la distancia horizontal $AC=d>0$ y el ángulo de elevación $\alpha\in(0,\pi/2)$. El triángulo $ACB$ es rectángulo en $C$.

![Altura de una torre vista desde terreno horizontal](figuras/IC2021_Catedra_7_1/07_torre_horizontal.png)

La tangente es la razón entre cateto opuesto y adyacente:

$$\tan\alpha=\frac hd,\qquad\boxed{h=d\tan\alpha.}$$

Esta expresión puede obtenerse mediante el seno y el coseno del ángulo y representa una aplicación directa de la trigonometría de triángulos rectángulos.

### Aplicación II: altura con terreno inclinado

**En la cátedra (1:25:05–1:29:05).** El segmento de terreno $AC=d$ asciende con inclinación $\gamma>0$ respecto de la horizontal. La visual desde $A$ hasta la cúspide $B$ forma un ángulo $\alpha$ respecto del terreno. La torre $BC=h$ es vertical.

![Altura desde un terreno inclinado](figuras/IC2021_Catedra_7_1/08_torre_inclinada.png)

En el triángulo $ABC$ el ángulo en $A$ es $\alpha$, el ángulo en $C$ es $\pi/2+\gamma$ y el ángulo en $B$ es $\pi/2-(\alpha+\gamma)$. La ley del seno da

$$\frac{h}{\operatorname{sen}\alpha}=\frac{d}{\operatorname{sen}(\pi/2-\alpha-\gamma)}.$$

Usando $\operatorname{sen}(\pi/2-t)=\cos t$ resulta

$$\boxed{h=\frac{d\operatorname{sen}\alpha}{\cos(\alpha+\gamma)}.}$$

Las condiciones geométricas de este modelo son $0<\alpha$, $0\leq\gamma$ y $\alpha+\gamma<\pi/2$. Cuando $\gamma=0$, se recupera $h=d\tan\alpha$.

### Aplicación III: dos observadores con base inaccesible

**En la cátedra (1:29:05–1:38:40).** Dos puntos de observación $A$ (más lejano) y $D$ (más próximo) se encuentran sobre terreno horizontal a distancia conocida $AD=d$. La base $C$ de la torre es inaccesible. El ángulo de elevación desde $A$ es $\alpha$, y desde $D$ es $\beta$, con $0<\alpha<\beta<\pi/2$.

![Dos observadores y distancia inaccesible](figuras/IC2021_Catedra_7_1/09_dos_observadores.png)

Se comienza por el triángulo $ADB$: su ángulo en $A$ es $\alpha$, su ángulo en $D$ es $\pi-\beta$ y el ángulo de $B$ es $\beta-\alpha$. Al aplicar la ley del seno, la distancia visual $DB=x$ satisface

$$\frac{x}{\operatorname{sen}\alpha}=\frac{d}{\operatorname{sen}(\beta-\alpha)},\qquad
x=\frac{d\operatorname{sen}\alpha}{\operatorname{sen}(\beta-\alpha)}.$$

El triángulo $DCB$ es rectángulo, con hipotenusa $DB=x$ y ángulo $\beta$ en $D$, por lo cual $h=x\operatorname{sen}\beta$. Sustituyendo el resultado anterior:

$$\boxed{h=\frac{d\operatorname{sen}\alpha\operatorname{sen}\beta}{\operatorname{sen}(\beta-\alpha)}.}$$

El profesor verifica la fórmula en el caso particular en que el segundo observador se sitúa en la base de la torre: entonces $\beta=\pi/2$ y la expresión se reduce a $h=d\tan\alpha$.

### Aplicación IV: dos observadores sobre terreno inclinado

**En la cátedra (1:38:40–1:40:32): problema propuesto.** El terreno asciende desde $A$ hacia $D$ y $C$ con inclinación $\gamma$ respecto de la horizontal. Los dos observadores siguen separados por la distancia $AD=d$, medida sobre el terreno. Sus visuales forman ángulos $\alpha$ y $\beta$, respectivamente, **respecto del terreno**, con $0<\alpha<\beta$; la torre es vertical.

![Dos observadores en terreno inclinado: generalización](figuras/IC2021_Catedra_7_1/10_dos_observadores_pendiente.png)

El profesor observa que el triángulo formado por los dos observadores y la cúspide mantiene el ángulo $\beta-\alpha$ y que el segundo paso requiere incorporar el ángulo $\pi/2+\gamma$ en la base de la torre. Deja el cálculo final como ejercicio.

**Ampliación editorial: solución completa.** Como en el problema anterior, el triángulo $ADB$ determina

$$x=DB=\frac{d\operatorname{sen}\alpha}{\operatorname{sen}(\beta-\alpha)}.$$

En el triángulo $DCB$, los lados $DB=x$ y $BC=h$ son opuestos, respectivamente, a los ángulos $\pi/2+\gamma$ y $\beta$. La ley del seno establece

$$\frac{h}{\operatorname{sen}\beta}=\frac{x}{\operatorname{sen}(\pi/2+\gamma)}
=\frac{x}{\cos\gamma}.$$

De ahí resulta

$$\boxed{h=\frac{d\operatorname{sen}\alpha\operatorname{sen}\beta}{\operatorname{sen}(\beta-\alpha)\cos\gamma}.}$$

Se exige $0\leq\gamma<\pi/2$, $\cos\gamma>0$ y, para que las visuales intercepten la torre por encima de su base, $0<\alpha<\beta$ y $\beta+\gamma<\pi/2$. Con $\gamma=0$ reaparece la fórmula del terreno horizontal.

### Taller de problemas y soluciones

Los ejercicios se presentan a continuación según la fuente de origen; las ampliaciones editoriales de cada apuntes permanecen expresamente identificadas.

#### Laboratorio de problemas complementarios: soluciones razonadas — cátedra 7.1

Los siguientes problemas son **ampliaciones editoriales originales**, organizadas para ejercitar las técnicas de la cátedra, con progresión desde identidades hasta levantamiento de medidas.

#### E1. Coseno de $15^\circ$
Como $15^\circ=45^\circ-30^\circ$, usamos el coseno de una diferencia:

$$
\begin{aligned}
\cos15^\circ&=\cos45^\circ\cos30^\circ+\operatorname{sen}45^\circ\operatorname{sen}30^\circ\\
&=\frac{\sqrt2}{2}\frac{\sqrt3}{2}+\frac{\sqrt2}{2}\frac12
=\boxed{\frac{\sqrt6+\sqrt2}{4}}.
\end{aligned}
$$

#### E2. Seno de $15^\circ$
$$
\operatorname{sen}(45^\circ-30^\circ)
=\frac{\sqrt2}{2}\frac{\sqrt3}{2}-\frac{\sqrt2}{2}\frac12
=\boxed{\frac{\sqrt6-\sqrt2}{4}}.
$$

#### E3. Coseno de $75^\circ$
El ángulo $75^\circ=45^\circ+30^\circ$. Por la fórmula de la suma,

$$\cos75^\circ=\frac{\sqrt6-\sqrt2}{4}.$$

La igualdad $\cos75^\circ=\operatorname{sen}15^\circ$ confirma el cálculo mediante complementariedad.

#### E4. Seno de $75^\circ$
$$\operatorname{sen}75^\circ=\operatorname{sen}(45^\circ+30^\circ)
=\frac{\sqrt6+\sqrt2}{4}.$$

#### E5. Seno del doble de $\pi/6$
$$\operatorname{sen}(\pi/3)=2\operatorname{sen}(\pi/6)\cos(\pi/6)
=2\cdot\frac12\cdot\frac{\sqrt3}{2}=\frac{\sqrt3}{2}.$$

#### E6. Coseno del doble de $\pi/6$
$$\cos(\pi/3)=\cos^2(\pi/6)-\operatorname{sen}^2(\pi/6)
=\frac34-\frac14=\frac12.$$

#### E7. Seno cuadrado de $\pi/12$
Con $x=\pi/6$, la identidad del ángulo medio produce

$$\operatorname{sen}^2(\pi/12)=\frac{1-\cos(\pi/6)}2
=\frac{2-\sqrt3}{4}.$$

El resultado es positivo y la elección de la raíz positiva para el seno mismo se justifica porque $\pi/12$ pertenece al primer cuadrante.

#### E8. Coseno de un ángulo medio del segundo cuadrante
Calculemos $\cos(2\pi/3)$ con la fórmula del medio ángulo de $x=4\pi/3$. Como

$$\cos^2(2\pi/3)=\frac{1+\cos(4\pi/3)}2=\frac{1-1/2}{2}=\frac14,$$

el valor absoluto es $1/2$. Dado que $2\pi/3$ está en el segundo cuadrante, el coseno es $\boxed{-1/2}$.

#### E9. Tangente de $\pi/8$
Usamos la identidad exacta de tangente del ángulo medio:

$$\tan(\pi/8)=\frac{\operatorname{sen}(\pi/4)}{1+\cos(\pi/4)}
=\frac{\sqrt2}{2+\sqrt2}=\boxed{\sqrt2-1}.$$

#### E10. Convertir un producto en suma
Sumamos las fórmulas de $\cos(x+y)$ y $\cos(x-y)$:

$$\cos(x+y)+\cos(x-y)=2\cos x\cos y.$$

Por tanto,

$$\boxed{\cos x\cos y=\frac{\cos(x+y)+\cos(x-y)}2}. $$

#### E11. Un triángulo con dos ángulos y un lado
Sea $\alpha=30^\circ$, $\beta=45^\circ$ y $a=8$. El tercero es $\gamma=105^\circ$. Por la ley del seno,

$$b=8\frac{\sin45^\circ}{\sin30^\circ}=8\sqrt2,\qquad
c=8\frac{\sin105^\circ}{\sin30^\circ}=16\sin105^\circ.$$

Como $\sin105^\circ=(\sqrt6+\sqrt2)/4$, resulta $c=4(\sqrt6+\sqrt2)$.

#### E12. Dos soluciones en el caso ambiguo
Conocemos $\beta=30^\circ$, $a=8$ y $b=5$. La ley del seno da

$$\sin\alpha=\frac{8\sin30^\circ}{5}=\frac45.$$

Los candidatos son $\alpha_1=\arcsin(4/5)\approx53.130^\circ$ y $\alpha_2=180^\circ-\alpha_1\approx126.870^\circ$. Ambos satisfacen $\alpha+\beta<180^\circ$. Por tanto existen dos triángulos, cuyos terceros ángulos son aproximadamente $96.870^\circ$ y $23.130^\circ$. El lado restante se obtiene por $c=(b/\sin\beta)\sin\gamma=10\sin\gamma$.

#### E13. Determinar el tercer lado mediante el coseno
En un triángulo se conocen $a=5$, $b=7$ y $\gamma=60^\circ$. Entonces

$$c^2=25+49-2\cdot5\cdot7\cdot\frac12=39,\qquad\boxed{c=\sqrt{39}}.$$

#### E14. Determinar un ángulo a partir de tres lados
Para $a=5$, $b=7$ y $c=8$, la ley del coseno entrega

$$\cos\gamma=\frac{25+49-64}{2\cdot5\cdot7}=\frac17,
\qquad \gamma=\arccos\frac17.$$

El ángulo es agudo porque su coseno es positivo.

#### E15. Torre horizontal con datos elementales
Un observador se encuentra a $d=50\,\mathrm m$ de la base y observa un ángulo $\alpha=30^\circ$. Entonces

$$h=50\tan30^\circ=\boxed{\frac{50}{\sqrt3}\,\mathrm m\approx28.87\,\mathrm m}.$$

#### E16. Torre con pendiente del terreno
El terreno asciende $\gamma=10^\circ$, la distancia sobre el terreno es $d=80\,\mathrm m$ y el ángulo visual respecto de ese terreno es $\alpha=20^\circ$. Resulta

$$h=\frac{80\sin20^\circ}{\cos30^\circ}\,\mathrm m\approx31.60\,\mathrm m.$$

#### E17. Dos observadores: punto inaccesible
Tomamos $d=40\,\mathrm m$, $\alpha=30^\circ$, $\beta=45^\circ$. El teorema del seno establece

$$h=\frac{40\sin30^\circ\sin45^\circ}{\sin15^\circ}\,\mathrm m
=20(\sqrt3+1)\,\mathrm m\approx54.64\,\mathrm m.$$

#### E18. Dos observadores en terreno inclinado
Con los mismos datos del ejercicio anterior y pendiente $\gamma=10^\circ$, la fórmula del problema IV proporciona

$$h=\frac{40\sin30^\circ\sin45^\circ}{\sin15^\circ\cos10^\circ}\,\mathrm m\approx55.49\,\mathrm m.$$

La comparación con E17 muestra el factor $1/\cos\gamma>1$ que introduce la inclinación cuando la distancia entre los observadores se mide sobre el suelo.

#### E19. Área por dos lados y el ángulo comprendido
Para lados $a=6$ y $b=9$ que forman $\gamma=30^\circ$, el área es

$$K=\frac12 ab\sin\gamma=\frac12\cdot6\cdot9\cdot\frac12
=\boxed{13.5}\ \text{unidades cuadradas}.$$

#### E20. Desigualdad de los lados desde la ley del coseno
Si $0<\gamma<\pi$, se cumple $-1<\cos\gamma<1$. Como $a,b>0$, de

$$c^2=a^2+b^2-2ab\cos\gamma$$

se deduce $(a-b)^2<c^2<(a+b)^2$ y por consiguiente

$$\boxed{|a-b|<c<a+b.}$$

Así, la ley del coseno contiene como consecuencia algebraica las desigualdades que caracterizan las longitudes de los lados de un triángulo no degenerado.

---

## Funciones trigonométricas inversas y ecuaciones

Al restringir el dominio de ciertas funciones trigonométricas se obtienen funciones inversas. Esta construcción permite definir ramas principales y resolver ecuaciones con todas sus familias de soluciones.

**Grabaciones de referencia:** [grabación de la cátedra 7.2](https://www.youtube.com/watch?v=EoIVowNQD70).

*Procedencia de este tramo: cátedra 7.2.*

### De la unicidad a la función inversa

**En la cátedra (10:31–13:35).** La sesión concluye la semana de trigonometría estudiando las funciones inversas de seno, coseno y tangente, y las ecuaciones que esas inversas permiten resolver. El problema generador es sencillo de formular: dado un número real $a$, hallar **todos** los ángulos $x$ que satisfacen una de las condiciones

$$\operatorname{sen}x=a,\qquad \cos x=a,\qquad \tan x=a.$$

La cuestión comprende dos niveles: localizar una solución distinguida y describir la familia completa. San Martín recuerda la relación entre **inyectividad y unicidad** y entre **sobreyectividad y existencia**, ya estudiada en álgebra.

Una aplicación $f:A\to B$ es **biyectiva** cuando cada $b\in B$ tiene exactamente un antecedente $a\in A$ tal que $f(a)=b$. La función inversa $f^{-1}:B\to A$ asigna a cada $b$ ese antecedente único. Gráficamente, los puntos $(a,b)$ del grafo de $f$ corresponden a los puntos $(b,a)$ del grafo de $f^{-1}$.

Las funciones seno y coseno tienen valores en $[-1,1]$ y repiten sus valores después de una vuelta completa. Por ello, el profesor escoge **intervalos de restricción** en los que cada altura aparece exactamente una vez, y fija $[-1,1]$ como codominio de esas ramas. La tangente toma todos los valores reales y repite sus valores cada $\pi$; para ella bastará escoger una rama entre dos asíntotas consecutivas.

**Ampliación editorial — convención de escritura.** El símbolo $f^{-1}$ designa la función inversa de $f$; en particular, $\operatorname{arcsen}$, $\arccos$ y $\arctan$ designan *ángulos*. Las funciones recíprocas son $1/\operatorname{sen}x$, $1/\cos x$ y $1/\tan x$, con sus propios dominios. Esta distinción permite leer correctamente las expresiones que aparecerán a continuación.

### La rama principal del seno y el arcoseno

**En la cátedra (13:35–31:19).** Para $x\in[-\pi/2,\pi/2]$, el seno es estrictamente creciente y recorre una vez todas las alturas comprendidas entre $-1$ y $1$. Además, este intervalo incorpora el primer cuadrante, indispensable para la trigonometría de triángulos rectángulos. De aquí nace la función restringida

$$s:\left[-\frac\pi2,\frac\pi2\right]\longrightarrow[-1,1],\qquad s(x)=\operatorname{sen}x.$$

![La rama del seno que se escoge para la inversión](figuras/IC2021_Catedra_7_2/01_seno_rama.png)

La aplicación $s$ es biyectiva. Su inversa, llamada **arcoseno**, tiene la correspondencia

$$\boxed{\operatorname{arcsen}:[-1,1]\longrightarrow\left[-\frac\pi2,\frac\pi2\right].}$$

Para cada $a\in[-1,1]$, el valor $\operatorname{arcsen}(a)$ es el único ángulo $\alpha\in[-\pi/2,\pi/2]$ tal que $\operatorname{sen}\alpha=a$. Esta formulación determina simultáneamente el dominio, el recorrido y la ley de la inversa.

**Ejemplos de la cátedra.** El profesor recupera las alturas de los ángulos elementales:

$$
\operatorname{arcsen}\left(\frac12\right)=\frac\pi6,\quad
\operatorname{arcsen}\left(\frac{\sqrt2}{2}\right)=\frac\pi4,\quad
\operatorname{arcsen}\left(-\frac{\sqrt3}{2}\right)=-\frac\pi3.
$$

![La gráfica creciente del arcoseno](figuras/IC2021_Catedra_7_2/03_grafica_arcoseno.png)

El profesor construye el gráfico de la inversa intercambiando las coordenadas del seno restringido. Es una reflexión respecto de la recta $y=x$: el punto $(\pi/2,1)$ pasa a $(1,\pi/2)$, y $(-\pi/2,-1)$ pasa a $(-1,-\pi/2)$.

![Reflexión de la curva restringida respecto de la diagonal](figuras/IC2021_Catedra_7_2/09_reflejo_inversa.png)

**Demostración desarrollada.** Como el seno es impar, si $\alpha\in[-\pi/2,\pi/2]$ tiene seno $a$, entonces $-\alpha$ pertenece al mismo intervalo y tiene seno $-a$. La unicidad de la inversa da

$$\boxed{\operatorname{arcsen}(-a)=-\operatorname{arcsen}(a)\qquad(-1\leq a\leq1).}$$

Las dos identidades de composición deben leerse con sus dominios:

$$\operatorname{sen}(\operatorname{arcsen} a)=a\quad(a\in[-1,1]),$$
$$\operatorname{arcsen}(\operatorname{sen}x)=x\quad\left(x\in[-\frac\pi2,\frac\pi2]\right).$$

Para un ángulo exterior al intervalo principal, $\operatorname{arcsen}(\operatorname{sen}x)$ devuelve el **representante principal** que tiene su misma altura. Esta propiedad conecta con la ecuación general de la sección siguiente.

### Resolver completamente $\operatorname{sen}x=a$

**En la cátedra (31:19–47:27).** Cuando $|a|>1$, el problema carece de soluciones reales por la acotación del seno. Para cada $a\in[-1,1]$, existe la solución principal

$$\alpha=\operatorname{arcsen}(a)\in[-\pi/2,\pi/2].$$

En el círculo unitario, la condición $\operatorname{sen}x=a$ describe la intersección de la circunferencia con la recta horizontal $y=a$. Para $-1<a<1$ aparecen, en general, dos puntos por vuelta. Si el primero tiene ángulo $\alpha$, el simétrico respecto del eje vertical tiene ángulo $\pi-\alpha$.

![Dos puntos del círculo con igual seno](figuras/IC2021_Catedra_7_2/02_circulo_seno.png)

La figura presenta $a>0$. La misma expresión $\pi-\alpha$ funciona cuando $a<0$: entonces $\alpha$ es negativo y la segunda dirección se obtiene en el tercer cuadrante. La escritura con ángulos orientados conserva los signos sin introducir valores absolutos artificiales.

**Demostración desarrollada.** La simetría y la periodicidad producen las dos familias

$$
\boxed{\begin{aligned}
x&=\alpha+2k\pi,\\
x&=\pi-\alpha+2k\pi,
\end{aligned}\qquad k\in\mathbb Z.}
$$

El profesor presenta una notación unificada. Cuando $k$ es par, $(-1)^k=1$; cuando $k$ es impar, $(-1)^k=-1$. Así, todos los valores se reúnen en

$$\boxed{x=k\pi+(-1)^k\operatorname{arcsen}(a),\qquad k\in\mathbb Z,\quad |a|\leq1.}$$

Si $a=1$ o $a=-1$, las familias describen repetidamente un mismo punto por vuelta. La fórmula conserva su validez; en esos extremos la línea horizontal es tangente al círculo.

**Analogía desarrollada en la cátedra (47:47–54:50).** Para resolver $x^2=a$, primero se obtiene la raíz principal $\sqrt a$ sobre $[0,\infty)$; después se recuperan ambas posibilidades mediante $x=\pm\sqrt a$ (para $a>0$). En las ecuaciones trigonométricas, la función inversa proporciona asimismo una solución principal, mientras que las simetrías y la periodicidad generan las demás. Por ejemplo, $\operatorname{arcsen}(1/2)=\pi/6$, y la ecuación $\operatorname{sen}x=1/2$ tiene soluciones $\pi/6+2k\pi$ y $5\pi/6+2k\pi$.

### El coseno restringido y el arcocoseno

**En la cátedra (54:50–1:10:33).** La elección natural para el coseno es la rama del primer y segundo cuadrantes. En el intervalo $[0,\pi]$ la función es estrictamente decreciente y recorre todas las alturas del $1$ al $-1$:

$$c:[0,\pi]\longrightarrow[-1,1],\qquad c(x)=\cos x.$$

![La rama invertible del coseno](figuras/IC2021_Catedra_7_2/04_coseno_rama.png)

Su inversa recibe el nombre **arcocoseno**:

$$\boxed{\arccos:[-1,1]\longrightarrow[0,\pi].}$$

Para cada $a\in[-1,1]$, $\arccos(a)$ es el único ángulo $\alpha\in[0,\pi]$ que satisface $\cos\alpha=a$. El recorrido de esta función es enteramente no negativo: en particular, el arcocoseno de un número negativo corresponde a un ángulo del **segundo cuadrante**.

$$
\arccos(1)=0,\quad
\arccos\left(\frac12\right)=\frac\pi3,\quad
\arccos(0)=\frac\pi2,\quad
\arccos\left(-\frac12\right)=\frac{2\pi}{3},\quad
\arccos(-1)=\pi.
$$

![Gráfica decreciente del arcocoseno](figuras/IC2021_Catedra_7_2/06_grafica_arcocoseno.png)

**Ampliación editorial.** La simetría del círculo respecto del eje vertical muestra que $\cos(\pi-\alpha)=-\cos\alpha$. Como ambos ángulos principales pertenecen a $[0,\pi]$, resulta

$$\arccos(-a)=\pi-\arccos(a),\qquad a\in[-1,1].$$

Las identidades de composición son

$$\cos(\arccos a)=a\ (a\in[-1,1]),\qquad
\arccos(\cos x)=x\ (x\in[0,\pi]).$$

### Resolver completamente $\cos x=a$

**En la cátedra (1:10:33–1:22:43).** La condición de existencia vuelve a ser $|a|\leq1$. Si se cumple, el ángulo principal es

$$\alpha=\arccos(a)\in[0,\pi].$$

En el círculo unitario, la ecuación $\cos x=a$ selecciona la recta vertical $x=a$. Los dos puntos de intersección se reflejan en el eje horizontal; sus ángulos son $\alpha$ y $-\alpha$.

![Dos direcciones que tienen el mismo coseno](figuras/IC2021_Catedra_7_2/05_circulo_coseno.png)

Por la paridad del coseno y la periodicidad, todas las soluciones se expresan como

$$\boxed{x=2k\pi\pm\arccos(a),\qquad k\in\mathbb Z,\quad |a|\leq1.}$$

El signo $\pm$ señala **dos familias** de soluciones. En los valores $a=1$ y $a=-1$ las familias pueden coincidir, ya que los puntos correspondientes están situados sobre el eje horizontal.

Una comprobación útil de la clase es $\cos x=-1/2$: el ángulo principal es $2\pi/3$, y las direcciones de una vuelta son $2\pi/3$ y $4\pi/3$. Ambas quedan incluidas en $2k\pi\pm2\pi/3$.

![Los dos ángulos para coseno igual a menos un medio](figuras/IC2021_Catedra_7_2/10_ecuacion_coseno.png)

### La tangente restringida y la arcotangente

**En la cátedra (1:22:43–1:27:06).** La tangente presenta asíntotas verticales en los ángulos $\pi/2+k\pi$. Entre $-\pi/2$ y $\pi/2$ es estrictamente creciente, recorre todos los valores reales y su dominio es abierto en ambos extremos:

$$t:\left(-\frac\pi2,\frac\pi2\right)\longrightarrow\mathbb R,\qquad t(x)=\tan x.$$

![Rama principal de la tangente y asíntotas](figuras/IC2021_Catedra_7_2/07_tangente_rama.png)

La función inversa es la **arcotangente**,

$$\boxed{\arctan:\mathbb R\longrightarrow\left(-\frac\pi2,\frac\pi2\right).}$$

Por ejemplo,

$$\arctan(0)=0,\quad \arctan(1)=\frac\pi4,\quad
\arctan(-1)=-\frac\pi4,\quad
\arctan(\sqrt3)=\frac\pi3.$$

![Arcotangente y sus dos asíntotas horizontales](figuras/IC2021_Catedra_7_2/08_grafica_arcotangente.png)

**Demostración desarrollada.** Si $a\in\mathbb R$ y $\alpha=\arctan(a)$, entonces $\tan\alpha=a$. Como la tangente tiene período $\pi$, las soluciones completas son

$$\boxed{x=\arctan(a)+k\pi,\qquad k\in\mathbb Z,\quad a\in\mathbb R.}$$

La arcotangente es impar; por consiguiente $\arctan(-a)=-\arctan(a)$. A diferencia del arcoseno y el arcocoseno, admite cualquier real como argumento.

### Una tabla para orientar las ecuaciones

| Función principal | Dominio de la inversa | Recorrido de la inversa | Solución general de $f(x)=a$ |
|:---|:---|:---|:---|
| $\operatorname{arcsen}$ | $[-1,1]$ | $[-\pi/2,\pi/2]$ | $k\pi+(-1)^k\operatorname{arcsen}(a)$ |
| $\arccos$ | $[-1,1]$ | $[0,\pi]$ | $2k\pi\pm\arccos(a)$ |
| $\arctan$ | $\mathbb R$ | $(-\pi/2,\pi/2)$ | $\arctan(a)+k\pi$ |

En todas las expresiones $k\in\mathbb Z$. El primer paso de la resolución consiste en verificar que el dato $a$ pertenezca al conjunto imagen de la función original. El segundo localiza un ángulo principal mediante la inversa. El tercero aplica las simetrías y el período adecuados.

**Ampliación editorial — criterio de comprobación.** Sustituir la fórmula de una familia en la ecuación original permite confirmar la corrección. Por ejemplo,

$$\operatorname{sen}\bigl(\pi-\operatorname{arcsen}(a)\bigr)=a,\quad
\cos\bigl(-\arccos(a)\bigr)=a,\quad
\tan\bigl(\arctan(a)+k\pi\bigr)=a.$$

Estas identidades proporcionan una verificación inmediata, mientras que el gráfico del círculo y la periodicidad justifican que se ha recuperado el **conjunto completo** de soluciones.

### Ejemplo final de la grabación: una ecuación compuesta

**En la cátedra (1:27:13–1:40:50).** San Martín propone resolver

$$\boxed{1+\operatorname{sen}x+\cos x+\operatorname{sen}(2x)+\cos(2x)=0.}$$

La estrategia central es transformar las funciones del ángulo doble mediante

$$\operatorname{sen}(2x)=2\operatorname{sen}x\cos x,\qquad
\cos(2x)=\cos^2x-\operatorname{sen}^2x.$$

**Desarrollo de la demostración.** Escribimos $s=\operatorname{sen}x$ y $c=\cos x$, de manera que $s^2+c^2=1$. Entonces la ecuación se convierte, por equivalencias, en

$$
\begin{aligned}
0&=1+s+c+2sc+c^2-s^2\\
 &=s+c+2sc+2c^2\\
 &=(s+c)(1+2c).
\end{aligned}
$$

Así, el problema inicial equivale a resolver cualquiera de las dos ecuaciones

$$\operatorname{sen}x+\cos x=0\qquad\text{o}\qquad 1+2\cos x=0.$$

La grabación resuelve explícitamente la segunda y enseña a transformar la primera mediante el factor $\sqrt2/2$, dejando parte del despeje final indicado. Completamos ambas familias a continuación.

**Primera familia — ampliación editorial.** La identidad de adición para el coseno da

$$
\frac{\sqrt2}{2}(\cos x+\operatorname{sen}x)
=\cos x\cos\frac\pi4+\operatorname{sen}x\operatorname{sen}\frac\pi4
=\cos\left(x-\frac\pi4\right).
$$

Por ello $\cos(x-\pi/4)=0$, de donde $x-\pi/4=\pi/2+k\pi$. La primera familia puede escribirse como

$$\boxed{x=-\frac\pi4+k\pi,\qquad k\in\mathbb Z.}$$

La fórmula obtenida directamente, $x=3\pi/4+k\pi$, describe el mismo conjunto después de cambiar el índice $k$.

**Segunda familia — en la cátedra y desarrollo editorial.** La condición $1+2\cos x=0$ conduce a $\cos x=-1/2$. Como $\arccos(-1/2)=2\pi/3$,

$$\boxed{x=2k\pi\pm\frac{2\pi}{3},\qquad k\in\mathbb Z.}$$

**Respuesta completa.** El conjunto buscado es la unión de esas tres progresiones angulares:

$$\boxed{S=\left\{-\frac\pi4+k\pi:k\in\mathbb Z\right\}
\cup\left\{2k\pi\pm\frac{2\pi}{3}:k\in\mathbb Z\right\}.}$$

La igualdad de la expresión original con el producto factorizado es una **identidad** válida para todo ángulo real; cada transformación ha preservado el conjunto de soluciones.

### Propuesta final de la clase: una combinación lineal

**En la cátedra (1:41:08–1:41:35).** San Martín deja planteada otra ecuación:

$$\sqrt3\cos x+\operatorname{sen}x=1.$$

Sugiere reconocer en sus coeficientes valores de seno y coseno de un ángulo elemental y reducir así el ejercicio a una sola función trigonométrica.

**Ampliación editorial — resolución.** Recordando que $\cos(\pi/6)=\sqrt3/2$ y $\operatorname{sen}(\pi/6)=1/2$,

$$\sqrt3\cos x+\operatorname{sen}x
=2\left(\cos x\cos\frac\pi6+\operatorname{sen}x\operatorname{sen}\frac\pi6\right)
=2\cos\left(x-\frac\pi6\right).$$

Así $\cos(x-\pi/6)=1/2$, con soluciones

$$x-\frac\pi6=2k\pi\pm\frac\pi3.$$

Por tanto,

$$\boxed{x=\frac\pi2+2k\pi\quad\text{o}\quad x=-\frac\pi6+2k\pi,\qquad k\in\mathbb Z.}$$

**Ampliación editorial — principio reusable.** Para constantes reales $A,B$ con $R=\sqrt{A^2+B^2}>0$, hay un ángulo $\varphi$ que satisface $\cos\varphi=A/R$ y $\operatorname{sen}\varphi=B/R$. Entonces

$$A\cos x+B\operatorname{sen}x=R\cos(x-\varphi).$$

Esta construcción, apoyada en el círculo unitario, transforma una combinación lineal de seno y coseno en una sola función con un desplazamiento angular. Es también el fundamento del método para resolver $A\cos x+B\operatorname{sen}x=C$: la existencia de soluciones se determina comparando $|C|$ con $R$.

### Balance y tránsito al siguiente tema

**En la cátedra y consultas finales (1:41:35–1:52:35).** Con las inversas de seno, coseno y tangente termina el bloque de trigonometría que entra en el segundo control del curso. En las consultas finales se mencionan cambios de calendario, la devolución de tareas y la próxima unidad dedicada al axioma del supremo. Estas intervenciones ofrecen contexto académico de 2021 y se consignan aquí únicamente como continuidad del itinerario, sin transformarlas en contenido matemático nuevo de esta sesión.

El argumento que organiza la clase puede resumirse de forma afirmativa: **elegir una rama biyectiva, determinar su inversa, obtener un ángulo principal y reconstruir la totalidad de soluciones por simetría y periodicidad**. Esa secuencia permite resolver ecuaciones desde la geometría del círculo y las propiedades de las funciones. La factorización del ejercicio final muestra, además, que las identidades trigonométricas y el álgebra de funciones trabajan conjuntamente.

### Taller de problemas y soluciones

Los ejercicios se presentan a continuación según la fuente de origen; las ampliaciones editoriales de cada apuntes permanecen expresamente identificadas.

#### Problemas complementarios resueltos — cátedra 7.2

Los siguientes problemas son **originales de esta edición**. Se organizan como una prolongación graduada de la clase: primero inversión, luego familias de soluciones y, finalmente, ecuaciones que necesitan identidades. Cada respuesta incluye el argumento que determina el conjunto completo de soluciones.

#### Ángulos principales
Calcular $\operatorname{arcsen}(1/2)$ y $\operatorname{arcsen}(-\sqrt2/2)$. **Solución.** En $[-\pi/2,\pi/2]$, el ángulo con seno $1/2$ es $\pi/6$ y el de seno $-\sqrt2/2$ es $-\pi/4$. Por tanto,

$$\operatorname{arcsen}(1/2)=\pi/6,\qquad\operatorname{arcsen}(-\sqrt2/2)=-\pi/4.$$

#### El segundo cuadrante
Calcular $\arccos(-1/2)$. **Solución.** El arcocoseno entrega un ángulo de $[0,\pi]$; la abscisa $-1/2$ corresponde a $2\pi/3$. Así, $\arccos(-1/2)=2\pi/3$.

#### El representante principal de un seno
Calcular $\operatorname{arcsen}(\operatorname{sen}(5\pi/6))$. **Solución.** $\operatorname{sen}(5\pi/6)=1/2$, de modo que el representante principal es $\pi/6$. El ángulo inicial y el principal comparten altura en el círculo.

#### El representante principal de un coseno
Calcular $\arccos(\cos(5\pi/3))$. **Solución.** El coseno vale $1/2$, y el único ángulo de $[0,\pi]$ con ese coseno es $\pi/3$.

#### La tangente y su período
Calcular $\arctan(\tan(3\pi/4))$. **Solución.** $\tan(3\pi/4)=-1$, y la arcotangente pertenece al intervalo abierto $(-\pi/2,\pi/2)$; por ello el resultado es $-\pi/4$.

#### Una ecuación del seno con dos familias
Resolver $\operatorname{sen}x=1/2$. **Solución.** El ángulo principal es $\pi/6$. Las soluciones son

$$x=\frac\pi6+2k\pi\quad\text{o}\quad x=\frac{5\pi}{6}+2k\pi,\qquad k\in\mathbb Z.$$

#### Seno negativo
Resolver $\operatorname{sen}x=-\sqrt3/2$. **Solución.** La rama principal da $\alpha=-\pi/3$. Por la reflexión $\pi-\alpha=4\pi/3$, resulta

$$x=-\frac\pi3+2k\pi\quad\text{o}\quad x=\frac{4\pi}{3}+2k\pi,\qquad k\in\mathbb Z.$$

#### Coseno negativo
Resolver $\cos x=-\sqrt2/2$. **Solución.** $\alpha=\arccos(-\sqrt2/2)=3\pi/4$. Por paridad y periodicidad,

$$x=2k\pi\pm\frac{3\pi}{4},\qquad k\in\mathbb Z.$$

#### Extremos de la función coseno
Resolver $\cos x=1$. **Solución.** El único punto del círculo con abscisa $1$ es $(1,0)$. Se alcanza después de cualquier número entero de vueltas:

$$x=2k\pi,\qquad k\in\mathbb Z.$$

#### Tangente y soluciones periódicas
Resolver $\tan x=\sqrt3$. **Solución.** La solución principal es $\pi/3$; las restantes se obtienen sumando múltiplos de $\pi$:

$$x=\frac\pi3+k\pi,\qquad k\in\mathbb Z.$$

#### Una tangente del ángulo doble
Resolver $\tan(2x)=1$. **Solución.** $2x=\pi/4+k\pi$, así que

$$x=\frac\pi8+\frac{k\pi}{2},\qquad k\in\mathbb Z.$$

#### Los ceros del seno del ángulo doble
Resolver $\operatorname{sen}(2x)=0$. **Solución.** Los ceros del seno son los múltiplos enteros de $\pi$, luego $2x=k\pi$ y

$$x=\frac{k\pi}{2},\qquad k\in\mathbb Z.$$

#### Dos funciones con el mismo valor
Resolver $\operatorname{sen}x=\cos x$. **Solución.** Como un ángulo que satisface la igualdad tiene $\cos x\ne0$, la división por el coseno es legítima. La condición es $\tan x=1$, de donde

$$x=\frac\pi4+k\pi,\qquad k\in\mathbb Z.$$

#### Una ecuación con el seno al cuadrado
Resolver $\operatorname{sen}^2x=1/4$. **Solución.** La ecuación equivale a $\operatorname{sen}x=1/2$ o $\operatorname{sen}x=-1/2$. Las cuatro direcciones de cada vuelta se condensan en

$$x=k\pi\pm\frac\pi6,\qquad k\in\mathbb Z.$$

#### Una suma que vale uno
Resolver $\operatorname{sen}x+\cos x=1$. **Solución.** Por la identidad de adición, $\operatorname{sen}x+\cos x=\sqrt2\operatorname{sen}(x+\pi/4)$. Por tanto $\operatorname{sen}(x+\pi/4)=1/\sqrt2$, y

$$x=2k\pi\quad\text{o}\quad x=\frac\pi2+2k\pi,\qquad k\in\mathbb Z.$$

#### El coseno de un ángulo y de su doble
Resolver $\cos(2x)=\cos x$. **Solución.** Escribiendo $c=\cos x$ y usando $\cos(2x)=2c^2-1$, obtenemos

$$2c^2-c-1=(2c+1)(c-1)=0.$$

Por tanto, $\cos x=1$ o $\cos x=-1/2$. El conjunto solución es

$$x=2k\pi\quad\text{o}\quad x=2k\pi\pm\frac{2\pi}{3},\qquad k\in\mathbb Z.$$

#### Una ecuación cuadrática en el seno
Resolver $2\operatorname{sen}^2x+\operatorname{sen}x-1=0$. **Solución.** El cambio $s=\operatorname{sen}x$ lleva a $(2s-1)(s+1)=0$. Así, $s=1/2$ o $s=-1$. Las soluciones son

$$x=\frac\pi6+2k\pi,\quad x=\frac{5\pi}{6}+2k\pi,\quad
x=\frac{3\pi}{2}+2k\pi,\qquad k\in\mathbb Z.$$

#### Dominio exacto de una identidad de composición
Determinar todos los reales $x$ para los que $\operatorname{arcsen}(\operatorname{sen}x)=x$. **Solución.** El arcoseno toma valores precisamente en $[-\pi/2,\pi/2]$. Dentro de ese intervalo es inversa del seno restringido y la igualdad se cumple. Fuera de él, el miembro izquierdo permanece en el intervalo y, por tanto, difiere del ángulo $x$. La respuesta es

$$\boxed{x\in[-\pi/2,\pi/2].}$$

#### Resolver una ecuación con parámetro
Para $a\in\mathbb R$, resolver $\cos x=2a-1$. **Solución.** Hay soluciones reales exactamente cuando $-1\leq2a-1\leq1$, esto es, cuando $0\leq a\leq1$. Para esos parámetros,

$$x=2k\pi\pm\arccos(2a-1),\qquad k\in\mathbb Z.$$

#### Generalizar el último ejercicio de la cátedra
Dados $A,B,C\in\mathbb R$ con $A^2+B^2>0$, estudiar $A\cos x+B\operatorname{sen}x=C$. **Solución.** Elegimos $R=\sqrt{A^2+B^2}$ y un ángulo $\varphi$ de coseno $A/R$ y seno $B/R$. La ecuación se transforma en

$$\cos(x-\varphi)=\frac{C}{R}.$$

Tiene soluciones cuando $|C|\leq R$, en cuyo caso

$$\boxed{x=\varphi+2k\pi\pm\arccos(C/R),\qquad k\in\mathbb Z.}$$

Este procedimiento proporciona una forma sistemática de reconocer el factor de normalización que San Martín propone buscar en la última parte de la grabación.

---

# Parte III. La completitud de los reales y las sucesiones

## Supremos, naturales y propiedad arquimediana

El axioma del supremo expresa una propiedad fundamental del continuo real. Desde ella se estudian cotas, extremos, números naturales, inducción y la propiedad arquimediana.

**Grabaciones de referencia:** [grabación de la cátedra 8.1](https://www.youtube.com/watch?v=U2nQmKdc_lo), [grabación de la cátedra 8.2](https://www.youtube.com/watch?v=Q-gZ2Ja3kCg).

*Procedencia de este tramo: cátedra 8.1.*

### El problema generador: completar los números reales

**En la cátedra (06:38–10:54).** El profesor vuelve al problema abierto desde el comienzo del curso: la estructura de los números reales se ha descrito como un **cuerpo ordenado**, pero aún falta la propiedad que hace de ese cuerpo un **cuerpo ordenado completo**. Los primeros axiomas establecieron las operaciones y el orden; el **axioma 8** expresará una propiedad adicional que permite justificar la existencia de números cuya presencia se había utilizado informalmente en los problemas anteriores.

La pregunta que guía la clase es concreta: *¿cómo se puede demostrar que existe un número real positivo cuyo cuadrado vale 2?* El cálculo algebraico permite manipular expresiones con $\sqrt2$ una vez admitida su existencia. La nueva tarea consiste en **obtener esa existencia a partir de una propiedad del sistema real**. Para ello será necesario conocer qué significa que un conjunto esté acotado y qué número especial recibe el nombre de *supremo*.

La estrategia pedagógica de San Martín consiste en comenzar por relaciones familiares de orden y avanzar hasta una afirmación de existencia: pasar de «un número está por encima de todos los elementos» a «entre todas las cotas superiores existe una menor».

### Cotas superiores e inferiores

#### Cota superior y conjunto acotado superiormente
**En la cátedra (10:54–20:03).** Sea $A\subseteq\mathbb R$ un conjunto **no vacío**. Un real $M$ es una **cota superior de $A$** cuando cada elemento de $A$ satisface $x\leq M$. Se escribe

$$\boxed{M\text{ es cota superior de }A\iff (\forall x\in A)\ x\leq M.}$$

El conjunto $A$ es **acotado superiormente** cuando posee al menos una cota superior, esto es,

$$\boxed{(\exists M\in\mathbb R)(\forall x\in A)\ x\leq M.}$$

El real $M$ pertenece a $\mathbb R$; su función es **dominar simultáneamente todos los elementos** de $A$. Su pertenencia a $A$ constituye una pregunta distinta. También importa el orden de los cuantificadores: aquí existe **un mismo** $M$ que sirve para **cada** $x\in A$.

La diferencia se ve al comparar

$$
\underbrace{(\exists M)(\forall x\in A)\ x\le M}_{\text{acotación superior}}
\qquad\text{y}\qquad
\underbrace{(\forall x\in A)(\exists M)\ x\le M}_{\text{afirmación elemental}}.
$$

En la segunda afirmación, $M$ puede elegirse nuevamente para cada $x$; por ejemplo, $M=x+1$. La primera exige una **cota común**.

![Cotas superiores e inferiores de un conjunto, con números de referencia](figuras/IC2021_Catedra_8_1/01_cotas.png)

#### Cota inferior y conjunto acotado inferiormente
**En la cátedra (20:03–23:33).** Un real $m$ es una **cota inferior de $A$** cuando se cumple $m\leq x$ para cada $x\in A$:

$$\boxed{m\text{ es cota inferior de }A\iff(\forall x\in A)\ m\leq x.}$$

El conjunto es **acotado inferiormente** cuando existe tal $m$. Diremos que un conjunto es **acotado** cuando dispone de cotas inferiores y superiores; equivalentemente, cuando existen reales $m,M$ tales que

$$\forall x\in A,\qquad m\le x\le M.$$

La representación geométrica ubica las cotas superiores a la derecha de todos los elementos del conjunto y las cotas inferiores a la izquierda de todos ellos. Esta imagen funciona aun cuando $A$ sea una unión de intervalos, una sucesión de puntos o un conjunto descrito mediante una desigualdad.

#### Leer las desigualdades: estricto implica débil
**En la cátedra (23:33–31:37).** El profesor dedica un pasaje a un error habitual: creer que $x<10$ impide escribir $x\leq10$. La relación débil tiene el significado lógico

$$x\leq y\quad\iff\quad (x<y)\ \lor\ (x=y).$$

Por tanto, $x<y$ **implica** $x\leq y$. Esta implicación se utiliza constantemente al comprobar que un número es cota superior; por ejemplo, de $0\leq x<1$ se deduce $x\leq1$.

**Ejemplos de la cátedra.** Para $A=[0,1]$, el real $10$ es una cota superior porque todos los puntos de $A$ son menores que 10. También lo son 1, 2, 11 y cualquier número superior a 1. Para

$$B=[0,1]\cup[3,4],$$

el número 2 domina los elementos del primer intervalo, pero $B$ contiene los números del segundo intervalo. En cambio, 4, 5 y 10 sí son cotas superiores de $B$.

![Una unión de intervalos y la ubicación de cotas posibles](figuras/IC2021_Catedra_8_1/02_union_intervalos.png)

#### Una cota genera nuevas cotas
**Demostración desarrollada (34:08–44:05).** Si $M$ es cota superior de $A$ y $T\geq M$, entonces $T$ también es cota superior. En efecto, para cada $x\in A$,

$$x\leq M\leq T,$$

de donde $x\leq T$. En particular, $M+1$, $M+\tfrac12$ y $M+10^6$ son cotas superiores. A estas cotas más grandes, obtenidas inmediatamente a partir de una conocida, el profesor las llama pedagógicamente *cotas triviales*.

La información matemática más precisa aparece al encontrar una **cota superior menor**. El problema del supremo consistirá precisamente en encontrar la menor de todas ellas.

De manera simétrica, si $m$ es cota inferior de $A$ y $t\le m$, entonces $t$ también es cota inferior. Las cotas inferiores más informativas son las mayores.

### Máximo y mínimo: una cota perteneciente al conjunto

**En la cátedra (44:05–48:52).** El real $M$ es el **máximo** de $A$ cuando cumple simultáneamente

$$\boxed{M\in A\qquad\text{y}\qquad(\forall x\in A)\ x\le M.}$$

El real $m$ es el **mínimo** de $A$ cuando

$$\boxed{m\in A\qquad\text{y}\qquad(\forall x\in A)\ m\le x.}$$

Estas definiciones combinan una propiedad **comparativa** (ser cota) y una propiedad **de pertenencia**. El máximo es un elemento que domina todos los elementos del conjunto; el mínimo pertenece al conjunto y es dominado por cada elemento suyo.

Para $A=[0,1]$, tenemos

$$\max A=1,\qquad\min A=0.$$

Esos mismos valores son también cotas superior e inferior. Para $B=[0,1)$, el número 0 es mínimo y el número 1 es cota superior. La apertura del extremo derecho modifica la cuestión del máximo: ningún punto de $B$ ocupa esa posición.

![Máximo de un intervalo cerrado y ausencia de máximo en el abierto por la derecha](figuras/IC2021_Catedra_8_1/03_maximo_abierto.png)

#### Por qué $[0,1)$ tiene supremos posibles, pero carece de máximo
**En la cátedra (48:52–59:20).** Los números $0.9$, $0.99$, $0.999$, etc., son elementos de $[0,1)$ y cada uno admite elementos mayores dentro del conjunto. San Martín presenta la escritura $0.\overline9=1$ como **motivación decimal**, separada de la demostración exacta. El valor 1 ya era una cota superior conocida.

La demostración decisiva evita la notación decimal. Tomemos cualquier $b<1$. Si además $b<0$, el elemento $0\in[0,1)$ satisface $0>b$. Si $0\le b<1$, consideremos el punto medio entre $b$ y 1:

$$c=\frac{b+1}{2}.$$

Entonces

$$b<c<1,$$

de modo que $c\in[0,1)$ y $c>b$. En ambos casos, $b$ queda superado por un elemento del conjunto. Por consiguiente, **todo número menor que 1 falla como cota superior**, mientras que 1 sí es una cota superior.

![El punto medio que supera a cualquier candidato menor que 1](figuras/IC2021_Catedra_8_1/04_punto_medio.png)

Este argumento prepara el concepto de *menor cota superior*: 1 lo es para $[0,1)$ y la pertenencia del número 1 al conjunto no interviene en ese carácter.

### Supremo e ínfimo: extremos de las cotas

#### El supremo
**En la cátedra (59:20–1:01:01).** Un real $s$ es el **supremo** de $A$, escrito $s=\sup A$, cuando satisface dos propiedades:

1. $s$ es una cota superior de $A$;
2. $s$ es menor o igual que cualquier cota superior de $A$.

En símbolos:

$$\boxed{\begin{aligned}
(\forall x\in A)&\quad x\leq s,\\
(\forall M\in\mathbb R)&\quad\bigl[(\forall x\in A)\ x\leq M\bigr]\Longrightarrow s\leq M.
\end{aligned}}$$

**Definición afirmativa.** El supremo es el mínimo del conjunto de las cotas superiores, cuando este último posee un mínimo. La formulación con cuantificadores hace explícito tanto el carácter de cota superior como su optimalidad.

En el ejemplo discutido,

$$\boxed{\sup[0,1)=1,\qquad\max[0,1)\text{ no existe}.}$$

En cambio, $[0,1]$ tiene máximo y supremo, ambos iguales a 1.

#### El ínfimo
**En la cátedra (1:01:01–1:02:06).** Un real $i$ es el **ínfimo** de $A$, escrito $i=\inf A$, cuando

$$\boxed{\begin{aligned}
(\forall x\in A)&\quad i\leq x,\\
(\forall m\in\mathbb R)&\quad\bigl[(\forall x\in A)\ m\leq x\bigr]\Longrightarrow m\leq i.
\end{aligned}}$$

El ínfimo es la mayor de las cotas inferiores. El máximo y el mínimo agregan la pertenencia al conjunto; el supremo y el ínfimo expresan la optimalidad dentro de sus respectivas familias de cotas.

![El supremo como frontera del conjunto de cotas superiores](figuras/IC2021_Catedra_8_1/05_familia_cotas.png)

**Ampliación editorial — unicidad.** Si $s,t$ cumplen las dos condiciones del supremo de $A$, como ambos son cotas superiores, la optimalidad de $s$ da $s\le t$ y la de $t$ da $t\le s$. Por antisimetría, $s=t$. La demostración para el ínfimo es análoga.

### Axioma 8: el axioma del supremo

**En la cátedra (1:02:06–1:10:30).** El profesor enuncia el axioma que completa la teoría de los reales:

> **Axioma del supremo (completitud de $\mathbb R$).** Todo subconjunto no vacío de $\mathbb R$ que esté acotado superiormente posee supremo en $\mathbb R$.

El contenido afirmativo es una **garantía de existencia**: las dos hipótesis sobre el conjunto aseguran un real que cumple las dos condiciones definitorias del supremo.

San Martín distingue este axioma de la afirmación acerca del máximo: el conjunto $[0,1)$ satisface el axioma porque tiene supremo igual a 1, aunque carece de máximo. El axioma expresa una propiedad nueva del cuerpo ordenado de los reales.

La **hipótesis de no vaciedad** y la **acotación superior** deben comprobarse antes de invocar el axioma. Esta verificación será central en la construcción de $\sqrt2$.

#### Por qué basta un axioma del supremo
**En la cátedra (1:10:30–1:11:11).** El profesor señala que el resultado simétrico para el ínfimo se deduce al cambiar el signo de los elementos.

**Ampliación editorial — demostración.** Sea $A\subseteq\mathbb R$ no vacío y acotado inferiormente. Formemos

$$-A:=\{-x:x\in A\}.$$

Si $m$ es cota inferior de $A$, entonces $-x\leq-m$ para todo $x\in A$; por tanto $-A$ está acotado superiormente. El axioma proporciona $s=\sup(-A)$. Definamos $i=-s$. Para cada $x\in A$, de $-x\leq s$ se obtiene $i\leq x$. Además, toda cota inferior $b$ de $A$ da una cota superior $-b$ de $-A$, de donde $s\leq-b$ y, por ello, $b\leq i$. Así,

$$\boxed{\inf A=-\sup(-A).}$$

Esta es una consecuencia del axioma del supremo; ofrece el teorema del ínfimo con sus hipótesis precisas.

### Construcción de $\sqrt2$ a partir del axioma

#### El plan de la demostración
**En la cátedra (1:11:11–1:17:00).** La tarea es construir un **real positivo $s$** cuya propiedad característica sea $s^2=2$. El profesor indica por qué comenzar escribiendo $[0,\sqrt2)$ sería circular: se usaría en el punto de partida el número cuya existencia se pretende justificar.

El procedimiento legítimo consiste en construir un conjunto usando solamente desigualdades con cantidades ya disponibles, comprobar las dos hipótesis del axioma, obtener su supremo y demostrar que ese supremo posee la propiedad deseada.

#### El conjunto auxiliar
**En la cátedra (1:17:00–1:22:25).** Se considera

$$\boxed{A=\{x\in\mathbb R:x\geq0\text{ y }x^2<2\}.}$$

La definición utiliza el orden, las operaciones y el número 2; está disponible antes de haber probado la existencia de la raíz cuadrada de 2. La intuición de un intervalo que llega hasta un extremo positivo se emplea como guía, mientras que las verificaciones se realizan con desigualdades.

**No vaciedad.** El 0 pertenece a $A$ porque $0\geq0$ y $0^2<2$; también pertenece 1, dado que $1^2<2$. De esta manera $A$ es no vacío.

**Acotación superior.** El número 2 es una cota superior. En efecto, si $x\geq0$ y $x^2<2$, entonces $x<2$: si $x\geq2$, de la monotonía del cuadrado en los no negativos se deduciría $x^2\geq4$, contrario a $x^2<2$. La misma idea permite obtener cotas más pequeñas; por ejemplo $\tfrac32$, cuyo cuadrado vale $\tfrac94>2$.

Quedan así verificadas las hipótesis del axioma: $A$ es **no vacío y acotado superiormente**. Por consiguiente, existe

$$\boxed{s:=\sup A\in\mathbb R.}$$

Como $1\in A$ y $\tfrac32$ es cota superior, tenemos

$$1\leq s\leq\frac32.$$

![La frontera entre cuadrados inferiores y superiores a 2](figuras/IC2021_Catedra_8_1/06_cuadrados.png)

#### La tricotomía de $s^2$ y lo que queda pendiente
**En la cátedra (1:27:48–1:38:15).** Obtenido el supremo, el profesor formula la última etapa: justificar que $s^2=2$. Por tricotomía del orden real, se presenta exactamente una de las posibilidades

$$s^2<2,\qquad s^2=2,\qquad s^2>2.$$

Para descartar $s^2>2$, anuncia la estrategia de encontrar un número positivo $s-\varepsilon<s$ cuyo cuadrado todavía sea mayor que 2. Tal número sería también cota superior de $A$, contradiciendo que $s$ es la **menor** cota superior.

Para descartar $s^2<2$, debe construirse un elemento $s+\varepsilon$ con cuadrado menor que 2: ese elemento pertenecería a $A$ y superaría a la cota superior $s$.

**Alcance exacto de la grabación.** En esta cátedra San Martín presenta el esquema de ambas contradicciones y anuncia expresamente que la elección cuantitativa de $\varepsilon$ y el cierre de la demostración se efectuarán en la clase siguiente. La prueba que aparece a continuación es una **terminación editorial independiente**, apoyada en la estrategia efectivamente explicada.

#### Ampliación editorial: demostración completa de $s^2=2$
**Primera posibilidad: $s^2>2$.** Puesto que $s\geq1$, el número

$$\varepsilon=\min\!\left\{\frac{s}{2},\frac{s^2-2}{4s}\right\}>0$$

satisface $s-\varepsilon>0$ y $2s\varepsilon\leq(s^2-2)/2$. Entonces

$$
(s-\varepsilon)^2
=s^2-2s\varepsilon+\varepsilon^2
\geq s^2-2s\varepsilon
\geq\frac{s^2+2}{2}>2.
$$

Para cada $x\in A$ tenemos $0\leq x$ y $x^2<2<(s-\varepsilon)^2$. La monotonía del cuadrado en $[0,\infty)$ da $x<s-\varepsilon$. Por tanto $s-\varepsilon$ es cota superior de $A$, pero $s-\varepsilon<s$: esto contradice la minimalidad de $s$.

**Segunda posibilidad: $s^2<2$.** Definimos

$$\varepsilon=\min\!\left\{\frac12,\frac{2-s^2}{2(2s+1)}\right\}>0.$$

Tenemos $0<\varepsilon\leq\tfrac12$, por lo que $\varepsilon^2\leq\varepsilon$. Además,

$$
(s+\varepsilon)^2
=s^2+2s\varepsilon+\varepsilon^2
\leq s^2+(2s+1)\varepsilon
\leq s^2+\frac{2-s^2}{2}
<2.
$$

Como $s+\varepsilon\geq0$, resulta que $s+\varepsilon\in A$; sin embargo $s+\varepsilon>s$, contradicción con el hecho de que $s$ es cota superior de $A$.

La tricotomía deja, por tanto, la igualdad

$$\boxed{s^2=2,\qquad s>0.}$$

**Unicidad del real positivo.** Si $t>0$ y $t^2=2$, entonces $(s-t)(s+t)=s^2-t^2=0$. Como $s+t>0$, necesariamente $s=t$. Este real único recibe el nombre de $\sqrt2$.

**Conclusión editorial.** Hemos deducido la existencia y unicidad de la raíz cuadrada positiva de 2 utilizando las operaciones y el orden de $\mathbb R$, junto con el axioma del supremo. La conclusión completa es un añadido de esta edición, indicado expresamente para mantener la fidelidad a la cátedra.

### Una lectura geométrica de la construcción

El conjunto de los $x$ no negativos cuyos cuadrados son menores que 2 ocupa el tramo de la recta real situado antes de la frontera buscada. La propiedad de completitud garantiza la existencia de un real que marca el borde de todas las cotas superiores. La demostración algebraica prueba que, en esa frontera, el cuadrado vale exactamente 2.

El cálculo decimal permite **encerrar**, aunque no reemplazar, la demostración exacta:

$$1.41^2=1.9881<2<2.0164=1.42^2,$$

de donde $1.41<\sqrt2<1.42$. Una decimal más exige nuevas comparaciones, pero la existencia del número ya quedó establecida por el argumento con el supremo.

![Cotas decimales y cuadráticos alrededor de la raíz de 2](figuras/IC2021_Catedra_8_1/07_aproximacion_raiz.png)

### Ampliaciones editoriales: consecuencias útiles

#### Relación entre máximo y supremo
Si $A$ posee máximo $M$, entonces $M$ es una cota superior de $A$. Toda cota superior $T$ satisface $M\le T$ porque $M\in A$. Por tanto

$$\boxed{\max A\text{ existe}\Longrightarrow\sup A=\max A.}$$

Análogamente, si $\min A$ existe, entonces $\inf A=\min A$. La recíproca requiere verificar que el supremo o el ínfimo **pertenezca** al conjunto correspondiente.

#### Caracterización por aproximaciones
**Ampliación editorial.** Para un conjunto no vacío $A$ acotado superiormente y $s\in\mathbb R$, se cumple

$$\boxed{s=\sup A\iff\begin{cases}
\forall x\in A,&x\le s,\\[2pt]
\forall\varepsilon>0,&\exists x_\varepsilon\in A:\ s-\varepsilon<x_\varepsilon.
\end{cases}}$$

**Demostración.** Si $s=\sup A$, entonces es cota superior. Para cada $\varepsilon>0$, el real $s-\varepsilon$ es menor que la menor cota superior y por ello existe $x_\varepsilon\in A$ que lo supera. Recíprocamente, las dos propiedades indican que $s$ es una cota superior y que cualquier $M<s$ es superado por algún elemento de $A$; por tanto $M$ es una cota inferior a la familia de las cotas superiores y $s$ es la menor de ellas.

El argumento formal permite expresar que **hay elementos de $A$ arbitrariamente próximos al supremo por la izquierda**. En la prueba de $[0,1)$, el punto medio entre $b$ y 1 realiza precisamente esta idea.

#### Por qué los racionales no poseen esta completitud
**Ampliación editorial.** Consideremos dentro de $\mathbb Q$ el conjunto

$$B=\{q\in\mathbb Q:q\geq0,\ q^2<2\}.$$

Es no vacío y acotado superiormente en el orden racional. Si poseyera supremo racional $r$, las mismas estimaciones con números racionales positivos utilizadas arriba obligarían a que $r^2=2$.

Sin embargo, ningún racional al cuadrado vale 2. Para comprobarlo, supongamos $r=p/q$ con $p,q\in\mathbb Z$, $q>0$ y fracción irreducible. De $p^2=2q^2$ se deduce que $p$ es par, de modo que $p=2k$. Entonces $q^2=2k^2$, por lo que $q$ también es par: esto contradice la irreducibilidad. En consecuencia, el conjunto $B$ carece de supremo **en $\mathbb Q$**. Esta comparación esclarece el papel específico del axioma 8.

![Los puntos racionales aproximan la frontera, pero su supremo está en los reales](figuras/IC2021_Catedra_8_1/08_racionales.png)

### Banco complementario de problemas resueltos

Los siguientes problemas son **originales de esta edición**. Están organizados para practicar el reconocimiento de cotas, la aplicación de las definiciones y las demostraciones con cuantificadores.

#### Problema 1. Un intervalo cerrado
Para $A=[-2,5]$, determine el máximo, el mínimo, el supremo y el ínfimo.

**Solución.** Todo $x\in A$ satisface $-2\le x\le5$, por lo que $-2$ es cota inferior y 5 cota superior. Ambos pertenecen a $A$; así,

$$\max A=\sup A=5,\qquad\min A=\inf A=-2.$$

#### Problema 2. Un extremo abierto
Para $A=(-2,5]$, determine los mismos cuatro valores.

**Solución.** La cota superior mínima es 5 y pertenece al conjunto, de modo que $\max A=\sup A=5$. La cota inferior máxima es $-2$, y $-2\notin A$: entonces $\inf A=-2$ y el mínimo no existe. La verificación de este último hecho se obtiene al tomar, para cualquier $x\in A$, el punto medio $(-2+x)/2$, que también pertenece a $A$ y es menor que $x$.

#### Problema 3. La unión de dos intervalos
Considere $A=[0,1]\cup[3,4)$. Identifique sus cotas extremas.

**Solución.** Para cada $x\in A$, $0\le x<4$, y hay puntos de $A$ arbitrariamente próximos a 4 desde la izquierda. Así $\sup A=4$ y $A$ carece de máximo. Como $0\in A$ y todos sus elementos son mayores o iguales que 0, $\inf A=\min A=0$.

#### Problema 4. Una sucesión creciente de números
Sea $A=\{1-1/n:n\in\mathbb N,\ n\ge1\}$.

**Solución.** Cada elemento satisface $0\le1-1/n<1$, por lo que 1 es cota superior y 0 es el mínimo. Para cualquier $b<1$, elija $n>1/(1-b)$, posible por la propiedad arquimediana de los naturales; entonces $1-1/n>b$. Por tanto $\sup A=1$, $\inf A=\min A=0$ y $A$ carece de máximo. *La propiedad arquimediana se usa aquí como herramienta adicional, separada del argumento de la clase.*

#### Problema 5. Una sucesión decreciente
Sea $B=\{1/n:n\in\mathbb N,\ n\ge1\}$.

**Solución.** Todos los elementos son positivos y a lo más 1; además $1\in B$. De ahí $\sup B=\max B=1$. Para cada $\varepsilon>0$ existe $n$ con $n>1/\varepsilon$, y entonces $1/n<\varepsilon$. Esto demuestra $\inf B=0$ y la inexistencia de mínimo.

#### Problema 6. Un conjunto definido mediante una cuadrática
Sea $C=\{x\in\mathbb R:x^2\le9\}$. Encuentre sus extremos.

**Solución.** La desigualdad equivale a $-3\le x\le3$. Por tanto $C=[-3,3]$, cuyo máximo y supremo valen 3, y cuyo mínimo e ínfimo valen $-3$.

#### Problema 7. Cuantificadores en dos órdenes
Decida si $\mathbb R$ es acotado superiormente y compare los dos enunciados

$$(\forall x\in\mathbb R)(\exists M\in\mathbb R):x\le M,\qquad(\exists M\in\mathbb R)(\forall x\in\mathbb R):x\le M.$$

**Solución.** El primero es verdadero: para un $x$ dado, tomar $M=x+1$. El segundo es falso: para cualquier candidato fijo $M$ existe el real $M+1$ que lo supera. Así, $\mathbb R$ es un conjunto no acotado superiormente.

#### Problema 8. Dos familias de cotas
Sea $A=(1,3)$. Determine **todos** los reales que son cotas superiores y todos los que son cotas inferiores.

**Solución.** Las cotas superiores son $[3,\infty)$, y las inferiores son $(-\infty,1]$. En consecuencia $\sup A=3$ e $\inf A=1$. Ambos extremos son límites de intervalos abiertos y ninguno pertenece a $A$; por ello el conjunto carece de máximo y mínimo.

#### Problema 9. La suma de una función y su conjunto de valores
Sea $A=(0,1)$ y $f(x)=x^2$. Calcule $\sup f(A)$ y $\inf f(A)$.

**Solución.** En los positivos, el cuadrado es estrictamente creciente; por ello $f(A)=(0,1)$. Se obtiene $\sup f(A)=1$ e $\inf f(A)=0$, sin máximo ni mínimo.

#### Problema 10. Cotas para $\sqrt2$ sin calculadora
Pruebe que $7/5<\sqrt2<3/2$.

**Solución.** Ambos extremos son positivos y

$$\left(\frac75\right)^2=\frac{49}{25}<2<\frac94=\left(\frac32\right)^2.$$

La función cuadrado es estrictamente creciente sobre los reales no negativos, de modo que las desigualdades de sus cuadrados implican las desigualdades de los números.

#### Problema 11. Un supremo es único
Demuestre directamente, a partir de la definición, que un conjunto tiene a lo sumo un supremo.

**Solución.** Supongamos que $s$ y $t$ son supremos de $A$. Puesto que $s$ es la menor de las cotas superiores y $t$ es cota superior, $s\le t$. Intercambiando los papeles se obtiene $t\le s$. La antisimetría del orden real da $s=t$.

#### Problema 12. El ínfimo a partir de la negación
Para $A=(2,7]$, determine $-A$, $\sup(-A)$ y $\inf A$.

**Solución.** Se tiene $-A=[-7,-2)$. Por tanto $\sup(-A)=-2$ y, de la relación probada en §5.1, $\inf A=-\sup(-A)=2$. El número 2 es el extremo inferior abierto de $A$.

#### Problema 13. Supremo de una unión
Sean $A,B\subseteq\mathbb R$ no vacíos y acotados superiormente. Demuestre que

$$\sup(A\cup B)=\max\{\sup A,\sup B\}.$$

**Solución.** Si $s=\sup A$ y $t=\sup B$, el número $u=\max\{s,t\}$ domina todos los elementos de $A$ y los de $B$, luego es cota superior de la unión. Toda cota superior $M$ de $A\cup B$ también lo es de $A$ y de $B$; por definición, $s\le M$ y $t\le M$, de donde $u\le M$. Así $u$ es el supremo buscado.

#### Problema 14. Una cota superior óptima
Sea $A=[0,1)$. Para cada $b<1$, construya explícitamente un elemento de $A$ mayor que $b$.

**Solución.** Si $b<0$, tome $x=0$. Si $0\le b<1$, tome $x=(b+1)/2$. En ambos casos $x\in A$ y $b<x$. Por tanto el número 1 es la menor de las cotas superiores de $A$. Esta construcción reproduce el núcleo exacto del argumento del profesor.

#### Problema 15. Aproximaciones al supremo
Demuestre que si $s=\sup A$ y $\varepsilon>0$, existe $a_\varepsilon\in A$ tal que $s-\varepsilon<a_\varepsilon\le s$.

**Solución.** El número $s-\varepsilon$ es estrictamente menor que el supremo y por tanto queda superado por algún elemento $a_\varepsilon\in A$. Como $s$ es cota superior, $a_\varepsilon\le s$. La combinación de las dos desigualdades entrega la afirmación.

#### Problema 16. Un máximo también es un supremo
Sean $A\subseteq\mathbb R$ no vacío y $m=\max A$. Justifique que $m=\sup A$.

**Solución.** Por definición de máximo, $m$ es cota superior de $A$. Si $M$ es otra cota superior, dado que $m\in A$ también se verifica $m\le M$. Así $m$ es la menor cota superior.

### Cierre editorial

La cátedra realiza el tránsito desde las desigualdades elementales hacia una proposición de existencia: **todo conjunto real no vacío y acotado superiormente posee una menor cota superior**. De ella nace el marco conceptual que permite completar la construcción de $\sqrt2$ y, posteriormente, estudiar sucesiones, límites y continuidad.

En el vídeo, el trabajo alcanza la obtención de $s=\sup\{x\ge0:x^2<2\}$ y el planteamiento de las contradicciones que descartarían $s^2>2$ y $s^2<2$. La elección formal de los incrementos queda anunciada para la próxima cátedra. En estas notas, la sección 6.4 desarrolla ambos incrementos y cierra la demostración, conservando la distinción entre **contenido de la fuente** y **contribución editorial**.

#### Referencias y alcance
- **Fuente primaria:** [Jorge San Martín, IC2021, Cátedra 8.1, lunes 8:30](https://www.youtube.com/watch?v=U2nQmKdc_lo). Transcripción automática cotejada con reconstrucción simbólica.
- **Referencia complementaria para verificar la formulación del axioma:** [Cálculo interactivo, axioma del supremo, UNAM](https://prometeo.matem.unam.mx/recursos/VariosNiveles/iCartesiLibri/recursos/Calculo_2_Interactivo/paginas_extra/axioma_del_supremo.html). La fuente externa se utiliza como verificación del enunciado general; no reemplaza la organización de la grabación.
- **Contribución propia:** demostraciones editoriales de §5.1, §6.4, §8 y los problemas resueltos de §9.

*Procedencia de este tramo: cátedra 8.2.*

### Del axioma del supremo a los números naturales

**En la cátedra (15:42–18:49).** La clase anterior formuló el axioma del supremo y mostró que es el principio de completitud utilizado para obtener números reales nuevos. Ahora San Martín quiere justificar otra familia de números utilizada durante todo el curso: **los naturales**. Su lugar es significativo. Los reales se han presentado axiomáticamente en cálculo y los naturales se han estudiado en álgebra; esta lección construye los naturales *dentro de* $\mathbb R$ para enlazar ambas perspectivas.

Es tentador escribir $0,1,2,3,\ldots$ y confiar en que los puntos suspensivos determinan por sí solos todo el conjunto. Sin embargo, una definición matemática precisa debe establecer la **propiedad que identifica todos sus elementos**. La solución será una condición de estabilidad: una vez que un conjunto contiene cierto número, también contiene su sucesor obtenido al sumar uno.

La convención de la asignatura es

$$\boxed{0\in\mathbb N.}$$

El profesor advierte que existen convenciones que comienzan los naturales en $1$; aquí se adopta $0$ de manera coherente con la definición de conjunto inductivo.

### Conjuntos inductivos

#### Una definición mediante dos propiedades afirmativas
**En la cátedra (18:49–21:15).** Sea $A\subseteq\mathbb R$. El conjunto $A$ es **inductivo** cuando posee simultáneamente las propiedades

$$
\boxed{
\begin{cases}
0\in A,\\[3pt]
(\forall x\in A)\quad x+1\in A.
\end{cases}}
$$

La primera determina el punto inicial de la construcción. La segunda expresa la **clausura por el sucesor** $S(x)=x+1$. La segunda condición es una afirmación cuantificada sobre todos los elementos de $A$: si se ha incluido $x$, se incluye también $x+1$.

La definición es aplicable a subconjuntos muy distintos de $\mathbb R$. Por ejemplo, un intervalo o una unión de intervalos pueden satisfacerla. Su contenido consiste en la presencia de $0$ y la invariancia de la pertenencia bajo el avance en una unidad.

#### Una familia de ejemplos progresivamente más pequeña
**En la cátedra (21:15–30:21).** Primero, $\mathbb R$ es inductivo: contiene $0$ y la suma de dos reales sigue siendo real. También lo es $[0,\infty)$: contiene $0$ y, si $x\geq0$, entonces $x+1\geq1>0$. En cambio, el intervalo $[1,\infty)$ cumple la condición del sucesor, pero **la condición inicial falla**, pues $0$ queda fuera de él.

El profesor da un paso adicional y considera

$$A_1=\{0\}\cup[1,\infty).$$

Este conjunto sí es inductivo: para $x=0$ se tiene $x+1=1\in A_1$; para $x\geq1$ se obtiene $x+1\geq2$, también en $A_1$. El conjunto $\{0\}$, por sí solo, ilustra el papel de la clausura: contiene el punto inicial, pero el sucesor de $0$ es $1$, que debe agregarse.

![Tres conjuntos inductivos contenidos unos en otros](figuras/IC2021_Catedra_8_2/01_inductivos_encajados.png)

La reducción puede continuar:

$$
A_4=\{0,1,2,3\}\cup[4,\infty)
$$

es inductivo. Sus primeros puntos $0,1,2,3$ llevan sucesivamente al siguiente, mientras que el intervalo $[4,\infty)$ permanece estable por suma de $1$. En esta construcción se aprecian dos regiones: puntos aislados al comienzo y una cola continua que permite seguir avanzando.

![Un inductivo con elementos aislados y una cola continua](figuras/IC2021_Catedra_8_2/02_inductivo_finito.png)

El ejemplo sirve para imaginar el procedimiento de **reducir conjuntos inductivos conservando sus dos propiedades**. San Martín utiliza la imagen de un árbol que pierde hojas: quedarán los puntos que toda construcción inductiva debe contener.

### Definición de los naturales por intersección

#### La familia de todos los conjuntos inductivos
**En la cátedra (30:21–32:40).** Introducimos la colección

$$
\mathcal I=\{A\subseteq\mathbb R:\ 0\in A\ \text{y}\ (\forall x\in A)\ x+1\in A\}.
$$

Esta colección tiene elementos: por ejemplo, $\mathbb R\in\mathcal I$. El **conjunto de los números naturales** se define como la intersección de esta familia:

$$
\boxed{\mathbb N=\bigcap_{A\in\mathcal I}A.}
$$

Para decidir si $x$ es natural, la expresión puede leerse de manera completamente explícita:

$$x\in\mathbb N\quad\Longleftrightarrow\quad
(\forall A\in\mathcal I)\ x\in A.$$

Aquí se reúnen dos ideas de álgebra: una **intersección arbitraria** y un **cuantificador universal**. Un elemento de la intersección pertenece a cada conjunto de la familia, independientemente de cuántos conjuntos haya. La definición reúne, por tanto, los reales cuya pertenencia está exigida por toda construcción inductiva posible.

![Esquema de conjuntos inductivos anidados e intersección](figuras/IC2021_Catedra_8_2/03_interseccion.png)

#### Teorema: $\mathbb N$ es inductivo
**Demostración desarrollada de la cátedra (32:40–41:18).** La dificultad de una intersección arbitraria consiste en determinar cuáles propiedades sobreviven a la operación. En este caso sobreviven las dos propiedades constitutivas.

**Primera propiedad.** Cada $A\in\mathcal I$ contiene a $0$, por definición de inductivo. En consecuencia,

$$0\in\bigcap_{A\in\mathcal I}A=\mathbb N.$$

**Segunda propiedad.** Sea $n\in\mathbb N$. Por la definición de intersección, $n\in A$ para todo $A\in\mathcal I$. Como cada $A$ es inductivo, $n+1\in A$ para todo $A\in\mathcal I$. Por tanto,

$$n+1\in\bigcap_{A\in\mathcal I}A=\mathbb N.$$

Hemos verificado exactamente las condiciones de la definición. Así,

$$\boxed{\mathbb N\text{ es un subconjunto inductivo de }\mathbb R.}$$

El teorema justifica en particular que $\mathbb N$ contiene a $0$ y que el sucesor de cualquier natural es nuevamente natural, con independencia del tamaño de ese natural.

#### La propiedad de minimalidad
**En la cátedra (41:43–44:18).** Como $\mathbb N$ es la intersección de todos los conjuntos inductivos, para cada $A\in\mathcal I$ se tiene $\mathbb N\subseteq A$. Combinando esto con el teorema anterior se obtiene la caracterización:

$$\boxed{\mathbb N\text{ es el menor subconjunto inductivo de }\mathbb R
\text{ respecto de la inclusión}.}$$

Más concretamente, si un conjunto $A$ es inductivo y además $A\subseteq\mathbb N$, entonces

$$\mathbb N\subseteq A\subseteq\mathbb N,
\qquad\text{de donde}\qquad A=\mathbb N.$$

Esta sencilla observación será el motor de la inducción matemática.

### El principio de inducción como teorema

#### El conjunto de los casos verdaderos
**En la cátedra (44:20–49:11).** Consideremos una proposición $P(n)$, formulada para cada natural $n$. Nuestro propósito es demostrar que la proposición es verdadera **para todo** natural. Construimos el conjunto

$$A_P=\{n\in\mathbb N:P(n)\text{ es verdadera}\}.$$

Por construcción, $A_P\subseteq\mathbb N$. La minimalidad obtenida anteriormente reduce el problema a verificar que $A_P$ es inductivo. Esto exige precisamente:

1. **Caso base:** la afirmación $P(0)$ es verdadera, de modo que $0\in A_P$.
2. **Paso inductivo:** para cada $n\in\mathbb N$, la verdad de $P(n)$ implica la verdad de $P(n+1)$, de modo que $n\in A_P$ lleva a $n+1\in A_P$.

Entonces $A_P$ es inductivo, y su inclusión en $\mathbb N$ obliga a la igualdad. El resultado es el **principio de inducción**:

$$
\boxed{\left(P(0)\ \land\ (\forall n\in\mathbb N)(P(n)\Rightarrow P(n+1))\right)
\Longrightarrow (\forall n\in\mathbb N)P(n).}
$$

![Caso base, avance por sucesores y conclusión de inducción](figuras/IC2021_Catedra_8_2/04_induccion.png)

La clase muestra aquí una relación conceptual profunda: la inducción es una consecuencia directa de la **minimalidad de los naturales**. El profesor la enlaza con el procedimiento aprendido previamente en álgebra, pero ahora queda fundamentada dentro de la estructura de $\mathbb R$.

#### Una proposición con implicación: cuidado con el caso base
**Demostración desarrollada de la cátedra (54:28–1:02:33).** San Martín selecciona, de una lista de propiedades, la proposición

$$P(n):\qquad n>0\Longrightarrow n\geq1.$$

Para $n=0$, el caso base es la proposición completa

$$P(0):\qquad (0>0)\Longrightarrow(0\geq1).$$

Su antecedente es falso; por la definición de implicación material, **la implicación entera es verdadera**. El profesor insiste en el papel de la estructura lógica: el caso base afirma $P(0)$, no cada una de las dos desigualdades que contiene por separado.

Para el paso inductivo, la fórmula que debe verificarse es

$$\bigl(n>0\Rightarrow n\geq1\bigr)\Longrightarrow
\bigl(n+1>0\Rightarrow n+1\geq1\bigr).$$

La conclusión interna $n+1\geq1$ equivale a $n\geq0$. La clase utiliza aquí la propiedad anterior, enunciada sin prueba en la pizarra, que dice que **todo natural es mayor o igual a cero**. Por lo tanto, $P(n+1)$ es verdadera y el paso queda demostrado. Este ejemplo pone de relieve que una inducción puede demostrar proposiciones que contienen conectivos y cuantificadores; es indispensable identificar la fórmula completa $P(n)$.

#### Propiedades elementales enunciadas en la cátedra
**En la cátedra (49:25–54:28).** El profesor enumera estas propiedades, y reserva la demostración detallada para la segunda de ellas:

| Propiedad | Enunciado |
|:---|:---|
| Positividad | $n\in\mathbb N\Rightarrow n\geq0$. |
| Primer sucesor positivo | $n\in\mathbb N,\ n>0\Rightarrow n\geq1$. |
| Separación | $m,n\in\mathbb N,\ n>m\Rightarrow n\geq m+1$. |
| Clausura | $m,n\in\mathbb N\Rightarrow m+n\in\mathbb N$ y $mn\in\mathbb N$. |
| Predecesor | $n\in\mathbb N,\ n>0\Rightarrow n-1\in\mathbb N$. |

Estas propiedades sustentan los argumentos posteriores relativos a enteros consecutivos y a la parte entera. Las verificaciones completas que siguen se presentan como **ampliación editorial**, puesto que la clase propone la mayoría como trabajo independiente.

#### Ampliación editorial: pruebas de las propiedades restantes
**Positividad.** El conjunto $[0,\infty)$ es inductivo. Por minimalidad, $\mathbb N\subseteq[0,\infty)$; por consiguiente, $n\geq0$ para cada natural $n$.

**Predecesor.** La proposición $Q(n)$ dice: «$n=0$ o existe $m\in\mathbb N$ con $n=m+1$». Para $n=0$ se cumple la primera alternativa. Si $n\in\mathbb N$, su sucesor $n+1$ se escribe como sucesor del natural $n$, por lo que $Q(n+1)$ es cierta. Por inducción, todo natural positivo tiene predecesor natural.

**Separación.** Probamos por inducción sobre $m$ que, para todo $n\in\mathbb N$, si $n>m$ entonces $n\geq m+1$. El caso $m=0$ es la propiedad ya demostrada en la cátedra. Para el paso, consideremos $n>m+1$. Como $n>0$, el predecesor $n-1$ es natural y satisface $n-1>m$. Por la hipótesis inductiva, $n-1\geq m+1$ y por tanto $n\geq m+2$. Así se obtiene la propiedad para $m+1$.

**Clausura aditiva.** Fijemos $n\in\mathbb N$ y apliquemos inducción a $m$: $n+0=n$ es natural; si $n+m$ es natural, entonces $n+(m+1)=(n+m)+1$ también. **Clausura multiplicativa.** Fijado $n$, tenemos $n\cdot0=0$; si $nm\in\mathbb N$, entonces $n(m+1)=nm+n\in\mathbb N$ por la clausura de la suma. Quedan demostradas ambas propiedades.

### Los naturales y el axioma del supremo

#### Mínimo e ínfimo de $\mathbb N$
**En la cátedra (1:03:13–1:05:13).** Ya se ha demostrado $0\in\mathbb N$ y $n\geq0$ para todo $n\in\mathbb N$. El $0$ es a la vez elemento del conjunto y cota inferior suya. Por ello,

$$\boxed{\min\mathbb N=\inf\mathbb N=0.}$$

La siguiente pregunta se refiere a las cotas superiores. El resultado es esencial para vincular los naturales con la completitud de los reales.

#### Teorema: los naturales crecen más allá de cualquier real
**Demostración desarrollada de la cátedra (1:05:13–1:16:35).** Para cada $M\in\mathbb R$ existe $n\in\mathbb N$ tal que $M<n$. En símbolos,

$$\boxed{(\forall M\in\mathbb R)(\exists n\in\mathbb N)\quad M<n.}$$

**Prueba por reducción al absurdo.** Supongamos que $\mathbb N$ es acotado superiormente. Como $0\in\mathbb N$, el conjunto es no vacío y, por el **axioma del supremo**, existe $s=\sup\mathbb N$. Al ser una cota superior,

$$n\leq s\qquad(\forall n\in\mathbb N).$$

Por el carácter inductivo de los naturales, $n+1\in\mathbb N$. Aplicando la misma desigualdad a este sucesor y restando $1$, obtenemos

$$n+1\leq s\quad\Longrightarrow\quad n\leq s-1
\qquad(\forall n\in\mathbb N).$$

Así, $s-1$ también es una cota superior de $\mathbb N$. Como $s-1<s$, esto contradice que $s$ sea la **menor** cota superior. Concluimos que para todo real $M$ existe un natural mayor que $M$.

![La contradicción entre el supremo hipotético y una cota menor](figuras/IC2021_Catedra_8_2/05_cota_imposible.png)

La demostración identifica el papel preciso de la completitud: el axioma del supremo habría producido una cota superior mínima; la estabilidad por sucesor permite construir a partir de ella una cota superior todavía menor, lo que fuerza la contradicción. El profesor presenta un dibujo hipotético de dos «regiones», una de naturales y otra de cotas, para mostrar qué habría que descartar al utilizar el axioma.

### La propiedad arquimediana

#### Enunciado y significado
**En la cátedra (1:22:13–1:29:16).** La propiedad arquimediana expresa que cualquier real estrictamente positivo puede sumarse consigo mismo un número natural suficiente de veces para superar una cantidad prefijada. Una forma destacada por San Martín es

$$
\boxed{(\forall\varepsilon\in\mathbb R)(\varepsilon>0\Rightarrow
(\exists n\in\mathbb N)\ n\varepsilon>1).}
$$

La letra $\varepsilon$ designa aquí **un número real positivo cualquiera**. El profesor advierte que el hecho de que en numerosas demostraciones se elijan valores pequeños responde a la dificultad del problema, mientras que el cuantificador comprende valores positivos de todos los tamaños.

La formulación equivalente más general es

$$\boxed{(\forall\varepsilon>0)(\forall R>0)(\exists n\in\mathbb N)\ n\varepsilon>R.}$$

Basta elegir $n>R/\varepsilon$, algo garantizado por la falta de cota superior de $\mathbb N$. Para $\varepsilon=0{,}23$ y $R=1$, el natural $n=5$ produce $5\varepsilon=1{,}15>1$; para un $\varepsilon$ menor se necesitará un natural mayor.

![Suma repetida de un epsilon positivo hasta sobrepasar uno](figuras/IC2021_Catedra_8_2/06_archimedea.png)

#### Prueba por negación de cuantificadores
**Demostración desarrollada de la cátedra (1:29:16–1:33:18).** Neguemos la primera formulación. Entonces existiría un $\varepsilon>0$ tal que

$$n\varepsilon\leq1\qquad\text{para todo }n\in\mathbb N.$$

Como $\varepsilon$ es positivo, podemos dividir sin cambiar el orden:

$$n\leq\frac1\varepsilon\qquad\text{para todo }n\in\mathbb N.$$

Esto convertiría al real $1/\varepsilon$ en cota superior de $\mathbb N$, contradiciendo el teorema anterior. Así se demuestra la propiedad. San Martín insiste en la transformación correcta de los cuantificadores: la negación de «para todo $\varepsilon>0$ existe $n$» tiene la forma «existe $\varepsilon>0$ tal que para todo $n$», conservando las condiciones sobre los conjuntos donde viven las variables.

El encadenamiento lógico de la clase puede sintetizarse así:

$$\boxed{\text{Axioma del supremo}
\ \Longrightarrow\ \mathbb N\text{ sin cota superior}
\ \Longrightarrow\ \text{propiedad arquimediana}.}$$

### Enteros y separación de puntos consecutivos

#### Construcción de $\mathbb Z$
**En la cátedra (1:33:18–1:35:28).** A partir de los naturales se introduce el conjunto de los enteros:

$$\boxed{\mathbb Z=\mathbb N\cup(-\mathbb N),\qquad -\mathbb N=\{-n:n\in\mathbb N\}.}$$

Los enteros reúnen los naturales y sus opuestos. La falta de cota superior de $\mathbb N$ y la simetría por cambio de signo permiten afirmar que $\mathbb Z$ se extiende tanto hacia valores arbitrariamente positivos como arbitrariamente negativos.

![Enteros positivos y negativos con distancia unitaria entre consecutivos](figuras/IC2021_Catedra_8_2/07_enteros.png)

#### Separación de dos enteros distintos
El profesor recupera una consecuencia de la propiedad de separación de los naturales: si $k,\ell\in\mathbb Z$ y $k<\ell$, entonces

$$\boxed{\ell\geq k+1,\qquad \ell-k\geq1.}$$

Por tanto,

$$\boxed{(k,k+1)\cap\mathbb Z=\varnothing\qquad(k\in\mathbb Z).}$$

Esta propiedad es indispensable en la prueba posterior: **dos enteros distintos están separados por una distancia de al menos una unidad**. Es preciso recordar que este resultado se obtiene de las propiedades de $\mathbb N$ enunciadas al principio y de la construcción de $\mathbb Z$; las pruebas auxiliares se encuentran en la sección editorial 4.4.

### Existencia de la parte entera

#### Un problema de existencia y máximo
**En la cátedra (1:35:28–1:38:47).** Dado $x\in\mathbb R$, consideramos

$$A_x=\{k\in\mathbb Z:k\leq x\}.$$

El propósito es localizar el **mayor entero contenido en este conjunto**. Como $\mathbb Z$ se extiende hacia valores arbitrariamente negativos, $A_x$ es no vacío. Además, $x$ es cota superior de $A_x$. Por el axioma del supremo existe

$$s=\sup A_x.$$

El profesor se propone demostrar una propiedad adicional: ese supremo pertenece a $A_x$, de manera que es su máximo. Así quedará justificada la existencia de la **función parte entera**.

#### Demostración de que el supremo es entero
**Demostración desarrollada de la cátedra (1:38:47–1:44:05).** Consideremos el real $s-\tfrac12$, estrictamente menor que el supremo. Por la propiedad que caracteriza al supremo, existe $k_*\in A_x$ con

$$s-\frac12<k_*\leq s.$$

Afirmamos que $k_*$ es cota superior de $A_x$. Si hubiera $\ell\in A_x$ con $\ell>k_*$, tendríamos dos enteros distintos en el intervalo

$$s-\frac12<k_*<\ell\leq s,$$

cuya longitud es $\tfrac12$. Pero dos enteros distintos distan al menos $1$. La contradicción muestra que $k_*$ es cota superior. Como además pertenece a $A_x$, es un **máximo** del conjunto y coincide con su supremo:

$$\boxed{s=k_*=\max A_x\in\mathbb Z.}$$

Llamamos **parte entera** de $x$ a este máximo:

$$\boxed{\lfloor x\rfloor=\max\{k\in\mathbb Z:k\leq x\}.}$$

![La parte entera como máximo entero situado a la izquierda del real](figuras/IC2021_Catedra_8_2/08_parte_entera.png)

#### Caracterización fundamental
Por construcción, $\lfloor x\rfloor\leq x$. La maximalidad significa que el entero sucesor $\lfloor x\rfloor+1$ está situado estrictamente a la derecha de $x$. Así:

$$\boxed{\lfloor x\rfloor\leq x<\lfloor x\rfloor+1.}$$

La desigualdad caracteriza de manera única a la parte entera. En efecto, si dos enteros $k,\ell$ cumplieran $k\leq x<k+1$ y $\ell\leq x<\ell+1$, entonces ambos describirían el único entero situado al comienzo del intervalo unitario que contiene a $x$.

Por ejemplo, $\lfloor2{,}7\rfloor=2$. Para números negativos, la misma regla vale: $-3\leq-2{,}7<-2$, de donde $\lfloor-2{,}7\rfloor=-3$. La parte entera coincide con la función *piso* (*floor*) en la nomenclatura internacional.

### Racionales, irracionales y completitud

#### La construcción de $\mathbb Q$
**En la cátedra (1:44:07–1:46:40).** El conjunto de los racionales se presenta como el conjunto de cocientes entre un entero y un natural positivo:

$$\boxed{\mathbb Q=\left\{\frac pq:p\in\mathbb Z,\ q\in\mathbb N,\ q>0\right\}.}$$

En esta forma el signo de un racional queda recogido por el numerador. El profesor señala que $\mathbb Q$ es un **cuerpo ordenado arquimediano**. Las operaciones y el orden se heredan de $\mathbb R$, y la propiedad arquimediana se verifica también para racionales positivos. Así, si $p/q>0$ con $p,q$ enteros y $q>0$, basta tomar el natural $n=2q$ para obtener

$$n\cdot\frac pq=2p>1,$$

pues $p$ es un entero estrictamente positivo y, por tanto, $p\geq1$.

La completitud distingue a $\mathbb R$ de $\mathbb Q$. El ejemplo histórico que articula la semana 8 es $\sqrt2$: es un real cuya existencia se puede obtener por el axioma del supremo, mientras que la prueba de su irracionalidad permite concluir que no pertenece a $\mathbb Q$. En consecuencia, los racionales admiten las operaciones de cuerpo y las propiedades de orden y arquimedianidad, pero **la propiedad de supremo para todos sus subconjuntos no vacíos acotados superiormente no se cumple dentro de $\mathbb Q$**.

Los irracionales forman el conjunto $\mathbb R\setminus\mathbb Q$.

#### Densidad: problema propuesto al cerrar la clase
**Indicación del profesor (1:46:41–1:47:23).** La clase termina invitando a estudiar en el apunte la **densidad de los racionales y de los irracionales en $\mathbb R$**. Sus enunciados son:

$$\boxed{a<b\Longrightarrow(\exists q\in\mathbb Q)\ a<q<b}$$

$$\boxed{a<b\Longrightarrow(\exists r\in\mathbb R\setminus\mathbb Q)\ a<r<b.}$$

![Entre dos números reales aparecen racionales e irracionales](figuras/IC2021_Catedra_8_2/09_densidad.png)

**Ampliación editorial: prueba de densidad racional.** Sean $a<b$. Por arquimedianidad existe $n\in\mathbb N$, $n>0$, tal que $n(b-a)>1$. Por la existencia de parte entera, el entero $k=\lfloor na\rfloor+1$ satisface

$$na<k\leq na+1<nb.$$

Dividiendo por $n>0$, obtenemos $a<k/n<b$, con $k/n\in\mathbb Q$.

**Ampliación editorial: prueba de densidad irracional.** Ya se conoce un irracional concreto, $\sqrt2$. Aplicando la densidad racional al intervalo $(a-\sqrt2,b-\sqrt2)$, existe $q\in\mathbb Q$ que satisface

$$a-\sqrt2<q<b-\sqrt2.$$

Por tanto, $r=q+\sqrt2$ cumple $a<r<b$ y es irracional: si fuese racional, también $\sqrt2=r-q$ sería racional. Así queda demostrado el segundo enunciado.

**Observación de fidelidad.** Al final de la grabación aparece una formulación oral o de transcripción sobre la pertenencia de $\sqrt2$ a los racionales que contradice lo explicado durante la semana. Los argumentos matemáticos coherentes son $\sqrt2\in\mathbb R$ y $\sqrt2\notin\mathbb Q$; esta edición señala la discrepancia y conserva esa distinción.

### Mapa lógico para continuar el curso

La Cátedra 8.2 está organizada en torno a una cadena de dependencias matemáticas que conviene conservar durante las siguientes semanas:

$$
\begin{gathered}
\text{Conjuntos inductivos}\ \longrightarrow\
\mathbb N\text{ mínimo inductivo}\ \longrightarrow\
\text{Inducción}\cr
\mathbb N\text{ inductivo}+\text{axioma del supremo}
\ \longrightarrow\ \mathbb N\text{ no acotado superiormente}\cr
\longrightarrow\ \text{propiedad arquimediana}
\ \longrightarrow\ \mathbb Z,\ \lfloor x\rfloor,\ \mathbb Q.
\end{gathered}
$$

La novedad esencial es que una construcción por **intersección de conjuntos** conduce a un principio de prueba para proposiciones, y este principio combinado con la completitud permite obtener hechos básicos de la recta real. En particular, la parte entera, que se utilizaba intuitivamente desde las primeras clases, queda ahora fundada como el máximo de un conjunto de enteros.

**Continuación en el curso.** El profesor anuncia que la clase 9.1 comenzará el estudio de las **sucesiones**, para el que se utilizarán continuamente los naturales, la inducción y la propiedad arquimediana. La densidad de racionales e irracionales queda sugerida como lectura y se desarrolla en esta edición únicamente en la sección editorial 9.2 y en los problemas 21–22.

### Taller de problemas y soluciones

Los ejercicios se presentan a continuación según la fuente de origen; las ampliaciones editoriales de cada apuntes permanecen expresamente identificadas.

#### Banco de problemas complementarios resueltos — cátedra 8.2

> **Ampliación editorial.** Los veinte problemas siguientes fueron redactados y resueltos para estudiar autónomamente la materia. Las soluciones son adicionales a la grabación y se apoyan en las definiciones, teoremas y pruebas anteriores.

#### Problema 1. Reconocer dos conjuntos inductivos
Demuestra que $\mathbb R$ y $[0,\infty)$ son inductivos.

**Solución.** $0$ pertenece a ambos. Para $x\in\mathbb R$, $x+1\in\mathbb R$ por clausura de la suma. Para $x\in[0,\infty)$, $x+1\geq1>0$, luego $x+1\in[0,\infty)$. Ambos cumplen las dos condiciones.

#### Problema 2. Un conjunto con una laguna
Determina si $B=\{0\}\cup[2,\infty)$ es inductivo.

**Solución.** $0\in B$. Sin embargo, el sucesor de $0$ es $1$ y $1\notin B$. La condición de sucesor muestra que $B$ falla la segunda propiedad.

#### Problema 3. Una unión inductiva
Comprueba que $C=\{0\}\cup[1,\infty)$ es inductivo.

**Solución.** El cero pertenece a $C$. Si $x=0$, su sucesor es $1\in C$; si $x\geq1$, entonces $x+1\geq2\in[1,\infty)\subseteq C$. El conjunto es inductivo.

#### Problema 4. Una cola continua precedida por puntos aislados
Comprueba que $D=\{0,1,2,3\}\cup[4,\infty)$ es inductivo.

**Solución.** El sucesor de $0,1,2,3$ pertenece al conjunto en cada caso; en particular, $3+1=4$ pertenece a la cola. Si $x\geq4$, entonces $x+1\geq5$ y permanece en ella. Como $0\in D$, se verifican ambas propiedades.

#### Problema 5. Intersección de inductivos
Sea $(A_i)_{i\in I}$ una familia no vacía de subconjuntos inductivos de $\mathbb R$. Demuestra que $\bigcap_{i\in I}A_i$ es inductivo.

**Solución.** Cada $A_i$ contiene a $0$, luego $0$ pertenece a la intersección. Si $x$ pertenece a la intersección, entonces pertenece a cada $A_i$, y de la clausura por sucesor se sigue que $x+1$ pertenece a cada $A_i$. Por ello, $x+1$ pertenece también a la intersección.

#### Problema 6. Minimalidad de los naturales
Si $A$ es inductivo y $A\subseteq\mathbb N$, demuestra que $A=\mathbb N$.

**Solución.** Por la definición de $\mathbb N$ como intersección de todos los inductivos, $\mathbb N\subseteq A$. La hipótesis aporta $A\subseteq\mathbb N$. La doble inclusión implica $A=\mathbb N$.

#### Problema 7. Una inducción con fórmula de suma
Demuestra para todo $n\in\mathbb N$:

$$\sum_{j=0}^{n}j=\frac{n(n+1)}{2}.$$

**Solución.** Para $n=0$ ambos lados son $0$. Supongamos la igualdad para $n$. Entonces

$$\sum_{j=0}^{n+1}j=\frac{n(n+1)}2+(n+1)=\frac{(n+1)(n+2)}2,$$

que es exactamente la fórmula con $n+1$.

#### Problema 8. La suma de cuadrados
Demuestra que $\sum_{j=0}^{n}j^2=n(n+1)(2n+1)/6$.

**Solución.** La identidad vale para $n=0$. Si vale para $n$, al agregar $(n+1)^2$ obtenemos

$$\begin{aligned}
\sum_{j=0}^{n+1}j^2
&=\frac{n(n+1)(2n+1)}6+(n+1)^2\\
&=\frac{(n+1)(2n^2+7n+6)}6\\
&=\frac{(n+1)(n+2)(2n+3)}6,
\end{aligned}$$

la fórmula correspondiente al sucesor.

#### Problema 9. Positividad de los naturales
Deduce $n\geq0$ para todo $n\in\mathbb N$ a partir de la definición por intersección.

**Solución.** $[0,\infty)$ es inductivo y $\mathbb N$ se incluye en cada inductivo. Luego $\mathbb N\subseteq[0,\infty)$, que es precisamente la afirmación.

#### Problema 10. Un natural positivo es al menos uno
Demuestra por inducción que $n>0$ implica $n\geq1$ para todo natural $n$.

**Solución.** La proposición para $n=0$ es $(0>0)\Rightarrow(0\geq1)$, verdadera por el antecedente falso. Si $n\in\mathbb N$, la positividad ya demostrada da $n\geq0$, luego $n+1\geq1$. Por ello el consecuente de $P(n+1)$ es verdadero. Se cumple la inducción.

#### Problema 11. Existencia del predecesor natural
Demuestra que para todo $n\in\mathbb N$, si $n>0$, entonces $n-1\in\mathbb N$.

**Solución.** Inducimos sobre la afirmación $P(n)$: «$n=0$ o $n-1\in\mathbb N$». Para $n=0$ vale la primera alternativa. Dado un natural $n$, la proposición $P(n+1)$ se cumple porque $(n+1)-1=n\in\mathbb N$. Concluimos que cada natural positivo tiene predecesor natural.

#### Problema 12. Separación entre naturales
Demuestra que si $n,m\in\mathbb N$ y $n>m$, entonces $n\geq m+1$.

**Solución.** Para $m=0$ aplica el problema 10. Supongamos el enunciado para $m$ y sea $n>m+1$. El natural $n$ es positivo y su predecesor $n-1$ es natural por el problema 11. Como $n-1>m$, la hipótesis inductiva da $n-1\geq m+1$; por consiguiente, $n\geq m+2$. La afirmación queda probada para $m+1$.

#### Problema 13. Clausura de suma y producto
Demuestra que $n+m$ y $nm$ son naturales cuando $m,n$ son naturales.

**Solución.** Fijemos $n$. Para la suma, el caso $m=0$ devuelve $n$; el paso inductivo añade $1$ al resultado natural $n+m$. Para el producto, el caso $m=0$ produce $0$; el paso utiliza $n(m+1)=nm+n$ y la clausura aditiva recién obtenida. De este modo ambas operaciones permanecen en $\mathbb N$.

#### Problema 14. Contradicción con un supremo hipotético
Explica por qué $s-1$ sería una cota superior de $\mathbb N$ si $s=\sup\mathbb N$ existiera.

**Solución.** Para todo natural $n$, también $n+1$ es natural. La hipótesis de que $s$ es cota superior impone $n+1\leq s$, así que $n\leq s-1$. Este último número domina todos los naturales y es estrictamente menor que $s$, contradiciendo su minimalidad como cota.

#### Problema 15. Un épsilon explícito
Para $\varepsilon=0{,}07$, encuentra el menor natural $n$ que satisface $n\varepsilon>1$.

**Solución.** La desigualdad equivale a $n>100/7\approx14{,}2857$. El menor natural que la satisface es $n=15$: $14\cdot0{,}07=0{,}98\leq1$ y $15\cdot0{,}07=1{,}05>1$.

#### Problema 16. Amplitud arquimediana arbitraria
Demuestra que dados $\varepsilon>0$ y $R>0$ existe $n\in\mathbb N$ con $n\varepsilon>R$.

**Solución.** $R/\varepsilon$ es un real. Como $\mathbb N$ no es acotado superiormente, existe $n\in\mathbb N$ con $n>R/\varepsilon$. Multiplicando por $\varepsilon>0$ obtenemos $n\varepsilon>R$.

#### Problema 17. Los enteros se extienden en ambas direcciones
Demuestra que para todo $M\in\mathbb R$ existen $k,\ell\in\mathbb Z$ con $k<M<\ell$.

**Solución.** El teorema de la sección 5 proporciona un natural $\ell>M$. Aplicado al real $-M$, proporciona un natural $n>-M$. Su opuesto $k=-n$ pertenece a $\mathbb Z$ y satisface $k<M$. Por tanto, los enteros sobrepasan cualquier real en ambas direcciones.

#### Problema 18. Parte entera de números positivos y negativos
Calcula $\lfloor3{,}8\rfloor$, $\lfloor-2{,}7\rfloor$ y $\lfloor-3\rfloor$.

**Solución.** Como $3\leq3{,}8<4$, la primera es $3$. Como $-3\leq-2{,}7<-2$, la segunda es $-3$. Finalmente, $-3\leq-3<-2$ y la última vale $-3$. El criterio es siempre $k\leq x<k+1$.

#### Problema 19. Traslación de la parte entera
Demuestra que para todo $x\in\mathbb R$ y $m\in\mathbb Z$, $\lfloor x+m\rfloor=\lfloor x\rfloor+m$.

**Solución.** Sea $k=\lfloor x\rfloor$. Se tiene $k\leq x<k+1$. Sumando el entero $m$, obtenemos $k+m\leq x+m<(k+m)+1$. La caracterización de la parte entera demuestra que $\lfloor x+m\rfloor=k+m$.

#### Problema 20. La parte fraccionaria
Define $\{x\}=x-\lfloor x\rfloor$. Demuestra $0\leq\{x\}<1$ y calcula $\{-2{,}7\}$.

**Solución.** Restamos $\lfloor x\rfloor$ a los tres términos de $\lfloor x\rfloor\leq x<\lfloor x\rfloor+1$. El resultado es $0\leq x-\lfloor x\rfloor<1$. Como $\lfloor-2{,}7\rfloor=-3$, tenemos $\{-2{,}7\}=-2{,}7+3=0{,}3$.

#### Problema 21. Densidad racional e irracional
Demuestra que todo intervalo abierto $(a,b)$ con $a<b$ contiene un racional y un irracional.

**Solución.** Elige por arquimedianidad $n\in\mathbb N$ tal que $n(b-a)>1$. Para $k=\lfloor na\rfloor+1$, se tiene $na<k\leq na+1<nb$. Así, $q=k/n$ es racional y está en $(a,b)$. Aplicamos la misma construcción al intervalo $(a-\sqrt2,b-\sqrt2)$ y obtenemos un racional $p$ allí. Entonces $p+\sqrt2$ pertenece a $(a,b)$ y es irracional.

#### Problema 22. Los racionales y el axioma del supremo
Justifica por qué el conjunto $E=\{q\in\mathbb Q:q\geq0,\ q^2<2\}$ carece de supremo en $\mathbb Q$.

**Solución.** El conjunto contiene $1$ y tiene, por ejemplo, la cota superior racional $2$. Sea $r=\sqrt2\in\mathbb R\setminus\mathbb Q$. Si existiera un supremo racional $s$ de $E$, se tendría $s\geq1$. Como $s$ y $r$ son distintos, hay dos posibilidades. Si $s<r$, por densidad racional existe $q\in\mathbb Q$ con $s<q<r$. Entonces $q\in E$, contradicción con que $s$ sea cota superior. Si $s>r$, por densidad racional existe $t\in\mathbb Q$ con $r<t<s$. Ese $t$ es cota superior racional de $E$ y menor que $s$, contradicción con la minimalidad. Por tanto, $E$ constituye un ejemplo de un conjunto racional no vacío, acotado superiormente y sin supremo dentro de $\mathbb Q$.

---

## Sucesiones y convergencia

Una sucesión es una función con dominio discreto, pero su convergencia se mide mediante cuantificadores que expresan aproximación arbitraria. Unicidad, acotación y álgebra de límites constituyen su primera teoría.

**Grabaciones de referencia:** [grabación de la cátedra 9.1](https://www.youtube.com/watch?v=OvFPirtl0yQ), [grabación de la cátedra 9.2](https://www.youtube.com/watch?v=fMkNJyhooZY).

*Procedencia de este tramo: cátedra 9.1.*

### De los números reales a las sucesiones

**En la cátedra (08:47–11:07).** La semana precedente se estudió el axioma del supremo, del que se dedujo la propiedad arquimediana de los reales. San Martín presenta ahora las sucesiones como una herramienta para expresar propiedades de aproximación y abordar problemas que, formulados directamente mediante la propiedad del supremo, resultarían más difíciles. Las semanas 9 y 10 comprenderán cuatro sesiones sobre sucesiones; esta primera se concentra en dos conceptos: qué es una sucesión y qué significa que converja.

Conviene distinguir dos planos. El **plano algebraico** permite calcular con los términos de una sucesión. El **plano analítico** permite preguntar por su comportamiento cuando el índice natural crece sin cota superior. La convergencia articula ambos planos mediante una condición cuantificada de aproximación.

### Definición y naturaleza funcional de una sucesión

#### Definición principal
**En la cátedra (11:07–14:11).** Una **sucesión real** es una función

$$
\boxed{s:\mathbb N\longrightarrow\mathbb R,
\qquad n\longmapsto s(n)=s_n.}
$$

La variable independiente es un índice natural. En este curso se mantiene la convención $\mathbb N=\{0,1,2,\ldots\}$. Para cada $n\in\mathbb N$, el real $s_n$ es el **término de índice $n$**. La sucesión es la función completa, cuyo comportamiento queda determinado por sus valores en todos los índices.

La idea se extiende a cualquier conjunto de llegada $X$ mediante una aplicación $s:\mathbb N\to X$. El curso trabaja con $X=\mathbb R$, mientras que en cursos posteriores podrán estudiarse sucesiones de puntos del plano, del espacio o de espacios más generales.

#### Salvedad acerca del dominio: términos iniciales omitidos
**En la cátedra (23:51–30:44).** San Martín adopta una convención práctica habitual en análisis: también estudia como sucesión una regla que posee valores para **todos los naturales salvo una cantidad finita de ellos**. Equivalentemente, existe $n_\ast\in\mathbb N$ a partir del cual todos los términos están definidos. Se habla entonces de una sucesión definida *eventualmente* o en una cola de los naturales.

Para precisar esta convención, puede escribirse

$$
s:\{n\in\mathbb N:n\ge n_\ast\}\longrightarrow\mathbb R.
$$

Cuando la regla solo presenta excepciones finitas, los términos restantes se pueden estudiar de manera coherente desde un índice suficientemente grande. El ejemplo clásico es

$$s_n=\frac1n,\qquad n\ge1,$$

cuyo primer término es $s_1=1$; después aparecen $s_2=1/2$, $s_3=1/3$, etcétera. La expresión también puede completarse como una función sobre toda $\mathbb N$ eligiendo arbitrariamente un valor real para $s_0$, pero el tratamiento de la clase conserva la forma $n\ge1$.

**Ejemplos contrastados en la cátedra:**

- $s_n=\sqrt{n-10}$ posee valores reales para todos los naturales $n\ge10$. Es una sucesión a partir del índice $10$.
- La fórmula $\sqrt{10-n}$ posee valores reales para $0\le n\le10$ y un conjunto finito de índices admisibles; por ello no proporciona una sucesión real infinita en la convención empleada.
- $s_n=(-1)^n$ está definida en todos los naturales. Sus valores alternan $1,-1,1,-1,\ldots$.
- La regla $\sqrt{(-1)^n}$ admite valores reales exactamente para los índices pares. La ausencia de términos en todos los índices impares impide considerarla una sucesión real eventualmente definida.

**Ampliación editorial: distinción de dominios.** Una función cuyo dominio es el conjunto de naturales pares sigue siendo, naturalmente, una función matemática; para estudiar una sucesión indexada por todos los naturales se puede volver a indexarla: $t_k=\sqrt{(-1)^{2k}}=1$. Esta reindexación produce una nueva sucesión y debe declararse expresamente. Así se preserva la diferencia entre la regla original y la nueva función.

#### Notación y estructura ordenada
**En la cátedra (14:11–23:24).** La notación característica es

$$
\boxed{(s_n)_{n\in\mathbb N}\quad\text{o, abreviadamente,}\quad(s_n).}
$$

El profesor prefiere $s,u,v,w$ para sucesiones y $n,m,k$ para índices, con subíndices en lugar de escribir $s(n)$. La exposición puede desplegar la sucesión como $(s_0,s_1,s_2,\ldots)$, que registra los valores **en su orden de aparición**.

Una sucesión y el conjunto de sus valores cumplen funciones diferentes. El conjunto imagen $\{s_n:n\in\mathbb N\}$ conserva qué valores aparecen, mientras que la función $n\mapsto s_n$ registra cuáles aparecen en cada índice y cuántas veces reaparecen. Por ejemplo,

$$
(1,2,1,2,\ldots),\qquad(2,1,2,1,\ldots)
$$

son sucesiones distintas; ambas tienen como imagen el conjunto $\{1,2\}$. Del mismo modo, $(1,1,1,\ldots)$ es una sucesión constante y su imagen es el conjunto unitario $\{1\}$. Por eso se reserva la llave para los conjuntos y se prefieren paréntesis para las sucesiones.

### Ejemplos que anticipan la convergencia

#### La sucesión alternante
**En la cátedra (28:42–30:01; 39:36–40:31).** La regla

$$s_n=(-1)^n$$

proporciona $s_{2k}=1$ y $s_{2k+1}=-1$ para todos los $k\in\mathbb N$. La gráfica muestra el movimiento alterno entre dos valores.

![Los términos de la sucesión alternante](figuras/IC2021_Catedra_9_1/01_oscilacion.png)

Más adelante esta sucesión será un ejemplo elemental de comportamiento oscilatorio que impide la convergencia a un único número real.

#### Truncamientos de decimales: $0,9$, $0,99$, $0,999$, …
**En la cátedra (31:06–33:28).** El profesor escribe primero los términos

$$
s_0=0,\quad s_1=0{,}9,\quad s_2=0{,}99,\quad
s_3=0{,}999,\quad\ldots
$$

Una fórmula que recoge exactamente este patrón es

$$
\boxed{s_n=\sum_{k=1}^{n}\frac9{10^k}=1-10^{-n},\qquad n\ge0,}
$$

interpretando la suma vacía para $n=0$ como $0$. El profesor muestra que se puede concebir $0,999\ldots$ como el número asociado al proceso de aproximación por una sucesión de decimales finitos.

![Truncamientos decimales que se aproximan a 1](figuras/IC2021_Catedra_9_1/02_nueves.png)

**Ampliación editorial.** La fórmula hace posible verificar de inmediato que $s_n\to1$, pues la distancia es $|s_n-1|=10^{-n}$. La igualdad $0{,}999\ldots=1$ adquiere así una interpretación precisa cuando la escritura decimal infinita se define como el límite de sus truncamientos. La demostración formal puede obtenerse con la definición de convergencia que se estudiará en la sección 6.

#### Aproximar $\sqrt2$ y $\pi$
**En la cátedra (33:28–36:57).** Aparece una familia de aproximaciones decimales de $\sqrt2$, comenzando por $1$, $1,4$, $1,41$, $1,414$, y otra construida a partir de los decimales de $\pi$: $3$, $3,1$, $3,14$, $3,141$, … El profesor utiliza estos ejemplos para hacer visible un número real al que se aproximan términos racionales.

**Ampliación editorial: formulación exacta.** Sea $x\ge0$ un real fijo. Definamos

$$
t_n(x)=\frac{\lfloor10^n x\rfloor}{10^n},\qquad n\in\mathbb N.
$$

Por la propiedad definitoria de la parte entera,

$$
0\le x-t_n(x)<10^{-n}.
$$

Esta desigualdad explica por qué los truncamientos racionales aproximan $x$. Para $x=\sqrt2$ se obtiene la primera familia descrita, y para $x=\pi$, la segunda. El empleo de la parte entera para expresar la regla es un desarrollo editorial de la idea mostrada en la clase.

### Representación geométrica

**En la cátedra (37:22–41:31).** Puesto que el índice siempre recorre los naturales, San Martín propone mirar directamente la **recta de los valores reales** e indicar el movimiento desde $s_0$ a $s_1$, desde $s_1$ a $s_2$, y así sucesivamente. La representación ordinaria en un plano cartesiano, con puntos $(n,s_n)$, sigue siendo correcta; el dibujo sobre la recta real enfatiza el acercamiento, la oscilación o el alejamiento de los valores.

Para la sucesión alternante el movimiento oscila de $1$ a $-1$. Para los truncamientos $1-10^{-n}$ cada nuevo término se coloca más cerca de $1$, mientras que la magnitud del salto decrece. El dibujo sugiere que existe un número real distinguido que organiza el comportamiento de los términos. La **definición de convergencia** permite caracterizar exactamente esa aproximación.

### La definición de convergencia

#### Enunciado con tres cuantificadores
**En la cátedra (41:45–49:58).** Sea $(s_n)$ una sucesión real eventualmente definida y sea $L\in\mathbb R$. Diremos que **la sucesión converge a $L$** cuando se cumple

$$
\boxed{\forall\varepsilon>0\;\exists N\in\mathbb N\;\forall n\ge N:
\quad |s_n-L|\le\varepsilon.}
\tag{C}
$$

Se escribe indistintamente

$$
(s_n)\longrightarrow L,\qquad s_n\longrightarrow L,
\qquad\lim_{n\to\infty}s_n=L.
$$

El índice $N$ se elige, cuando corresponde, suficientemente grande para que $s_n$ esté definido para cada $n\ge N$. Esta salvedad importa en el ejemplo $1/n$.

**Lectura lógica.** Para **cada** precisión positiva $\varepsilon$ existe un índice $N$ de manera que **todos** los términos con índice $n\ge N$ están a una distancia de $L$ menor o igual que esa precisión. En particular, los términos de una cola completa de la sucesión cumplen simultáneamente la misma desigualdad.

San Martín contrapone esta formulación con la condición de cota superior y la propiedad arquimediana, estudiadas previamente:

$$
\begin{aligned}
 b\text{ es cota superior de }A
 &\iff (\forall a\in A)\;a\le b,\\[3pt]
 \text{Propiedad arquimediana}
 &:\quad (\forall\varepsilon>0)(\exists N\in\mathbb N)\;\varepsilon N>1,\\[3pt]
 \text{Convergencia a }L
 &:\quad(\forall\varepsilon>0)(\exists N\in\mathbb N)
   (\forall n\ge N)\;|s_n-L|\le\varepsilon.
\end{aligned}
$$

La última condición incorpora el tercer cuantificador, encargado de que la proximidad al límite **persista** para todos los índices posteriores.

#### Convención $\le\varepsilon$ y formulación estricta
**En la cátedra.** La versión escrita por San Martín utiliza $|s_n-L|\le\varepsilon$. En otros manuales es corriente la forma $|s_n-L|<\varepsilon$. Ambas expresan la misma convergencia porque $\varepsilon$ recorre **todos** los reales positivos.

**Ampliación editorial: prueba de equivalencia.** Si se cumple la versión estricta, se cumple también la versión amplia para el mismo $\varepsilon$. A la inversa, dada una precisión $\varepsilon>0$, se aplica la versión amplia a la precisión positiva $\varepsilon/2$. Existe entonces $N$ para el que

$$|s_n-L|\le\frac\varepsilon2<\varepsilon\qquad(n\ge N).$$

Por tanto, las dos convenciones son lógicamente equivalentes. Mantendremos $\le$ en las demostraciones para reproducir la formulación de esta cátedra.

### El significado geométrico del límite

#### Distancia e intervalo de proximidad
**En la cátedra (50:33–57:32).** La desigualdad que aparece al final de (C) puede transformarse mediante las propiedades del valor absoluto:

$$
\begin{aligned}
|s_n-L|\le\varepsilon
&\iff -\varepsilon\le s_n-L\le\varepsilon\\
&\iff L-\varepsilon\le s_n\le L+\varepsilon\\
&\iff s_n\in[L-\varepsilon,L+\varepsilon].
\end{aligned}
$$

Así, la proximidad se expresa geométricamente mediante un intervalo **centrado en $L$ y de radio $\varepsilon$**. El profesor lo llama vecindad de $L$. El intervalo cerrado tiene longitud $2\varepsilon$ y representa todos los valores que satisfacen la desigualdad de la cátedra.

La definición completa afirma que, para cualquier tamaño positivo de ese intervalo, existe un lugar de la sucesión desde el cual sus términos **permanecen** dentro de él.

#### El umbral $N$ y su dependencia de $\varepsilon$
**En la cátedra (58:37–1:05:33; 1:11:13–1:15:56).** Los términos iniciales pueden encontrarse fuera del intervalo, ingresar, salir de nuevo e ingresar otra vez. Lo exigido es la existencia de un umbral $N$ a partir del cual *todos* permanecen dentro. El orden lógico es esencial:

$$
\underset{\text{precisión elegida}}{\forall\varepsilon>0}
\quad\underset{\text{umbral que podemos elegir}}{\exists N}
\quad\underset{\text{todos los índices posteriores}}{\forall n\ge N}.
$$

Si se reduce $\varepsilon$, el intervalo se estrecha y puede resultar necesario elegir un índice umbral mayor. En una sucesión constante igual a $L$ cualquier índice sirve para toda precisión, porque $|L-L|=0$.

**Precisiones editoriales:**

1. El índice umbral **puede depender de la precisión**: es frecuente escribir $N=N(\varepsilon)$. La definición exige encontrar alguno; no requiere hallar el menor.
2. Si un umbral $N$ funciona para cierta precisión, cualquier $N'\ge N$ también funciona para esa misma precisión.
3. Con la misma sucesión, un umbral que sirve para $\varepsilon_1$ también sirve para cualquier $\varepsilon_2\ge\varepsilon_1$.
4. La sucesión **puede alcanzar el límite** en uno, varios o todos sus términos. La convergencia describe distancias y permanencia, y admite la igualdad $s_n=L$.
5. El valor $\varepsilon=0$ queda fuera de (C): imponerlo pediría que todos los términos de una cola fueran exactamente $L$, propiedad más fuerte que la convergencia ordinaria.

#### Por qué se necesita el cuantificador final
**Ampliación editorial.** Consideremos $s_n=(-1)^n$. Para la precisión $\varepsilon=1/2$, las distancias a cualquier candidato $L$ no pueden ser pequeñas simultáneamente en todos los índices pares e impares suficientemente grandes. En efecto, si ambas distancias fueran $\le1/2$, tendríamos

$$
2=|1-(-1)|\le|1-L|+|L+1|\le1,
$$

una imposibilidad. La sucesión alternante, por tanto, **no converge a ningún real**.

La exigencia «hay términos arbitrariamente avanzados próximos a $L$» es distinta de la convergencia: podrían existir también términos arbitrariamente avanzados lejos de él. El último cuantificador asegura la estabilidad de **toda la cola**.

### Un procedimiento para demostrar convergencia

**En la cátedra (1:18:11–1:25:21).** San Martín comienza la práctica con un protocolo implícito que conviene explicitar:

1. **Fijar el candidato al límite.** En esta sesión, el profesor lo proporciona, pues el problema de *calcular* límites se desarrollará más adelante.
2. **Fijar un $\varepsilon>0$ arbitrario.** El objetivo consiste en satisfacer la desigualdad $|s_n-L|\le\varepsilon$.
3. **Simplificar algebraicamente la distancia** $|s_n-L|$ y traducirla a una condición más manejable sobre $n$.
4. **Elegir un índice $N$** mediante la propiedad arquimediana, la parte entera o una estimación conveniente.
5. **Volver a los cuantificadores**: verificar para cada $n\ge N$ la desigualdad pedida y concluir la convergencia.

El paso más importante es la transición desde una necesidad sobre $n$ hasta la **construcción o existencia de un umbral** que funciona uniformemente para toda la cola.

### Primer ejemplo: $1/n\longrightarrow0$

#### Demostración desarrollada mediante la propiedad arquimediana
**En la cátedra (1:18:11–1:25:21).** Consideramos

$$s_n=\frac1n,\qquad n\ge1,$$

y queremos demostrar que $s_n\to0$. Sea $\varepsilon>0$. Por la propiedad arquimediana existe $N\in\mathbb N$ tal que

$$\varepsilon N>1.$$

En particular, $N\ge1$. Para todo $n\ge N$, puesto que $\varepsilon>0$, se verifica

$$\varepsilon n\ge\varepsilon N>1.$$

Dividimos entre $n\varepsilon>0$ para obtener

$$0<\frac1n<\varepsilon.$$

Como $s_n$ es positivo, $|s_n-0|=1/n$, y por consiguiente

$$\forall n\ge N:\qquad |s_n-0|\le\varepsilon.$$

Hemos encontrado un índice $N$ para cada precisión $\varepsilon>0$, por lo que

$$\boxed{\lim_{n\to\infty}\frac1n=0.}$$

**Comentario pedagógico.** El profesor subraya cómo la propiedad arquimediana aporta dos cuantificadores y el orden $n\ge N$ permite incorporar el tercero. La clave de la demostración es la cadena $\varepsilon n\ge\varepsilon N>1$.

#### Segunda demostración desarrollada mediante la parte entera
**En la cátedra (1:25:21–1:31:10).** La condición necesaria para la prueba es

$$\frac1n\le\varepsilon\quad\iff\quad n\ge\frac1\varepsilon.$$

La recta real contiene naturales mayores que $1/\varepsilon$. Una elección explícita que sirve para todo $\varepsilon>0$ es

$$\boxed{N(\varepsilon)=\left\lfloor\frac1\varepsilon\right\rfloor+1.}$$

En efecto, la propiedad definitoria de la parte entera asegura

$$\left\lfloor\frac1\varepsilon\right\rfloor
\le\frac1\varepsilon
<\left\lfloor\frac1\varepsilon\right\rfloor+1=N(\varepsilon).$$

Luego $n\ge N(\varepsilon)$ implica $n>1/\varepsilon$, y de ahí $1/n<\varepsilon$. Esto satisface nuevamente (C).

El índice elegido es **suficiente**, aunque no tiene por qué ser el mínimo. Para $\varepsilon=10^{-3}$ la fórmula da $N=1001$, mientras que $N=1000$ también sirve con la convención $\le\varepsilon$.

![El recíproco de n entra y permanece en la banda epsilon](figuras/IC2021_Catedra_9_1/03_epsilon_uno_sobre_n.png)

**Ampliación editorial.** Otra elección válida es $N=\max\{1,\lceil1/\varepsilon\rceil\}$; corresponde al menor natural positivo que satisface $N\ge1/\varepsilon$. Ambas expresiones muestran cómo construir un testigo del cuantificador existencial.

### Segundo ejemplo: sucesión constante

**En la cátedra (1:31:13–1:33:19).** Sea $s_n=2$ para todo $n\in\mathbb N$. El candidato es $L=2$. Dado cualquier $\varepsilon>0$ y cualquier índice $N\in\mathbb N$, para todo $n\ge N$ tenemos

$$|s_n-L|=|2-2|=0\le\varepsilon.$$

Por tanto, $s_n\to2$. El mismo razonamiento permite enunciar el siguiente resultado general.

**Proposición (demostración desarrollada).** Para todo real $c$, la sucesión constante $s_n=c$ converge a $c$:

$$\boxed{\lim_{n\to\infty}c=c.}$$

Este ejemplo aclara que la definición de convergencia admite sucesiones que alcanzan su límite desde el comienzo. También exhibe un caso en el cual el umbral $N$ puede elegirse independientemente de $\varepsilon$.

### Tercer ejemplo: $\sqrt{n+1}-\sqrt n\longrightarrow0$

#### La dificultad aparente
**En la cátedra (1:33:23–1:38:15).** Consideramos

$$s_n=\sqrt{n+1}-\sqrt n,\qquad n\ge0.$$

Los dos sumandos crecen con $n$, por lo que la resta exige una transformación algebraica antes de estimar su magnitud. Multiplicamos numerador y denominador por la expresión conjugada:

$$
\begin{aligned}
\sqrt{n+1}-\sqrt n
&=\frac{(\sqrt{n+1}-\sqrt n)(\sqrt{n+1}+\sqrt n)}{\sqrt{n+1}+\sqrt n}\\[2pt]
&=\boxed{\frac1{\sqrt{n+1}+\sqrt n}}.
\end{aligned}
$$

La diferencia inicial se convierte así en el recíproco de una suma positiva y creciente.

#### «Relajación» de una desigualdad
**En la cátedra (1:38:15–1:44:45).** San Martín introduce el método que denomina **relajación**: sustituir una expresión por una cota superior algebraicamente más simple, pero suficientemente precisa para seguir siendo menor que la tolerancia deseada. Para cada $n\ge1$,

$$
0<\frac1{\sqrt{n+1}+\sqrt n}
\le\frac1{\sqrt n}.
$$

Elegimos entonces un umbral que controle $1/\sqrt n$.

**Demostración desarrollada.** Sea $\varepsilon>0$. La propiedad arquimediana aplicada al número positivo $\varepsilon^2$ proporciona $N\in\mathbb N$ tal que

$$\varepsilon^2N>1.$$

En particular $N\ge1$. Si $n\ge N$, entonces $\varepsilon^2n\ge\varepsilon^2N>1$, de donde $\sqrt n>1/\varepsilon$ y, en consecuencia,

$$
|s_n-0|=s_n
=\frac1{\sqrt{n+1}+\sqrt n}
\le\frac1{\sqrt n}<\varepsilon.
$$

Concluimos que

$$\boxed{\lim_{n\to\infty}\left(\sqrt{n+1}-\sqrt n\right)=0.}$$

![La diferencia de raíces y su cota por uno sobre raíz de n](figuras/IC2021_Catedra_9_1/04_raices.png)

**Ampliación editorial: umbral explícito.** La elección

$$
N(\varepsilon)=\left\lfloor\frac1{\varepsilon^2}\right\rfloor+1
$$

satisface $N>1/\varepsilon^2$ y permite repetir la demostración con una fórmula concreta. También puede utilizarse la cota un poco más fina

$$s_n\le\frac1{2\sqrt n}\qquad(n\ge1),$$

pues $\sqrt{n+1}\ge\sqrt n$. Esa alternativa genera un umbral más pequeño, pero el objetivo didáctico de la cátedra consiste en escoger una estimación sencilla y correcta, y cerrar con ella la prueba.

### Consecuencias de la definición: desarrollos editoriales

Las siguientes proposiciones **no se presentan como demostradas por el profesor en esta grabación**. Se incluyen para consolidar el manejo de los cuantificadores.

#### Modificar finitos términos conserva el límite
**Proposición.** Sean $(s_n)$ y $(t_n)$ sucesiones reales tales que existe $K\in\mathbb N$ con $s_n=t_n$ para todos los $n\ge K$. Si $s_n\to L$, entonces $t_n\to L$.

**Demostración.** Para $\varepsilon>0$ elegimos $N$ tal que $n\ge N$ implica $|s_n-L|\le\varepsilon$. Definimos $M=\max\{N,K\}$. Para $n\ge M$ se verifica $t_n=s_n$, y por ello $|t_n-L|=|s_n-L|\le\varepsilon$. Se cumplen los tres cuantificadores para $(t_n)$ y el mismo límite. $\square$

El resultado explica por qué el valor inicial no definido de $1/n$ resulta irrelevante para la convergencia: la propiedad se refiere a la conducta en las colas.

#### Un límite real es único
**Proposición.** Si una sucesión real converge a $L$ y también converge a $M$, entonces $L=M$.

**Demostración.** Consideremos la distancia $d=|L-M|$. Si $d>0$, elegimos $\varepsilon=d/3$. Por convergencia existen $N_L$ y $N_M$ tales que para todo $n\ge N=\max\{N_L,N_M\}$,

$$|s_n-L|\le\varepsilon,\qquad |s_n-M|\le\varepsilon.$$

Aplicando la desigualdad triangular,

$$d=|L-M|\le|L-s_n|+|s_n-M|\le2\varepsilon=\frac{2d}{3},$$

contradicción con $d>0$. En consecuencia $d=0$ y $L=M$. $\square$

#### Una sucesión puede alcanzar el límite infinitas veces
**Ejemplo editorial.** Fijado $L\in\mathbb R$, definamos para $n\ge1$

$$s_n=\begin{cases}
L,& n\text{ par},\\
L+1/n,& n\text{ impar}.
\end{cases}$$

Entonces $|s_n-L|\le1/n$. Para cada $\varepsilon>0$, elegimos $N$ como en la demostración de $1/n\to0$. Se deduce que $s_n\to L$. Todos los términos de índice par son exactamente iguales al límite, mientras que los términos de índice impar se aproximan a él. Esta construcción ilustra con precisión la respuesta del profesor a la pregunta de si una sucesión convergente puede «tocar» su límite.

#### Un método general de comparación
**Proposición editorial.** Si existen $K\in\mathbb N$ y una sucesión $(a_n)$ de números no negativos tales que

$$|s_n-L|\le a_n\quad(n\ge K),\qquad a_n\longrightarrow0,$$

entonces $s_n\to L$.

**Demostración.** Sea $\varepsilon>0$. Por la convergencia de $a_n$ a cero existe $N_1$ tal que $a_n\le\varepsilon$ para todo $n\ge N_1$. Para $n\ge\max\{K,N_1\}$ se tiene $|s_n-L|\le a_n\le\varepsilon$, como se deseaba. $\square$

La comparación formaliza la estrategia de relajación utilizada en el ejemplo de las raíces.

### Guía de comprobación para futuras demostraciones

Antes de dar por concluida una prueba de convergencia, comprobar lo siguiente:

- Se ha identificado la sucesión y el real candidato $L$.
- Se ha fijado un $\varepsilon>0$ completamente arbitrario.
- El índice $N$ es natural y garantiza que todos los términos posteriores están definidos.
- Las desigualdades utilizadas conservan su sentido y sus hipótesis de positividad.
- El índice $N$ se ha obtenido por un argumento legítimo, no solo por una intuición gráfica.
- La afirmación final se verifica para **todos** los $n\ge N$.
- Se ha distinguido claramente lo que demuestra la clase de los resultados añadidos en estas notas.

*Procedencia de este tramo: cátedra 9.2.*

### Una segunda entrada a la convergencia

**En la cátedra (14:21–17:37).** El profesor explica el carácter excepcional de la sesión: algunos alumnos habían visto una clase previa sobre sucesiones y manifestaron dificultades con su contenido. Se repite el itinerario con explicaciones más prolongadas y especial cuidado en el uso de los cuantificadores. La finalidad inmediata es convertir la definición de límite en una herramienta para demostrar teoremas. El tema dominante será el **álgebra de límites**, cuyo empleo exige conocer de antemano la convergencia de las sucesiones involucradas.

La primera cátedra, 9.1, presentó una sucesión real como una función cuyos índices recorren los naturales (o una cola de ellos) y estudió su convergencia. Esta clase parte de esa base para obtener propiedades que permitan calcular límites de sucesiones nuevas a partir de otras ya conocidas. La transición es notable: de verificar directamente una condición con tres cuantificadores se pasa a **establecer reglas de cálculo justificadas por esa misma condición**.

#### La definición recuperada
**En la cátedra (17:37–20:12).** Una sucesión real $(s_n)$ **converge** al real $L$ cuando

$$
\boxed{\forall\varepsilon>0\;\exists N\in\mathbb N\;\forall n\geq N:\quad |s_n-L|\leq\varepsilon.}
$$

Se escribe $s_n\to L$. La condición equivale a

$$
L-\varepsilon\leq s_n\leq L+\varepsilon
\qquad(n\geq N).
$$

Por cada radio $\varepsilon>0$ existe un índice $N$ a partir del cual **todos** los términos permanecen en el intervalo cerrado $[L-\varepsilon,L+\varepsilon]$. El profesor insiste en el orden de los cuantificadores: se fija primero una precisión arbitraria; entonces puede elegirse un umbral adecuado; finalmente se comprueba la propiedad para todos los índices posteriores.

Conviene apreciar el alcance lógico del término *todos*. Una sucesión puede visitar muchas veces un intervalo alrededor de $L$ y salir de él inmediatamente. La convergencia exige la **permanencia eventual** para cada radio positivo. Esa permanencia es compatible con oscilaciones, igualdades $s_n=L$ y aproximaciones por ambos lados.

#### El umbral y la precisión
**En la cátedra (20:12–28:57).** El umbral depende, en general, de la sucesión, del límite y de la precisión solicitada. Para $s_n=1/n$, con $n\geq1$, la elección

$$
N(\varepsilon)=\left\lfloor\frac1\varepsilon\right\rfloor+1
$$

es suficiente para que $1/n\leq\varepsilon$ siempre que $n\geq N(\varepsilon)$. Al exigir una distancia más pequeña, puede hacer falta avanzar más en la sucesión. Una sucesión constante $s_n=L$ satisface la condición desde el primer índice disponible: $|s_n-L|=0$ para todos sus términos y para todo $\varepsilon>0$.

El uso de $N(\varepsilon)$ como umbral es una forma de **cuantificar una velocidad de aproximación**; la convergencia por sí sola asegura la existencia de algún umbral, mientras la estimación concreta revela cuánto debe avanzarse en un ejemplo determinado.

![Esquema editorial: ingreso eventual a una vecindad de radio épsilon](figuras/IC2021_Catedra_9_2/01_vecindad_umbral.png)

*Esquema editorial.* Los puntos representan $s_n=1+1/n$, con $n\geq1$. Para $L=1$ y $\varepsilon=0{,}22$, se puede elegir $N=5$; desde entonces los términos quedan en la banda indicada. El trazado que une los puntos solo ayuda a seguir la secuencia de índices.

### Unicidad del límite

#### Teorema
**En la cátedra (28:57–30:38).** La propiedad enunciada es la siguiente:

> **Teorema (unicidad del límite).** Si una sucesión real $(s_n)$ converge a dos números reales $L_1$ y $L_2$, entonces $L_1=L_2$.

En símbolos,

$$
\boxed{(s_n\to L_1)\land(s_n\to L_2)\quad\Longrightarrow\quad L_1=L_2.}
$$

Con el teorema queda justificada la expresión **el límite** de la sucesión y la notación

$$
\lim_{n\to\infty}s_n=L.
$$

El teorema establece la unicidad del número de convergencia; la existencia de ese número depende de la sucesión concreta. La sucesión $(-1)^n$, por ejemplo, está definida para todos los naturales, pero no posee límite real.

#### Dos convergencias producen dos índices
**En la cátedra (30:38–43:40).** Sean $L_1$ y $L_2$ dos límites supuestos de la misma sucesión. Para cada $\delta>0$, la primera convergencia da un índice $N_1$ para el cual

$$
|s_n-L_1|\leq\delta\qquad(n\geq N_1),
$$

mientras que la segunda da un índice $N_2$ con

$$
|s_n-L_2|\leq\delta\qquad(n\geq N_2).
$$

Como ambas definiciones admiten **cualquier** radio positivo, se puede utilizar el mismo $\delta$ en las dos. Los índices $N_1$ y $N_2$ son testigos de propiedades distintas y se conservan identificados por separado. El umbral

$$
\boxed{N=\max\{N_1,N_2\}}
$$

permite disponer simultáneamente de ambas desigualdades para todos los $n\geq N$. Este paso, que el profesor explica con dos semirrectas de naturales, es un recurso general: **un número finito de condiciones que se cumplen eventualmente puede hacerse valer a la vez tomando el máximo de sus umbrales**.

**Corrección editorial de precisión lógica (41:32).** En la explicación oral se sugiere que, una vez establecida la igualdad de los límites, los índices testigo serían iguales. En rigor, la definición asegura la **existencia**, y cualquier índice suficientemente grande puede servir de testigo. Incluso cuando ambos límites coinciden, se pueden elegir testigos distintos. El máximo funciona tanto si los límites coinciden como si todavía se desconoce esa coincidencia; esta es la formulación que preserva la validez lógica de la demostración.

#### La desigualdad triangular
**En la cátedra (44:21–50:56).** Para números reales $a,b,c$, la desigualdad triangular adopta la forma

$$
|a-b|\leq |a-c|+|c-b|.
$$

Su significado geométrico consiste en comparar la distancia directa entre $a$ y $b$ con un recorrido que pasa por un punto intermedio $c$. La derivación algebraica parte de la identidad

$$
a-b=(a-c)+(c-b)
$$

seguida de $|x+y|\leq|x|+|y|$. Elegimos $a=L_1$, $b=L_2$ y $c=s_n$. Para $n\geq N$ se obtiene

$$
\begin{aligned}
|L_1-L_2|
&\leq|L_1-s_n|+|s_n-L_2|\\
&\leq \delta+\delta=2\delta.
\end{aligned}
$$

![Esquema editorial: desigualdad triangular y término intermedio](figuras/IC2021_Catedra_9_2/02_distancias_triangulo.png)

*Esquema editorial.* Las posiciones dibujadas son ilustrativas. El razonamiento se aplica con cualquier orden relativo de $L_1$, $s_n$ y $L_2$ en la recta real.

#### Conclusión mediante el ínfimo
**Demostración desarrollada (50:56–57:36).** Para cada $\delta>0$, la estimación anterior vale con un umbral adecuado, pero $|L_1-L_2|$ es una cantidad fija, independiente de $n$ y de $\delta$. Por tanto,

$$
0\leq \frac{|L_1-L_2|}{2}\leq\delta
\qquad\text{para todo }\delta>0.
$$

La cantidad central es una **cota inferior** del conjunto $\mathbb R_{>0}=(0,\infty)$. Por la propiedad del ínfimo,

$$
\frac{|L_1-L_2|}{2}\leq \inf(0,\infty)=0.
$$

Combinando ambas desigualdades, $|L_1-L_2|=0$, y entonces $L_1=L_2$. Esto demuestra el teorema.

**Ampliación editorial (prueba directa con el radio).** Dado un $\varepsilon>0$, aplicar ambas convergencias con $\delta=\varepsilon/2$. Para $n\geq\max\{N_1,N_2\}$,

$$
|L_1-L_2|\leq 2\delta=\varepsilon.
$$

Una cantidad real no negativa que resulta menor o igual que todo número real positivo vale cero. Esta lectura proporciona una formulación condensada del mismo argumento que el profesor desarrolla mediante las cotas y el ínfimo.

**Observación editorial.** La desigualdad triangular y el máximo de índices tienen un papel estructural: aparecerán de nuevo en la prueba de la suma de sucesiones nulas. La estrategia consiste en transformar estimaciones individuales en una estimación conjunta y, después, elegir adecuadamente los márgenes de error.

### Álgebra de límites: enunciado y condiciones de uso

**En la cátedra (57:47–1:04:55).** El docente enuncia el teorema que permitirá calcular muchos límites mediante operaciones algebraicas. Si

$$
a_n\longrightarrow A,\qquad b_n\longrightarrow B,
$$

entonces las sucesiones $a_n+b_n$, $a_n-b_n$ y $a_nb_n$ convergen, respectivamente, a $A+B$, $A-B$ y $AB$. Si además $B\neq0$, el cociente $a_n/b_n$ está eventualmente definido y converge a $A/B$:

$$
\boxed{
\begin{aligned}
\lim(a_n+b_n)&=A+B,\\
\lim(a_n-b_n)&=A-B,\\
\lim(a_nb_n)&=AB,\\
\lim\frac{a_n}{b_n}&=\frac AB\qquad(B\neq0).
\end{aligned}}
$$

Las igualdades suponen **convergencia previa de las dos sucesiones originales**. El profesor recalca esta hipótesis porque una aplicación formal sin ella puede llevar a conclusiones incorrectas. La prueba completa del teorema se anuncia como objetivo; en la clase se establecen las herramientas de las sucesiones nulas y acotadas y se realiza una discusión parcial del cociente, especialmente en el intercambio final con los estudiantes. Una demostración integral, identificada como editorial, aparece más adelante en estas notas.

#### Un producto que revela la necesidad de las hipótesis
**En la cátedra (1:00:01–1:02:20).** El ejemplo es

$$
a_n=n,\qquad b_n=\frac1n\quad(n\geq1).
$$

La primera sucesión crece sin cota superior y carece de límite real; la segunda converge a cero. En consecuencia, el teorema del producto **carece de hipótesis suficientes** en esta situación. Se puede estudiar el producto directamente:

$$
a_nb_n=n\frac1n=1\qquad(n\geq1).
$$

El producto es una sucesión constante y converge a $1$. Este ejemplo obliga a distinguir la identidad algebraica que describe el término del uso legítimo de un teorema de límites.

#### Una reorganización útil: si $na_n$ converge
**En la cátedra (1:02:38–1:04:08).** Se plantea el siguiente ejercicio: si $na_n\to L$, ¿qué puede afirmarse sobre $(a_n)$? Para $n\geq1$,

$$
a_n=(na_n)\frac1n.
$$

Las sucesiones del producto del lado derecho sí convergen: la primera por hipótesis y la segunda a cero por la cátedra 9.1. Por tanto, mediante la regla del producto,

$$
\boxed{a_n\longrightarrow L\cdot0=0.}
$$

Aquí se aplica el teorema a factores cuya convergencia está efectivamente acreditada. El caso ilustra una regla metodológica más general: antes de calcular el límite, reescribir la expresión para identificar los objetos a los que corresponden las hipótesis conocidas.

### Sucesiones nulas y acotadas

#### Definición de sucesión nula
**En la cátedra (1:05:28–1:07:49).** Una sucesión real $(a_n)$ se llama **nula** cuando converge a cero:

$$
\boxed{(a_n)\text{ es nula}\quad\Longleftrightarrow\quad a_n\to0.}
$$

La definición también puede escribirse mediante cuantificadores:

$$
\forall\varepsilon>0\;\exists N\in\mathbb N\;
\forall n\geq N:\ |a_n|\leq\varepsilon.
$$

Ejemplos tratados por el profesor son $a_n=1/n$ para $n\geq1$ y la sucesión constante $a_n=0$. Ambos casos satisfacen exactamente la misma definición. El primero tiene términos positivos que se aproximan a cero; el segundo vale cero en cada índice. Esta comparación prepara la comprensión de los límites de funciones y de las asíntotas horizontales.

#### Definición de sucesión acotada
**En la cátedra (1:07:49–1:11:43).** Una sucesión $(b_n)$ es **acotada** cuando existe un real $M\geq0$ tal que

$$
\boxed{\forall n:\quad |b_n|\leq M.}
$$

La doble desigualdad $-M\leq b_n\leq M$ expresa simultáneamente la acotación inferior y superior. En particular, el conjunto de sus valores está contenido en el intervalo $[-M,M]$. Se estudiarán también sucesiones que comienzan en un índice $n_\ast$: el cuantificador recorre entonces todos los índices de su dominio.

La clase considera ejemplos como

$$
b_n=\frac{n}{n+1},\qquad0\leq b_n<1,
$$

para $n\geq0$, y

$$
c_n=(-1)^n,\qquad |c_n|=1.
$$

Ambas son acotadas. La segunda exhibe una alternancia perpetua entre $1$ y $-1$, por lo que su acotación, por sí sola, permite un comportamiento muy distinto del de una sucesión nula.

**Precisión de la cátedra sobre las cotas (1:10:31–1:11:41).** El profesor adopta $M\geq0$, pues la sucesión identicamente nula tiene como **menor cota posible del valor absoluto** el número $M=0$. También podría utilizarse una cota estrictamente positiva para caracterizar la existencia de alguna cota; sin embargo, la elección $M\geq0$ permite conservar exactamente la menor cota cuando se alcanza cero.

![Esquema editorial: nula y acotada frente a acotada no nula](figuras/IC2021_Catedra_9_2/03_nula_acotada.png)

*Esquema editorial.* Las sucesiones $1/n$ y $(-1)^n$ son acotadas; solo la primera converge a cero. El gráfico refuerza la diferencia entre contener los términos en un intervalo fijo y aproximarlos a un punto con precisión arbitraria.

### Teorema de las sucesiones nulas y acotadas

**En la cátedra (1:11:43–1:26:09).** El profesor presenta un conjunto de cuatro propiedades que sirven como herramientas para demostrar el álgebra de límites. Su organización conceptual es la siguiente.

> **Teorema (nulas y acotadas).** Para sucesiones reales eventualmente definidas:
>
> 1. La suma y el producto de dos sucesiones nulas son sucesiones nulas.
> 2. La suma y el producto de dos sucesiones acotadas son sucesiones acotadas.
> 3. Toda sucesión nula es acotada.
> 4. El producto de una sucesión nula por una sucesión acotada es una sucesión nula.

Las proposiciones son correctas y su orden responde a las necesidades de la clase. La tercera hace posible tratar las nulas como un caso particular de las acotadas. La cuarta permite controlar productos incluso cuando el factor acotado tiene un comportamiento oscilante y carece de límite.

#### Suma de sucesiones nulas: demostración realizada en clase
**Demostración desarrollada (1:26:09–1:39:26).** Sean $a_n\to0$ y $b_n\to0$. Deseamos probar que $a_n+b_n\to0$. Dado $\varepsilon>0$, elegimos el **radio auxiliar** $\delta=\varepsilon/2>0$.

Por la convergencia de $(a_n)$ existe $N_1$ con

$$
|a_n|\leq\frac\varepsilon2\qquad(n\geq N_1).
$$

Por la convergencia de $(b_n)$ existe $N_2$ con

$$
|b_n|\leq\frac\varepsilon2\qquad(n\geq N_2).
$$

Definimos $N=\max\{N_1,N_2\}$. Para todo $n\geq N$, la desigualdad triangular proporciona

$$
\begin{aligned}
|(a_n+b_n)-0|
&\leq |a_n|+|b_n|\\
&\leq\frac\varepsilon2+\frac\varepsilon2=\varepsilon.
\end{aligned}
$$

La definición de convergencia muestra que $a_n+b_n\to0$. **Queda demostrada** la propiedad de la suma.

**En la cátedra: elección flexible del error (1:34:34–1:39:04).** Se examinan diferentes radios auxiliares. Se pueden usar, por ejemplo, $\varepsilon/5$ en ambos factores: entonces $|a_n+b_n|\leq2\varepsilon/5\leq\varepsilon$. También se puede distribuir el presupuesto total en dos porciones positivas $\alpha\varepsilon$ y $(1-\alpha)\varepsilon$, con $0<\alpha<1$. La elección simétrica $\varepsilon/2$ es cómoda porque su suma vale exactamente $\varepsilon$. El recurso es general: **anticipar cómo se combinarán las cotas y elegir desde el comienzo las precisiones necesarias**.

#### Producto de dos nulas
**En la cátedra (1:39:28–1:41:15).** El profesor esboza la prueba y propone escoger $\sqrt\varepsilon$ como radio auxiliar, pues al multiplicar dos estimaciones se obtiene el error solicitado. La demostración completa queda para el estudiante.

**Ampliación editorial (demostración).** Dado $\varepsilon>0$, el número $\sqrt\varepsilon$ es real y positivo. Por nulidad de ambas sucesiones existen $N_1,N_2$ tales que, para todo $n\geq N=\max\{N_1,N_2\}$,

$$
|a_n|\leq\sqrt\varepsilon,
\qquad |b_n|\leq\sqrt\varepsilon.
$$

En ese rango,

$$
|a_nb_n|=|a_n|\,|b_n|
\leq\sqrt\varepsilon\sqrt\varepsilon
=\varepsilon.
$$

Se concluye $a_nb_n\to0$. Otra opción es probar primero que una sucesión nula es acotada y después aplicar la cuarta propiedad del teorema.

#### Suma y producto de acotadas
**En la cátedra (1:12:56–1:14:16).** Se enuncian ambas propiedades. El razonamiento formal queda como práctica.

**Ampliación editorial (demostración).** Supongamos $|a_n|\leq M$ y $|b_n|\leq K$ en todos los índices, con $M,K\geq0$. Entonces

$$
|a_n+b_n|\leq|a_n|+|b_n|\leq M+K
$$

muestra la acotación de la suma, y

$$
|a_nb_n|=|a_n||b_n|\leq MK
$$

muestra la acotación del producto. La resta también es acotada porque $|a_n-b_n|\leq M+K$.

#### Toda sucesión nula es acotada
**En la cátedra (1:20:14–1:21:21; 1:41:17–1:41:31).** El profesor enuncia esta implicación y remite a los estudiantes a la demostración desarrollada en el material previo.

**Ampliación editorial (demostración).** Sea $a_n\to0$. Aplicamos la convergencia con $\varepsilon=1$. Existe $N\in\mathbb N$ tal que $|a_n|\leq1$ para todo $n\geq N$. El conjunto de los términos anteriores $\{|a_n|:0\leq n<N\}$ es finito; si contiene elementos, tiene un máximo. Elegimos

$$
M=\max\bigl(\{1\}\cup\{|a_n|:0\leq n<N\}\bigr).
$$

Entonces $|a_n|\leq M$ en todos los índices. Si la sucesión comienza en $n_\ast>0$, se restringe el conjunto finito a los índices de su dominio. La prueba muestra que **la convergencia controla una cola infinita y la finitud controla los términos iniciales**.

La recíproca es falsa: $(-1)^n$ está acotada y no converge a cero. Basta tomar $\varepsilon=1/2$: ningún término satisface $|(-1)^n|\leq1/2$.

#### Nula por acotada: demostración principal
**Demostración desarrollada (1:41:17–1:45:05).** Sean $(a_n)$ acotada y $(b_n)$ nula. Existe $M\geq0$ tal que $|a_n|\leq M$ en todos sus índices. Para demostrar $a_nb_n\to0$, se toma un $\varepsilon>0$ cualquiera. El profesor señala una dificultad que suele ocultarse: puede ocurrir $M=0$, de modo que el cociente $\varepsilon/M$ carecería de significado.

Se elige por ello el **radio auxiliar**

$$
\delta=\frac\varepsilon{M+1}>0.
$$

La nulidad de $(b_n)$ suministra un índice $N$ tal que $|b_n|\leq\delta$ para todos los $n\geq N$. Como la cota de $(a_n)$ vale en todos los índices, para $n\geq N$ tenemos

$$
\begin{aligned}
|a_nb_n|
&=|a_n|\,|b_n|\\
&\leq M\frac\varepsilon{M+1}\\
&\leq\varepsilon.
\end{aligned}
$$

La última desigualdad es válida porque $M/(M+1)\leq1$. Se cumple la definición de sucesión nula; por tanto,

$$
\boxed{a_n\text{ acotada},\ b_n\to0
\quad\Longrightarrow\quad a_nb_n\to0.}
$$

**Ampliación editorial (lectura del método).** El factor acotado puede oscilar permanentemente. El factor nulo, mediante un error elegido en función de $M$, hace pequeño el producto. Esta propiedad permite estudiar ejemplos tales como

$$
s_n=\frac{\cos(n^2+\sqrt n)}{n},\qquad n\geq1.
$$

La sucesión del coseno está acotada por $1$, mientras $1/n\to0$; se sigue $s_n\to0$. Es un ejemplo editorial que conserva la estructura de los ejemplos de funciones trigonométricas compuestas discutidos por el profesor.

### De las nulas a las convergentes: traslación por el límite

**En la cátedra (1:45:58–1:46:41).** En la discusión de los cocientes aparece la observación de que demostrar $s_n\to L$ equivale a demostrar que la sucesión diferencia $(s_n-L)$ es nula:

$$
\boxed{s_n\to L\quad\Longleftrightarrow\quad s_n-L\to0.}
$$

La equivalencia sale directamente de la identidad $|(s_n-L)-0|=|s_n-L|$. Sirve para trasladar cualquier problema de convergencia hacia una propiedad de nulidad. En las pruebas algebraicas resulta útil descomponer

$$
a_n=A+u_n,\qquad b_n=B+v_n,
\qquad u_n\to0,\ v_n\to0.
$$

Las cantidades $A$ y $B$ permanecen fijas; el comportamiento asintótico está en los errores $u_n$ y $v_n$.

#### Álgebra de límites: demostración editorial completa
**Ampliación editorial.** La clase enuncia el teorema del álgebra y demuestra las herramientas decisivas; el siguiente desarrollo completa su justificación a partir de esas herramientas.

**Suma.** Con $a_n=A+u_n$ y $b_n=B+v_n$,

$$
(a_n+b_n)-(A+B)=u_n+v_n\longrightarrow0,
$$

por la suma de nulas. Luego $a_n+b_n\to A+B$. El caso de la resta se obtiene porque $-v_n$ es nula.

**Producto.** Se desarrolla

$$
\begin{aligned}
a_nb_n-AB
&=(A+u_n)(B+v_n)-AB\\
&=Av_n+Bu_n+u_nv_n.
\end{aligned}
$$

Las sucesiones $Av_n$ y $Bu_n$ son nulas porque los factores constantes son acotados; $u_nv_n$ es nula por ser producto de dos nulas. La suma de estas tres sucesiones es nula. Se concluye $a_nb_n\to AB$.

**Recíproco.** Supongamos $B\neq0$ y $b_n\to B$. Al aplicar la definición con $\varepsilon=|B|/2$ existe $N$ tal que $|b_n-B|\leq|B|/2$ para $n\geq N$. La desigualdad triangular inversa proporciona

$$
|b_n|\geq |B|-|b_n-B|\geq\frac{|B|}{2}>0.
$$

Así, los términos del denominador están eventualmente separados de cero, el recíproco $1/b_n$ queda definido para $n\geq N$ y

$$
\left|\frac1{b_n}\right|\leq\frac2{|B|}.
$$

Además,

$$
\left|\frac1{b_n}-\frac1B\right|
=\frac{|b_n-B|}{|B|\,|b_n|}
\leq \frac2{|B|^2}|b_n-B|\longrightarrow0.
$$

Por tanto, $1/b_n\to1/B$.

**Cociente.** Cuando $B\neq0$,

$$
\frac{a_n}{b_n}=a_n\frac1{b_n}
\longrightarrow A\frac1B=\frac AB.
$$

Queda demostrado el álgebra de límites, con una condición adicional que suele darse por implícita: si hubo valores $b_n=0$ en una cantidad **finita** de índices iniciales, el cociente se considera desde el índice a partir del cual el denominador queda separado de cero.

#### Cómo se esboza el cociente durante la consulta
**En la cátedra (1:46:01–1:50:38).** El profesor propone estudiar la diferencia entre el cociente y su candidato a límite:

$$
\frac{a_n}{b_n}-\frac AB
=\frac{Ba_n-Ab_n}{Bb_n}.
$$

El numerador tiende a $BA-AB=0$ cuando ya se conocen las reglas de suma y producto con constantes. La clave pendiente consiste en probar que el recíproco $1/(Bb_n)$ permanece acotado cuando $B\neq0$ y $b_n\to B$. El profesor identifica este lema como el paso delicado y remite al apunte del curso para su desarrollo. La demostración editorial del apartado anterior hace explícita precisamente esa estimación.

### Ejemplos, aproximación lateral e indeterminación

#### Dos sucesiones con límite uno
**En la cátedra (1:51:24–1:56:55).** Se consideran

$$
p_n=\frac n{n+1},\qquad
q_n=\frac{n+1}{n}\qquad(n\geq1).
$$

Para la primera, dividir numerador y denominador por $n$ da

$$
p_n=\frac1{1+1/n}\longrightarrow\frac1{1+0}=1.
$$

Además,

$$
1-p_n=\frac1{n+1}>0,
$$

por lo que $p_n<1$ y se aproxima al límite por valores inferiores. La segunda se escribe

$$
q_n=1+\frac1n\longrightarrow1,
\qquad q_n-1=\frac1n>0,
$$

lo que muestra una aproximación desde valores superiores. De manera semejante,

$$
\frac{n-1}{n}=1-\frac1n\longrightarrow1
$$

con términos inferiores a uno para $n\geq1$.

![Esquema editorial: aproximación al mismo límite desde lados distintos](figuras/IC2021_Catedra_9_2/04_aproximacion_lateral.png)

*Esquema editorial.* Ambos recorridos comparten el límite real $1$. La definición de convergencia controla la **distancia** al límite; las desigualdades $p_n<1$ y $q_n>1$ precisan el lado desde el cual se produce la aproximación.

#### Cuando numerador y denominador tienden a cero
**En la cátedra (1:58:11–2:02:06).** El teorema del cociente exige un límite de denominador distinto de cero. Cuando las dos sucesiones del cociente tienden a cero, se requieren transformaciones que permitan estudiar cada caso. El profesor ofrece tres ejemplos para mostrar diferentes comportamientos:

$$
\frac{1/n}{1/n}=1\longrightarrow1,
$$

$$
\frac{1/n^2}{1/n}=\frac1n\longrightarrow0,
$$

$$
\frac{1/n}{1/n^2}=n.
$$

En el tercer ejemplo, el cociente es la sucesión de los naturales positivos, que es no acotada y no converge a ningún real. Los tres cocientes comparten límites cero en numerador y denominador, pero sus resultados son distintos. Se trata de la **forma indeterminada $0/0$**: la información de los dos límites originales es insuficiente para determinar el comportamiento del cociente.

![Esquema editorial: tres cocientes con la misma forma cero sobre cero](figuras/IC2021_Catedra_9_2/05_tres_cocientes.png)

*Esquema editorial.* La escala vertical se ha adaptado para mostrar las tres trayectorias. El cociente puede tender a cero, mantenerse en uno o crecer sin cota.

**Ampliación editorial (oscilación).** Incluso puede ocurrir que el cociente siga acotado y carezca de límite. Para $n\geq1$, sean

$$
a_n=\frac{(-1)^n}{n},\qquad b_n=\frac1n.
$$

Ambas sucesiones tienden a cero, pues $|a_n|=1/n\to0$, mientras

$$
\frac{a_n}{b_n}=(-1)^n
$$

oscila entre $-1$ y $1$. Este ejemplo completa la clasificación cualitativa sugerida por el profesor, sin atribuirle la construcción añadida.

#### El cociente que queda para la siguiente sesión
**En la cátedra (2:02:07–2:03:53).** La consulta final pregunta también por un límite de denominador cero y numerador de límite distinto de cero. El profesor anuncia que lo tratará en una sesión posterior. El asunto permanece **propuesto**, sin una regla demostrada aquí. En particular, la información sobre el signo y el acercamiento del denominador determina el análisis de los comportamientos infinitos; ese desarrollo corresponde a otra clase.

### Referencias y acta de verificación

**Fuente primaria.** Jorge San Martín, «IC2021: Cátedra 9.2. Sucesiones (2/4)», emisión del **5 de junio de 2021**. [Grabación en YouTube](https://www.youtube.com/watch?v=fMkNJyhooZY). Duración indicada por el reproductor: **2:05:08**. Contenido sustantivo recuperado desde aproximadamente **14:21** hasta el cierre **2:05:06**, mediante transcripción automática española. Los tiempos se contrastaron con el índice de la descripción visible de YouTube y el texto de los subtítulos.

**Clase precedente.** Jorge San Martín, «IC2021: Cátedra 9.1. Sucesiones (1/4)», 28 de mayo de 2021. [Grabación](https://www.youtube.com/watch?v=OvFPirtl0yQ). La presente sesión reelabora conceptos de una grabación anterior del mismo tema, pero estas notas corresponden específicamente al curso IC2021, sesión 9.2.

**Alcance de la verificación.** Se consultaron el título y la descripción pública, la indexación temporal y el texto íntegro accesible de los subtítulos automáticos. La transcripción se normalizó mediante comprobación matemática de los enunciados. Las figuras son diagramas editoriales originales y no pretenden reproducir fielmente la disposición de la pizarra. El teorema general del álgebra, el recíproco acotado, la acotación de una nula y algunas reglas de productos se desarrollan editorialmente allí donde el profesor los enuncia, esboza o remite a material externo. La observación sobre la no unicidad de los índices testigo se corrige expresamente.

**Estado PNC v1.0.** Fuente identificada; cobertura sustantiva desde el inicio docente hasta el cierre; enunciados y argumentos cotejados; atribuciones diferenciadas; figuras marcadas como editoriales. Los detalles técnicos de la compilación y de la conservación en Obsidian se registran en el archivo README adjunto a los entregables.

### Taller de problemas y soluciones

Los ejercicios se presentan a continuación según la fuente de origen; las ampliaciones editoriales de cada apuntes permanecen expresamente identificadas.

#### Problemas para estudiar — cátedra 9.1

Los ejercicios siguientes son **propuestos y resueltos editorialmente**, a partir de las técnicas de la cátedra. Se distinguen así de los tres ejemplos efectivamente desarrollados durante la sesión.

#### Problema 1. Una precisión concreta
Para $s_n=1/n$ y $\varepsilon=1/500$, determinar el menor índice natural positivo $N$ que satisface $|s_n|\le\varepsilon$ para todo $n\ge N$.

**Solución.** La desigualdad equivale a $n\ge500$. Por tanto, $N=500$ es el menor índice; todos los posteriores también satisfacen la condición.

#### Problema 2. Un desplazamiento del límite
Probar por definición que $s_n=3+2/n$ converge a $3$ para $n\ge1$.

**Solución.** Como $|s_n-3|=2/n$, basta exigir $n\ge 2/\varepsilon$. Una elección válida es $N=\lfloor2/\varepsilon\rfloor+1$. Si $n\ge N$, entonces $|s_n-3|<\varepsilon$.

#### Problema 3. La diferencia de dos raíces desplazadas
Probar que $\sqrt{n+2}-\sqrt n\to0$.

**Solución.** La racionalización proporciona

$$0<\sqrt{n+2}-\sqrt n=\frac2{\sqrt{n+2}+\sqrt n}\le\frac2{\sqrt n}\quad(n\ge1).$$

Elegimos $N=\lfloor4/\varepsilon^2\rfloor+1$. Para todo $n\ge N$ se cumple $2/\sqrt n<\varepsilon$, de donde se sigue el límite.

#### Problema 4. Permanencia frente a reaparición
Sea $t_n=0$ para $n$ par y $t_n=1$ para $n$ impar. Determinar si $t_n\to0$.

**Solución.** Para $\varepsilon=1/2$, todo índice impar satisface $|t_n-0|=1>1/2$. Como después de cualquier $N$ existe un índice impar, la condición final «para todo $n\ge N$» falla. Por tanto, la sucesión no converge a $0$. Una variación del argumento con dos valores alternantes demuestra que tampoco converge a otro real.

#### Problema 5. Un ejemplo de sucesión finalmente constante
Definir $u_0=9$, $u_1=-3$, $u_2=8$ y $u_n=5$ para todo $n\ge3$. Probar $u_n\to5$.

**Solución.** Dado $\varepsilon>0$, basta tomar $N=3$. Entonces $|u_n-5|=0\le\varepsilon$ para todos los $n\ge3$.

#### Problema 6. Convergencia con alternancia de signo
Probar que $v_n=(-1)^n/n$ converge a cero para $n\ge1$.

**Solución.** Para todo $n\ge1$, $|v_n-0|=1/n$. Empleando el umbral del problema de $1/n$, se obtiene la convergencia. Los signos cambian en cada término, pero la magnitud se aproxima a cero.

#### Problema 7. Formular correctamente la negación
Escribir la negación lógica de «$(s_n)$ converge a $L$» bajo la convención de la cátedra.

**Solución.** Negar sucesivamente los cuantificadores y la desigualdad produce

$$
\boxed{\exists\varepsilon_0>0\;\forall N\in\mathbb N\;
\exists n\ge N:\quad |s_n-L|>\varepsilon_0.}
$$

El enunciado afirma que existe una precisión positiva fija para la cual se encuentran, después de cualquier umbral, términos que quedan fuera de la banda de radio $\varepsilon_0$.

#### Herramientas para resolver ejercicios — cátedra 9.2

La clase ofrece una estrategia recurrente. Primero se reconocen las **hipótesis**: ¿se conocen límites individuales?, ¿se sabe que una sucesión es nula?, ¿se dispone de una cota uniforme? Después se reescribe la expresión, conservando equivalencias verdaderas para cada índice. Finalmente se aplica una propiedad cuya hipótesis está comprobada. Esta secuencia evita transformar reglas de límites en operaciones mecánicas desprovistas de justificación.

#### Estimar simultáneamente
Dos propiedades válidas respectivamente para $n\geq N_1$ y $n\geq N_2$ se cumplen ambas para

$$
n\geq\max\{N_1,N_2\}.
$$

Para una familia finita $N_1,\ldots,N_k$, se toma $N=\max\{N_1,\ldots,N_k\}$. Este mecanismo permite sumar desigualdades, multiplicar cotas no negativas y reutilizar la desigualdad triangular.

#### Elegir el error auxiliar adecuado
En una **suma** de dos nulas se eligen radios cuya suma sea a lo sumo $\varepsilon$; en un **producto** de dos nulas, radios cuyo producto sea a lo sumo $\varepsilon$; en el producto de una **nula por una acotada por $M$**, se usa $\varepsilon/(M+1)$ para obtener una expresión positiva y válida también cuando $M=0$. El error auxiliar se determina **antes** de solicitar los índices testigo, y la definición de convergencia garantiza su existencia.

#### Reconocer la diferencia con el límite
Para una expresión complicada $s_n$, escribir $s_n-L$ puede revelar una suma de errores nulos, un producto nulo por acotado o una fracción cuyo denominador queda separado de cero. La traducción $s_n\to L\iff(s_n-L)\to0$ es una de las razones de la importancia del lenguaje de las sucesiones nulas.

#### Práctica de estudio — cátedra 9.2

Los siguientes ejercicios son **propuestas editoriales**; se apoyan en los métodos de la cátedra y se distinguen de las tareas mencionadas por el profesor.

**Problema 1.** Demostrar directamente, desde la definición, que si $a_n\to0$ y $c\in\mathbb R$, entonces $ca_n\to0$. Considerar por separado $c=0$ y $c\neq0$.

**Problema 2.** Suponer $a_n\to0$ y $|b_n|\leq 7$ para todos los $n$. Encontrar un radio auxiliar explícito que demuestre $a_nb_n\to0$.

**Problema 3.** Si $a_n\to A$ y $b_n\to B$, justificar rigurosamente que $3a_n-2b_n\to3A-2B$ usando la traslación a sucesiones nulas.

**Problema 4.** Encontrar una sucesión acotada que carezca de límite real y una sucesión nula que valga cero en infinitos índices y sea distinta de cero en otros infinitos índices.

**Problema 5.** Dar un ejemplo de dos sucesiones nulas cuyo cociente converja a $5$, otro cuyo cociente oscile, y otro cuyo cociente no sea acotado.

**Problema 6.** Si $b_n\to-3$, demostrar que para índices suficientemente grandes $|b_n|\geq3/2$ y usar esta estimación para acotar $1/b_n$.

**Problema 7.** Mostrar que $a_n=\sin(n)/n$ es nula para $n\geq1$, sin calcular $\lim\sin(n)$.

**Problema 8.** Demostrar con la definición que la sucesión $a_n=1+1/n$, $n\geq1$, converge a $1$. Proponer un $N(\varepsilon)$ explícito y señalar para qué índices se cumple $|a_n-1|\leq10^{-3}$.

#### Orientaciones y respuestas de control
1. Para $c=0$, $|ca_n|=0$. Para $c\neq0$, solicitar $|a_n|\leq\varepsilon/|c|$.
2. Basta exigir $|a_n|\leq\varepsilon/8$; entonces $|a_nb_n|\leq7\varepsilon/8\leq\varepsilon$.
3. Escribir $u_n=a_n-A$, $v_n=b_n-B$: la diferencia con el candidato es $3u_n-2v_n$, suma de sucesiones nulas.
4. Sirven $(-1)^n$ y $a_n=(1+(-1)^n)/(2(n+1))$ para $n\geq0$.
5. Por ejemplo, $a_n=5/n$, $b_n=1/n$; $a_n=(-1)^n/n$, $b_n=1/n$; y $a_n=1/n$, $b_n=1/n^2$.
6. Para $|b_n+3|\leq3/2$, la triangular inversa da $|b_n|\geq3/2$ y $|1/b_n|\leq2/3$.
7. Usar $|\sin n|\leq1$ y la nulidad de $1/n$.
8. Sirve $N(\varepsilon)=\lfloor1/\varepsilon\rfloor+1$. Para $\varepsilon=10^{-3}$, todos los $n\geq1000$ cumplen la desigualdad cerrada; la elección general propuesta da $N=1001$ y también funciona.

---

## Comparaciones, velocidad y monotonía de sucesiones

La comparación de sucesiones conduce al teorema del sándwich, a la desigualdad de Bernoulli y a los límites de potencias y raíces. La monotonía y el supremo completan el panorama de convergencia.

**Grabaciones de referencia:** [grabación de la cátedra 10.1](https://www.youtube.com/watch?v=uWNFjH-GDEA), [grabación de la cátedra 10.2](https://www.youtube.com/watch?v=CQgnnA48rEA).

*Procedencia de este tramo: cátedra 10.1.*

### De la aproximación al orden

En la cátedra anterior se estableció que una sucesión real $(s_n)$ converge a un número $L\in\mathbb R$ cuando se satisface la condición

$$
\boxed{
(\forall\varepsilon>0)(\exists N\in\mathbb N)
(\forall n\ge N)\quad |s_n-L|\le\varepsilon.
}
$$

El índice $N$ depende del margen $\varepsilon$ y de la sucesión. Cada cota para el error $|s_n-L|$ expresa que, a partir de ese índice, todos los términos permanecen dentro del intervalo $[L-\varepsilon,L+\varepsilon]$. La propiedad arquimediana permite construir índices para errores tan pequeños como se quiera.

La propiedad de convergencia es especialmente útil al combinar valores aproximados con desigualdades. El **orden** de los reales proporciona información que se conserva al pasar al límite. El paso requiere una precisión: una desigualdad estricta entre términos puede convertirse en igualdad entre límites. La razón es geométrica: dos sucesiones pueden permanecer una a cada lado y acercarse al mismo número.

**Ejemplo editorial.** Para $n\ge1$ tomemos $u_n=0$ y $v_n=1/n$. Entonces $u_n<v_n$ para cada $n$, mientras que

$$
\lim_{n\to\infty}u_n=\lim_{n\to\infty}v_n=0.
$$

El orden llega al límite bajo la forma de una desigualdad amplia.

#### Un lema sobre la positividad eventual
**Demostración editorial.** Si $x_n\to a$ y $a>0$, los términos de $(x_n)$ son estrictamente positivos desde algún índice. En efecto, sea $\varepsilon=a/2>0$. Existe $N$ tal que, para $n\ge N$,

$$
|x_n-a|\le\frac a2,
\qquad\text{de donde}\qquad
x_n\ge a-\frac a2=\frac a2>0.
$$

De igual manera, si $a<0$, entonces $x_n<0$ desde algún índice, pues basta imponer $|x_n-a|\le(-a)/2$. Este lema ofrece la base de una prueba por contradicción del orden de los límites.

### El límite respeta las desigualdades

**Teorema (límites y orden; resumen MA1001, §10.1).** Sean $(u_n)$ y $(w_n)$ dos sucesiones reales, con

$$
u_n\longrightarrow u,
\qquad
w_n\longrightarrow w.
$$

Si existe $N_0\in\mathbb N$ tal que $u_n\le w_n$ para cada $n\ge N_0$, entonces

$$\boxed{u\le w.}$$

**Demostración desarrollada editorialmente.** Consideremos la sucesión de diferencias

$$d_n=w_n-u_n.$$

Por el álgebra de límites, $d_n\to w-u$. A partir de $N_0$ se cumple $d_n\ge0$. Supongamos que $w-u<0$. El lema anterior asegura entonces la existencia de un índice $N_1$ a partir del cual $d_n<0$. Para $n\ge\max\{N_0,N_1\}$ se obtendrían simultáneamente $d_n\ge0$ y $d_n<0$, situación incompatible con el orden real. Por consiguiente $w-u\ge0$, es decir, $u\le w$. $\square$

La palabra **eventualmente** abrevia una condición exacta: existe un índice natural $N_0$ desde el cual la desigualdad vale para todos los términos. La convergencia depende de las colas de las sucesiones; alterar una cantidad finita de términos iniciales conserva el mismo límite.

**Corolario editorial (intervalo de límites).** Si $a\le u_n\le b$ eventualmente y $u_n\to L$, entonces $a\le L\le b$. Se aplica el teorema a las dos sucesiones constantes $a$ y $b$.

**Contraejemplo editorial para precisar el enunciado.** La conclusión estricta $u<w$ exige hipótesis adicionales. Las sucesiones $u_n=-1/n$ y $w_n=1/n$ satisfacen $u_n<w_n$, pero ambas convergen a $0$.

### Teorema del sándwich

Hay ocasiones en que se conoce una sucesión $v_n$ mediante dos desigualdades y se desea calcular su límite. El teorema del sándwich convierte esas dos cotas en un resultado de convergencia cuando los extremos se aproximan al mismo real.

**Teorema (sándwich; resumen MA1001, §10.1).** Sean $(u_n)$, $(v_n)$ y $(w_n)$ sucesiones reales. Supongamos que

$$
\lim_{n\to\infty}u_n
=
\lim_{n\to\infty}w_n=L
$$

y que existe $N_\ast$ tal que

$$
(\forall n\ge N_\ast)\qquad
u_n\le v_n\le w_n.
$$

Entonces $(v_n)$ converge y

$$\boxed{\lim_{n\to\infty}v_n=L.}$$

**Demostración desarrollada editorialmente.** Fijemos $\varepsilon>0$. De $u_n\to L$ obtenemos un índice $N_1$ con

$$L-\varepsilon\le u_n\le L+\varepsilon
\qquad(n\ge N_1).$$

De $w_n\to L$ obtenemos un índice $N_2$ con

$$L-\varepsilon\le w_n\le L+\varepsilon
\qquad(n\ge N_2).$$

Tomamos un índice común

$$
\boxed{N=\max\{N_\ast,N_1,N_2\}.}
$$

Para todo $n\ge N$ se cumplen las tres condiciones de manera simultánea. Encadenando sus partes útiles resulta

$$
L-\varepsilon\le u_n\le v_n\le w_n\le L+\varepsilon.
$$

De ello se sigue $|v_n-L|\le\varepsilon$. Como $\varepsilon>0$ fue arbitrario, la definición de convergencia demuestra $v_n\to L$. $\square$

![Esquema editorial: dos cotas convergentes y la sucesión intermedia.](figuras/IC2021_Catedra_10_1/01_sandwich.png){width=85%}

En la demostración, el uso de $\max\{N_\ast,N_1,N_2\}$ es la operación decisiva. Cada condición empieza a valer desde un índice posiblemente distinto; escoger el mayor permite utilizarlas todas a la vez.

#### Una forma habitual: valor absoluto acotado
**Corolario editorial.** Si $a_n\ge0$, $a_n\to0$ y

$$|v_n|\le a_n\qquad\text{eventualmente},$$

entonces $v_n\to0$, pues $-a_n\le v_n\le a_n$ y los extremos convergen a cero.

Por ejemplo, si $|v_n|\le C/n$ desde algún índice, con $C>0$ fijo, entonces $v_n\to0$. Esta forma reduce el problema a encontrar una cota sencilla que tienda a cero.

#### Un ejemplo oscilante
**Ejemplo editorial.** Consideremos

$$v_n=\frac{\sin(n!)}{n},\qquad n\ge1.$$

El argumento $n!$ puede generar un comportamiento oscilante, pero la desigualdad elemental $-1\le\sin x\le1$ proporciona inmediatamente

$$
-\frac1n\le\frac{\sin(n!)}n\le\frac1n.
$$

Los extremos convergen a cero y, por tanto,

$$\boxed{\lim_{n\to\infty}\frac{\sin(n!)}n=0.}$$

El teorema identifica el límite a partir de las cotas, sin exigir el cálculo del comportamiento de la parte oscilante.

### Una desigualdad que transforma potencias en cotas

El capítulo complementario de MA1001 estudia la **desigualdad de Bernoulli** como instrumento para el teorema del sándwich. Su función es permitir estimaciones de potencias usando expresiones polinomiales sencillas.

**Proposición (Bernoulli; resumen MA1001, §10.2).** Para todo natural $n\ge0$ y todo real $h>-1$,

$$\boxed{(1+h)^n\ge1+nh.}$$

**Demostración editorial por inducción.** Para $n=0$ ambos miembros son $1$. Supongamos que la desigualdad vale para cierto natural $n$. Como $1+h>0$, podemos multiplicar ambos miembros por $1+h$ y conservar el sentido de la desigualdad:

$$
\begin{aligned}
(1+h)^{n+1}
&\ge(1+nh)(1+h)\\
&=1+(n+1)h+nh^2\\
&\ge1+(n+1)h.
\end{aligned}
$$

El último paso utiliza $n\ge0$ y $h^2\ge0$. La inducción completa la demostración. $\square$

![Esquema editorial: comparación entre $(1+h)^n$ y $1+nh$ para un $h$ fijo positivo.](figuras/IC2021_Catedra_10_1/02_bernoulli.png){width=82%}

**Observación editorial.** La hipótesis $h>-1$ hace positivo el factor $1+h$ y legitima la multiplicación durante el paso inductivo. Para $h>0$, el crecimiento de $1+nh$ expresa inmediatamente que $(1+h)^n$ supera cualquier cota real al crecer $n$.

### La sucesión geométrica $q^n$

**Resultado del resumen MA1001, §10.2.** Dado $q\in\mathbb R$, el comportamiento de la sucesión $(q^n)$ se organiza mediante el valor absoluto de la base.

$$
\boxed{
\begin{array}{ll}
q=1 &\Longrightarrow\quad q^n\to1,\\[2pt]
|q|<1 &\Longrightarrow\quad q^n\to0,\\[2pt]
q\in(-\infty,-1]\cup(1,\infty)
&\Longrightarrow\quad (q^n)\ \text{diverge en }\mathbb R.
\end{array}}
$$

El caso $q=0$ se entiende con la sucesión de valores $0$ desde $n\ge1$; el término $0^0$ se omite o se conviene por separado. El caso $q=-1$ genera la alternancia $1,-1,1,-1,\ldots$.

#### Demostración cuando $0<q<1$
Escribimos $q=1/(1+h)$ con $h=q^{-1}-1>0$. Aplicando Bernoulli,

$$
0<q^n=\frac{1}{(1+h)^n}
\le\frac{1}{1+nh}.
$$

Por la propiedad arquimediana, $1/(1+nh)\to0$. El teorema del sándwich concluye que $q^n\to0$.

Cuando $-1<q<0$, la sucesión $|q|^n$ converge a cero y $|q^n|=|q|^n$; la misma conclusión se obtiene por el criterio de valor absoluto.

#### Demostración cuando $|q|>1$
Para $q>1$ escribimos $q=1+h$, con $h>0$. Bernoulli proporciona $q^n\ge1+nh$, de manera que $(q^n)$ crece sin cota superior y, en particular, carece de límite real.

Para $q<-1$, sus valores absolutos satisfacen $|q^n|=|q|^n\ge1+nh$ con $h=|q|-1>0$. Una sucesión real convergente es acotada, de modo que $(q^n)$ tampoco converge.

**Caso de alternancia.** Para $q=-1$ las subsucesiones de índices pares e impares tienen valores constantes $1$ y $-1$, respectivamente. Si la sucesión entera convergiera, ambas subsucesiones tendrían el mismo límite, lo que contradice $1\ne-1$.

![Esquema editorial: sucesiones geométricas con bases positivas y negativas dentro del intervalo de módulo menor que uno.](figuras/IC2021_Catedra_10_1/03_geometricas.png){width=85%}

#### Bases variables
**Proposición complementaria (resumen MA1001, §10.2).** Si $q_n\to q$ y $|q|<1$, entonces

$$\boxed{(q_n)^n\longrightarrow0.}$$

**Demostración editorial.** Escogemos $r$ tal que $|q|<r<1$. Por convergencia, $|q_n|<r$ para todos los índices suficientemente grandes. Elevando a la potencia natural $n$ obtenemos

$$0\le|q_n|^n\le r^n,$$

y el miembro derecho tiende a cero. El sándwich concluye la prueba.

Si $|q|>1$, se puede elegir $r$ con $1<r<|q|$. Desde cierto índice, $|q_n|\ge r$ y, por tanto, $|(q_n)^n|\ge r^n$. La sucesión $(q_n)^n$ es no acotada y carece de límite real.

Los casos de frontera $|q|=1$ requieren inspección adicional: la información $q_n\to1$ por sí sola es compatible con límites distintos de $(q_n)^n$. Por ejemplo, $(1+1/n)^n$ y $(1+1/n^2)^n$ siguen comportamientos diferentes. La primera sucesión se vincula con la construcción del número $e$ y la segunda converge a $1$.

### Raíces de índice creciente

La operación de extraer raíces convierte una potencia de exponente $n$ en una expresión cuyo límite se puede estimar mediante Bernoulli.

**Proposición complementaria (resumen MA1001, §10.2).** Para todo $a>0$,

$$\boxed{\lim_{n\to\infty}\sqrt[n]{a}=1.}$$

**Demostración editorial.** Si $a=1$, cada término vale $1$. Supongamos $a>1$ y definamos $h_n=\sqrt[n]{a}-1>0$. Entonces $a=(1+h_n)^n$. Por Bernoulli,

$$a\ge1+nh_n,$$

de donde

$$0\le h_n\le\frac{a-1}{n}\longrightarrow0.$$

Así $\sqrt[n]{a}=1+h_n\to1$. Si $0<a<1$, tomamos $b=1/a>1$. Ya sabemos que $\sqrt[n]{b}\to1$ y, por el álgebra de límites aplicada al recíproco,

$$\sqrt[n]{a}=\frac1{\sqrt[n]{b}}\longrightarrow1.$$

Esta demostración describe cómo una desigualdad elemental de potencias produce una aproximación arbitrariamente precisa a la unidad.

#### Raíces de términos que también varían
**Proposición complementaria (resumen MA1001, §10.2).** Si $a_n\to a>0$ y $a_n>0$ desde algún índice, entonces

$$\boxed{\sqrt[n]{a_n}\longrightarrow1.}$$

**Demostración editorial.** Existe $N$ tal que, para $n\ge N$,

$$\frac a2\le a_n\le\frac{3a}{2}.$$

La función raíz $n$-ésima es creciente en $(0,\infty)$; por ello

$$\sqrt[n]{a/2}\le\sqrt[n]{a_n}\le\sqrt[n]{3a/2}.$$

Las dos sucesiones extremas convergen a $1$ por el resultado precedente. El teorema del sándwich demuestra el límite buscado.

![Esquema editorial: raíces $n$-ésimas de dos números positivos que se aproximan a $1$.](figuras/IC2021_Catedra_10_1/04_raices.png){width=84%}

### Ampliación editorial: Bernoulli de segundo orden

El apartado 10.3 del resumen MA1001 desarrolla una forma más precisa de la desigualdad de Bernoulli. Se incluye aquí como **ampliación editorial**, pues su pertenencia a la grabación del 7 de junio está pendiente de confirmación.

Para $h\ge0$ y $n\ge2$ vale

$$
\boxed{(1+h)^n\ge1+nh+\frac{n(n-1)}2h^2.}
$$

La desigualdad se obtiene del desarrollo binomial: todos los coeficientes y potencias restantes son no negativos. También puede establecerse por inducción. Su utilidad aparece en el límite

$$\boxed{\sqrt[n]{n}\longrightarrow1.}$$

**Demostración editorial.** Para $n\ge2$ escribimos $x_n=\sqrt[n]{n}-1\ge0$. Entonces $n=(1+x_n)^n$ y la desigualdad anterior asegura

$$
n\ge1+nx_n+\frac{n(n-1)}2x_n^2
\ge1+\frac{n(n-1)}2x_n^2.
$$

Así,

$$
0\le x_n^2\le\frac{2(n-1)}{n(n-1)}=\frac2n,
\qquad
0\le x_n\le\sqrt{\frac2n}\longrightarrow0.
$$

Por tanto $\sqrt[n]{n}=1+x_n\to1$. El exponente variable se controla a través de una estimación cuadrática explícita.

#### Una comparación de velocidades
**Ampliación editorial.** Para cada $k\in\mathbb N$ y cada $q\in\mathbb R$ con $|q|<1$,

$$\boxed{n^kq^n\longrightarrow0.}$$

En efecto, basta estudiar $0<r=|q|<1$, y escribir $r=(1+h)^{-1}$ con $h>0$. Para $n\ge2(k+1)$, el binomio de Newton proporciona

$$
(1+h)^n\ge \binom n{k+1}h^{k+1}
\ge\frac{(n/2)^{k+1}}{(k+1)!}\,h^{k+1}.
$$

Por ello,

$$
0\le n^kr^n
\le\frac{2^{k+1}(k+1)!}{h^{k+1}}\frac1n
\longrightarrow0.
$$

El resultado explica cómo un decaimiento geométrico domina, a largo plazo, cualquier potencia natural fija.

### Ejemplos resueltos para consolidar el método

#### Ejemplo 1. Una oscilación que se extingue
Sea $s_n=(-1)^n/n$ para $n\ge1$. Como $|s_n|=1/n\to0$, el criterio de valor absoluto demuestra $s_n\to0$. La alternancia de signo convive con una amplitud que se hace arbitrariamente pequeña.

#### Ejemplo 2. Un cociente de polinomios
Para $n\ge1$,

$$
\frac{2n+1}{3n-4}
=\frac{2+1/n}{3-4/n}.
$$

El denominador converge a $3$; por tanto, es distinto de cero desde algún índice y el álgebra de límites da

$$\lim_{n\to\infty}\frac{2n+1}{3n-4}=\frac23.$$

La expresión original puede no estar definida en uno o varios índices iniciales; el límite estudia la cola donde se encuentra definida.

#### Ejemplo 3. Una potencia geométrica con factor polinomial
Como $|2/3|<1$, la ampliación de la sección 7.1 permite concluir

$$\lim_{n\to\infty}n^3\left(-\frac23\right)^n=0.$$

La oscilación del signo y el crecimiento del factor $n^3$ quedan dominados por el decaimiento geométrico.

#### Ejemplo 4. Una raíz dependiente del índice
Sea $a_n=2+1/n>0$. Como $a_n\to2$, el resultado de la sección 6.1 implica

$$\lim_{n\to\infty}\sqrt[n]{2+1/n}=1.$$

La conclusión se justifica por acotamiento entre raíces de constantes positivas, sin expandir la raíz.

*Procedencia de este tramo: cátedra 10.2.*

### El problema que organiza el cierre de la unidad

**En la cátedra (13:09–14:11).** El profesor distingue el propósito de las dos semanas terminadas y el de la semana siguiente. Durante las cuatro cátedras se han **aprendido** las sucesiones: qué significa converger, cómo operar con límites y cómo demostrar estimaciones. En la semana 11 se comenzarán a **utilizar** como herramientas para construir y estudiar nuevos objetos matemáticos. La última sesión reúne dos familias que permiten experimentar con esas herramientas: potencias de una base fija y raíces cuyo índice crece.

La pregunta inicial tiene la forma siguiente. Dado un real fijo $q$, ¿qué ocurre con $q^n$ cuando el natural $n$ crece? Una respuesta completa depende del tamaño y del signo de $q$. Después aparece una cuestión complementaria: dado $q>0$, ¿qué ocurre con la raíz $n$-ésima $\sqrt[n]{q}$? La segunda pregunta exige primero justificar que esas raíces existen en $\mathbb R$.

Las herramientas recuperadas de las clases anteriores son la convergencia $\varepsilon$–$N$, el teorema del sándwich, el álgebra de límites, el axioma del supremo y la familia de desigualdades de Bernoulli. Para una sucesión $(a_n)$ y un real $L$ conservamos la convención de la cátedra:

$$
\boxed{a_n\longrightarrow L\iff
(\forall\varepsilon>0)(\exists N\in\mathbb N)(\forall n\ge N)\quad
|a_n-L|\le\varepsilon.}
$$

El valor de $N$ puede depender de $\varepsilon$. En una demostración por sándwich, cada cota de la sucesión intermedia debe estar definida en una cola de índices y las dos sucesiones extremas deben converger al mismo número.

### El mapa completo de las potencias geométricas

**En la cátedra (14:11–16:19; 45:37–54:58).** Fijado $q\in\mathbb R$, consideremos la sucesión $a_n=q^n$. Su comportamiento se clasifica mediante el módulo de la base y los valores de frontera:

$$
\boxed{
\begin{array}{c|c}
\text{Base fija }q&\text{Comportamiento de }(q^n)\\ \hline
q=0 & q^n=0\ (n\ge1),\quad \lim q^n=0\\
q=1 & q^n=1,\quad \lim q^n=1\\
|q|<1 & \lim q^n=0\\
q=-1 & (-1)^n\text{ alterna entre }1\text{ y }-1\\
|q|>1 & |q^n|\text{ crece sin cota superior}
\end{array}}
$$

Para $q=0$ se trabaja con $n\ge1$, según la convención de omitir el término inicial $0^0$. Para $q=-1$, la sucesión está acotada por $1$ en módulo y conserva una oscilación de amplitud fija. Una sucesión convergente es acotada, pero el ejemplo $(-1)^n$ exhibe por qué la acotación, por sí sola, permite distintos comportamientos.

![Esquema editorial: comportamiento de potencias con base positiva menor que uno, negativa de módulo menor que uno y positiva mayor que uno.](figuras/IC2021_Catedra_10_2/01_clasificacion_geom.png){width=92%}

El profesor centra inicialmente el análisis en $0<q<1$, porque de ese caso se derivarán después las bases negativas de módulo pequeño. El caso $|q|>1$ quedará resuelto mediante recíprocos.

### La transformación decisiva: del número $q<1$ a una potencia de Bernoulli

**En la cátedra (16:19–20:00).** Supongamos $0<q<1$. Su recíproco satisface $1/q>1$. En consecuencia existe $h>0$ tal que

$$
\frac1q=1+h,\qquad h=\frac1q-1>0,
\qquad
q^n=\frac1{(1+h)^n}.
$$

Esta sustitución expresa el denominador mediante una potencia cuya base tiene la forma que requiere la desigualdad de Bernoulli. La elección del recíproco es la estrategia que pone en funcionamiento la prueba. El exponente $n$ permite obtener cotas cada vez mayores para el denominador; al invertirlas, aparecen cotas superiores cada vez menores para $q^n$.

La forma elemental de Bernoulli para $h>0$ y $n\in\mathbb N$ afirma

$$
(1+h)^n\ge 1+nh.
$$

Como ambos miembros son positivos, la relación entre sus recíprocos es

$$
0<q^n=\frac1{(1+h)^n}\le\frac1{1+nh}.
$$

El miembro derecho converge a cero. Puede verificarse escribiendo

$$
\frac1{1+nh}=\frac{1/n}{1/n+h}
\ \longrightarrow\ \frac0h=0,
$$

con $h>0$ fijo. La sucesión constante cero converge también a cero. Por el sándwich,

$$\boxed{0<q<1\quad\Longrightarrow\quad q^n\longrightarrow0.}$$

**Demostración desarrollada.** El profesor hace explícito el sentido de las desigualdades: cuando se reemplaza un denominador positivo por uno más pequeño, la nueva fracción es una **cota superior** de la original. También señala que la condición $q<1$ es estricta en el extremo derecho. Para $q=1$, todos los términos valen $1$ y el límite es $1$.

**Ampliación editorial: umbral $\varepsilon$.** Si se desea exhibir un índice a partir del cual $q^n\le\varepsilon$, basta elegir $N$ de manera que $1+Nh\ge1/\varepsilon$. La propiedad arquimediana garantiza esa elección. Esta construcción traduce el sándwich a la definición cuantificada de convergencia.

La cátedra menciona bases como $0{,}999$ y otros decimales próximos a $1$: cada base fija estrictamente menor que $1$ produce una sucesión convergente a cero. La proximidad de la base a $1$ influye en el número de índices necesarios para alcanzar una tolerancia determinada. En contraste, la base exactamente igual a $1$ produce la sucesión constante uno.

### La velocidad de convergencia: cocientes de dos sucesiones nulas

**En la cátedra (26:53–35:20).** Hasta aquí se ha determinado que $q^n\to0$. El profesor propone una segunda pregunta: **¿con qué rapidez se acerca al cero, comparada con otras sucesiones conocidas?** Dos ejemplos familiares son $1/n$ y $1/n^2$. Ambas son nulas, y la segunda es más rápida en el sentido de que

$$
\frac{1/n^2}{1/n}=\frac1n\longrightarrow0.
$$

Esta forma de comparación se extiende: cuando $a_n$ y $b_n$ son sucesiones nulas, con $b_n\ne0$ eventualmente, y $a_n/b_n\to0$, se dice que $a_n$ es de orden menor que $b_n$ o que **se anula más rápidamente** que $b_n$. La escritura $a_n=o(b_n)$ es una **ampliación editorial de notación**; el profesor trabaja principalmente con el cociente.

Para comparar $q^n$ con $1/n$ hay que examinar

$$
\frac{q^n}{1/n}=nq^n.
$$

Si en la estimación de la sección anterior multiplicamos por $n$, obtenemos

$$
0\le nq^n\le\frac{n}{1+nh}.
$$

Pero el límite de la cota superior es $1/h>0$, de modo que estas dos cotas **todavía no determinan** el límite de $nq^n$. Es una limitación de la estimación utilizada, que abre el paso a una desigualdad más fuerte.

#### Bernoulli de segundo orden
**En la cátedra (35:20–38:31).** Para $h>0$ y $n\ge2$, la fórmula binomial asegura

$$
(1+h)^n
=1+nh+\binom n2h^2+\cdots+h^n
\ge\binom n2h^2
=\frac{n(n-1)}2h^2.
$$

Por tanto,

$$
0\le nq^n
=\frac{n}{(1+h)^n}
\le\frac{2n}{n(n-1)h^2}
=\frac{2}{(n-1)h^2}
\longrightarrow0.
$$

El teorema del sándwich concluye

$$\boxed{nq^n\longrightarrow0\qquad(0<q<1).}$$

El resultado muestra que la potencia geométrica converge a cero más rápidamente que $1/n$: una vez dividida por $1/n$, todavía converge a cero. El papel de Bernoulli de segundo orden consiste en hacer aparecer en el denominador un polinomio de grado dos que domina al factor $n$ del numerador.

#### Bernoulli de tercer orden
**En la cátedra (39:48–42:12).** Cuando la comparación es ahora con $1/n^2$, el cociente a estudiar es $n^2q^n$. Aplicando el término cúbico de la expansión binomial, para $n\ge3$ se obtiene

$$
(1+h)^n\ge \binom n3h^3
=\frac{n(n-1)(n-2)}6h^3.
$$

En consecuencia,

$$
0\le n^2q^n
\le \frac{6n}{(n-1)(n-2)h^3}
\longrightarrow0.
$$

La expresión derecha es un cociente racional cuyo denominador posee mayor grado que el numerador. Así, $q^n$ se anula también más rápido que $1/n^2$. El docente propone continuar: si se multiplica por $n^3$, se emplea una cota binomial de grado cuatro, y así sucesivamente.

![Esquema editorial: para $h>0$, cada grado adicional de la cota binomial controla una potencia mayor de $n$.](figuras/IC2021_Catedra_10_2/02_bernoulli_grados.png){width=88%}

#### El resultado general y su demostración
**En la cátedra (42:55–45:37).** Para todo entero fijo $p\ge0$,

$$
\boxed{0<q<1\quad\Longrightarrow\quad
\lim_{n\to\infty}n^p q^n=0.}
$$

El profesor explica la estrategia: ante un numerador de grado $p$, se elige en la expansión binomial un término de grado $p+1$. Esta diferencia de grados fuerza el límite a cero.

**Ampliación editorial: prueba completa con índices.** Sea $m=p+1$ y $n\ge m$. Como $h>0$,

$$
(1+h)^n\ge\binom nm h^m,
\qquad
0\le n^p q^n\le \frac{n^p}{\binom n{p+1}h^{p+1}}.
$$

La última fracción puede reescribirse como

$$
\frac{n^p}{\binom n{p+1}h^{p+1}}
=
\frac{(p+1)!}{n\,h^{p+1}}
\prod_{j=1}^{p}\frac{n}{n-j}.
$$

Para $n\ge2p$ (y $n\ge p+1$), cada factor $n/(n-j)$ es a lo sumo $2$. Por tanto,

$$
0\le n^p q^n\le
\frac{2^p(p+1)!}{n\,h^{p+1}}
\longrightarrow0.
$$

El sándwich termina la prueba. Para $p=0$ la misma estimación se entiende con producto vacío, cuyo valor es $1$.

**Corolario editorial.** Si $P$ es cualquier polinomio real y $0<|q|<1$, entonces $P(n)q^n\to0$: por linealidad, cada monomio $n^kq^n$ converge a cero, y la posible alternancia de signos se controla mediante el valor absoluto. En particular, para todo polinomio $P$ que sea positivo y crezca sin cota, $q^n$ se anula más rápidamente que $1/P(n)$.

![Esquema editorial: la comparación de $q^n$ con $1/n$ y $1/n^2$ en escala vertical logarítmica.](figuras/IC2021_Catedra_10_2/03_velocidad.png){width=88%}

El gráfico es una representación a escala finita de un comportamiento **asintótico**: para decidir la rapidez mediante cocientes importa el límite cuando $n\to\infty$, y una comparación entre unos cuantos términos iniciales solo ofrece intuición.

### Bases negativas y bases de módulo grande

**En la cátedra (45:37–54:58).** La clasificación se completa mediante dos reducciones a casos ya conocidos.

#### Bases $-1<q<0$
Para estas bases puede escribirse $q=-|q|$ y, por tanto,

$$q^n=(-1)^n|q|^n.$$

La sucesión $((-1)^n)$ está acotada, pues $|(-1)^n|=1$. Como $0<|q|<1$, la sucesión $(|q|^n)$ es nula. El teorema previamente estudiado afirma que el producto de una sucesión acotada por otra nula es nulo. Por tanto,

$$\boxed{-1<q<0\quad\Longrightarrow\quad q^n\longrightarrow0.}$$

La alternancia del signo produce valores a ambos lados del origen; la amplitud $|q|^n$ de esa alternancia se reduce hacia cero. Las cotas $-|q|^n\le q^n\le |q|^n$ suministran también una prueba directa por sándwich.

#### Bases $|q|>1$
Si $|q|>1$, el recíproco satisface $0<|1/q|<1$. Así,

$$
\left(\frac1q\right)^n\longrightarrow0,
\qquad q^n=\frac1{(1/q)^n}.
$$

La sucesión del denominador tiene términos distintos de cero, y su valor absoluto converge a cero. Esto implica que los módulos de sus recíprocos crecen sin cota superior. En efecto, dado $M>0$, existe un índice a partir del cual

$$0<\left|\frac1q\right|^n<\frac1M;
\qquad\text{luego}\qquad |q^n|>M.$$

Por tanto, $q^n$ es una sucesión real **no acotada** y, en virtud del teorema «convergente implica acotada», carece de límite real finito.

**Ampliación editorial.** Si $q>1$, los términos son positivos y crecen sin cota: se suele escribir $q^n\to+\infty$ como descripción de divergencia infinita. Si $q<-1$, los módulos crecen sin cota mientras los signos alternan. Esta diferencia queda registrada por separado; en ambos casos la sucesión carece de límite en $\mathbb R$.

**Mapa conclusivo de la primera mitad.** Las bases de módulo estrictamente menor que uno dan límites cero, con convergencia geométrica; la base $1$ produce límite uno; la base $-1$ conserva la alternancia; las bases de módulo mayor que uno generan módulos no acotados.

### Una dificultad previa a las raíces: demostrar su existencia

**En la cátedra (55:03–1:00:18).** La segunda familia es

$$\bigl(\sqrt[n]{q}\bigr)_{n\ge1},\qquad q>0\text{ fijo}.$$

Para hablar de sus términos es preciso justificar que para cualquier entero positivo $n$ existe la raíz $n$-ésima positiva de $q$. El profesor recupera el axioma del supremo y subraya la utilidad de las sucesiones: las pruebas de existencia, que antes exigían manipular expresiones algebraicas con un pequeño $\varepsilon$, pueden ahora hacerse comparando dos sucesiones explícitas y pasando al límite.

#### El conjunto generador
Fijemos un natural $p\ge2$ y un real $q>0$. Queremos hallar un real $s>0$ tal que

$$s^p=q.$$

**En la cátedra (1:00:18–1:10:22).** Consideremos

$$
\boxed{A=\{x\in\mathbb R:x>0\ \text{y}\ x^p<q\}.}
$$

Este conjunto tiene elementos positivos y una cota superior. El profesor organiza la verificación por casos. Si $0<q<1$, el propio $q$ pertenece a $A$, porque $q^p<q$; el número $1$ es una cota superior, pues $x^p<q<1$ implica $x<1$. Si $q>1$, el número $1$ pertenece a $A$ y $q$ es una cota superior: de $x^p<q<q^p$ se sigue $x<q$. El caso $q=1$ tiene raíz evidente $s=1$.

La implicación utilizada aquí se apoya en que la función potencia $x\mapsto x^p$ es **estrictamente creciente** sobre los reales positivos. Una justificación algebraica es que, si $0<a<b$,

$$
b^p-a^p=(b-a)(b^{p-1}+b^{p-2}a+\cdots+a^{p-1})>0.
$$

Así, $A$ es no vacío y está acotado superiormente. Por el axioma del supremo existe

$$s=\sup A>0.$$

El paso restante es demostrar que $s^p=q$. La positividad de $s$ se deduce de que $A$ contiene un número estrictamente positivo y $s$ es cota superior del conjunto.

#### Acercarse al supremo desde ambos lados
**Demostración desarrollada (1:10:22–1:19:17).** Para cada $n\ge1$ se tiene $s+1/n>s$. Este número queda fuera de $A$, pues $s$ es cota superior; de la definición de $A$ se obtiene

$$
\boxed{q\le\left(s+\frac1n\right)^p.}
$$

Por otro lado, como $s>0$ y $1/n\to0$, existe $N$ tal que $s-1/n>0$ cuando $n\ge N$. Para esos índices el número $s-1/n$ es inferior al supremo. La propiedad característica del supremo asegura que ese número **es inferior a algún elemento de $A$** y, por la monotonía de la potencia, se cumple

$$
\boxed{\left(s-\frac1n\right)^p\le q\qquad(n\ge N).}
$$

Una forma equivalente de justificar la última relación, presentada como argumento por contradicción en clase, es observar que si $(s-1/n)^p>q$, entonces todos los elementos $x\in A$ satisfarían $x<s-1/n$. Esto convertiría a $s-1/n$ en una cota superior estrictamente menor que $s$, contradiciendo que $s$ es la menor cota superior.

Para $n$ suficientemente grande, por tanto,

$$
\boxed{\left(s-\frac1n\right)^p\le q\le
\left(s+\frac1n\right)^p.}
$$

Las dos sucesiones de extremos convergen a $s^p$, porque $s\pm1/n\to s$ y la potencia $p$ es un producto finito, al que se aplica el álgebra de límites. Al pasar al límite en las desigualdades resulta

$$s^p\le q\le s^p,$$

y así $\boxed{s^p=q}$. La raíz $p$-ésima positiva existe y es $s=\sup A$.

![Esquema editorial: un conjunto acotado y las perturbaciones $s\pm1/N$ que permiten probar la igualdad para la potencia del supremo.](figuras/IC2021_Catedra_10_2/04_supremo_perturbaciones.png){width=86%}

**Ampliación editorial: unicidad.** Si $x,y>0$ y $x^p=y^p=q$, entonces

$$
0=x^p-y^p=(x-y)\sum_{k=0}^{p-1}x^{p-1-k}y^k.
$$

La suma es estrictamente positiva, de modo que $x-y=0$ y $x=y$. Con ello queda justificada también la escritura unívoca $\sqrt[p]{q}$.

#### La pregunta sobre $s\pm1/n$
**En la discusión final (1:43:42–1:51:50).** Un estudiante pregunta por qué se han utilizado precisamente $s+1/n$ y $s-1/n$. El profesor destaca que ambos son reales disponibles para cualquier $n$ positivo; sus posiciones respecto de $s$ son conocidas, y su diferencia con $s$ tiende a cero. La elección hace posible pasar al límite sin expandir una potencia de grado arbitrario.

**Ampliación editorial.** El mismo argumento funciona con cualquier sucesión $(\delta_n)$ que satisfaga $\delta_n>0$ para todo $n$ y $\delta_n\to0$, siempre que se tome $n$ suficientemente grande para tener $s-\delta_n>0$. En lugar de $s\pm1/n$ pueden emplearse $s\pm(1/2)^n$, por ejemplo. La sucesión $1/n$ es especialmente cómoda porque sus propiedades se han demostrado en las primeras cátedras y encadena la completitud con el álgebra de límites.

### El límite de $\sqrt[n]{q}$ con base fija

**En la cátedra (1:21:05–1:31:29).** Una vez establecida la existencia de las raíces positivas, se considera la sucesión

$$r_n=\sqrt[n]{q},\qquad q>0.$$

Para $q=1$, todos los términos valen $1$. Si $q>1$, la potencia positiva conserva el orden y cada $r_n$ satisface $r_n>1$. Se define entonces una sucesión $h_n>0$ mediante

$$r_n=1+h_n,
\qquad q=(1+h_n)^n.$$

La desigualdad de Bernoulli de primer orden, válida para cada índice y para su correspondiente $h_n>0$, permite escribir

$$
q=(1+h_n)^n\ge1+nh_n.
$$

Despejando,

$$
\boxed{0<h_n\le\frac{q-1}{n}.}
$$

La cota superior tiende a cero, por lo que $h_n\to0$. Por el álgebra de límites,

$$r_n=1+h_n\longrightarrow1.$$

**Caso $0<q<1$.** El profesor lo propone como ejercicio breve a partir del recíproco. Como $1/q>1$, ya se conoce que $(1/q)^{1/n}\to1$. Por tanto,

$$
\sqrt[n]{q}=\frac1{\sqrt[n]{1/q}}\longrightarrow\frac11=1.
$$

En conjunto,

$$\boxed{\forall q>0,\qquad \lim_{n\to\infty}\sqrt[n]{q}=1.}$$

Un ejemplo tratado oralmente es $q=10\,000$: la extracción de raíces de índice cada vez mayor conduce hacia $1$ desde valores superiores. La demostración explica este fenómeno para cualquier real positivo fijo.

### El límite de $\sqrt[n]{n}$: Bernoulli de segundo orden

**En la cátedra (1:31:29–1:36:34).** El siguiente problema tiene una diferencia decisiva: el radicando también depende del índice. El profesor compara la raíz $n$-ésima de una constante $q$ con

$$r_n=\sqrt[n]{n}\qquad(n\ge1).$$

El número $r_n$ es al menos $1$, de modo que puede escribirse $r_n=1+h_n$ con $h_n\ge0$. Elevando a la potencia $n$,

$$
n=(1+h_n)^n.
$$

Bernoulli de primer orden aporta $n\ge1+nh_n$ y, por tanto, $h_n\le(n-1)/n$. Esa cota superior converge a $1$ y no alcanza para determinar que $h_n\to0$. Es el mismo fenómeno observado antes al estudiar $nq^n$: necesitamos aprovechar un grado más de la desigualdad.

**Demostración desarrollada (1:34:18–1:36:14).** Para $n\ge2$, Bernoulli de segundo orden proporciona

$$
(1+h_n)^n\ge
1+nh_n+\binom n2h_n^2
\ge1+\frac{n(n-1)}2h_n^2.
$$

Como el miembro izquierdo es $n$, se obtiene

$$
\frac{n(n-1)}2h_n^2\le n-1,
\qquad
0\le h_n\le\sqrt{\frac2n}.
$$

La cota de la derecha converge a cero. Por el sándwich, $h_n\to0$ y finalmente

$$\boxed{\lim_{n\to\infty}\sqrt[n]{n}=1.}$$

![Esquema editorial: raíces enésimas de una constante, de $n$ y de $n^2$, todas convergentes a $1$.](figuras/IC2021_Catedra_10_2/05_raices_enesimas.png){width=88%}

#### Ejercicio propuesto en la clase: $\sqrt[n]{n^2}$
**En la cátedra (1:36:34–1:37:47).** El docente ofrece dos caminos: emplear una desigualdad de Bernoulli de grado mayor, o utilizar un argumento algebraico ya disponible. El segundo es inmediato:

$$
\sqrt[n]{n^2}=(\sqrt[n]{n})^2\longrightarrow1^2=1.
$$

**Ampliación editorial.** Para todo entero fijo $p\ge0$,

$$\boxed{\lim_{n\to\infty}\sqrt[n]{n^p}=1,}$$

porque $\sqrt[n]{n^p}=(\sqrt[n]{n})^p$ y el producto de un número fijo de sucesiones convergentes converge al producto de sus límites. El orden de las cuantificaciones importa: $p$ queda fijado mientras $n$ crece.

### El teorema de las sucesiones monótonas acotadas

**En la cátedra (1:38:38–1:43:01).** Como conclusión, el profesor anuncia el **teorema de las sucesiones monótonas acotadas**, que será indispensable para la semana 11. Advierte mediante el ejemplo $(-1)^n$ que una sucesión acotada puede oscilar. El dato adicional que permite asegurar convergencia es la **monotonía**.

Una sucesión real $(a_n)$ es *creciente* (en sentido amplio) cuando $a_n\le a_{n+1}$ para todo índice de su dominio, y *decreciente* (en sentido amplio) cuando $a_{n+1}\le a_n$ para todo índice. Se denomina *monótona* cuando satisface alguna de esas relaciones. En el uso matemático, ambas pueden incluir igualdades sucesivas; la estricta monotonía se indica separadamente.

El teorema tiene dos enunciados equivalentes en alcance:

$$
\begin{aligned}
(a_n)\text{ creciente y acotada superiormente}
&\Longrightarrow a_n\longrightarrow\sup\{a_n:n\in\mathbb N\},\\
(a_n)\text{ decreciente y acotada inferiormente}
&\Longrightarrow a_n\longrightarrow\inf\{a_n:n\in\mathbb N\}.
\end{aligned}
$$

**Estatuto en la fuente:** el profesor **enuncia y explica el sentido del teorema**; recomienda revisarlo en el apunte. Su demostración completa **queda fuera del desarrollo de esta grabación**. La siguiente prueba se incorpora por motivos de estudio.

#### Ampliación editorial: demostración con el supremo
Supongamos $(a_n)$ creciente y acotada superiormente y sea

$$L=\sup\{a_n:n\in\mathbb N\}.$$

Por la propiedad característica del supremo, dado $\varepsilon>0$ existe algún término $a_N$ con

$$L-\varepsilon<a_N\le L.$$

Como la sucesión es creciente, para todo $n\ge N$ se tiene $a_N\le a_n\le L$. Por tanto,

$$L-\varepsilon<a_n\le L,
\qquad |a_n-L|<\varepsilon.
$$

Con ello $a_n\to L$. Para una sucesión decreciente acotada inferiormente, la misma idea se desarrolla con el ínfimo de sus términos y desigualdades invertidas.

![Esquema editorial: una sucesión creciente que converge a su supremo y una sucesión acotada oscilante.](figuras/IC2021_Catedra_10_2/06_monotonas.png){width=87%}

La relevancia conceptual del teorema es que **permite demostrar la existencia del límite sin disponer previamente de una fórmula para calcularlo**. Este es precisamente el puente que destaca San Martín hacia los temas de la semana 11.

### Revisión de estrategias y dificultades habituales

La secuencia de las cuatro cátedras deja una técnica recurrente. Frente a una expresión que debe tender a cero, se buscan cotas útiles en lugar de intentar calcular directamente sus términos. Si la cota disponible conserva un límite positivo y, por tanto, deja el problema abierto, se fortalece la desigualdad hasta que aparezca un denominador de mayor grado. Bernoulli de grado $p+1$ sirve para neutralizar un numerador de grado $p$.

La construcción de raíces muestra una estrategia diferente. El conjunto $A=\{x>0:x^p<q\}$ determina un candidato $s=\sup A$. Una pareja de perturbaciones $s\pm1/n$ proporciona desigualdades que, mediante el álgebra de límites, pasan a la igualdad $s^p=q$. Esta prueba relaciona tres elementos vistos en semanas distintas: **completitud de los reales, convergencia de sucesiones y continuidad de las operaciones algebraicas finitas**.

En el cierre, el teorema de monotonía y acotación agrega una vía para demostrar convergencia cuando el límite aún se desconoce. Estas herramientas tienen funciones precisas y complementarias: el sándwich identifica el límite de una sucesión intermedia; Bernoulli produce cotas manejables; el supremo construye números; la monotonía acotada garantiza la convergencia de una sucesión organizada por el orden.

**Precauciones de lectura.** La potencia $q^n$ mantiene fija su base; las raíces $\sqrt[n]{n}$ cambian simultáneamente índice y radicando. En una comparación de rapidez, se fija el orden del cociente para interpretar qué sucesión es más pequeña. En las demostraciones de existencia, las potencias $p$ permanecen fijas mientras el índice auxiliar $n$ recorre los naturales. Al aplicar un límite de cocientes se verifica que el límite del denominador sea distinto de cero. Finalmente, distinguir los resultados **demostrados en la cátedra** de los **enunciados para estudio** preserva el alcance original de la clase.

### Taller de problemas y soluciones

Los ejercicios se presentan a continuación según la fuente de origen; las ampliaciones editoriales de cada apuntes permanecen expresamente identificadas.

#### Ejercicios editoriales de comprobación — cátedra 10.1

Los siguientes problemas son **elaboración editorial original**. Permiten practicar la identificación de hipótesis y la construcción de desigualdades.

**Ejercicio 1.** Sean $u_n,v_n\to L$ y $u_n\le w_n\le v_n$ para todo $n\ge17$. Demuestre $w_n\to L$ y explique el papel del número $17$.

**Ejercicio 2.** Justifique que $\lim_{n\to\infty}|\sin(n^2)|/\sqrt n=0$.

**Ejercicio 3.** Sea $q=-3/4$. Determine el límite de $q^n$ y encuentre un índice $N$ suficiente para que $|q^n|\le10^{-3}$ cuando $n\ge N$.

**Ejercicio 4.** Demuestre por la definición de convergencia que $s_n=(n-1)/(n+1)\to1$. Describa desde qué lado se aproxima a $1$.

**Ejercicio 5.** Calcule $\lim_{n\to\infty}\sqrt[n]{7}$ y $\lim_{n\to\infty}\sqrt[n]{7+(-1)^n/n}$.

**Ejercicio 6.** Verifique que las sucesiones $u_n=0$ y $v_n=1/n$ satisfacen $u_n<v_n$, y explique el alcance preciso del teorema de orden al tomar límites.

**Ejercicio 7.** Construya dos sucesiones $(a_n)$ y $(b_n)$ con $a_n\le b_n$ para todo $n$ que tengan límites diferentes. ¿Qué desigualdad deben satisfacer esos límites?

**Ejercicio 8.** Determine si converge $(-1)^n$, y redacte una demostración usando la definición de convergencia o sus subsucesiones.

#### Orientaciones y soluciones breves
1. Para $\varepsilon>0$ se toman índices $N_1,N_2$ asociados con $u_n$ y $v_n$ y se usa $N=\max\{17,N_1,N_2\}$. El índice $17$ asegura la desigualdad requerida en la cola.
2. La desigualdad $0\le|\sin(n^2)|/\sqrt n\le1/\sqrt n$ y el sándwich dan el resultado.
3. El límite es cero. Cualquier $N$ natural que cumpla $(3/4)^N\le10^{-3}$ sirve; por ejemplo $N=25$, pues $(3/4)^{25}<10^{-3}$.
4. Se tiene $|s_n-1|=2/(n+1)$. Para $\varepsilon>0$ basta escoger $N$ con $N+1\ge2/\varepsilon$. Como $s_n=1-2/(n+1)$, todos sus términos quedan por debajo de $1$.
5. Ambos límites valen $1$. En el segundo caso el término dentro de la raíz tiende a $7>0$.
6. Ambos límites son cero. La conclusión general conserva $\le$ y permite igualdad.
7. Por ejemplo, $a_n=0$ y $b_n=2$; sus límites satisfacen $0\le2$. En general, por el teorema de orden, $\lim a_n\le\lim b_n$.
8. Diverge, porque las subsucesiones de índices pares e impares son constantes de valores $1$ y $-1$, respectivamente, y una sucesión convergente transmite su límite a cada subsucesión.

#### Ejercicios para reconstruir las ideas — cátedra 10.2

Los ejercicios 1 y 2 desarrollan tareas propuestas en la grabación. Los demás son **ejercicios editoriales originales** para comprobar la transferencia de las técnicas.

**Ejercicio 1 — propuesto en clase.** Demuestre que $\sqrt[n]{1/7}\to1$ mediante el recíproco y el caso $q>1$.

**Ejercicio 2 — propuesto en clase.** Justifique $\sqrt[n]{n^2}\to1$ por dos métodos: a partir de $\sqrt[n]{n}\to1$ y mediante una cota binomial de orden tres.

**Ejercicio 3 — editorial.** Para $q=4/5$, construya $h=1/q-1$ y una cota explícita que demuestre $q^n\to0$.

**Ejercicio 4 — editorial.** Demuestre con Bernoulli de segundo orden que $n(3/4)^n\to0$; determine qué grado necesitaría para estudiar $n^5(3/4)^n$.

**Ejercicio 5 — editorial.** Analice el comportamiento de $(-2/3)^n$, $(-1)^n$ y $(-3/2)^n$. Precise cuáles son acotadas y cuáles convergen.

**Ejercicio 6 — editorial.** Dado un polinomio $P(n)$ y un número $q$ con $|q|<1$, justifique $P(n)q^n\to0$.

**Ejercicio 7 — editorial.** Defina $A=\{x>0:x^3<7\}$. Identifique un elemento de $A$, una cota superior y explique por qué $(\sup A)^3=7$.

**Ejercicio 8 — editorial.** Para $a_n=2-1/(n+1)$, pruebe que $(a_n)$ es creciente y acotada superiormente. Aplique el teorema final para obtener su límite.

**Ejercicio 9 — editorial.** Encuentre una sucesión real acotada que tenga términos en dos valores distintos infinitas veces. Justifique mediante la definición de convergencia que carece de límite real.

**Ejercicio 10 — editorial.** Sea $(\delta_n)$ una sucesión estrictamente positiva con $\delta_n\to0$. Sustituya $1/n$ por $\delta_n$ en la demostración de la existencia de $\sqrt[p]{q}$ y establezca qué índice mínimo debe escogerse para utilizar $s-\delta_n>0$.

#### Indicaciones y soluciones breves
1. Como $7^{1/n}\to1$, el álgebra de límites aplicada a $1/7^{1/n}$ da $1$.
2. Primer método: $(n^{1/n})^2\to1$. Segundo: ponga $n^2=(1+h_n)^n\ge\binom n3h_n^3$; así $0\le h_n\le[6n/((n-1)(n-2))]^{1/3}\to0$.
3. $h=1/4$; por Bernoulli, $0<(4/5)^n\le1/(1+n/4)\to0$.
4. Con $h=1/3$, $0\le n(3/4)^n\le 2/((n-1)h^2)\to0$. Para $n^5q^n$ se emplea Bernoulli de grado seis.
5. $(-2/3)^n\to0$; $(-1)^n$ es acotada y oscila; $|(-3/2)^n|\to+\infty$, por lo que la última carece de límite real.
6. Escriba $P(n)=\sum_{k=0}^d c_kn^k$ y use el límite de cada $n^k|q|^n$. Para $q=0$ los términos desde $n\ge1$ valen cero.
7. $1\in A$ y $7$ es cota superior; con $s=\sup A$ se comprueba $(s-1/n)^3\le7\le(s+1/n)^3$ para índices grandes, y el paso al límite da $s^3=7$.
8. $a_{n+1}-a_n=1/((n+1)(n+2))>0$; además $a_n<2$. Por el teorema, converge a su supremo, que vale $2$.
9. $a_n=(-1)^n$ sirve: si convergiera a $L$, las colas de índices pares e impares exigirían simultáneamente $L=1$ y $L=-1$.
10. Dado que $s>0$ y $\delta_n\to0$, elija $N$ tal que $\delta_n<s$ para $n\ge N$. Desde ese índice se repite la prueba de las dos desigualdades.

---

# Parte IV. Exponenciales y logaritmos

## La función exponencial y su inversa logarítmica

La función exponencial se construye a partir de aproximaciones y satisface una identidad que transforma sumas en productos. La inversa logarítmica permite introducir potencias de exponente real y logaritmos en bases arbitrarias.

**Grabaciones de referencia:** [grabación de la cátedra 11.1](https://www.youtube.com/watch?v=K-9dw9jW2BE), [grabación de la cátedra 11.2](https://www.youtube.com/watch?v=9PVAjc3s-Mg).

*Procedencia de este tramo: cátedra 11.1.*

### De las sucesiones a una nueva función

**En la cátedra (12:34–15:32).** El profesor anuncia el cambio de objeto de estudio: durante las semanas 9 y 10 se aprendió a reconocer y calcular límites de sucesiones; ahora ese conocimiento servirá para **construir una función**. La idea central consiste en asociar a cada número real $x$ una sucesión y, a partir de ella, un número real determinado por su límite.

Para $x\in\mathbb R$ fijo y cada entero positivo $n$, se considera

$$
E_n(x)=\left(1+\frac{x}{n}\right)^n.
$$

El símbolo $x$ designa el **parámetro** de la construcción. En cambio, $n$ es la variable de la sucesión. Una vez fijado $x$, se obtiene la lista $E_1(x),E_2(x),E_3(x),\dots$, cuyos términos se aproximan a un número cuando $n$ aumenta. La pregunta matemática fundamental es si esa aproximación posee un límite real para cada $x$.

**Definición.** Para los valores reales $x$ en los que la sucesión converge, se define

$$
\boxed{\displaystyle \exp(x):=\lim_{n\to\infty}\left(1+\frac{x}{n}\right)^n.}
$$

La **unicidad del límite**, demostrada en la cátedra 9.2, proporciona la unicidad del valor de $\exp(x)$. El **teorema de convergencia**, que ocupa la parte mayor de esta sesión, establecerá la existencia de ese valor para todo $x\in\mathbb R$. De este modo se construye una función $\exp:\mathbb R\to\mathbb R$.

**Ampliación editorial.** Al estudiar el límite solo importa el comportamiento desde cierto índice en adelante. Esta observación permite manejar todos los valores reales de $x$: aun cuando $x$ sea un número negativo de gran módulo, la base $1+x/n$ se vuelve positiva cuando $n>-x$. Desde ese índice pueden aplicarse las desigualdades necesarias.

### El exponente variable y una dificultad real

#### Un cálculo aparente
**En la cátedra (15:35–18:25).** El profesor previene contra el procedimiento informal

$$
1+\frac{x}{n}\longrightarrow 1
\qquad\Longrightarrow\qquad
\left(1+\frac{x}{n}\right)^n\longrightarrow 1^n=1.
$$

La conclusión propuesta carece de justificación: la operación de elevar a la potencia $n$ también depende del índice. La base se aproxima a $1$, mientras el exponente crece sin cota. La interacción entre estos movimientos es precisamente el problema que hay que estudiar. Para $x=0$ la expresión vale **exactamente** $1$ en cada índice; el resto de los valores de $x$ requieren la demostración.

La advertencia se puede reformular en términos de **álgebra de límites**. El teorema que permite trasladar el límite a una potencia $k$ trata un exponente natural **fijo** $k$. En $E_n(x)$ el exponente cambia al pasar del índice $n$ al índice $n+1$.

#### Un caso comparable que sí admite una estimación simple
**En la cátedra (18:28–22:18).** El profesor considera

$$
T_n(x)=\left(\frac12+\frac{x}{n}\right)^n.
$$

La base tiende a $1/2$. Para un $x$ fijo, la definición de convergencia asegura que, desde algún índice $N(x)$, se cumple

$$
\frac14\le \frac12+\frac{x}{n}\le\frac34.
$$

Son números positivos, de modo que elevar a la potencia entera $n$ conserva el orden:

$$
\left(\frac14\right)^n
\le T_n(x)\le
\left(\frac34\right)^n,
\qquad n\ge N(x).
$$

Ambas sucesiones geométricas extremas convergen a cero. El **teorema del sándwich** demuestra, por consiguiente,

$$
\boxed{\displaystyle \lim_{n\to\infty}\left(\frac12+\frac{x}{n}\right)^n=0.}
$$

La elección de $1/4$ y $3/4$ cumple la función esencial de situar las bases de las sucesiones mayorante y minorante dentro del intervalo $(0,1)$. Si, por ejemplo, la base tiende a $7/8$, pueden utilizarse bases fijas como $13/16$ y $15/16$, de acuerdo con la explicación de [24:52](https://www.youtube.com/watch?v=K-9dw9jW2BE&t=1492s).

![Esquema editorial: dos regímenes para bases que tienden a 1/2 y a 1.](figuras/IC2021_Catedra_11_1/01_dos_regimenes.png)

*Figura 1 (esquema editorial).* Para el mismo parámetro $x=1.6$, la potencia con base límite $1/2$ tiende a cero; la potencia con base límite $1$ se aproxima a $\exp(1.6)$. Las curvas han sido calculadas a partir de sus fórmulas, no extraídas de la pizarra.

#### La cota deja de ser informativa cuando la base tiende a uno
**En la cátedra (22:18–29:34).** Ahora, para $0<\varepsilon<1$ y desde cierto índice,

$$
1-\varepsilon\le1+\frac{x}{n}\le1+\varepsilon.
$$

Tras elevar a $n$:

$$
(1-\varepsilon)^n\le E_n(x)\le(1+\varepsilon)^n.
$$

La cota inferior converge a cero, mientras la superior es una sucesión creciente sin cota superior. El orden obtenido permite ubicar cada término, pero **sus extremos no convergen al mismo número**. Por ello se necesita una cota superior que dependa de una manera más adecuada de $n$.

**Ampliación editorial.** Para cualquier $a$ con $0<a<1$ y para $x$ fijo,

$$
\lim_{n\to\infty}\left(a+\frac{x}{n}\right)^n=0.
$$

En efecto, se elige $r$ con $a<r<1$; eventualmente $|a+x/n|\le r$ y por tanto

$$
0\le \left|a+\frac{x}{n}\right|^n\le r^n\to0.
$$

La cota mediante el valor absoluto permite tratar de forma uniforme cualquier signo inicial de la base. En esta cátedra la situación crítica es el límite de base $a=1$.

### Positividad eventual y estrategia de convergencia

**En la cátedra (29:35–37:00).** El caso $x=0$ produce $E_n(0)=1$, de donde

$$\boxed{\exp(0)=1.}$$

Para cualquier otro $x\in\mathbb R$ se comprueba la equivalencia

$$
1+\frac{x}{n}>0
\quad\Longleftrightarrow\quad n>-x,
\qquad n\ge1.
$$

Por la propiedad arquimediana, existe un índice natural $N_x$ tal que todos los $n\ge N_x$ satisfacen $n>-x$. Para esos índices, $E_n(x)$ es positivo. Es preciso explicitar esta condición al operar con cocientes de términos y potencias de desigualdades; la fórmula original se encuentra definida para todo $n\ge1$, pero la positividad utilizada en las pruebas se establece en una cola de la sucesión.

San Martín elige como método el **teorema de las sucesiones monótonas acotadas**: una sucesión creciente y acotada superiormente converge, y su límite es el supremo del conjunto formado por sus términos. Así, la prueba consta de dos tareas genuinamente distintas:

1. demostrar $E_{n+1}(x)\ge E_n(x)$ desde un índice suficiente;
2. encontrar una cota superior real independiente de $n$.

El teorema de monotonía y acotación se había **enunciado** en la cátedra 10.2. Su demostración a partir del axioma del supremo pertenece al desarrollo teórico complementario.

### Demostración de monotonía

#### Elegir el cociente apropiado
**En la cátedra (37:01–43:00).** Para una sucesión de términos positivos, el signo de la diferencia $E_{n+1}-E_n$ y la comparación del cociente $E_{n+1}/E_n$ con $1$ expresan el mismo orden. En este ejercicio resulta más conveniente el cociente porque sus potencias permiten una factorización apropiada.

Se parte de

$$
\frac{E_{n+1}(x)}{E_n(x)}
=\frac{\left(1+\frac{x}{n+1}\right)^{n+1}}
{\left(1+\frac{x}{n}\right)^n}
=\left(\frac{n+x+1}{n+1}\right)^{n+1}
\left(\frac{n}{n+x}\right)^n.
$$

La maniobra de factorizar con **exponente común $n+1$**, que el profesor presenta como una elección estratégica, conduce a

$$
\frac{E_{n+1}(x)}{E_n(x)}
=\underbrace{\left(
\frac{n(n+x+1)}{(n+1)(n+x)}
\right)^{n+1}}_{\text{aplicable a Bernoulli I}}
\frac{n+x}{n}.
$$

El numerador y el denominador de la fracción que aparece dentro de la potencia difieren en $x$:

$$
\frac{n(n+x+1)}{(n+1)(n+x)}
=\frac{(n+1)(n+x)-x}{(n+1)(n+x)}
=1-\frac{x}{(n+1)(n+x)}.
$$

#### Aplicar Bernoulli I
**Demostración desarrollada (43:00–53:35).** Para $m\in\mathbb N$ y $h>-1$, la desigualdad de Bernoulli I afirma

$$
(1+h)^m\ge1+mh.
$$

Tomamos $m=n+1$ y

$$h=-\frac{x}{(n+1)(n+x)}.$$

La hipótesis $h>-1$ se cumple cuando $n>-x$. Para $x\le0$ el número $h$ es no negativo; para $x>0$, la desigualdad $x<(n+1)(n+x)$ se verifica para todo $n\ge1$.

Por Bernoulli,

$$
\left(1-\frac{x}{(n+1)(n+x)}\right)^{n+1}
\ge 1-\frac{x}{n+x}
=\frac{n}{n+x}.
$$

El factor $(n+x)/n$ es positivo desde el índice elegido. De aquí,

$$
\frac{E_{n+1}(x)}{E_n(x)}
\ge \frac{n}{n+x}\frac{n+x}{n}=1.
$$

Hemos demostrado que, para cada real fijo $x$, existe un $N_x$ tal que

$$
\boxed{E_{n+1}(x)\ge E_n(x)\quad(n\ge N_x).}
$$

La **monotonía eventual** es suficiente para estudiar la convergencia. Los términos anteriores a $N_x$ constituyen una parte finita de la sucesión.

![Esquema editorial: monotonía eventual de la sucesión exponencial para dos parámetros.](figuras/IC2021_Catedra_11_1/02_monotonia.png)

*Figura 2 (esquema editorial).* Para $x=-2$ y $x=2$, las colas positivas de $E_n(x)$ crecen hacia sus límites respectivos. La desigualdad que garantiza esta monotonía se ha demostrado algebraicamente.

### Bernoulli III: una desigualdad superior

**En la cátedra (57:01–1:06:10).** Bernoulli I da la cota inferior

$$
E_n(x)=\left(1+\frac{x}{n}\right)^n\ge1+x.
$$

Como la sucesión crece, interesa además una cota **superior**. El profesor la obtiene mediante otra versión de las desigualdades de Bernoulli, que denomina *Bernoulli III*.

**Teorema (Bernoulli III).** Si $n\ge1$ y

$$-1<h<\frac1n,$$

entonces

$$
\boxed{(1+h)^n\le\frac1{1-nh}.}
$$

#### Demostración de Bernoulli III
**Demostración desarrollada.** Para cada real $h$ se tiene $1-h^2\le1$. Si $-1<h<1$, ambos factores $1-h$ y $1+h$ son positivos y, por consiguiente,

$$
(1-h)^n(1+h)^n=(1-h^2)^n\le1.
$$

La primera desigualdad de Bernoulli, aplicada a $-h$, asegura

$$
(1-h)^n\ge1-nh.
$$

La hipótesis $h<1/n$ garantiza $1-nh>0$. Multiplicando por el factor positivo $(1+h)^n$ se obtiene

$$
(1-nh)(1+h)^n\le (1-h)^n(1+h)^n\le1.
$$

Dividir por $1-nh$ concluye la prueba. Es una desigualdad de naturaleza distinta de Bernoulli I: proporciona una mayoración de la potencia por una expresión racional.

#### La cota para $x<1$
**En la cátedra (1:06:11–1:08:24).** Sustituyendo $h=x/n$ en Bernoulli III, la condición $h>-1$ se traduce en $n>-x$, mientras que $h<1/n$ equivale a $x<1$. Por tanto, cuando $x<1$ y $n$ es suficientemente grande,

$$
\boxed{0<E_n(x)=\left(1+\frac{x}{n}\right)^n\le\frac1{1-x}.}
$$

La cota depende del parámetro fijo $x$ y permanece constante cuando cambia $n$. Ya se dispone de monotonía creciente y acotación superior, así que $E_n(x)$ converge para cada $x<1$.

![Esquema editorial: cotas para la sucesión exponencial con x=0.6.](figuras/IC2021_Catedra_11_1/03_cotas_bernoulli.png)

*Figura 3 (esquema editorial).* La cota inferior de Bernoulli I y la superior de Bernoulli III en el caso $x=0.6$. Ambas son válidas, aunque la superior es deliberadamente holgada. Su utilidad es establecer acotación.

#### Completar el caso $x\ge1$
**En la cátedra (1:14:37–1:22:09).** Sea $x\ge1$. Por la propiedad arquimediana podemos elegir un entero $m\ge2$ con $m>x$. El número $y=x/m$ cumple $0<y<1$, por lo que la estimación anterior vale para $E_n(y)$:

$$
E_n(x/m)\le\frac1{1-x/m}.
$$

La monotonía ya demostrada para el parámetro $x$ permite comparar los términos de índices $n$ y $mn$:

$$
E_n(x)\le E_{mn}(x).
$$

Por otro lado, debido a las propiedades de las potencias,

$$
E_{mn}(x)=\left(1+\frac{x}{mn}\right)^{mn}
=\left[\left(1+\frac{x/m}{n}\right)^n\right]^m
=\bigl(E_n(x/m)\bigr)^m.
$$

Como todas las bases son positivas en los índices usados,

$$
E_n(x)\le E_{mn}(x)
\le\left(\frac1{1-x/m}\right)^m.
$$

La expresión del extremo derecho es un número real fijo. Hemos probado la acotación superior de la sucesión para **cada $x\ge1$**; combinada con el caso $x<1$, proporciona una prueba para todos los reales.

**Teorema principal de la cátedra.** Para cada $x\in\mathbb R$ la sucesión $E_n(x)$ es eventualmente positiva, eventualmente creciente y acotada superiormente. En consecuencia, converge a un número real estrictamente positivo. Queda definida

$$
\boxed{\exp:\mathbb R\longrightarrow(0,\infty),\qquad
x\longmapsto \lim_{n\to\infty}\left(1+\frac{x}{n}\right)^n.}
$$

La positividad del límite se sigue de la monotonía de la cola y de la existencia de un término positivo: $\exp(x)\ge E_{N_x}(x)>0$.

**Ampliación editorial.** La prueba de la monotonía de $E_n(x)$ establece que el límite coincide con el supremo de la cola positiva. De allí nacen desigualdades útiles:

$$
E_n(x)\le\exp(x)\le
\begin{cases}
\dfrac1{1-x},&x<1,\\[6pt]
\left(1-\dfrac xm\right)^{-m},&x\ge1,\ m\in\mathbb N,\ m>x.
\end{cases}
$$

En la primera desigualdad se toma $n$ desde un índice suficientemente grande cuando $x<0$.

### El número $e$ surge de esta construcción

**En la cátedra (1:23:29–1:28:38).** El número tradicionalmente denominado $e$ se define como

$$
\boxed{e:=\exp(1)=\lim_{n\to\infty}\left(1+\frac1n\right)^n.}
$$

Para $n\ge1$ y utilizando la mayoración general con $x=1$ y $m=n+1$ se obtiene

$$
\boxed{\left(1+\frac1n\right)^n\le e\le
\left(1+\frac1n\right)^{n+1}.}
$$

La primera sucesión de cotas crece y la segunda decrece. Ambas convergen al mismo número $e$. En consecuencia, podemos obtener valores aproximados usando dos sucesiones que lo encierran.

| $n$ | Cota inferior $L_n$ | Cota superior $U_n$ |
|---:|---:|---:|
| 1 | 2.000000 | 4.000000 |
| 2 | 2.250000 | 3.375000 |
| 5 | 2.488320 | 2.985984 |
| 10 | 2.593742 | 2.853117 |
| 100 | 2.704814 | 2.731862 |
| 1000 | 2.716924 | 2.719641 |

El valor decimal de referencia es $e\approx2.718281828459\ldots$. El docente sitúa el número entre dos cotas explícitas e ilustra su aproximación mediante el cálculo con índices cada vez mayores.

![Esquema editorial: las cotas L_n y U_n aproximan el número e.](figuras/IC2021_Catedra_11_1/04_cotas_e.png)

*Figura 4 (esquema editorial).* Convergencia desde abajo y desde arriba de las sucesiones de cotas que definen el número $e$.

**Ampliación editorial.** La diferencia de las cotas se puede calcular exactamente:

$$
U_n-L_n=\left(1+\frac1n\right)^n\frac1n=\frac{L_n}{n}.
$$

Al ser $L_n\le4$ por la cota anterior, se deduce $0\le U_n-L_n\le4/n\to0$. Esta estimación permite demostrar que las dos sucesiones de cotas tienen el mismo límite sin recurrir a series de potencias.

### Primera ley estructural: de la suma al producto

**En la cátedra (1:28:48–1:30:09).** La propiedad que distingue a la función construida es

$$
\boxed{\exp(x+y)=\exp(x)\,\exp(y),\qquad x,y\in\mathbb R.}
$$

En la identidad, la suma de los parámetros se transforma en el producto de los valores de la función. La demostración parte de las definiciones mediante sucesiones; requiere prestar atención al término cruzado que aparece al multiplicar dos binomios.

#### Un lema para perturbaciones pequeñas
**En la cátedra (1:30:09–1:34:33).** El profesor introduce un lema técnico de aplicación más amplia.

**Lema.** Sea $(h_n)$ una sucesión real que cumple

$$
h_n\longrightarrow0,\qquad nh_n\longrightarrow0.
$$

Entonces, desde un índice suficientemente grande la base $1+h_n$ es positiva y

$$
\boxed{(1+h_n)^n\longrightarrow1.}
$$

**Demostración desarrollada.** Bernoulli I y III, aplicados cuando $-1<h_n<1/n$, proporcionan

$$
1+nh_n\le(1+h_n)^n\le\frac1{1-nh_n}.
$$

Puesto que $nh_n\to0$, eventualmente $nh_n<1$ y, además, $h_n>-1$, por lo que ambas desigualdades son válidas. El extremo izquierdo converge a $1$ y también el derecho, gracias al álgebra de límites. El teorema del sándwich concluye la demostración.

**En la cátedra.** San Martín subraya que el lema se aplica a perturbaciones **más pequeñas que $1/n$ en el sentido de cocientes**. Por ejemplo, $h_n=x/n^2$ da $nh_n=x/n\to0$ y, por tanto,

$$
\lim_{n\to\infty}\left(1+\frac{x}{n^2}\right)^n=1.
$$

En cambio, para $h_n=x/n$ se tiene $nh_n=x$; el límite relevante se llama precisamente $\exp(x)$, y el lema solo proporciona $1$ cuando $x=0$.

![Esquema editorial: un caso del lema para perturbaciones pequeñas.](figuras/IC2021_Catedra_11_1/05_lema_nulo.png)

*Figura 5 (esquema editorial).* Para $h_n=1/n^2$ se muestran $(1+h_n)^n$ y sus dos cotas bernoullianas, todas aproximándose a $1$.

#### Demostración de la igualdad fundamental
**Demostración desarrollada (1:35:52–1:43:38).** Por el álgebra de límites y la convergencia de cada sucesión exponencial,

$$
\begin{aligned}
\exp(x)\exp(y)
&=\lim_{n\to\infty}
\left(1+\frac xn\right)^n
\left(1+\frac yn\right)^n\\
&=\lim_{n\to\infty}
\left(1+\frac{x+y}{n}+\frac{xy}{n^2}\right)^n.
\end{aligned}
$$

El sumando $xy/n^2$ es el término cruzado. Para compararlo con la definición de $\exp(x+y)$ escribimos, cuando $n$ es suficientemente grande,

$$
1+\frac{x+y}{n}+\frac{xy}{n^2}
=\left(1+\frac{x+y}{n}\right)
\left(1+\frac{\frac{xy}{n^2}}{1+\frac{x+y}{n}}\right).
$$

Definimos

$$
h_n:=\frac{xy}{n^2\left(1+\frac{x+y}{n}\right)}
=\frac{xy}{n(n+x+y)}.
$$

Como $x$ e $y$ son constantes reales,

$$
h_n\longrightarrow0,
\qquad nh_n=\frac{xy}{n+x+y}\longrightarrow0.
$$

El lema demuestra que $(1+h_n)^n\to1$. Factorizando y tomando límites,

$$
\begin{aligned}
\exp(x)\exp(y)
&=\lim_{n\to\infty}
\left(1+\frac{x+y}{n}\right)^n
(1+h_n)^n\\
&=\exp(x+y)\cdot1
=\exp(x+y).
\end{aligned}
$$

La prueba ha convertido la perturbación $xy/n^2$ en un factor cuyo límite es $1$, y esta operación explica la validez de la ley exponencial. La cátedra concluye aquí la demostración central.

### Consecuencias y conexiones matemáticas

**Ampliación editorial.** La igualdad fundamental, junto con $\exp(0)=1$ y la positividad ya demostrada, permite deducir otras propiedades con argumentos breves. Se distinguen de los dos teoremas principales efectivamente desarrollados en la clase.

#### Reciprocidad
Tomando $y=-x$ se obtiene

$$
1=\exp(0)=\exp(x)\exp(-x).
$$

Como $\exp(x)>0$, existe su recíproco y queda

$$\boxed{\exp(-x)=\frac1{\exp(x)}.}$$

#### Potencias con exponentes enteros
Por inducción en $k\in\mathbb N$, la ley de adición da

$$
\exp(kx)=[\exp(x)]^k.
$$

Para $k\in\mathbb Z$ la misma relación se extiende usando reciprocidad. En particular, $\exp(k)=e^k$ para cada entero $k$.

#### Monotonía de la función exponencial
Para cada real $t>0$, Bernoulli I aplicado a $E_n(t)$ implica $E_n(t)\ge1+t$. Al tomar límites,

$$\exp(t)\ge1+t>1.$$

Si $x<y$, entonces $y=x+(y-x)$ con $y-x>0$. Por la ley de adición,

$$
\exp(y)=\exp(x)\exp(y-x)>\exp(x).
$$

Así, la función exponencial es **estrictamente creciente** en $\mathbb R$. Esta propiedad se desprende del material establecido, aunque su demostración pertenece a la presente ampliación.

#### Acotación y orden: dos tipos de monotonía
La **monotonía de la sucesión $E_n(x)$**, para un parámetro fijo $x$, compara $E_n(x)$ con $E_{n+1}(x)$. La **monotonía de la función $x\mapsto\exp(x)$** compara $\exp(x)$ con $\exp(y)$ cuando $x<y$. Son afirmaciones distintas y requieren argumentos propios. La primera es el instrumento de existencia; la segunda es una consecuencia de la ley de adición.

### Preguntas de la grabación y precisión terminológica

**En la cátedra (1:44:25–1:49:17).** A propósito de una consulta de los asistentes, el profesor distingue tres objetos: la **sucesión** $E_n(x)$, su **límite** $\exp(x)$ y una **cota superior** obtenida para sus términos. Dado que la cola es creciente, su límite coincide con el supremo de la cola y está por encima de cada término; la desigualdad de Bernoulli III permite acotarlo a su vez por una expresión independiente de $n$. Este orden de ideas justifica la aproximación numérica de $e$.

**En la cátedra (1:49:31–1:51:17).** El profesor aclara el uso de *creciente* y *decreciente* en la convención **no estricta**: una función constante satisface ambas condiciones porque

$$f(x_1)\le f(x_2)\qquad\text{y}\qquad f(x_1)\ge f(x_2)$$

cuando sus valores son iguales. En la convención estricta se emplean $<$ y $>$. La distinción importa al negar una proposición cuantificada; la negación de una condición de tipo $\le$ exige una desigualdad estricta $>$ para algún par de puntos. El mismo cuidado rige al estudiar sucesiones monótonas.

*Procedencia de este tramo: cátedra 11.2.*

### La igualdad de adición organiza toda la clase

**En la cátedra (10:45–13:28).** La semana 11 comenzó construyendo, para cada $x\in\mathbb R$, la función

$$
\exp(x):=\lim_{n\to\infty}\left(1+\frac{x}{n}\right)^n.
$$

En la cátedra 11.1 se demostró que el límite existe para todo real, que $\exp(x)>0$, que $\exp(0)=1$ y, mediante un lema sobre perturbaciones de orden $o(1/n)$, la **igualdad fundamental**

$$
\boxed{\exp(x+y)=\exp(x)\exp(y),\qquad x,y\in\mathbb R.}
$$

Esta identidad expresa una correspondencia entre dos operaciones: la suma de números reales y el producto de números reales positivos. La exposición del 12 de junio estudia las consecuencias de esa correspondencia. Primero obtiene nuevas fórmulas algebraicas; después emplea la desigualdad de Bernoulli para conocer el comportamiento global de la función, demostrar que alcanza cualquier valor positivo y construir su inversa.

En particular, la exposición distingue tres preguntas que se encadenan: **cómo calcular** una exponencial mediante otras exponenciales; **cómo ordenar** sus valores cuando varía el argumento; y **cómo resolver** la ecuación $\exp(x)=u$ para un real positivo $u$. Esta última pregunta dará origen al logaritmo natural.

### Corolarios de la igualdad fundamental

#### El opuesto se transforma en recíproco
**En la cátedra (13:28–15:58).** Elegimos $y=-x$ en la igualdad fundamental:

$$
1=\exp(0)=\exp(x-x)=\exp(x)\exp(-x).
$$

Como $\exp(x)>0$, el producto admite división por $\exp(x)$. Por consiguiente,

$$
\boxed{\exp(-x)=\frac1{\exp(x)}.}
$$

Si ahora escribimos una diferencia como suma con el opuesto, obtenemos

$$
\boxed{\exp(x-y)=\exp(x)\exp(-y)=\frac{\exp(x)}{\exp(y)}.}
$$

Esta relación constituye la primera familia de corolarios. La suma de argumentos se expresa mediante producto de valores; la diferencia de argumentos se expresa mediante cociente de valores. El paso entre las dos fórmulas queda enteramente justificado por la identidad de adición y por la positividad de la función.

#### Múltiplos enteros del argumento
**En la cátedra (16:01–20:17).** Con $y=x$,

$$
\exp(2x)=\exp(x)\exp(x)=(\exp x)^2.
$$

Iterando,

$$
\exp(3x)=\exp(2x+x)=(\exp x)^3.
$$

San Martín propone formalizar la pauta mediante **inducción matemática**. La afirmación es

$$
\boxed{\exp(kx)=(\exp x)^k\qquad (k\in\mathbb Z).}
$$

**Ampliación editorial: demostración de la inducción propuesta.** Para $k=0$, ambos miembros valen $1$. Suponiendo $\exp(kx)=(\exp x)^k$ para cierto natural $k$, se tiene

$$
\exp((k+1)x)=\exp(kx+x)=\exp(kx)\exp(x)
=(\exp x)^{k+1}.
$$

Esto establece la fórmula para los naturales. Si $k=-m$, con $m\ge1$, la identidad del recíproco da

$$
\exp(-mx)=\frac1{\exp(mx)}=\frac1{(\exp x)^m}=(\exp x)^{-m}.
$$

La demostración conserva explícito el lugar en que se utilizan una hipótesis de inducción y una propiedad anterior.

#### Argumentos fraccionarios y raíces
**En la cátedra (20:20–23:44).** Consideremos un entero $n\ge1$. La identidad anterior aplicada al argumento $x/n$ establece

$$
\left(\exp\left(\frac{x}{n}\right)\right)^n
=\exp\left(n\frac{x}{n}\right)=\exp(x).
$$

La exponencial del argumento $x/n$ es un número positivo. Por unicidad de la raíz enésima positiva,

$$
\boxed{\exp\left(\frac{x}{n}\right)=\sqrt[n]{\exp(x)}.}
$$

Ahora sea $q=m/n\in\mathbb Q$ con $m\in\mathbb Z$ y $n\ge1$. Al combinar el resultado con la fórmula de los múltiplos enteros,

$$
\exp(qx)
=\exp\left(m\frac{x}{n}\right)
=\left(\sqrt[n]{\exp(x)}\right)^m.
$$

El lado derecho posee precisamente el significado de una potencia racional de base positiva. Así llegamos a

$$
\boxed{\exp(qx)=(\exp x)^q,\qquad q\in\mathbb Q.}
$$

En particular, al poner $x=1$ y recordar que $e:=\exp(1)$,

$$
\exp(q)=e^q\qquad(q\in\mathbb Q).
$$

#### La potencia racional y su base positiva
**En la cátedra (23:47–28:30).** Para $a>0$ y $q=m/n\in\mathbb Q$, con $n\ge1$, la **potencia racional** $a^q$ es el único número positivo que satisface

$$
(a^q)^n=a^m;
\qquad\text{equivalentemente,}\qquad
\boxed{a^{m/n}:=\sqrt[n]{a^m}.}
$$

La definición debe depender del número racional $q$, cuyos representantes fraccionarios pueden ser distintos. **Ampliación editorial.** Esa independencia puede comprobarse directamente. Si $m/n=p/r$, entonces $mr=np$. Los números positivos $z:=\sqrt[n]{a^m}$ y $w:=\sqrt[r]{a^p}$ satisfacen

$$
z^{nr}=a^{mr}=a^{np}=w^{nr}.
$$

La función $t\mapsto t^{nr}$ es estrictamente creciente sobre $(0,\infty)$; por tanto $z=w$. Así, la potencia racional está bien definida.

La clase examina también la raíz cúbica real de un número negativo como ejemplo de una **operación con dominio distinto**. En efecto, $\sqrt[3]{-1}=-1$. Si se pretendiese aplicar a una base negativa la fórmula de potencias racionales sin conservar la independencia de las representaciones $1/3=2/6$, aparecerían las expresiones $\sqrt[3]{-1}=-1$ y $\sqrt[6]{(-1)^2}=1$. El ejemplo muestra por qué la definición del curso toma como base un número estrictamente positivo. La raíz cúbica real mantiene su definición propia y sus propiedades.

### La desigualdad fundamental de la exponencial

#### Del límite de sucesiones a una cota universal
**En la cátedra (34:56–37:58).** Durante la clase precedente se probó que, para cada $x\in\mathbb R$, la sucesión

$$
E_n(x)=\left(1+\frac{x}{n}\right)^n
$$

es eventualmente positiva, creciente y convergente a $\exp(x)$. En consecuencia, todo término de la cola positiva satisface $E_n(x)\le\exp(x)$.

Por otro lado, para $n$ suficientemente grande se cumple $x/n>-1$. La desigualdad de Bernoulli, aplicada a $h=x/n$, asegura que

$$
\left(1+\frac{x}{n}\right)^n\ge1+n\frac{x}{n}=1+x.
$$

Por transitividad,

$$
\boxed{\exp(x)\ge1+x\qquad(x\in\mathbb R).}
$$

**Demostración desarrollada.** Se han utilizado dos cotas de naturaleza distinta: Bernoulli proporciona una cota inferior uniforme y la monotonía de los términos proporciona una cota superior dada por su límite. El encadenamiento $1+x\le E_n(x)\le\exp(x)$ conserva la desigualdad al eliminar el término intermedio. La condición sobre $n$ depende de $x$ y basta para todo el razonamiento.

![Esquema editorial: gráfica de la exponencial y de su cota inferior lineal.](figuras/IC2021_11_2/01_desigualdad_exponencial.png){width=90%}

*Figura 1 (esquema editorial).* La curva $\exp(x)$ se sitúa sobre la recta $1+x$. Ambas pasan por $(0,1)$. La figura representa la desigualdad fundamental y facilita identificar su papel en los argumentos posteriores.

#### Positividad, valores respecto de uno y crecimiento
**En la cátedra (38:08–45:50).** Para $x>0$, la desigualdad fundamental implica

$$
\exp(x)\ge1+x>1.
$$

Para $x<0$ el opuesto $-x$ es positivo, y por tanto $\exp(-x)>1$. La identidad del recíproco produce

$$
0<\exp(x)=\frac1{\exp(-x)}<1.
$$

Junto con $\exp(0)=1$, obtenemos tres situaciones ordenadas:

$$
\begin{array}{c|c}
\text{Argumento} & \text{Valor de la exponencial}\\\hline
x<0 & 0<\exp(x)<1\\
x=0 & \exp(x)=1\\
x>0 & \exp(x)>1
\end{array}
$$

Para estudiar la comparación entre valores de la función, tomemos $x_1<x_2$. Entonces $x_2-x_1>0$ y

$$
\exp(x_2-x_1)>1.
$$

Usando la fórmula de la diferencia,

$$
\frac{\exp(x_2)}{\exp(x_1)}>1.
$$

Dado que $\exp(x_1)>0$, concluimos

$$
\boxed{x_1<x_2\quad\Longrightarrow\quad \exp(x_1)<\exp(x_2).}
$$

Esta propiedad describe el **crecimiento estrictamente monótono** de la función exponencial en toda la recta real. En particular, garantiza su inyectividad: cada valor de la imagen posee un único argumento.

### La exponencial alcanza todos los reales positivos

#### El problema que resta por resolver
**En la cátedra (45:50–50:40).** San Martín formula el teorema de alcance de valores: para cada $y>0$ existe $x\in\mathbb R$ tal que $\exp(x)=y$. Su demostración usa la propiedad del supremo y dos familias de sucesiones ya estudiadas, recuperando el método aplicado anteriormente a la existencia de raíces.

La idea es construir el real buscado como frontera de los argumentos cuyos valores exponenciales están por debajo de $y$. La monotonía estricta establece el orden de esos argumentos; la propiedad del supremo suministra una frontera; las perturbaciones $1/n$ permiten identificar el valor de la función en esa frontera.

#### Las dos sucesiones auxiliares
**En la cátedra (50:40–55:03).** Como $e=\exp(1)>1$,

$$
\exp(-n)=e^{-n}=\left(\frac1e\right)^n\longrightarrow0
\qquad(n\to\infty).
$$

Además,

$$
\exp(n)=e^n=\frac1{\exp(-n)}
$$

crece más allá de cualquier cota superior. Esta segunda conclusión puede justificarse directamente: para cualquier $M>0$, la primera convergencia permite elegir $n$ tal que $0<\exp(-n)<1/M$, y de ahí $\exp(n)>M$.

Las dos sucesiones tienen funciones distintas en la demostración: la primera asegura la existencia de argumentos con exponencial menor que el $y$ dado; la segunda suministra argumentos cuyo valor exponencial supera $y$.

#### Construcción mediante el axioma del supremo
**Demostración desarrollada (55:03–1:11:25).** Fijemos un real $y>0$ y consideremos

$$
A_y:=\{x\in\mathbb R:\exp(x)<y\}.
$$

**Primera etapa: existencia de elementos.** Dado que $\exp(-n)\to0$, existe $n_0\ge1$ con $\exp(-n_0)<y$. Por tanto $-n_0\in A_y$ y el conjunto posee elementos.

**Segunda etapa: cota superior.** Como $\exp(n)$ crece por encima de toda cota, existe $m_0\ge1$ tal que $y<\exp(m_0)$. Si $x\in A_y$, entonces

$$
\exp(x)<y<\exp(m_0).
$$

La monotonía estricta obliga a $x<m_0$. Así, $m_0$ es cota superior de $A_y$.

**Tercera etapa: el supremo.** El axioma del supremo permite definir

$$
s:=\sup A_y\in\mathbb R.
$$

Para cualquier entero $n\ge1$ se tienen las dos desigualdades

$$
\boxed{\exp\left(s-\frac1n\right)
\le y\le
\exp\left(s+\frac1n\right).}
$$

En efecto, si $\exp(s+1/n)<y$, entonces $s+1/n\in A_y$, contradiciendo que $s$ es una cota superior. Por el otro lado, si $\exp(s-1/n)>y$, la monotonía de $\exp$ asegura que todo $x\in A_y$ satisface $x<s-1/n$: aparecería una cota superior estrictamente menor que $s$, contradiciendo la definición de supremo. En ambos argumentos la igualdad queda admitida de manera correcta.

**Cuarta etapa: paso al límite sin utilizar continuidad previa.** La igualdad fundamental permite escribir

$$
\exp(s)\exp\left(-\frac1n\right)
\le y\le
\exp(s)\exp\left(\frac1n\right).
$$

La identidad de exponentes fraccionarios, obtenida anteriormente, transforma los extremos en

$$
\frac{\exp(s)}{\sqrt[n]{e}}
\le y\le
\exp(s)\sqrt[n]{e}.
$$

La clase 10.2 demostró que $\sqrt[n]{e}\to1$. En consecuencia, ambos extremos convergen a $\exp(s)$. El orden de límites conduce a

$$
\boxed{\exp(s)=y.}
$$

La prueba establece que cada $y>0$ es alcanzado. Junto con el crecimiento estrictamente monótono, establece también que el argumento $s$ es único.

![Esquema editorial: construcción del argumento mediante el supremo.](figuras/IC2021_11_2/03_construccion_supremo.png){width=90%}

*Figura 2 (esquema editorial).* Se fija un nivel $y>0$ y se determina $s=\sup A_y$. Los argumentos $s-1/n$ y $s+1/n$ producen dos valores exponenciales que encierran el nivel $y$.

![Esquema editorial: dos sucesiones derivadas de las raíces enésimas de e.](figuras/IC2021_11_2/05_aproximaciones_del_supremo.png){width=90%}

*Figura 3 (esquema editorial).* Las sucesiones $\sqrt[n]{e}$ y $1/\sqrt[n]{e}$ convergen a $1$ por lados opuestos, como requiere el paso al límite del argumento anterior.

**Conclusión de la cátedra.** La función

$$
\exp:\mathbb R\longrightarrow(0,\infty)
$$

es estrictamente creciente y alcanza cada elemento del codominio. Por ello es una **biyección** de $\mathbb R$ sobre $(0,\infty)$.

### El logaritmo natural como función inversa

#### Definición y dominios
**En la cátedra (1:16:56–1:19:59).** Una función biyectiva determina una función inversa que devuelve el único argumento asociado a cada valor de su imagen. La biyección exponencial construida en la sección anterior permite definir

$$
\boxed{\ln:(0,\infty)\longrightarrow\mathbb R,
\qquad \ln:=\exp^{-1}.}
$$

En esta definición, el **logaritmo natural** $\ln(u)$ de un real positivo $u$ es el único real $x$ que cumple $\exp(x)=u$. La equivalencia fundamental es

$$
\boxed{\exp(x)=u\quad\Longleftrightarrow\quad x=\ln(u),
\qquad x\in\mathbb R,\ u>0.}
$$

De la inversión se deducen las identidades de composición

$$
\exp(\ln u)=u\quad(u>0),
\qquad
\ln(\exp x)=x\quad(x\in\mathbb R).
$$

El dominio de $\ln$ es $(0,\infty)$ porque este conjunto es el recorrido completo de $\exp$; su recorrido es $\mathbb R$ porque $\exp$ recibe como argumento todos los números reales. Dado que la exponencial es estrictamente creciente, su inversa $\ln$ también lo es. En particular,

$$
\ln 1=0,\qquad \ln e=1,
$$

y $\ln u<0$ cuando $0<u<1$, mientras que $\ln u>0$ cuando $u>1$.

![Esquema editorial: exponencial y logaritmo como funciones inversas.](figuras/IC2021_11_2/02_exponencial_logaritmo.png){width=88%}

*Figura 4 (esquema editorial).* Las gráficas $y=\exp(x)$ y $y=\ln(x)$ son reflejos respecto de la recta $y=x$. Sus dominios y recorridos se intercambian al invertir la función.

#### La regla del producto
**En la cátedra (1:19:59–1:22:53).** Sean $u,v>0$. Los números $\ln u$ y $\ln v$ pertenecen a $\mathbb R$, así que la igualdad fundamental permite calcular

$$
\exp(\ln u+\ln v)
=\exp(\ln u)\exp(\ln v)
=uv.
$$

Al aplicar la inversa a ambos miembros,

$$
\boxed{\ln(uv)=\ln u+\ln v\qquad(u,v>0).}
$$

La **igualdad fundamental del logaritmo** expresa una correspondencia en el sentido inverso a la exponencial: el producto de positivos se transforma en suma de reales. De igual manera, a partir de la regla exponencial de la diferencia se obtiene

$$
\boxed{\ln\left(\frac uv\right)=\ln u-\ln v\qquad(u,v>0).}
$$

#### El logaritmo de una potencia racional
**En la cátedra (1:23:17–1:26:12).** Para $u>0$ y $q\in\mathbb Q$, la identidad $\exp(qx)=(\exp x)^q$ aplicada a $x=\ln u$ da

$$
\exp(q\ln u)=(\exp(\ln u))^q=u^q.
$$

Al invertir,

$$
\boxed{\ln(u^q)=q\ln u\qquad(u>0,\ q\in\mathbb Q).}
$$

El desarrollo lógico es importante: primero se obtiene una propiedad de la exponencial, luego se inserta un argumento real conocido y por último se invierte. La posibilidad de extraer factores racionales del logaritmo depende así de la construcción previa de potencias racionales.

### Potencias con exponente real

#### Una definición que amplía la potencia racional
**En la cátedra (1:26:12–1:31:30).** La última identidad puede reescribirse como

$$
\boxed{a^q=\exp(q\ln a)\quad(a>0,\ q\in\mathbb Q).}
$$

Su lado derecho tiene sentido para todo número real $q$, porque $\ln a\in\mathbb R$ y la exponencial está definida sobre $\mathbb R$. Esa observación conduce a la definición general:

$$
\boxed{a^x:=\exp(x\ln a),\qquad a>0,\ x\in\mathbb R.}
$$

La definición proporciona una función de exponente real para cada base positiva y extiende la potencia racional ya construida: para $x\in\mathbb Q$ coincide con la raíz enésima de la potencia entera correspondiente. En particular, como $\ln e=1$,

$$
\boxed{e^x=\exp(x)\qquad(x\in\mathbb R).}
$$

**Ampliación editorial.** La definición permite deducir sin nuevos postulados las leyes

$$
\begin{aligned}
a^{x+y}&=a^x a^y,\\
(a^x)^z&=a^{xz},\\
(ab)^x&=a^x b^x\qquad (a,b>0),
\end{aligned}
$$

para exponentes reales. Por ejemplo, la primera sigue directamente de

$$
\exp((x+y)\ln a)=\exp(x\ln a)\exp(y\ln a).
$$

Si $a>1$, entonces $\ln a>0$ y la función $x\mapsto a^x$ es estrictamente creciente. Si $0<a<1$, entonces $\ln a<0$ y esa función es estrictamente decreciente. Esta observación conecta la construcción analítica de las potencias con el orden de los reales.

#### Logaritmos de base arbitraria
**En la cátedra (1:32:13–1:36:46).** Se fija una base $a>0$ con $a\ne1$ y un valor $b>0$. La ecuación

$$
a^x=b
$$

puede escribirse, por definición de potencia real, como $\exp(x\ln a)=b$. La inversión conduce a

$$
x\ln a=\ln b.
$$

Como $a\ne1$, se tiene $\ln a\ne0$, lo que permite despejar un único valor de $x$:

$$
\boxed{\log_a b:=\frac{\ln b}{\ln a},\qquad a>0,\ a\ne1,\ b>0.}
$$

Así, $\log_a b$ es el único exponente real que satisface $a^x=b$. La fórmula de **cambio de base** surge inmediatamente. Si $c>0$ y $c\ne1$,

$$
\boxed{\log_a b=\frac{\log_c b}{\log_c a}.}
$$

En efecto,

$$
\frac{\log_c b}{\log_c a}
=\frac{\ln b/\ln c}{\ln a/\ln c}
=\frac{\ln b}{\ln a}.
$$

La nueva definición conserva las propiedades del logaritmo natural porque dividir por la constante $\ln a$ transforma las mismas identidades algebraicas. Si $a>1$, $\log_a$ es estrictamente creciente; si $0<a<1$, es estrictamente decreciente.

### Desigualdades complementarias de la exponencial y el logaritmo

#### Cota superior para la exponencial
**En la cátedra (1:37:12–1:39:59).** La desigualdad fundamental establece $\exp(-x)\ge1-x$ para todo $x$. Para $x<1$ el miembro derecho es positivo. Utilizando $\exp(-x)=1/\exp(x)$,

$$
\frac1{\exp(x)}\ge1-x>0,
$$

por lo que

$$
\boxed{1+x\le\exp(x)\le\frac1{1-x}\qquad(x<1).}
$$

La cota inferior funciona para todo argumento real; la superior se obtiene en el intervalo $(-\infty,1)$, donde la división conserva el sentido de la desigualdad. Estas cotas serán especialmente útiles para estudiar límites en torno a $x=0$.

#### Dos cotas para el logaritmo
**En la cátedra (1:37:12–1:41:19).** Si $u>0$, se puede aplicar $\exp(x)\ge1+x$ a $x=\ln u$. Como $\exp(\ln u)=u$,

$$
u\ge1+\ln u,
\qquad\text{y por tanto}\qquad
\ln u\le u-1.
$$

La misma desigualdad, aplicada ahora a $1/u>0$, entrega

$$
\ln\left(\frac1u\right)\le\frac1u-1.
$$

Por la regla del cociente, $\ln(1/u)=-\ln u$. Multiplicando por $-1$ e invirtiendo el orden,

$$
\ln u\ge1-\frac1u.
$$

En conjunto,

$$
\boxed{1-\frac1u\le\ln u\le u-1\qquad(u>0).}
$$

Las dos cotas coinciden en $u=1$, donde $\ln1=0$. La primera es una expresión racional; la segunda es lineal. Ambas proceden de una misma desigualdad exponencial por sustitución y uso de la función inversa.

![Esquema editorial: dos cotas para el logaritmo natural.](figuras/IC2021_11_2/04_cotas_logaritmo.png){width=90%}

*Figura 5 (esquema editorial).* La gráfica de $\ln u$ queda entre la curva $1-1/u$ y la recta $u-1$ para todo $u>0$.

### Consulta final: el logaritmo como límite de una sucesión

**En la cátedra (1:44:41–1:49:07).** Un estudiante pregunta si el logaritmo también puede definirse mediante el límite de una sucesión. San Martín recuerda la convergencia $\sqrt[n]{a}\to1$ para cada $a>0$ y explica que, después de restar $1$, es natural comparar la rapidez de aproximación a cero con la sucesión $1/n$. El cociente relevante es

$$
\frac{\sqrt[n]{a}-1}{1/n}
=n\bigl(\sqrt[n]{a}-1\bigr).
$$

El profesor enuncia la identidad

$$
\boxed{\ln a=\lim_{n\to\infty}n\bigl(\sqrt[n]{a}-1\bigr),\qquad a>0,}
$$

y precisa que su demostración requiere un análisis adicional. Esta relación **se anuncia en la consulta; la prueba siguiente es una ampliación editorial**.

**Ampliación editorial: demostración mediante las desigualdades ya conocidas.** Fijemos $a>0$ y escribamos $y=\ln a$. Por la definición de potencia real,

$$
\sqrt[n]{a}=\exp\left(\frac yn\right).
$$

Para $n$ suficientemente grande se cumple $y/n<1$. Aplicamos las dos desigualdades exponenciales de la sección anterior al argumento $y/n$:

$$
1+\frac yn
\le \exp\left(\frac yn\right)
\le \frac1{1-y/n}.
$$

Restar $1$ y multiplicar por $n>0$ conduce a

$$
y\le n\left(\exp\left(\frac yn\right)-1\right)
\le \frac{y}{1-y/n}.
$$

Las expresiones extremas convergen a $y$, puesto que $y$ es fijo. Por el teorema del sándwich, el término central converge igualmente a $y=\ln a$. Esto demuestra el límite anunciado y muestra cómo una función inversa construida por el supremo puede describirse también mediante una sucesión de raíces.

**Nota de fidelidad.** La transcripción permite reconocer con claridad la fórmula final y su explicación conceptual. La prueba detallada aquí expuesta se ha elaborado para estas notas; el docente la presenta como un problema más extenso.

### Registro de procedencia y verificación

- **Fuente audiovisual:** Jorge San Martín, *IC21: Cátedra 11.2. Exponencial (segunda parte) y Logaritmo*, transmisión del 12 de junio de 2021, [grabación](https://www.youtube.com/watch?v=9PVAjc3s-Mg).
- **Modalidad de revisión:** transcripción automática en español desde el inicio de la exposición hasta el final de las consultas; descripción y capítulos públicos de YouTube. **La escritura completa de la pizarra permanece pendiente de cotejo visual independiente.**
- **Demostraciones expuestas en la clase:** corolarios algebraicos de la exponencial, desigualdad fundamental, crecimiento estricto, existencia de preimagen mediante supremo, reglas básicas del logaritmo y cambio de base.
- **Desarrollos identificados como editoriales:** inducción completa sobre múltiplos naturales, independencia de representantes de las potencias racionales, continuidad de las propiedades de potencia real y demostración detallada de $\ln a=\lim n(\sqrt[n]{a}-1)$.
- **Normalización matemática:** las palabras «cuociente», «cota», «exponencial», «recíproco», «ínfimo» y «supremo» aparecen deformadas en los subtítulos; se restauraron de acuerdo con el desarrollo y se normalizó la notación $\mathbb R_{>0}=(0,\infty)$.
- **Rigor:** los signos en el paso de $\exp(-x)\ge1-x$ a la cota superior de $\exp x$ se restringieron a $x<1$; los logaritmos y potencias generales se formularon con base positiva y, para bases logarítmicas, distinta de $1$.
- **PNC v1.0:** se documentan cobertura, autoría, demostraciones, figuras editoriales y la cadena de archivos Markdown–LaTeX–PDF; la compilación, inspección visual y subida a Drive se consignan en `README.md` y `MANIFEST_SHA256.txt` tras realizarse.

### Taller de problemas y soluciones

Los ejercicios se presentan a continuación según la fuente de origen; las ampliaciones editoriales de cada apuntes permanecen expresamente identificadas.

#### Ejercicios de estudio — cátedra 11.1

Los ejercicios de este apartado son **ampliaciones editoriales**, salvo que se indique su antecedente concreto en la grabación.

**Ejercicio 1 — Identificar el límite al que tiende la base.** Sea $a\in(0,1)$ y $x\in\mathbb R$. Probar con una cota geométrica que $\lim_{n\to\infty}(a+x/n)^n=0$. Explicar por qué la misma cota deja de decidir el caso $a=1$.

**Ejercicio 2 — Cuidado con el exponente.** Determinar el límite de $(1+2/n)^n$ mediante la definición de $\exp$ y comparar con el argumento formal que produciría $1$. Señalar la hipótesis precisa que falta en ese argumento.

**Ejercicio 3 — Monotonía.** Para $x=-3$ establecer un índice $N$ a partir del cual $E_n(x)>0$. Probar la desigualdad $E_{n+1}(x)\ge E_n(x)$ a partir de Bernoulli I.

**Ejercicio 4 — Bernoulli III.** Demostrar para $n\ge1$ y $-1<h<1/n$ que $(1+h)^n\le1/(1-nh)$. Identificar cada condición que permite dividir y elevar a la potencia $n$.

**Ejercicio 5 — Cota para un parámetro grande.** Construir una cota superior constante de $E_n(7/3)$ eligiendo $m=3$ y expresarla como potencia de un racional.

**Ejercicio 6 — Aproximar $e$.** Escribir las cotas $L_{10}$ y $U_{10}$ de $e$, calcularlas con al menos seis decimales y acotar el ancho del intervalo resultante.

**Ejercicio 7 — Aplicación del lema.** Determinar el límite de $(1+3/n^2)^n$, indicando las dos condiciones sobre la sucesión $h_n$.

**Ejercicio 8 — El término cruzado.** Partiendo de $(1+x/n)(1+y/n)$, construir la sucesión $h_n$ que interviene en la demostración de $\exp(x+y)=\exp(x)\exp(y)$. Justificar por qué $nh_n\to0$.

**Ejercicio 9 — Reciprocidad.** Probar, con la ley fundamental y el caso $x=0$, que $\exp(-x)=1/\exp(x)$. Deducir $\exp(-2)\exp(2)=1$.

**Ejercicio 10 — Monotonía como función.** Demostrar que $x<y$ implica $\exp(x)<\exp(y)$, utilizando $\exp(t)\ge1+t$ para $t>0$.

#### Indicaciones y comprobación
1. Elige $r$ con $a<r<1$; eventualmente $|a+x/n|\le r$. Al elevar a $n$, domina la sucesión $r^n$.
2. El límite es $\exp(2)$; la operación de potencia varía simultáneamente con $n$.
3. Es suficiente $N=4$. Con $n\ge4$, la prueba general de la sección 4 aplica directamente.
4. Factoriza $1-h^2=(1-h)(1+h)$ y usa la cota inferior $(1-h)^n\ge1-nh>0$.
5. Como $7/3<3$, toma $m=3$ y deduce $E_n(7/3)\le (1-7/9)^{-3}=(9/2)^3=729/8$.
6. $L_{10}\approx2.593742$ y $U_{10}\approx2.853117$; la diferencia es $L_{10}/10\approx0.259374$.
7. $h_n=3/n^2$ satisface $h_n\to0$ y $nh_n=3/n\to0$, por lo que el límite es $1$.
8. $h_n=xy/[n(n+x+y)]$; entonces $nh_n=xy/(n+x+y)\to0$.
9. El producto de las dos exponenciales vale $\exp(0)=1$.
10. Para $t=y-x>0$ vale $\exp(t)\ge1+t>1$; multiplicar por $\exp(x)>0$ concluye.

#### Ejemplos resueltos y problemas generativos — cátedra 11.2

Los ejemplos de esta sección son **ampliaciones editoriales**, creadas para consolidar el material. Mantienen los teoremas y convenciones establecidos en la cátedra.

#### Ejemplo 1. Resolver una ecuación exponencial
Para $\exp(2x-1)=5$ aplicamos la función inversa a ambos lados:

$$
2x-1=\ln5,
\qquad
\boxed{x=\frac{1+\ln5}{2}}.
$$

La unicidad de la solución proviene de la inyectividad de la exponencial.

#### Ejemplo 2. Reunir potencias con argumentos relacionados
Si $a>0$, entonces

$$
\exp(3\ln a-\ln2)
=\frac{\exp(3\ln a)}{\exp(\ln2)}
=\boxed{\frac{a^3}{2}}.
$$

Este cálculo combina la identidad de la suma, la del opuesto y la inversión.

#### Ejemplo 3. Resolver una ecuación de potencias reales
Sea $a>0$, $a\ne1$ y $b>0$. La ecuación $a^x=b$ posee la solución única

$$
\boxed{x=\log_a b=\frac{\ln b}{\ln a}}.
$$

Por ejemplo, para $3^{2x}=7$ obtenemos $2x\ln3=\ln7$, de modo que $x=\ln7/(2\ln3)$.

#### Ejemplo 4. Usar una desigualdad para acotar un logaritmo
Para $u=3/2$, la desigualdad doble establece

$$
\frac13=1-\frac23
\le\ln\left(\frac32\right)
\le\frac12.
$$

Esta estimación suministra cotas racionales del valor del logaritmo sin recurrir a una aproximación decimal.

#### Diez ejercicios propuestos
1. A partir de la igualdad fundamental, demostrar $\exp(-3x)=\exp(x)^{-3}$ con cada paso justificado.
2. Probar por inducción que $\exp(nx)=(\exp x)^n$ para $n\in\mathbb N$ y extender el resultado a los enteros.
3. Demostrar la identidad $\exp(x/6)=\sqrt[6]{\exp x}$ y precisar la unicidad de la raíz positiva.
4. Si $u>0$, calcular $\ln(u^{5/3})$ empleando el teorema sobre potencias racionales.
5. Dar una demostración detallada de que la función $\ln$ es estrictamente creciente.
6. Justificar que para cualquier $y>0$ el conjunto $A_y=\{x:\exp x<y\}$ posee supremo; utilizar las sucesiones $s\pm1/n$ para identificar $\exp s$.
7. Demostrar que $a^{x+y}=a^x a^y$ para todos $a>0$ y $x,y\in\mathbb R$.
8. Probar el cambio de base $\log_a b=\log_c b/\log_c a$ e indicar las condiciones sobre las bases.
9. Hallar cotas racionales para $\ln(4/3)$ mediante las desigualdades fundamentales.
10. A partir de $1+x\le\exp x\le1/(1-x)$, demostrar sin derivadas que $\displaystyle\lim_{n\to\infty}n(\sqrt[n]{a}-1)=\ln a$.

#### Orientaciones para comprobar los resultados
**Ejercicios 1–4.** Se utiliza la identidad exponencial de adición, junto con la propiedad de las potencias enteras y la definición de raíz positiva. En el cuarto ejercicio se obtiene $(5/3)\ln u$.

**Ejercicios 5–6.** La inversa de una biyección estrictamente creciente conserva el orden. Para el supremo, emplear $\exp(-n)\to0$ y $\exp(n)$ sin cota superior; después usar las cotas del apartado 4.

**Ejercicios 7–8.** Desarrollar $\exp((x+y)\ln a)$ por la identidad fundamental. En el cambio de base, simplificar dos cocientes de logaritmos naturales.

**Ejercicios 9–10.** Para $u=4/3$, la doble desigualdad entrega $1/4\le\ln(4/3)\le1/3$. En el último ejercicio, sustituir $x=(\ln a)/n$ en las cotas de la exponencial y aplicar el sándwich.

---

# Parte V. Límites de funciones y cálculo diferencial

## Puntos de acumulación y límite de una función

El límite describe el comportamiento de una función cerca de un punto de acumulación de su dominio. Las sucesiones admisibles ofrecen una caracterización que distingue este comportamiento del valor puntual de la función.

**Grabaciones de referencia:** [grabación de la cátedra 12.1](https://www.youtube.com/watch?v=iQD_ImPaRWo).

*Procedencia de este tramo: cátedra 12.1.*

### El problema que inaugura el cálculo de funciones

**En la clase (11:31–14:08).** Después de estudiar el axioma del supremo, las sucesiones y la función exponencial con su inversa, San Martín presenta las herramientas que permitirán investigar sistemáticamente las funciones reales de variable real. Las semanas 12 y 13 estarán dedicadas a los límites de funciones; el tema de las derivadas aparecerá en la semana 14. La presente sesión se concentra en un primer desafío: expresar con precisión qué significa aproximarse a un punto del dominio o a su frontera y observar las imágenes que produce una función.

Una función real de variable real tendrá la forma

$$
f:A\longrightarrow\mathbb R,\qquad A\subseteq\mathbb R.
$$

Nos interesa un punto real $a$ —el profesor escribe habitualmente $\bar x$— y la expresión

$$
\lim_{x\to a}f(x).
$$

La pregunta que orienta esta notación es la siguiente: **cuando los argumentos de $f$ se aproximan a $a$ a través de los puntos de $A$, ¿hacia qué valor se aproximan sus imágenes?** Esta investigación aprovecha la relación entre valores de una función y valores de una sucesión.

**En la clase (14:52–22:35).** El profesor distingue dos operaciones. La evaluación puntual $f(a)$ describe el valor asignado al argumento $a$, siempre que $a\in A$. El límite describe el comportamiento de las imágenes para argumentos del dominio próximos a $a$ y distintos de él. Una función puede tener en $a$ un valor especialmente elegido, puede presentar allí un hueco, o puede coincidir en ese punto con la tendencia de las imágenes cercanas. La existencia y el valor de un límite se investigan observando las imágenes de esos argumentos próximos.

La observación da también el sentido matemático de la idea histórica de aproximarse «justo antes». En el orden de los reales, entre dos números distintos existen otros números; por ejemplo, si $u<v$, su media $(u+v)/2$ satisface $u<(u+v)/2<v$. De este modo, la aproximación puede continuar con distancias arbitrariamente pequeñas. San Martín menciona aquí la igualdad $0{,}\overline9=1$ para ilustrar que una aproximación carece de un último término inmediatamente anterior a $1$.

### Dos primeros ejemplos: el valor puntual y el límite

#### La parte entera restringida a un intervalo
**En la clase (22:45–26:38).** Consideremos

$$
f:[0,1]\longrightarrow\mathbb R,\qquad f(x)=\lfloor x\rfloor.
$$

Para $0\le x<1$ se tiene $f(x)=0$, mientras que $f(1)=1$. Los argumentos del dominio que se aproximan a $1$ y son distintos de $1$ pertenecen al intervalo $[0,1)$ y tienen siempre imagen $0$. Por consiguiente,

$$
\boxed{\lim_{\substack{x\to1\\x\in[0,1]}}\lfloor x\rfloor=0,\qquad f(1)=1.}
$$

Aquí la aproximación sucede por puntos del dominio $[0,1]$; cerca de $1$ estos puntos se encuentran a su izquierda. Esta precisión será decisiva cuando estudiemos qué puntos están disponibles para construir un límite.

![Esquema editorial. Parte entera en el dominio [0,1]: el punto cerrado en (1,1) representa f(1); el círculo abierto en (1,0) indica la aproximación de las imágenes cercanas.](figuras/IC2021_Catedra_12_1/01_valor_y_limite.png)

#### Un punto excluido y dos cocientes algebraicos
**En la clase (26:38–31:38).** Sea, primero,

$$
g(x)=\frac{x-1}{x-1},\qquad A=\mathbb R\setminus\{1\}.
$$

Para $x\in A$, el cociente vale $1$. Por tanto,

$$
\lim_{x\to1}g(x)=1.
$$

El mismo procedimiento se aplica a

$$
h(x)=\frac{x^2-1}{x-1},\qquad x\in\mathbb R\setminus\{1\}.
$$

La factorización $x^2-1=(x-1)(x+1)$ permite escribir $h(x)=x+1$ en su dominio. Si $x$ se aproxima a $1$ desde ese dominio, $x+1$ se aproxima a $2$; así,

$$
\boxed{\lim_{x\to1}\frac{x^2-1}{x-1}=2.}
$$

Las dos funciones proporcionan ejemplos de **discontinuidad removible** en el lenguaje que se desarrollará más adelante: la regla algebraica queda definida en un dominio perforado y las imágenes circundantes determinan un único valor de aproximación.

![Esquema editorial. A la izquierda, la función constante de valor 1 con un punto excluido. A la derecha, la recta x+1 con un punto excluido en (1,2).](figuras/IC2021_Catedra_12_1/02_agujeros_y_limites.png)

### Cómo formalizar la aproximación: sucesiones admisibles

**En la clase (31:45–39:19).** La aproximación de los argumentos puede realizarse con una sucesión $(x_n)$ que se acerque cada vez más a $a$. Como estamos estudiando la función $f:A\to\mathbb R$, cada $x_n$ debe pertenecer al dominio. Además, el comportamiento de aproximación se examina mediante términos distintos del propio punto $a$.

El profesor organiza el procedimiento en **tres condiciones**:

$$
\boxed{\begin{aligned}
&x_n\longrightarrow a,\\
&x_n\in A\quad\text{para todo }n,\\
&x_n\ne a\quad\text{para todo }n.
\end{aligned}}
$$

Llamaremos *sucesión admisible para la aproximación a $a$* a una sucesión con esas propiedades. Esta denominación es editorial; corresponde a las tres condiciones de la pizarra. Por ejemplo, $x_n=a+1/n$ converge a $a$ y presenta términos distintos de $a$. Resultará admisible cuando todos sus términos pertenezcan a $A$. En un dominio $A=(0,1)$, la sucesión $x_n=1-1/(n+1)$ es admisible para aproximarse a $1$.

![Esquema editorial. Términos de la sucesión 1-1/(n+1), contenidos en (0,1), acercándose a 1.](figuras/IC2021_Catedra_12_1/04_sucesion_en_dominio.png)

Si $(x_n)$ cumple las tres condiciones, podemos evaluar la función término a término y obtener una nueva sucesión:

$$
\bigl(f(x_n)\bigr)_{n\ge1}.
$$

La definición del límite exigirá que esta sucesión de imágenes tenga una aproximación común para **cada elección** de sucesión admisible. Esta universalidad enlaza las sucesiones con el comportamiento integral de una función alrededor de un punto.

### Puntos de acumulación: el dominio fija las aproximaciones posibles

#### Definición secuencial
**En la clase (39:19–58:36).** Antes de formular el límite, el profesor introduce el concepto de *punto de acumulación*. El concepto caracteriza los puntos reales a los cuales puede aproximarse una sucesión de elementos de un conjunto permaneciendo en ese conjunto.

**Definición — Punto de acumulación (en la clase, 51:57–57:00).** Sea $A\subseteq\mathbb R$. Un número $a\in\mathbb R$ es un **punto de acumulación de $A$** si existe una sucesión $(x_n)$ tal que

$$
\boxed{\forall n\ge1:\ x_n\in A,\quad x_n\ne a,
\qquad \lim_{n\to\infty}x_n=a.}
$$

Escribiremos $A'$ para el conjunto de puntos de acumulación de $A$, notación editorial usual en topología. Su relación con $A$ depende de cómo se distribuyen los elementos: un extremo de un intervalo puede ser punto de acumulación aunque ese extremo se encuentre excluido; un punto aislado del conjunto puede pertenecer a $A$ y carecer de acumulación a su alrededor.

**Ampliación editorial — Caracterización por vecindades.** La definición anterior es equivalente a

$$
\forall\varepsilon>0\ \exists x\in A:
\quad 0<|x-a|<\varepsilon.
$$

La sucesión explícita de la definición demuestra esta propiedad tomando un término suficientemente próximo a $a$. Recíprocamente, eligiendo para cada $n$ un $x_n\in A$ tal que $0<|x_n-a|<1/n$, se construye una sucesión admisible que converge a $a$. Esta equivalencia anticipa las vecindades que se estudiarán en cursos posteriores; **su prueba se incorpora editorialmente**.

#### Intervalos, extremos y puntos aislados
**En la clase (40:16–51:40; recapitulación 1:04:08–1:16:55).** Para el dominio $[0,1]$ todos sus puntos son de acumulación, incluidos los extremos. También los puntos $0$ y $1$ son acumulación de $(0,1)$: desde dentro del intervalo se puede aproximar cualquiera de ellos tanto como se desee. En ambos casos,

$$
[0,1]'=[0,1],\qquad (0,1)'=[0,1].
$$

En cambio, el conjunto $\{1\}$ contiene un único punto aislado. Toda sucesión con términos en él es constante, de modo que ninguna satisface a la vez la condición de tener términos distintos de $1$ y converger a $1$. Por ello $\{1\}'=\varnothing$. Para un conjunto finito de puntos distintos la misma distancia positiva entre puntos impide aproximaciones infinitamente finas desde elementos diferentes. También $\mathbb N'=\varnothing$ como subconjunto de $\mathbb R$: cada natural está separado del siguiente por una unidad.

![Esquema editorial. Los conjuntos [0,1] y (0,1) tienen el mismo conjunto derivado [0,1]; el singleton {1/2} tiene derivado vacío.](figuras/IC2021_Catedra_12_1/03_puntos_de_acumulacion.png)

El profesor revisa además los dominios con huecos: si $A=\mathbb R\setminus\{1\}$, las sucesiones $1+1/n$ o $1-1/n$ se aproximan a $1$ desde $A$, y, por tanto, $A'=\mathbb R$. Para el conjunto vacío también vale $\varnothing'=\varnothing$.

La clasificación queda resumida en la tabla siguiente.

| Conjunto $A$ | Puntos de acumulación $A'$ | Idea de comprobación |
|:--|:--|:--|
| $\mathbb R$ | $\mathbb R$ | $a+1/n\to a$. |
| $[0,1]$ | $[0,1]$ | Aproximación desde el intervalo. |
| $(0,1)$ | $[0,1]$ | Ambos extremos son alcanzables. |
| $\mathbb R\setminus\{1\}$ | $\mathbb R$ | El punto excluido es alcanzable. |
| $\{1\}$ | $\varnothing$ | Punto aislado. |
| $\{0,1,2,3\}$ | $\varnothing$ | Conjunto finito. |
| $\mathbb N$ | $\varnothing$ | Distancia entre naturales consecutivos. |
| $\varnothing$ | $\varnothing$ | Ausencia de elementos con que construir la sucesión. |
| $\mathbb Q$ | $\mathbb R$ | Densidad de los racionales. |
| $\mathbb R\setminus\mathbb Q$ | $\mathbb R$ | Densidad de los irracionales. |

**Precisión editorial.** El límite $n\to\infty$ de una sucesión $s:\mathbb N\to\mathbb R$ es una herramienta distinta del límite de funciones en un punto **real finito** de acumulación del dominio. La ausencia de puntos de acumulación reales de $\mathbb N$ concuerda con el uso del límite de sucesiones cuando el índice crece sin cota. El profesor hace expresamente esta distinción entre **1:13:32 y 1:16:47**.

#### Los racionales y los irracionales se acumulan en todo real
**En la clase (1:16:55–1:26:15).** La densidad de los racionales afirma que, dados dos reales $u<v$, existe un racional $r$ tal que $u<r<v$. El profesor propone construir, para un real $a$, términos racionales $r_n$ que satisfagan

$$
a<r_n<a+\frac1n.
$$

El teorema del sándwich implica $r_n\to a$, y cada $r_n$ pertenece a $\mathbb Q$ y difiere de $a$. Por tanto, **todo real es punto de acumulación de $\mathbb Q$**. En particular, se pueden aproximar $\sqrt2$, $\pi$ o $e$ mediante sucesiones racionales.

La densidad de los irracionales produce el resultado análogo para $\mathbb R\setminus\mathbb Q$. El profesor observa, por ejemplo, que cuando $a\in\mathbb Q$, la sucesión $a+\sqrt2/n$ está formada por irracionales, converge a $a$ y tiene términos distintos del límite; cuando $a$ es irracional puede emplearse $a+1/n$.

$$
\boxed{\mathbb Q'=\mathbb R,
\qquad (\mathbb R\setminus\mathbb Q)'=\mathbb R.}
$$

Esta propiedad constituye una razón conceptual para estudiar límites en la frontera de un dominio. Una función inicialmente definida en $\mathbb Q$ puede examinarse mediante sucesiones racionales que convergen a números irracionales. La posibilidad de definir allí un valor por límite requiere además que **todas** las aproximaciones admisibles generen la misma tendencia de imágenes.

### Definición rigurosa del límite de una función

**En la clase (1:26:15–1:34:43).** Llegamos a la definición que organiza los ejemplos anteriores. Sea $f:A\to\mathbb R$, sea $a$ un punto de acumulación de $A$ y sea $L\in\mathbb R$.

**Definición — Límite secuencial de una función.** Diremos que

$$
\lim_{x\to a}f(x)=L
$$

si para toda sucesión $(x_n)$ que satisfaga

$$
x_n\in A,\qquad x_n\ne a\quad(n\ge1),
\qquad x_n\longrightarrow a,
$$

la sucesión de imágenes satisface

$$
\boxed{f(x_n)\longrightarrow L.}
$$

Una formulación cuantificada permite identificar con precisión su estructura lógica:

$$
\boxed{\forall(x_n)\;\Bigl[
\bigl((\forall n)\ x_n\in A\setminus\{a\}\bigr)
\land x_n\to a
\ \Longrightarrow\ f(x_n)\to L\Bigr].}
$$

![Esquema editorial. Cada sucesión admisible de argumentos convergente a a genera una sucesión de imágenes que converge al mismo L.](figuras/IC2021_Catedra_12_1/06_criterio_secuencial.png)

**Demostración desarrollada de la buena definición de las imágenes.** Cada término $x_n$ se encuentra en el dominio $A$. Por la regla funcional, $f(x_n)$ es un número real, y la asignación $n\mapsto f(x_n)$ define una función $\mathbb N\to\mathbb R$, es decir, una sucesión. Este paso explica por qué el profesor insiste en la tercera condición. Se trata de una composición $f\circ x$, donde la sucesión $x:\mathbb N\to A$ sirve de entrada a $f$.

**Ampliación editorial — Por qué exigimos un punto de acumulación.** La hipótesis $a\in A'$ garantiza la existencia de sucesiones admisibles. Si $a$ fuese aislado, el enunciado «para toda sucesión admisible» quedaría satisfecho formalmente para todo valor $L$ por ausencia de tales sucesiones. Al reservar la definición de límite para puntos de acumulación preservamos la interpretación del concepto y la unicidad del límite cuando existe.

### Ejemplos formales con sucesiones

#### Función identidad
**En la clase (1:34:43–1:39:11).** Sea $f:\mathbb R\to\mathbb R$ definida por $f(x)=x$. Para cada $a\in\mathbb R$, tomamos una sucesión arbitraria $x_n\to a$ con $x_n\ne a$. Entonces

$$
f(x_n)=x_n\longrightarrow a.
$$

Como la conclusión se obtiene para cualquier sucesión admisible, podemos escribir

$$
\boxed{\lim_{x\to a}x=a.}
$$

El profesor introduce también $f(x)=2x$. En ese caso $f(x_n)=2x_n\to2a$ por el álgebra de límites de sucesiones; por tanto,

$$
\lim_{x\to a}2x=2a.
$$

La sencillez de estas pruebas resulta instructiva: una vez fijado correctamente el cuantificador «para toda sucesión», un teorema previo sobre sucesiones produce el nuevo resultado sobre funciones.

#### Dos cocientes con denominador $1-x$
**En la clase (1:39:11–1:43:02).** La transcripción permite identificar dos cocientes estudiados cerca del punto $1$:

$$
g(x)=\frac{x-1}{1-x},\qquad
h(x)=\frac{x^2-1}{1-x},\qquad x\ne1.
$$

**Lectura incierta.** La primera fórmula aparece parcialmente degradada en los subtítulos, pero la verbalización posterior del denominador $1-x$, la simplificación y las respuestas $-1$ y $-2$ sustentan esta reconstrucción. Requiere cotejo final con la imagen de pizarra.

Tomemos una sucesión $x_n\to1$ con $x_n\ne1$. Entonces

$$
g(x_n)=\frac{x_n-1}{1-x_n}=-1
\ \Longrightarrow\ \lim_{x\to1}g(x)=-1.
$$

Asimismo,

$$
h(x_n)=\frac{(x_n-1)(x_n+1)}{1-x_n}
=-(x_n+1)\longrightarrow-2.
$$

Por tanto,

$$
\boxed{\lim_{x\to1}\frac{x^2-1}{1-x}=-2.}
$$

La simplificación se ha hecho en el dominio del cociente, en el que cada término $x_n$ satisface la restricción $x_n\ne1$. La sucesión compuesta está definida y admite el cálculo de límite.

### Una función definida según racionalidad: prueba y contraejemplo

**En la clase (1:43:18–1:50:26, con preguntas hasta 1:56:33).** Se considera la función

$$
f:\mathbb R\longrightarrow\mathbb R,
\qquad f(x)=\begin{cases}
x,&x\in\mathbb Q,\\
x^2,&x\in\mathbb R\setminus\mathbb Q.
\end{cases}
$$

Cada real pertenece a exactamente una de las dos clases indicadas, de manera que $f$ asigna un único valor a cada argumento. El profesor pregunta por el límite en $x=1$ y señala que tanto la rama $x$ como la rama $x^2$ se aproximan allí al mismo valor $1$.

![Esquema editorial. Las curvas x y x² indican las fórmulas posibles; la función toma la primera sobre racionales y la segunda sobre irracionales. Coinciden en 1 y difieren en 1/2. Las líneas continuas del esquema representan fórmulas, no todas las imágenes efectivas de la función.](figuras/IC2021_Catedra_12_1/05_ramas_racionales_irracionales.png)

**Demostración desarrollada (1:45:04–1:49:49).** Consideremos una sucesión arbitraria $(x_n)$ que converge a $1$, con $x_n\ne1$. Para cada índice, de acuerdo con la naturaleza racional del término,

$$
|f(x_n)-1|=\begin{cases}
|x_n-1|,&x_n\in\mathbb Q,\\
|x_n^2-1|,&x_n\notin\mathbb Q.
\end{cases}
$$

Ambas posibilidades satisfacen la **misma** estimación

$$
0\le |f(x_n)-1|
\le |x_n-1|+|x_n^2-1|.
$$

El miembro derecho converge a $0$ porque $x_n\to1$ implica $x_n^2\to1$. El teorema del sándwich concluye

$$
|f(x_n)-1|\longrightarrow0,
\qquad f(x_n)\longrightarrow1.
$$

El cálculo cubre incluso sucesiones que alternan términos racionales e irracionales. Como la sucesión elegida era arbitraria,

$$
\boxed{\lim_{x\to1}f(x)=1.}
$$

**Ejercicio propuesto en la clase (1:49:51).** Estudiar $\lim_{x\to0}f(x)$.

**Ampliación editorial — Solución.** Para toda sucesión $x_n\to0$,

$$
0\le |f(x_n)|\le |x_n|+|x_n|^2\longrightarrow0.
$$

Así, $\lim_{x\to0}f(x)=0$.

**Ejercicio propuesto en la clase (1:50:01; discusión 1:55:23–1:56:33).** Estudiar $\lim_{x\to1/2}f(x)$.

**Ampliación editorial — Solución.** Por densidad, podemos elegir una sucesión racional $r_n\to1/2$ con $r_n\ne1/2$ y otra irracional $t_n\to1/2$. Entonces

$$
f(r_n)=r_n\longrightarrow\frac12,
\qquad f(t_n)=t_n^2\longrightarrow\frac14.
$$

Las dos aproximaciones admisibles generan límites de imágenes diferentes. Por el criterio secuencial, **el límite de $f$ en $1/2$ no existe**. La conclusión utiliza la unicidad del límite de una sucesión, ya conocida en el curso; el teorema específico de unicidad del límite de funciones se anuncia para la siguiente clase.

### Herramientas que quedan anunciadas

**En la clase (1:50:19–1:51:01).** San Martín anuncia para la siguiente sesión tres familias de resultados: unicidad del límite de una función, álgebra de los límites y teorema del sándwich para funciones. Explica que sus demostraciones se apoyarán en los resultados respectivos de sucesiones. **Estas notas los registran como anuncios de la clase:** el tratamiento sistemático de sus demostraciones corresponde a la cátedra siguiente.

**Ampliación editorial — Puente conceptual.** Si $a$ es un punto de acumulación de $A$ y una función tiene límite $L$ en $a$, el mismo $L$ debe aparecer a lo largo de cada sucesión admisible. Esta universalidad es la clave para transferir resultados del cálculo con sucesiones al cálculo con funciones. Una sola sucesión sirve para explorar o descartar un límite candidato; demostrar la existencia de un límite exige controlar **todas** las sucesiones admisibles.

### Taller de problemas y soluciones

Los ejercicios se presentan a continuación según la fuente de origen; las ampliaciones editoriales de cada apuntes permanecen expresamente identificadas.

#### Práctica adicional con soluciones breves — cátedra 12.1

Los siguientes ocho ejercicios son **ampliaciones editoriales**, incorporadas para consolidar la clase. Se separan de los dos ejercicios propuestos por el docente en la sección anterior.

**1. Punto acumulable de un intervalo.** Hallar $A'$ para $A=(-2,3]$.

*Solución.* Para cada $a\in[-2,3]$ existen puntos de $A$, diferentes de $a$, arbitrariamente próximos a él, y para todo $a$ fuera de ese intervalo existe una vecindad disjunta de $A$. Por tanto, $A'=[-2,3]$.

**2. Punto aislado añadido.** Hallar $B'$ para $B=(0,1)\cup\{3\}$.

*Solución.* El intervalo contribuye con todos los puntos de $[0,1]$. El punto $3$ queda separado de $(0,1)$ y de cualquier otro elemento de $B$. Por tanto, $B'=[0,1]$.

**3. Sucesión admisible en un extremo.** Construir una sucesión de $(2,5)$ que tienda a $5$.

*Solución.* $x_n=5-1/(n+1)$ pertenece a $(2,5)$, difiere de $5$ y converge a $5$.

**4. Límite de un cociente.** Calcular $\lim_{x\to3}(x^2-9)/(x-3)$.

*Solución.* Si $x\ne3$, la fracción vale $x+3$, y toda sucesión admisible convergente a $3$ produce imágenes convergentes a $6$.

**5. Valor en el punto alterado.** Sea $f(x)=2x$ para $x\ne1$ y $f(1)=17$. Calcular $\lim_{x\to1}f(x)$.

*Solución.* Toda sucesión con términos distintos de $1$ produce $f(x_n)=2x_n\to2$; el límite es $2$.

**6. Una función oscilante entre dos valores.** Sea $g(x)=1$ para $x\in\mathbb Q$ y $g(x)=2$ para $x\notin\mathbb Q$. Estudiar el límite de $g$ en cualquier real.

*Solución.* Las sucesiones racionales admisibles producen imágenes $1$, y las irracionales producen imágenes $2$. En cada real se obtienen límites distintos; en ninguno existe el límite.

**7. Ramas que coinciden en otro punto.** Para $f(x)=x$ sobre racionales y $f(x)=x^2$ sobre irracionales, encontrar todos los puntos donde existe el límite.

*Solución.* Si existe límite en $a$, la rama racional exige $L=a$ y la irracional exige $L=a^2$; luego $a=a^2$, que equivale a $a\in\{0,1\}$. En ambos puntos se aplica la estimación común utilizada en la clase; esos son precisamente los puntos pedidos.

**8. Conjunto de reciprocidades.** Sea $C=\{1/n:n\in\mathbb N,\ n\ge1\}$. Hallar $C'$.

*Solución.* La sucesión $1/n$ converge a $0$, de modo que $0\in C'$. Cada término $1/k$ se encuentra aislado de los demás; todo real fuera de $C\cup\{0\}$ tiene una vecindad que deja fuera a $C$. Por tanto, $C'=\{0\}$.

---

## Álgebra, comparación y límites fundamentales

Los teoremas para límites de funciones heredan su estructura de los teoremas para sucesiones. Las cotas y el teorema del sándwich llevan a los límites fundamentales exponenciales y trigonométricos.

**Grabaciones de referencia:** [grabación de la cátedra 12.2](https://www.youtube.com/watch?v=pn5sq_kgAB0).

*Procedencia de este tramo: cátedra 12.2.*

### La definición secuencial que organiza el curso

**En la clase (03:20–06:39).** San Martín recuerda que el límite se estudia en un punto de acumulación del dominio, porque el argumento es una aproximación a ese punto por elementos del dominio. La condición crucial es universal: **toda** sucesión admisible ha de producir el mismo límite de imágenes.

Sea $A\subseteq\mathbb R$, sea $f:A\to\mathbb R$ y sea $a$ un **punto de acumulación de $A$**: existe una sucesión $(x_n)$ de elementos de $A$, con $x_n\neq a$ para todo $n$, que converge a $a$. Para un real $L$, escribimos

$$
\lim_{x\to a}f(x)=L
$$

cuando se cumple la siguiente condición:

$$
\boxed{\quad\forall (x_n)\subseteq A:\quad
\bigl[x_n\ne a\ (\forall n),\ x_n\to a\bigr]
\ \Longrightarrow\ f(x_n)\to L.\quad}
$$

La función transformó una sucesión del dominio en la sucesión de imágenes $(f(x_n))$. Para estudiar el límite, dejamos fijo el punto $a$ y hacemos variar las sucesiones que lo alcanzan desde $A\setminus\{a\}$. El valor $f(a)$ —cuando existe— constituye información puntual; los valores $f(x_n)$ describen el comportamiento en torno al punto.

**Demostración desarrollada.** En una función definida en un conjunto perforado, como $f(x)=(x-1)/(x-1)$ para $x\ne1$, toda sucesión admisible $x_n\to1$ verifica $f(x_n)=1$. En consecuencia, el límite es $1$, aunque la expresión carezca de valor en $x=1$. Este razonamiento enlaza directamente con la cátedra 12.1.

### Primer teorema: unicidad

**En la clase (06:41–12:57).** El docente establece que una función puede tener **un único límite** en un punto de acumulación. La demostración utiliza la unicidad del límite de sucesiones.

**Teorema.** Si $a$ es punto de acumulación de $A$ y

$$
\lim_{x\to a}f(x)=L_1,\qquad
\lim_{x\to a}f(x)=L_2,
$$

entonces $L_1=L_2$.

**Demostración desarrollada.** Por acumulación de $A$ existe una sucesión admisible $(x_n)\subseteq A\setminus\{a\}$ con $x_n\to a$. La primera hipótesis implica que $f(x_n)\to L_1$. La segunda implica que **esa misma** sucesión $f(x_n)\to L_2$. La unicidad del límite de sucesiones da $L_1=L_2$. $\square$

La expresión «para toda sucesión» tiene aquí una consecuencia práctica considerable: para mostrar que una función carece de límite en $a$, basta construir **dos sucesiones testigo** que se aproximen a $a$ desde el dominio y cuyas imágenes converjan a números distintos. La presencia de dos caminos con distintos destinos prueba la incompatibilidad con un límite único.

![Esquema editorial: dos familias de puntos cuyas imágenes tienen límites distintos.](figuras/IC2021_Catedra_12_2/01_dos_limites_por_sucesiones.png)

**Ampliación editorial — un ejemplo preciso.** Sea

$$
f(x)=\begin{cases}1,&x\in\mathbb Q,\\2,&x\in\mathbb R\setminus\mathbb Q.\end{cases}
$$

En torno a $a=0$ se consideran dos sucesiones: $r_n=1/n$, formada por racionales, y $s_n=\sqrt2/n$, formada por irracionales. Ambas convergen a cero y cumplen $r_n,s_n\neq0$. Sus imágenes son constantes, respectivamente, $f(r_n)=1$ y $f(s_n)=2$. Por unicidad, $\lim_{x\to0}f(x)$ no existe. Este es un ejemplo **editorial** construido para representar el método que San Martín explica mediante gráficos de ramas distintas.

El profesor relaciona esta idea con la función parte entera: en un salto, los acercamientos desde conjuntos del dominio situados a lados distintos del punto pueden determinar valores límite diferentes. Asimismo recuerda que modificar el dominio cambia las sucesiones admisibles y, por consiguiente, puede cambiar la existencia del límite.

### Segundo teorema: álgebra de límites

**En la clase (13:01–15:40).** Las propiedades de suma, diferencia, producto y cociente se trasladan de las sucesiones a las funciones. El método consiste en introducir una sucesión arbitraria $x_n\to a$, calcular las imágenes de cada función y aplicar el álgebra de los límites de sucesiones.

Sea $f,g:A\to\mathbb R$, con $a$ punto de acumulación de $A$, y supongamos

$$
\lim_{x\to a}f(x)=F,\qquad \lim_{x\to a}g(x)=G.
$$

Para constantes $\alpha,\beta\in\mathbb R$, las reglas son

$$
\begin{aligned}
\lim_{x\to a}(\alpha f(x)+\beta g(x))&=\alpha F+\beta G,\\
\lim_{x\to a}f(x)g(x)&=FG,\\
\lim_{x\to a}\frac{f(x)}{g(x)}&=\frac{F}{G}\qquad\text{si }G\ne0.
\end{aligned}
$$

La tercera expresión se interpreta en el dominio donde $g(x)\ne0$. Como $G\ne0$, la condición $g(x_n)\ne0$ se cumple eventualmente para cualquier sucesión admisible; igualmente, por la definición del límite, existe un entorno perforado donde el denominador tiene signo estable y permanece separado de cero.

**Demostración desarrollada (producto).** Dada cualquier sucesión admisible $x_n\to a$, las hipótesis proporcionan $f(x_n)\to F$ y $g(x_n)\to G$. Por el teorema del producto de sucesiones, $f(x_n)g(x_n)\to FG$. Como la elección de $(x_n)$ fue arbitraria, la definición del límite de funciones entrega la conclusión. $\square$

**Precisión editorial sobre dominios.** Cuando $f:A\to\mathbb R$ y $g:B\to\mathbb R$ tienen dominios diferentes, sus operaciones se estudian en el **dominio común correspondiente**. Para el cociente se utiliza $\{x\in A\cap B:g(x)\ne0\}$; además, el punto $a$ debe ser de acumulación de dicho dominio. Esta precisión evita inferencias basadas en expresiones sin evaluación definida.

### Tercer teorema: sándwich en un entorno perforado

**En la clase (15:55–22:20).** El profesor recupera el teorema del sándwich, enfatizando el cambio entre límites de sucesiones y límites de funciones: ahora las desigualdades se piden **cerca del punto de aproximación**, sobre el dominio que corresponde, con el propio punto excluido cuando sea necesario.

**Teorema (sándwich).** Supongamos que $g:A\to\mathbb R$ y que $a$ es punto de acumulación de $A$. Sean $f$ y $h$ funciones definidas al menos sobre los puntos de $A$ suficientemente próximos a $a$. Si existe $\delta>0$ tal que

$$
f(x)\le g(x)\le h(x)
\quad\text{para }x\in A,\quad 0<|x-a|<\delta,
$$

y si $f$ y $h$, consideradas sobre ese mismo dominio de aproximación, satisfacen

$$
\lim_{x\to a}f(x)=\lim_{x\to a}h(x)=L,
$$

entonces $\lim_{x\to a}g(x)=L$.

**Demostración desarrollada — aportación editorial a partir de la indicación del docente.** Elegimos una sucesión arbitraria $x_n\in A\setminus\{a\}$ con $x_n\to a$. Por convergencia existe $N$ tal que $0<|x_n-a|<\delta$ para $n\ge N$. Por tanto,

$$
f(x_n)\le g(x_n)\le h(x_n)\qquad(n\ge N).
$$

Los extremos convergen a $L$ por la definición secuencial del límite de funciones. El teorema del sándwich para sucesiones implica $g(x_n)\to L$. Como $(x_n)$ era arbitraria, queda probado el límite de $g$. $\square$

![Esquema editorial: una función oscilante encerrada entre dos cotas convergentes.](figuras/IC2021_Catedra_12_2/02_sandwich_piso_techo.png)

El esquema muestra un **piso** $f$ y un **techo** $h$ que convergen a una altura común. La trayectoria intermedia puede oscilar y el valor exacto en $a$ es ajeno a la condición. El teorema extrae un comportamiento límite del orden de las tres funciones.

### Primeras aplicaciones: identidad, polinomios y racionales

**En la clase (22:41–31:55).** Como $\lim_{x\to a}x=a$ y $\lim_{x\to a}c=c$ para toda constante $c$, el álgebra de límites demuestra por inducción que

$$
\lim_{x\to a}x^k=a^k,\qquad k\in\mathbb N_0.
$$

Para un polinomio $P(x)=\sum_{k=0}^{m}c_kx^k$, resulta

$$
\boxed{\lim_{x\to a}P(x)=P(a).}
$$

Esta coincidencia entre el límite y el valor puntual es una propiedad de los polinomios que el docente subraya como caso especialmente sencillo.

Si $P$ y $Q$ son polinomios y $Q(a)\ne0$, el cociente $R(x)=P(x)/Q(x)$ satisface

$$
\boxed{\lim_{x\to a}\frac{P(x)}{Q(x)}=\frac{P(a)}{Q(a)}.}
$$

Cuando $Q(a)=0$, el álgebra del cociente requiere examinar la función. Se pueden presentar situaciones diferentes:

**En la clase — hueco algebraico (27:13).** La función

$$
R(x)=\frac{1-x}{x-1},\qquad x\in\mathbb R\setminus\{1\},
$$

vale $-1$ para cada punto de su dominio. El gráfico es una recta horizontal con un punto excluido, y $\lim_{x\to1}R(x)=-1$.

![Esquema editorial: la función cociente se reduce a una constante en su dominio y posee un hueco en x=1.](figuras/IC2021_Catedra_12_2/03_hueco_en_cociente_racional.png)

**En la clase — comportamiento no acotado (28:15–31:48).** Si $Q(a)=0$ y $P(a)\ne0$, cerca de $a$ el cociente $P(x)/Q(x)$ tiene magnitud arbitrariamente grande en los puntos donde está definido. Para justificarlo, se puede invertir el cociente:

$$
\lim_{x\to a}\frac{Q(x)}{P(x)}=\frac{Q(a)}{P(a)}=0.
$$

A lo largo de cualquier sucesión $x_n\to a$ donde $Q(x_n)\ne0$, el recíproco $P(x_n)/Q(x_n)$ es no acotado en valor absoluto. Más precisamente, para un $M>0$ se puede escoger $\delta$ de modo que, al cumplir $0<|x-a|<\delta$ y $Q(x)\ne0$, se obtenga $|Q(x)/P(x)|<1/M$; entonces $|P(x)/Q(x)|>M$. En el caso de polinomios, $a$ es un cero aislado de $Q$ cuando $Q$ es un polinomio distinto del nulo, y este comportamiento corresponde a una asíntota vertical.

**Precisión editorial.** El dato $Q(a)=0$ por sí solo señala un lugar donde analizar la expresión; la prueba del comportamiento no acotado utiliza además $P(a)\ne0$. El ejemplo con numerador y denominador nulos muestra por qué interesa distinguir ambos casos antes de simplificar o anunciar una asíntota.

### La exponencial: desigualdades que generan límites

**En la clase (32:00–39:57).** La exponencial fue construida en la semana anterior mediante límites de sucesiones. Para recuperar su comportamiento cerca de cero, San Martín utiliza dos desigualdades válidas simultáneamente cuando $x<1$:

$$
\boxed{\qquad 1+x\le e^x\le\frac{1}{1-x},\qquad x<1.\qquad}
$$

La primera es la **desigualdad fundamental de la exponencial**: $e^x\ge1+x$ para todo $x\in\mathbb R$. La segunda resulta de aplicar la primera a $-x$:

$$
e^{-x}\ge1-x
\quad\Longleftrightarrow\quad
\frac1{e^x}\ge1-x.
$$

Como $e^x>0$, multiplicar por $e^x$ conserva el orden. Para $x<1$, el factor $1-x$ es positivo y se puede dividir, obteniendo $e^x\le1/(1-x)$. Esta restricción de dominio es decisiva al usar la cota superior.

![Esquema editorial: la exponencial se encuentra entre 1+x y 1/(1-x).](figuras/IC2021_Catedra_12_2/04_cotas_de_la_exponencial.png)

**Teorema.** $\displaystyle\lim_{x\to0}e^x=1$.

**Demostración desarrollada.** Existe un entorno perforado de cero contenido en $(-\infty,1)$. En él,

$$
1+x\le e^x\le\frac1{1-x}.
$$

Por el álgebra de límites, $\lim_{x\to0}(1+x)=1$ y $\lim_{x\to0}1/(1-x)=1$. Por el teorema del sándwich, la función intermedia converge a $1$. $\square$

#### El límite fundamental de primer orden
**En la clase (40:00–55:44).** La expresión $e^x-1$ converge a cero cuando $x\to0$. San Martín pregunta entonces por su **escala de aproximación**: cuánto vale el cociente de esa cantidad con $x$, que también converge a cero. El teorema del cociente del álgebra de límites requiere un denominador con límite distinto de cero y, por ello, aquí interesa construir otro sándwich.

**Teorema.**

$$
\boxed{\lim_{x\to0}\frac{e^x-1}{x}=1.}
$$

**Demostración desarrollada.** Restamos uno a la desigualdad de la sección anterior:

$$
x\le e^x-1\le\frac{x}{1-x}\qquad(x<1).
$$

Si $0<x<1$, podemos dividir por $x$ conservando el sentido de las desigualdades:

$$
1\le\frac{e^x-1}{x}\le\frac1{1-x}.
$$

Si $x<0$, al dividir por $x$ se invierten las dos desigualdades:

$$
\frac1{1-x}\le\frac{e^x-1}{x}\le1.
$$

Las dos situaciones se reúnen mediante el mínimo y el máximo de las cotas:

$$
\boxed{
\min\!\left\{1,\frac1{1-x}\right\}
\le\frac{e^x-1}{x}\le
\max\!\left\{1,\frac1{1-x}\right\}
\quad(0<|x|<1).}
$$

Cuando $x\to0$, tanto la constante $1$ como la fracción $1/(1-x)$ convergen a $1$. Sus mínimos y máximos convergen también a $1$ (por ejemplo, porque $\min(u,v)=\tfrac12(u+v-|u-v|)$ y $\max(u,v)=\tfrac12(u+v+|u-v|)$). Por sándwich, el cociente converge a $1$. $\square$

![Esquema editorial: cotas que intercambian posiciones según el signo de x para el cociente exponencial.](figuras/IC2021_Catedra_12_2/05_cociente_exponencial_sandwich.png)

**Sentido conceptual — ampliación editorial.** La igualdad anterior expresa que, cuando $x$ se acerca a cero, la diferencia $e^x-1$ y la propia variable $x$ tienen el mismo comportamiento de primer orden:

$$
e^x-1=x\,q(x),\qquad \lim_{x\to0}q(x)=1.
$$

En un curso posterior este límite será el fundamento de la derivada de la exponencial en el origen. En la presente clase surge mediante un teorema de orden y dos desigualdades elementales.

**Ejercicio propuesto en la clase (55:45).** Calcular $\lim_{x\to1}\ln x$ a partir de las cotas del logaritmo. La demostración editorial aparece en el apartado de práctica.

### Trigonometría: de la geometría de un arco a los límites fundamentales

**En la clase (1:02:17–1:25:12).** El profesor construye un esquema del círculo unitario, fijando un ángulo $x$ expresado en radianes, con $-\pi/2<x<\pi/2$. Compara cuatro objetos geométricos: la altura $|\sin x|$, la cuerda desde $(1,0)$ hasta $(\cos x,\sin x)$, el arco de longitud $|x|$ y el segmento tangente de longitud $|\tan x|$.

![Esquema editorial: círculo unitario, cuerda, arco y segmento tangente. La comparación del arco y la tangente utiliza una premisa geométrica expresamente declarada.](figuras/IC2021_Catedra_12_2/06_circulo_unitario_desigualdades_geometricas.png)

En notación de la exposición, $A=(1,0)$, $P=(\cos x,\sin x)$, $Q=(\cos x,0)$ y $R=(1,\tan x)$. El segmento $PQ$ mide $|\sin x|$, y la cuerda $AP$ mide

$$
|AP|=\sqrt{(1-\cos x)^2+\sin^2x}
=\sqrt{2(1-\cos x)}.
$$

La comparación de un cateto con la hipotenusa proporciona

$$
|\sin x|\le\sqrt{2(1-\cos x)}.
$$

El argumento geométrico de la clase conduce después a

$$
\boxed{
|\sin x|\le\sqrt{2(1-\cos x)}\le|x|\le|\tan x|,
\qquad |x|<\frac\pi2.}
\tag{G}
$$

**Alcance de la demostración en la clase.** El docente justifica intuitivamente que la cuerda es más corta que el arco correspondiente y que el arco es más corto que el trayecto tangente: emplea una imagen de un elástico que, al tensarse desde el arco hasta el punto exterior, aumenta su longitud. Advierte explícitamente que este último paso queda fundamentado **geométricamente**, y que la reconstrucción completa desde axiomas y definiciones analíticas de la trigonometría corresponde a un curso posterior. Por fidelidad documental, aquí tomamos (G) como **lema geométrico de partida**, distinguido de los pasos algebraicos rigurosamente desarrollados a continuación. Una demostración formal de (G) necesita precisar la definición del arco y justificar las comparaciones de longitud sin circularidad.

#### Primeros límites: seno y coseno
Del lado izquierdo de (G) y de la cota $\sqrt{2(1-\cos x)}\le|x|$ se deduce

$$
-|x|\le\sin x\le|x|.
$$

El sándwich entrega

$$
\boxed{\lim_{x\to0}\sin x=0.}
$$

Para el coseno, la cuerda proporciona $0\le2(1-\cos x)\le x^2$. Así,

$$
0\le1-\cos x\le\frac{x^2}{2},
$$

y por sándwich $1-\cos x\to0$ cuando $x\to0$. En consecuencia,

$$
\boxed{\lim_{x\to0}\cos x=1.}
$$

La construcción respeta la secuencia de la clase: los límites más sencillos permiten abordar el cociente fundamental de orden uno.

#### El límite del seno dividido por su argumento
**En la clase (1:20:36–1:23:41).** Para $0<|x|<\pi/2$, el cociente $\sin x/x$ es positivo: el seno y el ángulo comparten signo. De $|\sin x|\le|x|$ se obtiene $\sin x/x\le1$. A su vez, de $|x|\le|\tan x|=|\sin x|/\cos x$, con $\cos x>0$, se deduce

$$
\cos x\le\frac{\sin x}{x}.
$$

Por tanto,

$$
\boxed{\cos x\le\frac{\sin x}{x}\le1,
\qquad 0<|x|<\frac\pi2.}
$$

Ambas cotas convergen a $1$, porque el límite del coseno en cero fue establecido antes. El sándwich demuestra

$$
\boxed{\lim_{x\to0}\frac{\sin x}{x}=1.}
$$

![Esquema editorial: el cociente seno/x queda entre coseno x y la constante uno.](figuras/IC2021_Catedra_12_2/07_seno_sobre_x_sandwich.png)

La hipótesis de ángulos en **radianes** es constitutiva de este límite. La definición de radián identifica la medida del ángulo con la longitud del arco de circunferencia de radio uno, propiedad utilizada en (G).

#### El límite del coseno: segundo orden
**En la clase (1:23:43–1:25:12).** Las desigualdades obtenidas con cuerda e hipotenusa son

$$
\sin^2x\le2(1-\cos x)\le x^2.
$$

Para $x\ne0$ podemos dividir por $2x^2>0$:

$$
\frac12\left(\frac{\sin x}{x}\right)^2
\le\frac{1-\cos x}{x^2}\le\frac12.
$$

Los extremos convergen a $1/2$ porque $\sin x/x\to1$. El teorema del sándwich concluye

$$
\boxed{\lim_{x\to0}\frac{1-\cos x}{x^2}=\frac12.}
$$

**Ampliación editorial — comprobación algebraica alternativa una vez conocido el límite seno/x.** La identidad $1-\cos x=\sin^2x/(1+\cos x)$, válida para $x$ próximo a cero, permite escribir

$$
\frac{1-\cos x}{x^2}
=\frac{1}{1+\cos x}\left(\frac{\sin x}{x}\right)^2
\longrightarrow\frac12\cdot1^2=\frac12.
$$

Esta segunda vía confirma el resultado, aunque hereda el presupuesto geométrico previamente usado para demostrar $\sin x/x\to1$.

### Límite de una composición: teorema anunciado y tarea

**En la clase (1:25:47–1:31:42).** El último resultado se presenta como preparación para la clase siguiente. Dado que $g(x)$ se aproxima a cierto $b$ cuando $x\to a$, es natural esperar que $f(g(x))$ se aproxime al límite de $f(u)$ cuando $u\to b$. El profesor detiene el argumento en una condición decisiva: la aproximación interior debe realizarse **por valores distintos de $b$** para aprovechar un límite que estudia el comportamiento de $f$ alrededor de $b$.

**Teorema (enunciado suficiente, explicitado editorialmente).** Sean $g:D\to B$ y $f:B\to\mathbb R$, y sea $a$ punto de acumulación de $D$. Supongamos que $g(x)\to b$ cuando $x\to a$, que $b$ es punto de acumulación de $B$, que $f(u)\to L$ cuando $u\to b$, y que existe $\delta>0$ tal que

$$
x\in D,\quad0<|x-a|<\delta
\quad\Longrightarrow\quad g(x)\ne b.
$$

Entonces

$$
\boxed{\lim_{x\to a}f(g(x))=L.}
$$

**Demostración editorial del ejercicio propuesto.** Elíjase una sucesión arbitraria $x_n\in D\setminus\{a\}$ con $x_n\to a$. Como $g(x)\to b$, tenemos $g(x_n)\to b$. Por la condición adicional, existe $N$ tal que $g(x_n)\ne b$ para $n\ge N$; además, $g(x_n)\in B$ por el tipo de $g$. La sucesión de argumentos $u_n=g(x_n)$, considerada desde $N$, es por tanto admisible en la definición del límite de $f$ en $b$. Esto obliga a $f(u_n)\to L$, es decir, $f(g(x_n))\to L$. Como la sucesión original era arbitraria, queda demostrado el límite de la composición. $\square$

**Contraejemplo editorial: por qué se requiere una condición adicional.** Definamos

$$
f(u)=\begin{cases}1,&u=0,\\0,&u\ne0,\end{cases}
\qquad g(x)=0\ \text{para todo }x.
$$

Entonces $\lim_{u\to0}f(u)=0$ y $\lim_{x\to0}g(x)=0$, pero $f(g(x))=f(0)=1$ para todo $x$, así que $\lim_{x\to0}f(g(x))=1$. El ejemplo muestra que un argumento interior puede permanecer en $b$ mientras el límite exterior depende exclusivamente de los valores de $f$ en otros puntos próximos a $b$.

![Esquema editorial: cuando g(x) toma el valor puntual b, el valor de f(b) interviene en la composición.](figuras/IC2021_Catedra_12_2/08_composicion_valor_puntual.png)

**Ampliación editorial.** Una segunda versión útil del teorema exige que $f$ sea **continua en $b$**, es decir, que su límite en $b$ coincida con $f(b)$; en ese caso, se permite que $g(x)=b$ en algunos puntos de aproximación, porque todas las imágenes continúan acercándose a $f(b)$. Esta formulación se desarrollará naturalmente en el estudio posterior de la continuidad.

**Ejercicio propuesto en la clase.** Verificar las hipótesis del teorema de composición tomando cualquier sucesión $x_n\to a$ del dominio de $f\circ g$. La solución que figura arriba es una ampliación editorial, siguiendo la estrategia que San Martín plantea oralmente.

### Taller de problemas y soluciones

Los ejercicios se presentan a continuación según la fuente de origen; las ampliaciones editoriales de cada apuntes permanecen expresamente identificadas.

#### Ejercicios de consolidación — ampliación editorial — cátedra 12.2

Los ejercicios siguientes son **originales de esta edición**. Recuperan las técnicas efectivamente desarrolladas, con énfasis en hipótesis, dominios y pruebas. Los problemas señalados como propuestos en la clase se distinguen en los enunciados.

**Ejercicio E1 — Dos caminos, dos límites.** Sea $f(x)=0$ si $x<0$ y $f(x)=1$ si $x\ge0$, con dominio $\mathbb R$. Investigue la existencia de $\lim_{x\to0}f(x)$ por sucesiones.

**Solución.** Las sucesiones $x_n=-1/n$ y $y_n=1/n$ convergen a cero, son distintas de cero y pertenecen al dominio. Sus imágenes son $f(x_n)=0$ y $f(y_n)=1$. Como sus límites difieren, el límite de $f$ en cero no existe.

**Ejercicio E2 — Dominio y hueco.** Calcule $\lim_{x\to3}(x^2-9)/(x-3)$ y explique por qué se puede simplificar la expresión al estudiar el límite.

**Solución.** La función está definida para $x\ne3$. Allí $(x^2-9)/(x-3)=x+3$, así que para toda sucesión admisible $x_n\to3$ la imagen converge a $3+3=6$. El resultado es $6$.

**Ejercicio E3 — Asíntota y cota.** Estudie la magnitud de $R(x)=(2x+1)/(x-2)$ cuando $x\to2$ y compárela con la función $(x-2)^2/(x-2)$ en el mismo punto.

**Solución.** Para la primera, el numerador converge a $5$ y el denominador a cero; la función tiene magnitud no acotada cerca de $2$ y una asíntota vertical. La segunda, definida para $x\ne2$, coincide allí con $x-2$ y tiene límite $0$.

**Ejercicio E4 — Sándwich con oscilación.** Demuestre $\lim_{x\to0}x\sin(1/x)=0$ con el dominio $\mathbb R\setminus\{0\}$.

**Solución.** Como $|\sin t|\le1$, se verifica $-|x|\le x\sin(1/x)\le|x|$ para cada $x\ne0$. Los extremos convergen a cero, y el sándwich entrega el resultado.

**Ejercicio E5 — Escala exponencial.** Para un real $c$, calcule $\lim_{x\to0}(e^{cx}-1)/x$.

**Solución.** Para $c=0$ el cociente es idénticamente cero. Para $c\ne0$, con $u=cx$ se tiene $(e^{cx}-1)/x=c(e^u-1)/u$. Como $u\to0$ y el cociente fundamental converge a $1$, el límite es $c$.

**Ejercicio E6 — Cambio de variable trigonométrico.** Para $c\ne0$, calcule $\lim_{x\to0}\sin(cx)/x$.

**Solución.** Es $c\,\sin(cx)/(cx)\to c$. La igualdad se fundamenta en el límite fundamental del seno con el ángulo $cx$ medido en radianes.

**Ejercicio E7 — Segundo orden trigonométrico.** Para $c\in\mathbb R$, calcule $\lim_{x\to0}(1-\cos(cx))/x^2$.

**Solución.** Si $c=0$, el cociente vale cero. Si $c\ne0$, escribiendo $u=cx$ obtenemos $c^2(1-\cos u)/u^2\to c^2/2$.

**Ejercicio E8 — Logaritmo en uno (propuesto en la clase, 55:45; solución editorial).** Demuestre $\lim_{x\to1}\ln x=0$ utilizando desigualdades.

**Solución.** Para todo $x>0$ vale $1-1/x\le\ln x\le x-1$, resultado deducido de $e^t\ge1+t$ al poner $t=\ln x$ y repetir para $1/x$. Al tender $x\to1$, ambos extremos tienden a cero; el sándwich demuestra $\ln x\to0$.

**Ejercicio E9 — Composición problemática.** Sean $f(u)=2$ cuando $u=0$ y $f(u)=0$ cuando $u\ne0$; sea $g(x)=x\sin(1/x)$ para $x\ne0$. Investigue si se puede aplicar directamente el teorema de composición de la sección 8 para calcular $\lim_{x\to0}f(g(x))$.

**Solución.** Tenemos $g(x)\to0$, y $\lim_{u\to0}f(u)=0$, pero $g(x)$ toma exactamente el valor cero para infinitos $x\to0$ (por ejemplo $x=1/(k\pi)$) y también toma valores distintos de cero para otros $x\to0$. Por los primeros puntos, $f(g(x))=2$; por los segundos, $f(g(x))=0$. Por tanto, el límite de la composición **no existe**. Esta situación también confirma la pertinencia de la condición adicional del teorema.

**Ejercicio E10 — Comparación de límites.** Considere $f(x)=(e^{2x}-1)/(2x)$ para $x\ne0$ y defina $f(0)=7$. Calcule $\lim_{x\to0}f(x)$.

**Solución.** Con $u=2x$, $f(x)=(e^u-1)/u\to1$. El valor puntual $7$ define $f(0)$, mientras que el límite es $1$.

**Ejercicio E11 — Demostrar el teorema de composición (propuesto en la clase, 1:30:53; solución editorial).** Con las hipótesis de la sección 8, desarrolle la prueba mediante sucesiones.

**Solución.** Véase la demostración editorial de la sección 8. El paso técnico consiste en observar que la composición $f(g(x_n))$ está definida sobre el dominio $D$ y que, eventualmente, $g(x_n)\in B\setminus\{b\}$. La condición universal del límite de $f$ se aplica entonces a los argumentos interiores.

---

## Límites de composiciones y caracterización épsilon-delta

La composición permite trasladar problemas a límites ya conocidos, siempre que se verifiquen sus hipótesis. La formulación épsilon-delta aporta una segunda caracterización rigurosa de la misma noción.

**Grabaciones de referencia:** [grabación de la cátedra 13.1](https://www.youtube.com/watch?v=R2rghIx2vRc).

*Procedencia de este tramo: cátedra 13.1.*

### El límite de una composición: qué es necesario comprobar

**En la clase ([13:03](https://www.youtube.com/watch?v=R2rghIx2vRc&t=783s)–[14:10](https://www.youtube.com/watch?v=R2rghIx2vRc&t=850s)).** La operación de composición organiza el cálculo en dos etapas: la función interior $g$ transforma la variable $x$; la función exterior $f$ actúa sobre $g(x)$. Si $x$ se aproxima a $a$ y $g(x)$ se aproxima a $b$, parece natural estudiar el comportamiento de $f(u)$ cuando $u$ se aproxima a $b$.

Para formular el teorema con precisión, consideramos dos funciones reales $g:D_g\to\mathbb R$ y $f:D_f\to\mathbb R$. Su **dominio de composición** es el conjunto

$$
D(f\circ g)=\{x\in D_g:g(x)\in D_f\}.
$$

Definimos $h=f\circ g$ por $h(x)=f(g(x))$ en ese conjunto. El teorema estudia el límite de $h$ cuando $x$ se aproxima a un punto de acumulación $a$ de $D(h)$.

**Teorema de composición (versión usada en la clase).** Supongamos que $a$ es punto de acumulación de $D(f\circ g)$, que $b$ es punto de acumulación de $D_f$, y que:

1. $\displaystyle\lim_{x\to a}g(x)=b$ en el dominio pertinente;
2. $\displaystyle\lim_{u\to b}f(u)=L$;
3. existe $\delta_0>0$ tal que para todo $x\in D(f\circ g)$ con $0<|x-a|<\delta_0$ se cumple $g(x)\ne b$.

Entonces

$$
\boxed{\displaystyle \lim_{x\to a}f(g(x))=L.}
$$

El tercer requisito puede leerse como una condición de **aproximación perforada de la imagen de $g$**: cerca de $a$, los valores de $g$ que intervienen en la composición pertenecen al dominio de $f$ y se aproximan a $b$ a través de puntos distintos de $b$. Esta hipótesis cumple un papel lógico, pues la definición de límite exterior utiliza precisamente valores $u\ne b$.

![Esquema editorial original: composición, dominios y convergencia.](figuras/IC2021_Catedra_13_1/01_composicion_y_dominios.png)

*Figura 1. Esquema editorial. El argumento secuencial obliga a conservar tanto la pertenencia a los dominios como la condición $g(x_n)\ne b$.*

#### Demostración desarrollada
**En la clase ([14:11](https://www.youtube.com/watch?v=R2rghIx2vRc&t=851s)–[21:44](https://www.youtube.com/watch?v=R2rghIx2vRc&t=1304s)).** Sea $(x_n)$ una sucesión **arbitraria** que satisface

$$
x_n\in D(f\circ g),\qquad x_n\ne a,\qquad x_n\longrightarrow a.
$$

La condición de dominio significa simultáneamente $x_n\in D_g$ y $g(x_n)\in D_f$. Como $g(x)\to b$ cuando $x\to a$, el criterio secuencial aplicado a $g$ establece

$$
g(x_n)\longrightarrow b.
$$

La hipótesis 3 añade que, para $n$ suficientemente grande, $g(x_n)\ne b$. Por tanto la sucesión de imágenes $(g(x_n))$ cumple las tres condiciones necesarias para aplicar a $f$ su límite en $b$: pertenece a $D_f$, converge a $b$ y se mantiene distinta de $b$ desde algún índice. De la segunda hipótesis se obtiene entonces

$$
f(g(x_n))\longrightarrow L.
$$

Como $(x_n)$ era arbitraria, este es el criterio secuencial del límite de $f\circ g$ en $a$. La afirmación queda demostrada. Los primeros términos, en caso de que no satisfagan la condición de cercanía, carecen de influencia sobre la convergencia de la sucesión.

#### Por qué la tercera hipótesis importa
**En la clase ([19:30](https://www.youtube.com/watch?v=R2rghIx2vRc&t=1170s)–[24:55](https://www.youtube.com/watch?v=R2rghIx2vRc&t=1495s)).** San Martín insiste en verificar $g(x)\ne b$ antes de sustituir una variable por otra. Una función interior puede tender a $b$ tomando exactamente ese valor para todos los $x$ cercanos a $a$; entonces el comportamiento de $f$ en el punto $b$ podría diferir de su límite alrededor de $b$.

**Ampliación editorial — contraejemplo comprobable.** Consideremos

$$
f(u)=\begin{cases}1,&u=0,\\0,&u\ne0,\end{cases}
\qquad g(x)=0\quad(x\in\mathbb R).
$$

Se cumplen $\lim_{x\to0}g(x)=0$ y $\lim_{u\to0}f(u)=0$. Sin embargo, la composición vale $f(g(x))=1$ en todos los puntos, por lo que $\lim_{x\to0}f(g(x))=1$. La condición 3 falla precisamente porque $g(x)=b=0$ para todo $x$.

![Esquema editorial original de una composición que revela el papel de la tercera hipótesis.](figuras/IC2021_Catedra_13_1/02_hipotesis_tercera.png)

*Figura 2. Esquema editorial. El valor puntual de la función exterior aparece de forma persistente si la función interior toma exactamente el valor límite.*

**Ampliación editorial — otra versión útil.** Si $f$ es continua en $b$ (es decir, $f(b)$ existe y $\lim_{u\to b}f(u)=f(b)$), entonces se puede admitir que $g(x)$ tome el valor $b$: en ese caso toda sucesión $g(x_n)\to b$ satisface $f(g(x_n))\to f(b)$. Esta variante requiere que la continuidad de $f$ haya sido previamente demostrada. En la clase se trabaja con la versión perforada y se deja el estudio sistemático de la continuidad para una unidad posterior.

#### Método de trabajo para un ejercicio
**En la clase ([22:08](https://www.youtube.com/watch?v=R2rghIx2vRc&t=1328s)–[26:29](https://www.youtube.com/watch?v=R2rghIx2vRc&t=1589s)).** San Martín recomienda reconocer primero la función interior, calcular a qué número tiende, comprobar explícitamente la condición adicional y, por último, calcular el límite de la función exterior en ese número. Conservar escrita la hipótesis 3 constituye una disciplina esencial de demostración.

### La exponencial en un punto real arbitrario

**En la clase ([26:55](https://www.youtube.com/watch?v=R2rghIx2vRc&t=1615s)–[33:59](https://www.youtube.com/watch?v=R2rghIx2vRc&t=2039s)).** De la cátedra anterior se sabe que

$$
\lim_{u\to0}e^u=1,
\qquad \lim_{u\to0}\frac{e^u-1}{u}=1.
$$

Para estudiar $e^x$ cuando $x\to a$, introducimos la variable interior $u=x-a$. Así $u\to0$ y, además, $x\ne a$ implica $u\ne0$. La función exponencial satisface

$$
e^x=e^{u+a}=e^u e^a.
$$

Por el límite conocido y el álgebra de límites,

$$
\boxed{\displaystyle\lim_{x\to a}e^x=e^a.}
$$

Este cálculo demuestra una propiedad que más adelante recibirá el nombre de *continuidad de la exponencial*: su valor en el punto coincide con el límite de sus valores próximos.

#### El primer cociente incremental
**En la clase ([34:41](https://www.youtube.com/watch?v=R2rghIx2vRc&t=2081s)–[40:50](https://www.youtube.com/watch?v=R2rghIx2vRc&t=2450s)).** Al restar $e^a$ del numerador y dividir por la diferencia de argumentos, aparece el límite

$$
\lim_{x\to a}\frac{e^x-e^a}{x-a}.
$$

El cambio $u=x-a$ produce, para $x\ne a$,

$$
\frac{e^x-e^a}{x-a}
=\frac{e^{a+u}-e^a}{u}
=e^a\frac{e^u-1}{u}.
$$

El último cociente tiende a $1$. Por consiguiente,

$$
\boxed{\displaystyle\lim_{x\to a}\frac{e^x-e^a}{x-a}=e^a.}
$$

El cociente mide la pendiente de la recta secante entre $(a,e^a)$ y $(x,e^x)$. Cuando $x$ se aproxima a $a$, esas pendientes se aproximan a $e^a$; esta construcción será la definición formal de derivada en la siguiente unidad.

![Esquema editorial original de secantes de una exponencial y su pendiente límite.](figuras/IC2021_Catedra_13_1/03_cociente_incremental_exponencial.png)

*Figura 3. Esquema editorial. Las secantes convergen hacia la recta de pendiente $e^a$ en el punto señalado.*

### La función seno y su cociente incremental

**En la clase ([41:00](https://www.youtube.com/watch?v=R2rghIx2vRc&t=2460s)–[44:52](https://www.youtube.com/watch?v=R2rghIx2vRc&t=2692s)).** El límite fundamental $\lim_{u\to0}\sin u=0$, junto con $\lim_{u\to0}\cos u=1$, fue establecido en la cátedra 12.2. Tomamos de nuevo $u=x-a$ y usamos la fórmula de adición:

$$
\sin x=\sin(u+a)=\sin u\cos a+\cos u\sin a.
$$

Por el álgebra de límites,

$$
\boxed{\displaystyle\lim_{x\to a}\sin x=\sin a.}
$$

La misma estrategia permite obtener $\lim_{x\to a}\cos x=\cos a$ a partir de la fórmula del coseno de una suma. Estas igualdades preparan el cálculo de cocientes incrementales.

**Demostración desarrollada ([44:54](https://www.youtube.com/watch?v=R2rghIx2vRc&t=2694s)–[55:59](https://www.youtube.com/watch?v=R2rghIx2vRc&t=3359s)).** Consideremos

$$
\frac{\sin x-\sin a}{x-a}.
$$

Con $u=x-a$ y la fórmula de adición,

$$
\begin{aligned}
\frac{\sin(a+u)-\sin a}{u}
&=\frac{\sin u\cos a+(\cos u-1)\sin a}{u}\\
&=\frac{\sin u}{u}\cos a+\frac{\cos u-1}{u}\sin a.
\end{aligned}
$$

El primer factor tiende a $\cos a$ porque $\sin u/u\to1$. El segundo cociente tiende a cero. En efecto,

$$
\frac{\cos u-1}{u}
=-u\,\frac{1-\cos u}{u^2}
\longrightarrow0\cdot\frac12=0.
$$

Aquí se emplean, en el orden apropiado, los dos límites fundamentales ya demostrados. Por ello,

$$
\boxed{\displaystyle\lim_{x\to a}\frac{\sin x-\sin a}{x-a}=\cos a.}
$$

![Esquema editorial original del cociente incremental de la función seno.](figuras/IC2021_Catedra_13_1/04_cociente_incremental_seno.png)

*Figura 4. Esquema editorial. El cociente incremental tiende a la pendiente $\cos a$.*

#### El coseno y la tangente
**Ejercicios propuestos en la clase ([56:00](https://www.youtube.com/watch?v=R2rghIx2vRc&t=3360s)–[58:57](https://www.youtube.com/watch?v=R2rghIx2vRc&t=3537s)).** El profesor pide calcular los cocientes correspondientes al coseno y a la tangente. Indica sus resultados: $-\sin a$ y $\sec^2 a$, respectivamente.

**Ampliación editorial — solución del coseno.** Para $u=x-a$,

$$
\begin{aligned}
\frac{\cos(a+u)-\cos a}{u}
&=\cos a\,\frac{\cos u-1}{u}-\sin a\,\frac{\sin u}{u}\\
&\longrightarrow0-\sin a.
\end{aligned}
$$

Así,

$$
\boxed{\displaystyle\lim_{x\to a}\frac{\cos x-\cos a}{x-a}=-\sin a.}
$$

**Ampliación editorial — solución de la tangente.** Para $\cos a\ne0$, la tangente se define en un entorno de $a$. Su identidad de diferencia da

$$
\tan x-\tan a=\frac{\sin(x-a)}{\cos x\cos a}.
$$

Por tanto,

$$
\frac{\tan x-\tan a}{x-a}
=\frac{\sin(x-a)}{x-a}\cdot\frac1{\cos x\cos a}
\longrightarrow\frac1{\cos^2a}=\sec^2a.
$$

El requisito $\cos a\ne0$ es necesario para que $\tan a$ sea un número real y para asegurar que la función esté definida cerca del punto.

#### La función cuadrática
**En la clase ([59:19](https://www.youtube.com/watch?v=R2rghIx2vRc&t=3559s)–[1:00:59](https://www.youtube.com/watch?v=R2rghIx2vRc&t=3659s)).** San Martín recuerda el cálculo elemental

$$
\frac{x^2-a^2}{x-a}=x+a\quad(x\ne a),
$$

cuya convergencia cuando $x\to a$ es $2a$. Es la misma arquitectura de cociente incremental, resuelta aquí mediante factorización algebraica. La clase señala que la teoría sistemática de estas pendientes corresponderá a la unidad de derivadas.

### Escalamiento y combinación de límites fundamentales

**En la clase ([1:07:07](https://www.youtube.com/watch?v=R2rghIx2vRc&t=4027s)–[1:13:01](https://www.youtube.com/watch?v=R2rghIx2vRc&t=4381s)).** Para un parámetro real fijo $a$, se estudia

$$
\lim_{x\to0}\frac{\sin(ax)}{x}.
$$

Si $a\ne0$, hacemos $u=ax$. Entonces $u\to0$ cuando $x\to0$ y $x\ne0$ garantiza $u\ne0$, condición adicional que el profesor exige verificar. Por consiguiente,

$$
\frac{\sin(ax)}{x}=a\frac{\sin u}{u}\longrightarrow a.
$$

Si $a=0$, el numerador es $\sin0=0$ para todo $x$, por lo que el cociente es la función constante $0$ en el entorno perforado y su límite vale $0=a$. Se obtiene, para **todo** $a\in\mathbb R$,

$$
\boxed{\displaystyle\lim_{x\to0}\frac{\sin(ax)}x=a.}
$$

Esta separación de casos es parte sustantiva de la clase: el resultado es uniforme en el parámetro, mientras que la demostración por sustitución requiere $a\ne0$.

![Esquema editorial original de varios cocientes sin(ax)/x.](figuras/IC2021_Catedra_13_1/05_limite_seno_ax_sobre_x.png)

*Figura 5. Esquema editorial. Para cada valor fijo de $a$, el cociente $\sin(ax)/x$ se aproxima a $a$.*

#### Dos parámetros en un cociente de senos
**En la clase ([1:13:04](https://www.youtube.com/watch?v=R2rghIx2vRc&t=4384s)–[1:15:00](https://www.youtube.com/watch?v=R2rghIx2vRc&t=4500s)).** Se considera $\sin(ax)/\sin(bx)$ cuando $x\to0$. Para $b\ne0$, la función del denominador está definida y es distinta de cero en un entorno perforado suficientemente pequeño. Multiplicamos numerador y denominador por $1/x$:

$$
\frac{\sin(ax)}{\sin(bx)}
=\frac{\sin(ax)/x}{\sin(bx)/x}.
$$

El numerador tiende a $a$ y el denominador tiende a $b\ne0$; el teorema del cociente proporciona

$$
\boxed{\displaystyle\lim_{x\to0}\frac{\sin(ax)}{\sin(bx)}=\frac ab\qquad(b\ne0).}
$$

#### Un ejercicio compuesto y la lectura de la pizarra
**Lectura incierta ([1:15:03](https://www.youtube.com/watch?v=R2rghIx2vRc&t=4503s)–[1:17:59](https://www.youtube.com/watch?v=R2rghIx2vRc&t=4679s)).** El profesor presenta un cociente formado por un seno elevado al cubo, un factor $1-\cos(bx)$ y un factor $e^{cx}-1$. La transcripción automática permite recuperar **la técnica de distribución de potencias de $x$**: normalizar el seno con $x$, el término cosenoidal con $x^2$ y la exponencial con $x$, pero la escritura exacta del cociente compuesto y algunos símbolos no quedan acreditados por el subtitulado. La igualdad concreta siguiente es, por tanto, una **ampliación editorial ejemplificadora**, y no una transcripción de la expresión que aparecía en la pizarra.

**Ampliación editorial — modelo de la técnica.** Si $b,c\ne0$, estudiemos

$$
R(x)=\frac{\sin^3(ax)}{(1-\cos(bx))(e^{cx}-1)}.
$$

Para $x$ cercano a cero y distinto de cero, sus factores permiten escribir

$$
R(x)=\frac{(\sin(ax)/x)^3}
{\bigl((1-\cos(bx))/x^2\bigr)\bigl((e^{cx}-1)/x\bigr)}.
$$

Usando los tres límites fundamentales normalizados,

$$
\lim_{x\to0}R(x)=\frac{a^3}{(b^2/2)c}=\boxed{\frac{2a^3}{b^2c}}.
$$

La hipótesis $b,c\ne0$ asegura que el denominador de este ejemplo tiene el comportamiento indicado y admite el cálculo del cociente. Si $a=0$, el numerador es cero y el resultado sigue siendo cero. El valor exacto de la expresión **original de clase** queda pendiente de cotejo visual de la pizarra.

![Esquema editorial original de tres cocientes normalizados.](figuras/IC2021_Catedra_13_1/06_tres_limites_fundamentales.png)

*Figura 6. Esquema editorial. Los cocientes $\sin x/x$, $2(1-\cos x)/x^2$ y $(e^x-1)/x$ convergen a $1$ y pueden combinarse algebraicamente.*

#### El cociente fundamental del logaritmo
**En la clase ([1:18:02](https://www.youtube.com/watch?v=R2rghIx2vRc&t=4682s)–[1:21:30](https://www.youtube.com/watch?v=R2rghIx2vRc&t=4890s)).** Ahora se solicita el límite

$$
\lim_{x\to1}\frac{\ln x}{x-1}.
$$

El numerador y el denominador tienden a cero, y su cociente requiere una nueva transformación. Elegimos $u=\ln x$. Dado que $x\to1$ por valores positivos, se tiene $u\to0$; como $\ln$ es inyectiva, $x\ne1$ implica $u\ne0$. La igualdad $x=e^u$ permite escribir

$$
\frac{\ln x}{x-1}=\frac{u}{e^u-1}
=\frac1{(e^u-1)/u}.
$$

El denominador converge a $1$, de donde

$$
\boxed{\displaystyle\lim_{x\to1}\frac{\ln x}{x-1}=1.}
$$

**Ampliación editorial.** Para $a>0$, un nuevo cambio $x=a+u$ unido a la identidad $\ln x-\ln a=\ln(x/a)$ da

$$
\boxed{\displaystyle\lim_{x\to a}\frac{\ln x-\ln a}{x-a}=\frac1a.}
$$

Es una primera anticipación de la pendiente de $\ln x$ en un punto general. Se incluye para completar el itinerario algebraico; la grabación desarrolla explícitamente el caso $a=1$.

### La caracterización épsilon-delta del límite

**En la clase ([1:22:01](https://www.youtube.com/watch?v=R2rghIx2vRc&t=4921s)–[1:30:31](https://www.youtube.com/watch?v=R2rghIx2vRc&t=5431s)).** San Martín explica que el límite puede formularse mediante desigualdades de distancias. El teorema reúne la cercanía horizontal de los argumentos y la cercanía vertical de las imágenes. En la exposición se dibujan franjas de altura $2\varepsilon$ y entornos de radio $\delta$; la demostración formal de la equivalencia con sucesiones queda anunciada como un resultado que puede desarrollarse aparte.

**Caracterización épsilon-delta.** Sean $f:A\to\mathbb R$, un punto de acumulación $a$ de $A$ y $L\in\mathbb R$. Entonces

$$
\boxed{\lim_{x\to a}f(x)=L\quad\Longleftrightarrow\quad
\forall\varepsilon>0\ \exists\delta>0\ \forall x\in A:
\bigl(0<|x-a|<\delta\bigr)\Rightarrow |f(x)-L|<\varepsilon.}
$$

El cuantificador $\forall\varepsilon>0$ expresa que la cercanía vertical solicitada puede ser tan exigente como se desee. El número $\delta>0$ se elige en función de esa exigencia: en la parte del dominio que cumple $0<|x-a|<\delta$, las imágenes cumplen $L-\varepsilon<f(x)<L+\varepsilon$. El entorno es **perforado**, pues la aproximación utiliza puntos distintos de $a$.

![Esquema editorial original de la caracterización épsilon-delta.](figuras/IC2021_Catedra_13_1/07_caracterizacion_epsilon_delta.png)

*Figura 7. Esquema editorial. Para una exigencia vertical $\varepsilon$, se encuentra un radio horizontal $\delta$ que conserva la imagen dentro de la banda; el valor puntual de $f(a)$ puede ocupar otra altura.*

#### Por qué ambas definiciones coinciden
**Ampliación editorial — demostración completa.** Supongamos primero que se cumple la caracterización épsilon-delta. Sea $x_n\in A$, con $x_n\ne a$ y $x_n\to a$. Dado $\varepsilon>0$, elegimos el $\delta$ de la caracterización. Como $x_n\to a$, existe $N$ tal que $n\ge N$ implica $|x_n-a|<\delta$. Entonces $|f(x_n)-L|<\varepsilon$ para $n\ge N$, por lo cual $f(x_n)\to L$.

Para la implicación inversa, supongamos que toda sucesión admisible satisface $f(x_n)\to L$. Si la condición épsilon-delta fallara, existiría un $\varepsilon_0>0$ tal que para **cada** $\delta>0$ habría un punto $x\in A$ con

$$
0<|x-a|<\delta,
\qquad |f(x)-L|\ge\varepsilon_0.
$$

Eligiendo $\delta=1/n$, obtenemos una sucesión $x_n\in A$ con $0<|x_n-a|<1/n$ y $|f(x_n)-L|\ge\varepsilon_0$ para todos los índices. Por el sándwich, $x_n\to a$, mientras que la distancia de $f(x_n)$ a $L$ conserva una cota inferior positiva. Eso contradice el criterio secuencial. Así se demuestra la equivalencia.

**Observación.** La exigencia de que $a$ sea punto de acumulación tiene aquí una importancia lógica: garantiza que existen puntos del dominio arbitrariamente próximos a $a$ y distintos de él. La clase vuelve sobre este punto mediante un ejemplo de cuantificadores sobre el conjunto vacío.

### Puntos de acumulación, existencia del límite y cuantificadores

**En la clase ([1:30:32](https://www.youtube.com/watch?v=R2rghIx2vRc&t=5432s)–[1:36:46](https://www.youtube.com/watch?v=R2rghIx2vRc&t=5806s)).** Un **punto de acumulación** de $A\subseteq\mathbb R$ es un real $a$ para el que existe una sucesión $(x_n)$ de puntos de $A$ que converge a $a$ y cuyos términos son todos distintos de $a$. Esta propiedad también puede formularse así:

$$
\forall\delta>0\quad
(A\setminus\{a\})\cap(a-\delta,a+\delta)\ne\varnothing.
$$

La caracterización permite distinguir dos problemas matemáticos: primero, si los puntos del dominio permiten aproximarse a $a$; segundo, si las imágenes de esos puntos convergen a un único valor. Ambos pasos son esenciales.

**Ejemplo de la clase.** La función $x\mapsto\sqrt{x}$ tiene por dominio $[0,\infty)$. El punto $-8$ se encuentra fuera del conjunto de puntos de acumulación de ese dominio: ninguna sucesión de términos no negativos puede converger a $-8$. Por tanto, dentro de la definición adoptada en el curso, el símbolo $\lim_{x\to-8}\sqrt{x}$ queda **fuera del ámbito en que se define el límite**.

**Ejemplo de la clase.** La parte entera $x\mapsto\lfloor x\rfloor$ tiene dominio $\mathbb R$, por lo que $1$ es un punto de acumulación. Sin embargo, las sucesiones $x_n=1-1/n$ y $y_n=1+1/n$, tomando $n\ge2$, producen imágenes que convergen a $0$ y $1$, respectivamente. Por unicidad, el límite bilateral en $1$ no existe. En este caso el dominio admite la aproximación, pero las imágenes ofrecen dos comportamientos incompatibles con un mismo límite.

![Esquema editorial original: punto fuera de acumulación y salto en un punto de acumulación.](figuras/IC2021_Catedra_13_1/08_acumulacion_y_salto.png)

*Figura 8. Esquema editorial. Son dos diagnósticos distintos: el dominio de $\sqrt{x}$ impide aproximarse a un real negativo; el de $\lfloor x\rfloor$ admite aproximarse a $1$, donde sus ramas laterales tienen límites diferentes.*

#### La sutileza del conjunto vacío
**En la clase ([1:37:00](https://www.youtube.com/watch?v=R2rghIx2vRc&t=5820s)–[1:42:31](https://www.youtube.com/watch?v=R2rghIx2vRc&t=6151s)).** Se estudian las dos proposiciones

$$
\forall x\in A\ P(x),
\qquad \exists x\in A\ P(x).
$$

Cuando $A$ tiene algún elemento, la primera proposición implica la segunda. Para $A=\varnothing$, la primera es verdadera por vacuidad y la segunda es falsa. La lección lógica es que el cuantificador universal describe un comportamiento de **todos los elementos disponibles**, mientras que el existencial acredita la presencia de al menos un elemento. Una implicación desde lo universal hacia lo existencial requiere que el conjunto sea habitado.

En el contexto del límite, exigir $a\in A'$ (el conjunto de puntos de acumulación) asegura la existencia de puntos de $A$ en **cada** entorno perforado de $a$. Esto evita que la condición $\forall x\in A$ se satisfaga vacíamente en una vecindad carente de puntos relevantes. De lo contrario, cualquier valor $L$ podría satisfacer la condición épsilon-delta sin que existan datos de la función cerca del punto, lo que destruiría la unicidad del supuesto límite. Por ello la hipótesis de acumulación forma parte constitutiva del marco conceptual del curso.

**En la clase ([1:42:32](https://www.youtube.com/watch?v=R2rghIx2vRc&t=6152s)–[1:45:08](https://www.youtube.com/watch?v=R2rghIx2vRc&t=6308s)).** El docente anticipa que en la cátedra 13.2 se estudiarán los **límites laterales**. Para un punto en el extremo del dominio, como $a=0$ para $\sqrt{x}$, se estudia la aproximación desde los puntos que pertenecen al dominio. La existencia de aproximaciones por la derecha y por la izquierda se tratará separadamente cuando corresponda. La pregunta final de la clase subraya que cada lado debe contener puntos relevantes antes de formular un límite lateral.

### Taller de problemas y soluciones

Los ejercicios se presentan a continuación según la fuente de origen; las ampliaciones editoriales de cada apuntes permanecen expresamente identificadas.

#### Problemas de práctica y soluciones — cátedra 13.1

Los siguientes ejercicios son **ampliaciones editoriales**, salvo donde se indica expresamente que San Martín propuso un cálculo durante la clase. Se distinguen aplicaciones directas, pruebas del teorema y problemas de transferencia. En cada caso deben verificarse el dominio y las hipótesis de la composición cuando se utilice.

**E1.** Calcular $\lim_{x\to2}e^{3x-1}$ mediante composición.

**E2.** Calcular $\lim_{x\to a}(e^{2x}-e^{2a})/(x-a)$ para $a\in\mathbb R$.

**E3.** Calcular $\lim_{x\to a}(\sin(3x)-\sin(3a))/(x-a)$.

**E4. Ejercicio propuesto en la clase (56:00).** Calcular $\lim_{x\to a}(\cos x-\cos a)/(x-a)$ y explicar el signo.

**E5. Ejercicio propuesto en la clase (57:37).** Calcular $\lim_{x\to a}(\tan x-\tan a)/(x-a)$ para $\cos a\ne0$.

**E6.** Calcular $\lim_{x\to0}\sin(5x)/x$ y $\lim_{x\to0}\sin(0x)/x$ identificando cuándo se utiliza la hipótesis adicional.

**E7.** Calcular $\lim_{x\to0}\sin(2x)/\sin(7x)$.

**E8.** Calcular $\lim_{x\to0}\bigl[\sin^3(2x)/((1-\cos3x)(e^{4x}-1))\bigr]$.

**E9.** Calcular $\lim_{x\to1}\ln x/(x-1)$ y $\lim_{x\to2}(\ln x-\ln2)/(x-2)$.

**E10.** Demostrar con épsilon-delta que $\lim_{x\to3}(2x-1)=5$.

**E11.** Construir dos sucesiones del dominio de $\lfloor x\rfloor$ que converjan a $1$ y produzcan límites de imágenes diferentes.

**E12.** Dados $f(u)=1$ si $u=0$ y $f(u)=0$ si $u\ne0$, y $g(x)=0$, determinar $\lim_{u\to0}f(u)$, $\lim_{x\to0}g(x)$ y $\lim_{x\to0}f(g(x))$; precisar la hipótesis incumplida.

**E13.** Para $f(x)=\sqrt{x}$ y su dominio natural, decidir si $-1$, $0$ y $4$ son puntos de acumulación, y calcular $\lim_{x\to0}\sqrt{x}$.

#### Soluciones comprobadas
**E1.** Para $g(x)=3x-1$, $g(x)\to5$ cuando $x\to2$, y si $x\ne2$ entonces $g(x)\ne5$. La exponencial tiene límite $e^5$ en $5$. Resultado: $\boxed{e^5}$.

**E2.** Usamos $u=2(x-a)$ y factorizamos $e^{2a}$:

$$
\frac{e^{2x}-e^{2a}}{x-a}
=2e^{2a}\frac{e^{u}-1}{u}\longrightarrow\boxed{2e^{2a}}.
$$

**E3.** Con $u=3(x-a)$,

$$
\frac{\sin(3x)-\sin(3a)}{x-a}
=3\frac{\sin(3a+u)-\sin(3a)}u\longrightarrow\boxed{3\cos(3a)}.
$$

**E4.** Por la fórmula de adición,

$$
\frac{\cos(a+u)-\cos a}{u}
=\cos a\frac{\cos u-1}{u}-\sin a\frac{\sin u}{u}
\longrightarrow\boxed{-\sin a}.
$$

El signo procede de la fórmula $\cos(a+u)=\cos a\cos u-\sin a\sin u$.

**E5.** La diferencia de tangentes produce

$$
\frac{\tan x-\tan a}{x-a}
=\frac{\sin(x-a)}{x-a}\cdot\frac1{\cos x\cos a}
\longrightarrow\boxed{\sec^2 a},\quad\cos a\ne0.
$$

**E6.** El primer límite vale $5$ al escribir $u=5x$. El segundo cociente es idénticamente cero para $x\ne0$, y su límite vale $0$. En el segundo caso, la sustitución $u=0x$ incumple $u\ne0$; la evaluación directa del cociente resuelve el ejercicio.

**E7.** Los dos cocientes normalizados por $x$ tienden a $2$ y $7$, respectivamente. Como el segundo límite es distinto de cero, el resultado es $\boxed{2/7}$.

**E8.** Se usan el cubo del seno normalizado, el coseno normalizado por $x^2$ y la exponencial normalizada por $x$:

$$
\lim=\frac{2^3}{(3^2/2)\cdot4}=\boxed{\frac49}.
$$

**E9.** El primer resultado es $\boxed{1}$, por $u=\ln x$. El segundo se reduce a $\ln(x/2)=\ln(1+(x-2)/2)$ y al cociente fundamental, por lo que el resultado es $\boxed{1/2}$.

**E10.** Sea $\varepsilon>0$ y elijamos $\delta=\varepsilon/2$. Para todo $x\in\mathbb R$ con $0<|x-3|<\delta$,

$$
|(2x-1)-5|=2|x-3|<2\delta=\varepsilon.
$$

Por la definición, $\boxed{\lim_{x\to3}(2x-1)=5}$.

**E11.** Tomamos $x_n=1-1/(n+1)$ y $y_n=1+1/(n+1)$, ambos distintos de $1$ y convergentes a $1$. Se cumple $\lfloor x_n\rfloor=0$ y $\lfloor y_n\rfloor=1$. Así, el límite bilateral en $1$ no existe.

**E12.** Se obtiene $\lim_{u\to0}f(u)=0$, $\lim_{x\to0}g(x)=0$ y $\lim_{x\to0}f(g(x))=1$. La función interior toma exactamente su valor límite en todos los puntos; por ello falla la condición adicional $g(x)\ne b$ del teorema de composición.

**E13.** El conjunto de puntos de acumulación de $[0,\infty)$ es $[0,\infty)$: $0$ y $4$ son puntos de acumulación y $-1$ queda fuera. Para $x_n\ge0$ con $x_n\to0$, se tiene $\sqrt{x_n}\to0$ porque $\sqrt{x_n}\ge0$ y, para $\varepsilon>0$, eventualmente $x_n<\varepsilon^2$ implica $\sqrt{x_n}<\varepsilon$. Por ello $\boxed{\lim_{x\to0}\sqrt{x}=0}$, con aproximaciones restringidas al dominio.

---

## Límites laterales, infinito y asíntotas

La noción de límite se amplía al restringir el dominio de aproximación y al considerar comportamientos sin cota. Los casos laterales, infinitos y desde arriba o abajo constituyen una familia de situaciones regidas por cuantificadores precisos.

**Grabaciones de referencia:** [grabación de la cátedra 13.2](https://www.youtube.com/watch?v=t3bX0a0x3kU).

*Procedencia de este tramo: cátedra 13.2.*

### El problema inicial: un límite debe poder estudiarse

**En la clase ([2:28](https://www.youtube.com/watch?v=t3bX0a0x3kU&t=148s)–[7:30](https://www.youtube.com/watch?v=t3bX0a0x3kU&t=450s)).** La definición secuencial de límite fue el fundamento anterior. Sea $f:A\to\mathbb R$ y sea $a$ un **punto de acumulación** de $A$: existe una sucesión $(x_n)$ de elementos de $A$, todos distintos de $a$, que converge a $a$. El límite de $f$ en $a$ es $L$ cuando, para **toda** sucesión así, las imágenes $f(x_n)$ convergen a $L$. Esta condición se caracteriza también mediante dos umbrales positivos:

$$
\boxed{\lim_{x\to a}f(x)=L\iff
\forall\varepsilon>0\ \exists\delta>0\ \forall x\in A:\quad
0<|x-a|<\delta\Longrightarrow |f(x)-L|<\varepsilon.}
$$

El número $\varepsilon$ mide la tolerancia vertical y $\delta$ controla la proximidad de los argumentos al punto $a$. Los puntos involucrados pertenecen al dominio $A$ y satisfacen $x\ne a$. El valor eventual de $f(a)$, cuando está definido, puede ser diferente de $L$.

![Esquema editorial: banda de alturas y zona de aproximación.](figuras/IC2021_Catedra_13_2/07_bandas_epsilon_delta.png)

*Figura 1. Esquema editorial de una condición épsilon-delta. La franja vertical de entradas puede estrecharse para colocar las imágenes en la franja horizontal fijada por la tolerancia.*

La hipótesis de **acumulación** asegura que cada vecindad perforada $(a-\delta,a+\delta)\cap(A\setminus\{a\})$ tiene al menos un punto. Así, el cuantificador universal examina efectivamente imágenes de la función y la aproximación responde a datos del dominio. Esta precaución dominará toda la clase: cada límite lateral o al infinito requiere que existan entradas admisibles arbitrariamente cerca de la región indicada.

**Ampliación editorial.** El criterio de acumulación puede expresarse mediante vecindades: $a\in A'$ si y solo si

$$
\forall r>0:\quad \bigl((a-r,a+r)\setminus\{a\}\bigr)\cap A\ne\varnothing.
$$

Su equivalencia con la existencia de una sucesión apropiada se obtiene eligiendo $x_n\in A$ con $0<|x_n-a|<1/n$. Recíprocamente, una sucesión convergente y de términos distintos de $a$ aporta un término en toda vecindad perforada. La función del punto de acumulación es garantizar que se dispone de **trayectorias de aproximación dentro del dominio**.

### Límites laterales: la variable se aproxima desde un lado

**En la clase ([8:09](https://www.youtube.com/watch?v=t3bX0a0x3kU&t=489s)–[16:57](https://www.youtube.com/watch?v=t3bX0a0x3kU&t=1017s)).** Tomamos un punto real $a$ y dividimos el dominio en sus partes situadas a la derecha e izquierda:

$$
A_+(a)=A\cap(a,+\infty),\qquad A_-(a)=A\cap(-\infty,a).
$$

El **límite derecho** estudia los valores $f(x)$ cuando $x$ procede de $A_+(a)$ y se acerca a $a$. El **límite izquierdo** estudia los valores $f(x)$ cuando $x$ procede de $A_-(a)$ y se acerca a $a$. Se definen, respectivamente, cuando $a$ es punto de acumulación del dominio unilateral pertinente.

**Límite derecho.** Si $a\in A_+(a)'$, entonces

$$
\lim_{x\to a^+}f(x)=L
\iff\forall\varepsilon>0\ \exists\delta>0\ \forall x\in A:\quad
 a<x<a+\delta\Longrightarrow |f(x)-L|<\varepsilon.
$$

**Límite izquierdo.** Si $a\in A_-(a)'$, entonces

$$
\lim_{x\to a^-}f(x)=L
\iff\forall\varepsilon>0\ \exists\delta>0\ \forall x\in A:\quad
 a-\delta<x<a\Longrightarrow |f(x)-L|<\varepsilon.
$$

El signo de $a^+$ o $a^-$ describe **la posición de las entradas** con respecto a $a$; el signo se coloca en la variable que tiende al punto. A lo largo de esta unidad conservaremos la condición de acumulación unilateral como parte explícita de la definición.

#### Teorema de recomposición de límites laterales
**En la clase ([16:20](https://www.youtube.com/watch?v=t3bX0a0x3kU&t=980s)–[20:37](https://www.youtube.com/watch?v=t3bX0a0x3kU&t=1237s)).** Supongamos que $a$ es punto de acumulación tanto de $A_+(a)$ como de $A_-(a)$. Entonces, para $L\in\mathbb R$,

$$
\boxed{\lim_{x\to a}f(x)=L
\iff
\lim_{x\to a^-}f(x)=L=\lim_{x\to a^+}f(x).}
$$

**Demostración desarrollada.** Si existe el límite total $L$, su definición se cumple para todos los puntos del dominio cercanos a $a$; se cumple, en particular, al restringirlos a cada conjunto unilateral. Por lo tanto ambos límites laterales valen $L$.

A la inversa, supongamos que los dos límites laterales existen y valen $L$. Dado $\varepsilon>0$, existen $\delta_-,\delta_+>0$ que funcionan, respectivamente, a izquierda y derecha. Tomemos $\delta=\min\{\delta_-,\delta_+\}$. Cualquier $x\in A$ con $0<|x-a|<\delta$ satisface exactamente una de las desigualdades $a-\delta<x<a$ o $a<x<a+\delta$. En ambos casos $|f(x)-L|<\varepsilon$. Esta es la definición del límite total.

La hipótesis de disponibilidad **de ambos lados** es esencial para este teorema. En un extremo del dominio la relación apropiada se establece con el lado que sí proporciona puntos de aproximación.

#### Primer ejemplo: el salto de la parte entera
**En la clase ([22:41](https://www.youtube.com/watch?v=t3bX0a0x3kU&t=1361s)–[25:37](https://www.youtube.com/watch?v=t3bX0a0x3kU&t=1537s)).** Para la función parte entera $f(x)=\lfloor x\rfloor$ definida en $\mathbb R$, los valores en $(0,1)$ son cero y los valores en $[1,2)$ son uno. Así,

$$
\lim_{x\to1^-}\lfloor x\rfloor=0,
\qquad
\lim_{x\to1^+}\lfloor x\rfloor=1.
$$

Como $1$ es acumulación de ambos sectores del dominio y los límites laterales son distintos, el límite total carece de valor real.

![Esquema editorial: función parte entera con salto en uno.](figuras/IC2021_Catedra_13_2/01_parte_entera_salto.png)

*Figura 2. Esquema editorial de las dos alturas alcanzadas por aproximaciones laterales a $1$.*

#### Segundo ejemplo: el extremo del dominio de la raíz
**En la clase ([25:46](https://www.youtube.com/watch?v=t3bX0a0x3kU&t=1546s)–[34:08](https://www.youtube.com/watch?v=t3bX0a0x3kU&t=2048s)).** Sea $f(x)=\sqrt{x}$, con $A=[0,+\infty)$. El punto cero es acumulación de $A$ y de $A_+(0)=(0,+\infty)$, mientras que el sector $A_-(0)$ es vacío. Por eso existen el límite derecho y el total:

$$
\boxed{\lim_{x\to0^+}\sqrt{x}=0=\lim_{x\to0}\sqrt{x}.}
$$

Para comprobar el valor, sea $\varepsilon>0$. Si $x\in[0,+\infty)$ y $0<|x|<\delta=\varepsilon^2$, entonces $0<\sqrt{x}<\varepsilon$. Esta demostración cubre simultáneamente el límite total y el derecho, porque los conjuntos de entradas realmente examinados coinciden cerca del origen.

![Esquema editorial: raíz cuadrada y extremo del dominio.](figuras/IC2021_Catedra_13_2/02_raiz_extremo_dominio.png)

*Figura 3. Esquema editorial. En el límite total de $\sqrt{x}$ en cero, todas las entradas admisibles provienen del lado derecho.*

**Observación editorial sobre lenguaje.** Decir que el límite izquierdo «no existe» puede significar dos situaciones matemáticamente distintas. Aquí el límite unilateral izquierdo **no es estudiable** por falta de puntos del dominio. En una función oscilante definida a la izquierda, el límite sí es estudiable y puede fallar la convergencia. La clase subraya reiteradamente esta diferencia.

#### Tercer ejemplo: dos expresiones del valor absoluto
**En la clase ([41:07](https://www.youtube.com/watch?v=t3bX0a0x3kU&t=2467s)–[46:33](https://www.youtube.com/watch?v=t3bX0a0x3kU&t=2793s)).** La función $h(x)=|x|/x$ tiene dominio $\mathbb R\setminus\{0\}$. Según el signo de la entrada,

$$
h(x)=\begin{cases}1,&x>0,\\-1,&x<0.\end{cases}
$$

Por tanto, $\lim_{x\to0^+}h(x)=1$ y $\lim_{x\to0^-}h(x)=-1$. Ambos lados son accesibles y las alturas difieren: el límite total en cero carece de valor. En cambio, para cualquier $a>0$ la función vale uno en un entorno suficientemente pequeño de $a$, aunque $a$ se encuentre muy cerca de cero. En particular, el límite en $0{,}1$ vale uno.

![Esquema editorial: cociente valor absoluto.](figuras/IC2021_Catedra_13_2/03_cociente_valor_absoluto.png)

*Figura 4. Esquema editorial de $|x|/x$.*

#### Cuarto ejemplo: oscilación con dos sucesiones de testigos
**En la clase ([34:20](https://www.youtube.com/watch?v=t3bX0a0x3kU&t=2060s)–[39:13](https://www.youtube.com/watch?v=t3bX0a0x3kU&t=2353s)).** Estudiemos $g(x)=\sin(1/x)$ en $A=\mathbb R\setminus\{0\}$. Consideremos las sucesiones positivas

$$
x_n=\frac1{\frac\pi2+2\pi n},\qquad
y_n=\frac1{\frac{3\pi}2+2\pi n},\qquad n\ge1.
$$

Ambas convergen a cero por la derecha. Sus imágenes satisfacen exactamente

$$
g(x_n)=1,\qquad g(y_n)=-1.
$$

Como una misma función presenta dos límites de imágenes distintos para entradas admisibles que se acercan al mismo punto desde la derecha, **carece de límite derecho en cero**. En particular, carece también de límite total. Análogamente se pueden construir testigos del lado izquierdo.

![Esquema editorial: oscilaciones y dos familias de puntos.](figuras/IC2021_Catedra_13_2/04_oscilacion_seno_reciproco.png)

*Figura 5. Esquema editorial de la oscilación persistente de $\sin(1/x)$ cerca de cero.*

### Límites al infinito: aproximación sin cota de la variable independiente

**En la clase ([46:33](https://www.youtube.com/watch?v=t3bX0a0x3kU&t=2793s)–[58:19](https://www.youtube.com/watch?v=t3bX0a0x3kU&t=3499s)).** Los límites $x\to+\infty$ y $x\to-\infty$ examinan la función en las colas de su dominio. Para definirlos, el dominio debe ser, respectivamente, **no acotado superiormente** o **no acotado inferiormente**. Este requisito cumple el mismo papel de disponibilidad que el punto de acumulación en los límites finitos.

Si $A$ es no acotado superiormente, decimos que

$$
\boxed{\lim_{x\to+\infty}f(x)=L\iff
\forall\varepsilon>0\ \exists R>0\ \forall x\in A:\quad
x>R\Longrightarrow|f(x)-L|<\varepsilon.}
$$

Si $A$ es no acotado inferiormente, definimos

$$
\boxed{\lim_{x\to-\infty}f(x)=L\iff
\forall\varepsilon>0\ \exists R>0\ \forall x\in A:\quad
x<-R\Longrightarrow|f(x)-L|<\varepsilon.}
$$

El profesor escribe la barrera del lado izquierdo como $-M$ con $M>0$. Esta decisión mantiene positivos los parámetros de umbral y conserva la interpretación geométrica: se estudian entradas progresivamente grandes en magnitud negativa.

Una **asíntota horizontal** en la dirección $x\to+\infty$ es una recta $y=L$ para la cual la función satisface el primer límite. En la dirección $x\to-\infty$ se utiliza el segundo. Una función puede tener alturas horizontales asintóticas distintas en ambos extremos de su dominio.

![Esquema editorial: dos asíntotas horizontales.](figuras/IC2021_Catedra_13_2/05_dos_asintotas_horizontales.png)

*Figura 6. Ejemplo editorial: $x/\sqrt{x^2+1}$ tiende a $1$ cuando $x\to+\infty$ y a $-1$ cuando $x\to-\infty$.*

**Ampliación editorial.** Para verificar los valores de la figura, escribimos

$$
\frac{x}{\sqrt{x^2+1}}=\frac{x/|x|}{\sqrt{1+1/x^2}}.
$$

En la cola positiva $x/|x|=1$; en la negativa, $x/|x|=-1$. El denominador tiende a uno. La igualdad demuestra ambos límites sin invocar derivadas.

### Las veinticinco condiciones: una matriz de entrada y salida

**En la clase ([1:03:43](https://www.youtube.com/watch?v=t3bX0a0x3kU&t=3823s)–[1:22:01](https://www.youtube.com/watch?v=t3bX0a0x3kU&t=4921s)).** El título de la sesión se explica por dos familias independientes de opciones. La entrada admite las cinco modalidades ya estudiadas. La salida puede aproximarse a $L$, hacerlo a través de valores **mayores** que $L$ o **menores** que $L$, crecer hacia $+\infty$ o decrecer hacia $-\infty$.

![Esquema editorial: matriz de veinticinco combinaciones.](figuras/IC2021_Catedra_13_2/09_matriz_25_casos.png)

*Figura 7. Matriz editorial de las 25 combinaciones. Su lectura precisa exige los cuantificadores y las condiciones de dominio que siguen.*

#### Cinco condiciones de entrada
Sea $A\subseteq\mathbb R$ un dominio y $a\in\mathbb R$. La letra $\rho>0$ será el parámetro de cercanía asociado a una modalidad de entrada. Definimos:

| Modalidad | Condición de entrada $P_\rho(x)$ | Requisito para que pueda estudiarse |
|:--|:--|:--|
| $x\to a$ | $x\in A$, $0<|x-a|<\rho$ | $a\in A'$ |
| $x\to a^+$ | $x\in A$, $a<x<a+\rho$ | $a\in(A\cap(a,\infty))'$ |
| $x\to a^-$ | $x\in A$, $a-\rho<x<a$ | $a\in(A\cap(-\infty,a))'$ |
| $x\to+\infty$ | $x\in A$, $x>\rho$ | $A$ no acotado superiormente |
| $x\to-\infty$ | $x\in A$, $x<-\rho$ | $A$ no acotado inferiormente |

Con esta tabla, la variable $\rho$ representa $\delta$ en los tres primeros casos y un umbral $R$ o $M$ positivo en los dos últimos. **El requisito de la última columna se comprueba antes de plantear el límite.**

#### Cinco condiciones de salida
Con una tolerancia $\varepsilon>0$ o una cota $H>0$, escribimos:

| Modalidad de salida | Condición vertical que debe cumplirse |
|:--|:--|
| $f(x)\to L$ | $|f(x)-L|<\varepsilon$ |
| $f(x)\to L$ **desde arriba**, notada en clase $L^+$ | $0<f(x)-L<\varepsilon$ |
| $f(x)\to L$ **desde abajo**, notada en clase $L^-$ | $0<L-f(x)<\varepsilon$ |
| $f(x)\to+\infty$ | $f(x)>H$ |
| $f(x)\to-\infty$ | $f(x)<-H$ |

La combinación de cualquier fila de entradas con cualquier fila de salidas determina una condición completa. Para una **salida finita**, el esquema universal es

$$
\boxed{\forall\varepsilon>0\ \exists\rho>0\ \forall x\in A:\quad
P_\rho(x)\Longrightarrow Q_\varepsilon(f(x)),}
$$

y para una **salida infinita**, se emplea

$$
\boxed{\forall H>0\ \exists\rho>0\ \forall x\in A:\quad
P_\rho(x)\Longrightarrow Q_H(f(x)).}
$$

Aquí $Q$ es la desigualdad vertical correspondiente a la fila elegida. Esta regla **genera explícitamente los 25 casos** sin memorizar veinticinco fórmulas extensas. En el propio documento, por ejemplo, los casos de entrada $a^+$ y salida $L$, de entrada $+\infty$ y salida $L$, de entrada $-\infty$ y salida $+\infty$, quedan escritos en detalle.

#### Tres combinaciones desarrolladas
**En la clase ([1:11:05](https://www.youtube.com/watch?v=t3bX0a0x3kU&t=4265s) y [1:16:43](https://www.youtube.com/watch?v=t3bX0a0x3kU&t=4603s)).** En la primera combinación explicada, la entrada se aproxima a $a$ **por la izquierda** y la salida se aproxima a $L$ **desde arriba**:

$$
\forall\varepsilon>0\ \exists\delta>0\ \forall x\in A:\quad
\bigl(a-\delta<x<a\bigr)
\Longrightarrow \bigl(0<f(x)-L<\varepsilon\bigr).
$$

El valor $L$ es el límite ordinario; la condición adicional $f(x)>L$ indica la dirección vertical. El profesor utiliza la expresión simbólica $L^+$ para conservar esa información adicional.

En la segunda combinación explicada se hace que $x\to-\infty$ mientras $f(x)\to+\infty$:

$$
\forall H>0\ \exists R>0\ \forall x\in A:\quad
x<-R\Longrightarrow f(x)>H.
$$

Una parábola como $f(x)=x^2$, con dominio $\mathbb R$, satisface esta condición: dado $H>0$, basta $R=\sqrt H+1$; de $x<-R$ se deduce $x^2>H$.

La tercera combinación, incorporada como **ampliación editorial**, utiliza $x\to a^+$ y salida $-\infty$:

$$
\forall H>0\ \exists\delta>0\ \forall x\in A:\quad
0<x-a<\delta\Longrightarrow f(x)<-H.
$$

Por ejemplo, $f(x)=-1/(x-a)$ en el dominio $(a,+\infty)$ tiene este comportamiento, pues basta escoger $\delta=1/(H+1)$.

#### ¿Qué significan precisamente $L^+$ y $L^-$?
**Ampliación editorial de rigor.** En el uso común de cálculo, el número real límite de una función sigue siendo $L$. El signo sobrepuesto en $L^+$ o $L^-$ funciona aquí como **etiqueta de aproximación vertical**, según la convención didáctica de la grabación, y añade una desigualdad eventual. Se distingue cuidadosamente de $a^+$ y $a^-$, que indican la dirección de aproximación horizontal de la variable $x$.

La condición $f(x)\to L$ desde arriba **implica** que $f(x)\to L$; la implicación inversa requiere más información. Por ejemplo, la función constante $f(x)=L$ tiene límite $L$, pero su aproximación a $L$ no satisface las desigualdades estrictas $f(x)>L$ o $f(x)<L$. También puede ocurrir que $f(x)-L$ cambie infinitas veces de signo y aun así tienda a cero.

![Esquema editorial: altura alcanzada desde arriba o desde abajo.](figuras/IC2021_Catedra_13_2/08_altura_desde_arriba_abajo.png)

*Figura 8. Ejemplo editorial de dos funciones que se aproximan a la misma altura $L$ con desigualdades de signo opuesto.*

Las **25 casillas describen condiciones lógicas relacionadas**, con refinamientos e implicaciones entre ellas. Por ello el conteo es una organización pedagógica de los posibles comportamientos, más que una colección de veinticinco teoremas independientes.

### Límites de salida infinita y asíntotas verticales

**En la clase ([1:17:01](https://www.youtube.com/watch?v=t3bX0a0x3kU&t=4621s)–[1:21:19](https://www.youtube.com/watch?v=t3bX0a0x3kU&t=4879s)).** Cuando la salida crece por encima de cualquier cota, se escribe un límite $+\infty$; cuando decrece por debajo de toda cota negativa, se escribe un límite $-\infty$. Por ejemplo,

$$
\lim_{x\to a^+}f(x)=+\infty
\iff
\forall H>0\ \exists\delta>0\ \forall x\in A:\quad
0<x-a<\delta\Longrightarrow f(x)>H.
$$

Asimismo,

$$
\lim_{x\to a^-}f(x)=-\infty
\iff
\forall H>0\ \exists\delta>0\ \forall x\in A:\quad
a-\delta<x<a\Longrightarrow f(x)<-H.
$$

Si al menos uno de los límites unilaterales de $f$ en $a$ presenta una de estas divergencias infinitas, la recta $x=a$ es una **asíntota vertical** en el sentido que se utiliza en la clase.

![Esquema editorial: asíntota vertical y sentidos divergentes.](figuras/IC2021_Catedra_13_2/06_asintota_vertical.png)

*Figura 9. Ejemplo editorial: $f(x)=1/x$ presenta $-\infty$ a la izquierda de cero y $+\infty$ a la derecha.*

**Demostración desarrollada.** Para $f(x)=1/x$, dado $H>0$, elegimos $\delta=1/(H+1)$. Si $0<x<\delta$, entonces $1/x>H+1>H$. Si $-\delta<x<0$, el recíproco es $1/x<-(H+1)<-H$. Quedan acreditados los dos límites infinitos laterales. Esta divergencia se refiere a magnitudes sin cota; $+\infty$ y $-\infty$ son **símbolos de comportamiento** y no valores reales alcanzados por la función.

### Extensiones del álgebra, el sándwich y la composición

**En la clase ([1:22:22](https://www.youtube.com/watch?v=t3bX0a0x3kU&t=4942s)–[1:29:20](https://www.youtube.com/watch?v=t3bX0a0x3kU&t=5360s)).** Los teoremas conocidos de límites finitos conservan sus reglas ordinarias de suma, producto y cociente en sus dominios apropiados. Los comportamientos infinitos permiten extender algunas reglas: una función que crece hacia $+\infty$ conserva esa divergencia al sumarle una función que posee límite real finito. Dos funciones que crecen hacia $+\infty$ también producen una suma que crece hacia $+\infty$.

La expresión $+\infty-\infty$ señala una **forma indeterminada**: los dos términos pueden tener diferentes velocidades y la diferencia puede tender a un número, a alguno de los infinitos o presentar oscilaciones. La razón $\infty/\infty$ también es indeterminada. Son categorías de análisis: indican que la información sobre los límites separados resulta insuficiente para determinar el límite de la combinación.

**Ampliación editorial: tres resultados para una misma apariencia.** Cuando $x\to+\infty$, las funciones

$$
\bigl(x+x\bigr)-x=x\to+\infty,
\qquad (x+1)-x\to1,
\qquad x-(x+x)\to-\infty
$$

se obtienen restando expresiones que divergen hacia $+\infty$, pero producen límites completamente distintos. Análogamente, $x/x\to1$, $x/x^2\to0$ y $x^2/x\to+\infty$ ilustran la razón $\infty/\infty$.

El **principio de comparación infinita** sí da resultados completos. Si $f(x)\le g(x)$ para todos los puntos admisibles suficientemente cercanos según la modalidad de entrada elegida y $f(x)\to+\infty$, entonces $g(x)\to+\infty$. Si $f(x)\le g(x)$ y $g(x)\to-\infty$, entonces $f(x)\to-\infty$.

**Demostración desarrollada.** En el primer caso, dado $H>0$, existe un umbral de entrada a partir del cual $f(x)>H$. La desigualdad entrega $g(x)\ge f(x)>H$. En el segundo caso, la condición $g(x)<-H$ y la comparación entregan $f(x)\le g(x)<-H$. Las mismas pruebas funcionan para cualquiera de las cinco modalidades de entrada siempre que las desigualdades se cumplan en la región pertinente.

La clase también destaca el amplio número de combinaciones en la **composición**: cinco comportamientos de entrada, cinco de la función interior y cinco de la exterior originan **125 configuraciones formales**. Este número organiza posibles enunciados. Cada teorema efectivo requiere además hipótesis apropiadas sobre dominios, puntos de acumulación y compatibilidad de las aproximaciones, tal como se demostró en la cátedra 13.1.

### Dos demostraciones finales con cuantificadores

#### El recíproco tiende a cero desde valores positivos
**En la clase ([1:29:29](https://www.youtube.com/watch?v=t3bX0a0x3kU&t=5369s)–[1:35:43](https://www.youtube.com/watch?v=t3bX0a0x3kU&t=5743s)).** Se demuestra

$$
\boxed{\lim_{x\to+\infty}\frac1x=0,\quad\text{con }\frac1x>0\text{ en la cola positiva}.}
$$

**Demostración desarrollada.** Dado $\varepsilon>0$, escogemos $R=1/\varepsilon$. Para cualquier $x>R$ se cumplen $x>0$ y

$$
0<\frac1x<\frac1R=\varepsilon.
$$

La elección del umbral depende explícitamente de $\varepsilon$, tal como exige la definición. En sucesiones la desigualdad correspondiente se satisface escogiendo un entero $N>1/\varepsilon$; aquí el umbral puede ser cualquier real positivo. La precisión adicional «desde arriba» registra que $1/x$ mantiene signo positivo para entradas suficientemente grandes.

#### La exponencial se aproxima a cero por la izquierda del eje de entradas
**En la clase ([1:35:43](https://www.youtube.com/watch?v=t3bX0a0x3kU&t=5743s)–[1:41:58](https://www.youtube.com/watch?v=t3bX0a0x3kU&t=6118s)).** Se demuestra

$$
\boxed{\lim_{x\to-\infty}e^x=0,\quad e^x>0.}
$$

**Demostración desarrollada.** Dado $\varepsilon>0$, buscamos una cota $R>0$ tal que $x<-R$ implique $e^x<\varepsilon$. Como el logaritmo es estrictamente creciente,

$$
e^x<\varepsilon\iff x<\ln\varepsilon.
$$

Basta elegir

$$
\boxed{R=\max\{1,-\ln\varepsilon\}.}
$$

En efecto, $R\ge-\ln\varepsilon$ implica $-R\le\ln\varepsilon$; por lo tanto, $x<-R$ asegura $x<\ln\varepsilon$ y de aquí $0<e^x<\varepsilon$. La elección funciona tanto para tolerancias pequeñas como grandes y mantiene el umbral $R$ estrictamente positivo. Esta demostración muestra cómo un resultado previo sobre la función logaritmo permite construir el umbral exigido por la definición.

### Taller de problemas y soluciones

Los ejercicios se presentan a continuación según la fuente de origen; las ampliaciones editoriales de cada apuntes permanecen expresamente identificadas.

#### Ejercicios de estudio y soluciones — cátedra 13.2

Los ejercicios siguientes son **ampliaciones editoriales**, salvo aquellos que retoman una actividad expresamente tratada o propuesta en la grabación. En cada solución conviene empezar por el dominio y las regiones de aproximación accesibles.

**Ejercicio 1 (repaso de la clase).** Hallar los dos límites laterales de $\lfloor x\rfloor$ en $x=2$. **Solución.** En $(1,2)$ la parte entera vale uno, y en $(2,3)$ vale dos. Por tanto, el izquierdo es uno y el derecho es dos; el límite total carece de valor real.

**Ejercicio 2 (repaso de la clase).** Determinar los límites accesibles de $\sqrt{x}$ en $0$. **Solución.** El dominio es $[0,+\infty)$; el límite total y el derecho son cero. El lado izquierdo carece de puntos de aproximación del dominio.

**Ejercicio 3 (editorial).** Para $f(x)=\sqrt{1-x}$, estudiar $x\to1$. **Solución.** El dominio es $(-\infty,1]$; el límite total y el izquierdo son cero. El límite derecho carece de dominio accesible.

**Ejercicio 4 (repaso de la clase).** Calcular los límites de $|x|/x$ en $0$. **Solución.** El izquierdo vale $-1$ y el derecho vale $1$; existe diferencia entre las dos aproximaciones.

**Ejercicio 5 (editorial).** Hallar $\lim_{x\to0}\sqrt{|x|}$. **Solución.** Si $0<|x|<\varepsilon^2$, entonces $\sqrt{|x|}<\varepsilon$. El límite total vale cero y ambos lados proporcionan entradas admisibles.

**Ejercicio 6 (repaso de la clase).** Probar con sucesiones que $\sin(1/x)$ carece de límite derecho en $0$. **Solución.** Utilizar $x_n=1/(\pi/2+2\pi n)$ e $y_n=1/(3\pi/2+2\pi n)$, cuyas imágenes son $1$ y $-1$.

**Ejercicio 7 (editorial).** Calcular $\lim_{x\to+\infty}(2x+1)/(x+3)$ e indicar el lado vertical de aproximación. **Solución.** Al dividir numerador y denominador por $x$ obtenemos $2$. Además, $(2x+1)/(x+3)-2=-5/(x+3)<0$ en la cola positiva: se aproxima a $2$ desde abajo.

**Ejercicio 8 (editorial).** Calcular $\lim_{x\to\pm\infty}x/\sqrt{x^2+1}$. **Solución.** Utilizar $x/|x|$ y dividir el denominador por $|x|$: se obtienen $+1$ a la derecha y $-1$ a la izquierda. Ambos valores se alcanzan mediante cotas de signo estrictas.

**Ejercicio 9 (editorial).** Determinar los límites laterales infinitos de $1/x^2$ en $0$. **Solución.** A ambos lados $1/x^2>H$ cuando $0<|x|<1/\sqrt H$, con $H>0$. Así ambos lados divergen a $+\infty$, y también se puede decir que la función diverge a $+\infty$ en el sentido de la definición total correspondiente.

**Ejercicio 10 (editorial).** Probar que $\lim_{x\to-\infty}e^{2x}=0$ mediante cuantificadores. **Solución.** Para $\varepsilon>0$ basta tomar $R=\max\{1,-\tfrac12\ln\varepsilon\}$; si $x<-R$, se obtiene $2x<\ln\varepsilon$ y $0<e^{2x}<\varepsilon$.

**Ejercicio 11 (editorial).** Sea $f(x)=3+x\sin(1/x)$ para $x\ne0$. Determinar el límite en cero y si se aproxima desde un único lado vertical. **Solución.** Puesto que $|x\sin(1/x)|\le|x|$, el límite es $3$. Los valores de $x\sin(1/x)$ toman signos positivos y negativos arbitrariamente cerca de cero, de modo que no se satisface una aproximación vertical estrictamente desde arriba ni estrictamente desde abajo.

**Ejercicio 12 (editorial).** Verificar un caso de comparación infinita: $f(x)=x^2$ y $g(x)=x^2+\cos x$ cuando $x\to+\infty$. **Solución.** Como $g(x)\ge x^2-1$ y $x^2-1\to+\infty$, la comparación implica $g(x)\to+\infty$.

**Ejercicio 13 (editorial).** Si $f(x)\equiv4$, estudiar su límite cuando $x\to+\infty$, comparándolo con las nociones $4^+$ y $4^-$. **Solución.** El límite ordinario es $4$. Las dos condiciones de aproximación vertical estricta fallan, pues la diferencia $f(x)-4$ vale cero en cada punto.

**Ejercicio 14 (editorial).** Sea $A=\{1/n:n\in\mathbb N,\ n\ge1\}$ y $f:A\to\mathbb R$ dada por $f(x)=x$. Estudiar el límite cuando $x\to0$ y los dos laterales. **Solución.** El cero es punto de acumulación de $A$ y de $A_+(0)$; el límite total y el derecho valen cero. Como $A\cap(-\infty,0)=\varnothing$, el izquierdo no es estudiable.

#### Problemas generativos para profundizar
**Ejercicio 15 (editorial).** Construir una función definida a ambos lados de cero que tenga límite total igual a cinco y que tome infinitas veces valores mayores y menores que cinco cerca del origen. **Solución orientativa.** Definir $f(0)=0$ y $f(x)=5+x\sin(1/x)$ para $x\ne0$. El teorema del sándwich establece $f(x)\to5$ y las oscilaciones de signo producen los dos comportamientos verticales.

**Ejercicio 16 (editorial).** Encontrar funciones $f$ y $g$ con $f(x),g(x)\to+\infty$ cuando $x\to+\infty$, tales que $f-g$ tienda respectivamente a $0$, a $7$, a $+\infty$ y a $-\infty$. **Solución.** En el mismo orden, pueden escogerse $(f,g)=(x,x)$, $(x+7,x)$, $(2x,x)$ y $(x,2x)$.

**Ejercicio 17 (editorial).** Enunciar y demostrar el límite $\lim_{x\to a^+}(x-a)^{-1}=+\infty$ mediante $H$ y $\delta$. **Solución.** Para $H>0$, elegir $\delta=1/(H+1)$; en $a<x<a+\delta$ se cumple $(x-a)^{-1}>H+1$.

**Ejercicio 18 (editorial).** Explicar con un ejemplo por qué el requisito $a\in A_-(a)'$ es esencial al usar el teorema de límites laterales. **Solución.** $f(x)=\sqrt x$ en $a=0$: su límite total es cero y el lateral derecho vale cero, mientras que el lateral izquierdo carece de entradas admisibles. El enunciado de coincidencia necesita la hipótesis de accesibilidad en ambos lados.

---

## La derivada como límite de pendientes

La pendiente de una secante varía con los puntos que la determinan. Al tomar un límite aparece la pendiente de la tangente, y con ella la derivada como función que cuantifica la variación local.

**Grabaciones de referencia:** [grabación de la cátedra 14.1](https://www.youtube.com/watch?v=Fc5tth2MNUc).

*Procedencia de este tramo: cátedra 14.1.*

### Del estudio de límites al problema de la tangente

**En la clase (13:26–16:34).** La semana 14 comienza con la derivada como una herramienta para estudiar la variación de una función real de variable real. La presentación es inicialmente geométrica: dado un punto de una curva, se buscan las pendientes de las rectas que pasan por ese punto y por un segundo punto móvil de la misma curva. El segundo punto se acerca al primero y las pendientes permiten reconocer la dirección local de la curva.

Fijemos una función $f:A\to\mathbb R$, un punto $a\in A$ y el punto $P=(a,f(a))$ del gráfico. Elegimos $x\in A$ con $x\ne a$ y formamos $Q=(x,f(x))$. La pendiente de la recta secante $PQ$ es

$$
m_a(x)=\frac{f(x)-f(a)}{x-a},\qquad x\ne a.
$$

El numerador es la variación de la ordenada y el denominador es la variación de la abscisa. La razón entre ambas expresa cuánto cambia $f$ por unidad de variación de su argumento.

![Esquema editorial: pendientes secantes y tangente](figuras/IC2021_Catedra_14_1/01_secantes_tangente.png)

**En la clase (18:42–27:09).** Cuando el punto $Q$ se desplaza sobre la curva hacia $P$, la pendiente de la secante suele aproximarse a un número. El caso $x=a$ queda fuera del cociente porque su denominador es cero. Precisamente por eso la herramienta apropiada es el límite cuando $x\to a$ por puntos del dominio distintos de $a$. Si ese límite es un real $m$, se llama **pendiente tangente** y la recta correspondiente posee la ecuación

$$
y=f(a)+m(x-a).
$$

Aquí se localiza el paso decisivo de la intuición al cálculo: las rectas secantes son objetos geométricos bien definidos para $x\ne a$; el límite de sus pendientes es un objeto numérico definido mediante la teoría anterior.

#### Ejemplo de la parábola
**Demostración desarrollada.** Para $f(x)=x^2$ y un punto fijo $a\in\mathbb R$,

$$
\frac{f(x)-f(a)}{x-a}=
\frac{x^2-a^2}{x-a}=
\frac{(x-a)(x+a)}{x-a}=x+a\quad(x\ne a).
$$

Por consiguiente,

$$
\lim_{x\to a}\frac{x^2-a^2}{x-a}=2a.
$$

La recta tangente a la parábola en $(a,a^2)$ tiene pendiente $2a$ y ecuación $y=a^2+2a(x-a)$. En el origen la pendiente es cero; a la derecha es positiva y a la izquierda es negativa.

### La derivada como función de la posición

**En la clase (27:09–46:40).** El profesor explora gráficamente la pendiente tangente de varias curvas, observando cómo cambia al desplazar el punto de contacto. Esa operación produce una **nueva función**: a cada abscisa donde existe pendiente tangente se asigna el valor de esa pendiente. Su gráfico puede trazarse a partir de la curva original.

![Esquema editorial: parábola y función pendiente](figuras/IC2021_Catedra_14_1/02_derivada_como_funcion.png)

En la parábola $x^2$ se reconoce $2x$: pendiente negativa a la izquierda del origen, nula en cero y positiva a la derecha. El estudio cualitativo de $\cos x$ conduce a una función de pendientes $-\sin x$. Asimismo, para $f(x)=1/x$ con $x\ne0$, la pendiente es negativa en ambos lados: su derivada es $-1/x^2$.

![Esquema editorial: coseno y su derivada](figuras/IC2021_Catedra_14_1/04_coseno_derivada.png)

![Esquema editorial: función recíproca y su derivada](figuras/IC2021_Catedra_14_1/05_reciproca_derivada.png)

**Ampliación editorial.** La gráfica de $f'$ proporciona información sobre el crecimiento local de $f$. Cuando $f'(a)>0$, la aproximación lineal $f(a+h)\approx f(a)+f'(a)h$ predice incrementos de $f$ para $h>0$ suficientemente pequeño. Cuando $f'(a)<0$, predice descensos. Esta interpretación será formalizada posteriormente con los teoremas que relacionan el signo de la derivada y la monotonía.

### El interior del dominio

**En la clase (46:40–1:14:42).** Antes de definir la derivada en un punto, San Martín introduce una noción topológica que expresa la existencia de una vecindad completa incluida en el dominio.

**Definición afirmativa.** Sea $A\subseteq\mathbb R$. Un real $a$ es **punto interior de $A$** cuando existe un $\delta>0$ tal que

$$
(a-\delta,a+\delta)\subseteq A.
$$

El conjunto de todos los puntos interiores de $A$ se denota por $\operatorname{int}(A)$, también $A^\circ$.

La definición permite aproximarse al punto desde ambos lados **sin abandonar el dominio**, una propiedad adecuada para estudiar la pendiente tangente bilateral.

![Esquema editorial: interior del intervalo y puntos extremos](figuras/IC2021_Catedra_14_1/03_interior_intervalo.png)

#### Casos examinados
Para $A=\mathbb R$, todo real es interior. Para $A=[0,1]$, el interior es $(0,1)$: cualquier $a$ estrictamente comprendido entre cero y uno admite, por ejemplo, $\delta=\tfrac12\min\{a,1-a\}$; en los extremos, cada entorno abierto completo alcanza puntos exteriores al dominio. También $\operatorname{int}((0,1))=(0,1)$. Para un conjunto finito, y en particular para $A=\{0\}$, el interior es vacío; en $\mathbb R$ el interior de $\mathbb N$ también es vacío.

**Demostración desarrollada.** Si $0<a<1$, tomemos $\delta=\min\{a,1-a\}/2>0$. Entonces $a-\delta>0$ y $a+\delta<1$, luego $(a-\delta,a+\delta)\subset (0,1)$. En cambio, para $a=0$ todo $\delta>0$ contiene $-\delta/2$, que está fuera de $[0,1]$; para $a=1$ contiene $1+\delta/2$. Por eso ambos extremos son puntos de acumulación del intervalo, pero no puntos interiores.

**Nota editorial.** La teoría moderna admite también **derivadas laterales** en extremos cuando el dominio lo permite. La clase adopta una definición inicial bilateral para puntos interiores, que preservamos como convención local del curso. La ausencia de interior en un dominio discreto impide aplicar esa definición bilateral; no invalida otras nociones de diferencia discreta.

### Definición formal de derivada

**En la clase (1:20:15–1:22:10).** Sea $f:A\to\mathbb R$ y $a\in\operatorname{int}(A)$. Se dice que **$f$ es derivable en $a$** cuando existe un número real $L$ tal que

$$
\boxed{f'(a)=\lim_{x\to a}\frac{f(x)-f(a)}{x-a}=L.}
$$

La notación $f'(a)$ designa el número pendiente en el punto. Si la función es derivable en diversos puntos, $f'$ designa la función que asocia a cada uno su derivada. En esta definición el límite es bilateral y **finito**. Una pendiente que crece sin cota al acercarse al punto no constituye derivada real finita en el sentido utilizado.

Es útil efectuar el cambio $h=x-a$. Puesto que $x=a+h$, se obtiene la forma equivalente

$$
f'(a)=\lim_{h\to0}\frac{f(a+h)-f(a)}{h}.
$$

**Ampliación editorial.** La fórmula permite deducir una aproximación local: si $f'(a)=m$, entonces existe un residuo $r(h)$ con $r(h)/h\to0$ tal que $f(a+h)=f(a)+mh+r(h)$. La tangente constituye así la parte lineal de primer orden de la variación de la función.

### Funciones elementales ya calculadas mediante límites

**En la clase (1:22:10–1:26:10).** San Martín recupera los cocientes de incrementos desarrollados en la unidad anterior, y muestra que ahora representan derivadas.

#### Exponencial
En las cátedras de límites se obtuvo

$$
\lim_{u\to0}\frac{e^u-1}{u}=1.
$$

Con $u=x-a$ se tiene

$$
\frac{e^x-e^a}{x-a}=e^a\frac{e^{x-a}-1}{x-a}\longrightarrow e^a.
$$

Por tanto, $\boxed{(e^x)'=e^x}$ en todo $\mathbb R$.

#### Seno y coseno
Utilizando $\lim_{h\to0}\sin h/h=1$ y $\lim_{h\to0}(\cos h-1)/h=0$, junto a las identidades de suma,

$$
\frac{\sin(a+h)-\sin a}{h}
=\cos a\frac{\sin h}{h}+\sin a\frac{\cos h-1}{h}
\longrightarrow\cos a.
$$

De manera análoga,

$$
\frac{\cos(a+h)-\cos a}{h}
=\cos a\frac{\cos h-1}{h}-\sin a\frac{\sin h}{h}
\longrightarrow-\sin a.
$$

En consecuencia, $(\sin x)'=\cos x$ y $(\cos x)'=-\sin x$, con el ángulo medido en radianes.

### Potencias de exponente natural

**En la clase (1:26:10–1:34:10).** Se analiza $f(x)=x^n$ para un entero positivo $n$. La prueba utiliza la identidad

$$
x^n-a^n=(x-a)\bigl(x^{n-1}+x^{n-2}a+\cdots+xa^{n-2}+a^{n-1}\bigr).
$$

**Demostración desarrollada.** Para $x\ne a$ podemos cancelar el factor $x-a$ y pasar al límite:

$$
\begin{aligned}
\lim_{x\to a}\frac{x^n-a^n}{x-a}
&=\lim_{x\to a}\sum_{k=0}^{n-1}x^{n-1-k}a^k\\
&=\sum_{k=0}^{n-1}a^{n-1}=n a^{n-1}.
\end{aligned}
$$

Así, $\boxed{(x^n)'=n x^{n-1}}$. Para $n=1$, la identidad da la derivada de la función identidad, $1$. Para $n=2$ se recupera $2x$; para $n=5$, $5x^4$. En esta parte el profesor hace explícito que el símbolo $n$ es un exponente fijo, mientras que $x$ es la variable que tiende al punto.

### La derivada de raíces

**En la clase (1:34:10–1:44:51).** Para $n\ge2$ se considera $f(x)=\sqrt[n]{x}$. El dominio real depende de la paridad de $n$: para $n$ par corresponde a $[0,\infty)$ y para $n$ impar a $\mathbb R$. La fórmula se estudia en puntos interiores donde el cálculo es legítimo; en especial, el punto cero exige atención.

#### Cambio de variable
Sea $a$ un punto del dominio donde $a\ne0$ y tomemos $u=\sqrt[n]{x}$, $b=\sqrt[n]{a}$. Entonces $x=u^n$, $a=b^n$ y, por la continuidad de la función raíz en los puntos correspondientes, $u\to b$ cuando $x\to a$. Se obtiene

$$
\begin{aligned}
\frac{\sqrt[n]{x}-\sqrt[n]{a}}{x-a}
&=\frac{u-b}{u^n-b^n}\\
&=\frac{1}{u^{n-1}+u^{n-2}b+\cdots+b^{n-1}}.
\end{aligned}
$$

Al pasar al límite, el denominador tiende a $n b^{n-1}$. Por tanto,

$$
\boxed{\left(\sqrt[n]{x}\right)'=\frac{1}{n\,x^{(n-1)/n}}}
$$

en los puntos reales $x\ne0$ de los dominios correspondientes. La expresión también coincide con la regla formal de potencias $\alpha x^{\alpha-1}$ para $\alpha=1/n$, pero aquí se ha demostrado mediante límites y factorización.

![Esquema editorial: raíz cuadrada y pendiente](figuras/IC2021_Catedra_14_1/06_raiz_punto_cero.png)

#### El caso cero y el alcance de la definición
Para $n$ par, $0$ es un extremo del dominio y no es interior de $[0,\infty)$: la derivada bilateral definida en la clase queda fuera de su alcance. Para $n$ impar y $n\ge3$, $0$ sí es interior del dominio, pero

$$
\frac{\sqrt[n]{x}-0}{x-0}=\frac{1}{x^{(n-1)/n}}
\longrightarrow+\infty\qquad(x\to0,\ x\ne0),
$$

porque $n-1$ es par y $x^{(n-1)/n}>0$ para $x\ne0$. El límite no constituye un número real finito; por ello la raíz impar de grado al menos tres no es derivable en cero conforme a la definición adoptada. Esta distinción entre **punto interior** y **existencia efectiva del límite derivada** cierra el razonamiento de la clase.

### Registro de fidelidad y referencias

**Fuente primaria:** [Jorge San Martín, «IC2021: Cátedra 14.1. Lunes 12:00»](https://www.youtube.com/watch?v=Fc5tth2MNUc), emisión del 5 de julio de 2021; subtítulos automáticos consultados el 1 de noviembre de 2026. La fecha corresponde a la emisión publicada, no a un dato inferido. La parte inicial contiene coordinación docente y pruebas de audio; la exposición matemática sustantiva empieza aproximadamente a 13:26. El cotejo visual completo de las curvas mostradas en pantalla queda pendiente.

**Criterio editorial:** se mantuvo el orden argumental y se separaron los ejemplos orales de las ampliaciones. Las seis figuras son esquemas matemáticos propios, generados a partir de ecuaciones verificadas. La versión impresa y el archivo Markdown comparten la misma fuente textual.

### Taller de problemas y soluciones

Los ejercicios se presentan a continuación según la fuente de origen; las ampliaciones editoriales de cada apuntes permanecen expresamente identificadas.

#### Práctica editorial con soluciones — cátedra 14.1

#### Ejercicio 1. Derivada de una constante
Demostrar que $f(x)=c$ tiene derivada cero en todo real. **Solución:** para $x\ne a$, el cociente $(c-c)/(x-a)$ es siempre cero; su límite es cero.

#### Ejercicio 2. Recta afín
Calcular la derivada de $f(x)=3x-7$. **Solución:** $(f(a+h)-f(a))/h=3$ para $h\ne0$, luego $f'(a)=3$.

#### Ejercicio 3. Tangente a una parábola
Hallar la recta tangente a $y=x^2$ en $a=-1$. **Solución:** $f(-1)=1$, $f'(-1)=-2$; la recta es $y-1=-2(x+1)$.

#### Ejercicio 4. Interior de un dominio
Calcular $\operatorname{int}([-2,1]\cup\{3\})$. **Solución:** el interior es $(-2,1)$; el punto aislado 3 no tiene un entorno abierto incluido en el conjunto.

#### Ejercicio 5. Diferencia de cubos
Calcular $\lim_{x\to2}(x^3-8)/(x-2)$. **Solución:** para $x\ne2$, la expresión es $x^2+2x+4$ y el límite vale $12$.

#### Ejercicio 6. Cociente exponencial
Calcular $\lim_{h\to0}(e^{3h}-1)/h$. **Solución:** con $u=3h$ el límite es $3\lim_{u\to0}(e^u-1)/u=3$.

#### Ejercicio 7. Derivada del coseno
Calcular $\lim_{h\to0}(\cos(a+h)-\cos a)/h$. **Solución:** aplicar la identidad del coseno de la suma y los límites fundamentales; resulta $-\sin a$.

#### Ejercicio 8. Raíz cúbica en cero
Decidir si $x^{1/3}$ es derivable en cero. **Solución:** $[h^{1/3}-0]/h=1/h^{2/3}\to+\infty$. No existe derivada finita en cero.

#### Ejercicio 9. Pendiente en puntos próximos
Comparar las pendientes de $f(x)=x^2$ en $a=1/10$ y $a=-1/10$. **Solución:** $f'(1/10)=1/5$ y $f'(-1/10)=-1/5$. Tienen igual magnitud y signo opuesto.

#### Ejercicio 10. Cociente de incrementos alternativo
Calcular $\lim_{h\to0}\bigl((2+h)^4-16\bigr)/h$. **Solución:** es la derivada de $x^4$ en $x=2$, obtenida por factorización; vale $4(2)^3=32$.

---

## Reglas y técnicas de derivación

La derivabilidad implica continuidad y permite establecer reglas operativas para sumas, productos y cocientes. Las reglas de composición e inversa amplían el repertorio, con hipótesis que es indispensable explicitar.

**Grabaciones de referencia:** [grabación de la cátedra 14.2](https://www.youtube.com/watch?v=eXthvzh8_9Y).

*Procedencia de este tramo: cátedra 14.2.*

### El objetivo de las técnicas de derivación

**En la clase (17:44–20:20).** El estudio de la cátedra 14.1 permitió derivar directamente algunas funciones elementales: polinomios, potencias, raíces, exponencial y funciones trigonométricas. La nueva pregunta es cómo obtener derivadas de las funciones construidas mediante **suma, resta, producto, cociente y composición**, y posteriormente mediante **inversión**.

Fijada una función $f:A\to\mathbb R$ y un punto interior $a\in\operatorname{int}(A)$, su derivada es el límite real

$$
 f'(a)=\lim_{x\to a}\frac{f(x)-f(a)}{x-a}
 =\lim_{h\to0}\frac{f(a+h)-f(a)}{h},
$$

si existe. Las reglas que estudiaremos convierten este límite en una operación calculable, siempre atendiendo a las condiciones de derivabilidad y a los dominios de las funciones que intervienen.

### Primer teorema: derivabilidad y continuidad

**En la clase (20:20–29:55).** Una función derivable en un punto tiene límite igual a su valor en él. Este resultado conecta la noción geométrica de pendiente tangente con la continuidad, que el profesor anuncia como objeto de estudio sistemático del semestre siguiente.

**Teorema.** Sea $f:A\to\mathbb R$, con $a$ interior de $A$. Si existe un número real $f'(a)$, entonces

$$
 \boxed{\lim_{x\to a}f(x)=f(a).}
$$

**Demostración reconstruida de la clase.** Para $x\in A$ distinto de $a$ se puede escribir

$$
\begin{aligned}
 f(x)&=f(a)+\bigl(f(x)-f(a)\bigr)\\
 &=f(a)+\frac{f(x)-f(a)}{x-a}\,(x-a).
\end{aligned}
$$

El cociente tiende al número finito $f'(a)$ por hipótesis y el factor $x-a$ tiende a cero. El álgebra de límites da

$$
\lim_{x\to a}f(x)=f(a)+f'(a)\cdot0=f(a).
$$

La conclusión identifica la **continuidad en $a$**: el comportamiento de $f$ en los puntos del dominio cercanos a $a$ converge al valor asignado al propio punto.

#### Una función continua con esquina
**En la clase (29:55–40:20).** Para $f(x)=|x|$ se verifica $\lim_{x\to0}|x|=0=f(0)$, de modo que $f$ es continua en cero. Sin embargo, su cociente incremental en el origen es

$$
\frac{|x|-|0|}{x-0}=\frac{|x|}{x}=\begin{cases}1,&x>0,\\-1,&x<0.\end{cases}
$$

Sus límites laterales son $1$ y $-1$, respectivamente. Como difieren, el límite bilateral de ese cociente **no existe** y $f$ carece de derivada finita en cero.

![Esquema editorial: continuidad y pendientes laterales del valor absoluto](figuras/IC2021_Catedra_14_2/01_valor_absoluto_continuidad.png)

#### Dos pendientes laterales y una decisión única
**Ampliación editorial.** La derivabilidad bilateral se comprueba examinando los cocientes incrementales desde ambos lados. Cuando el dominio contiene un intervalo abierto centrado en $a$, se tienen las derivadas laterales

$$
 f'_-(a)=\lim_{h\to0^-}\frac{f(a+h)-f(a)}{h},\qquad
 f'_+(a)=\lim_{h\to0^+}\frac{f(a+h)-f(a)}{h},
$$

si existen como números reales. La derivada $f'(a)$ existe precisamente cuando ambas derivadas laterales existen y coinciden. El valor absoluto da $f'_-(0)=-1$ y $f'_+(0)=1$.

Otra función continua con quiebre es

$$
 q(x)=\begin{cases}-x,&x<0,\\2x,&x\ge0.\end{cases}
$$

Ambas ramas se encuentran en $(0,0)$, por lo que $q$ es continua en cero; el cociente incremental vale $-1$ para $h<0$ y $2$ para $h>0$. La diferencia entre las pendientes es la propiedad relevante. La figura siguiente constituye un ejemplo editorial independiente.

![Esquema editorial: ramas con pendientes laterales diferentes](figuras/IC2021_Catedra_14_2/07_derivadas_laterales.png)

**Consecuencia lógica.** La implicación «derivable $\Rightarrow$ continua» está demostrada. Su recíproca es falsa, como muestra el valor absoluto. Fuera de cero, el valor absoluto es derivable y

$$
 (|x|)'=\begin{cases}1,&x>0,\\-1,&x<0,\end{cases}
 \qquad\text{equivalentemente } (|x|)'=\frac{|x|}{x}\quad(x\ne0).
$$

**Ampliación editorial.** La derivabilidad exige un comportamiento lineal de primer orden único. Las funciones $|x|$ y la función $x\mapsto\sqrt{|x|}$ ilustran dos modos diferentes de perder derivabilidad: en la primera se obtienen pendientes laterales finitas diferentes; en la segunda los cocientes pueden crecer sin cota. Existen, además, funciones continuas en toda la recta y no derivables en ningún punto, posibilidad mencionada por el docente sin construir un ejemplo específico en esta sesión.

### Álgebra de derivadas: suma, resta y multiplicación por una constante

**En la clase (41:57–47:10).** Supongamos que $f$ y $g$ son derivables en $a$ y están definidas en un intervalo abierto que contiene $a$. Las funciones $f+g$ y $f-g$ también son derivables en $a$, con

$$
 \boxed{(f+g)'(a)=f'(a)+g'(a),\qquad (f-g)'(a)=f'(a)-g'(a).}
$$

**Demostración desarrollada.** Para $x\ne a$,

$$
\begin{aligned}
 \frac{(f+g)(x)-(f+g)(a)}{x-a}
 &=\frac{[f(x)-f(a)]+[g(x)-g(a)]}{x-a}\\
 &=\frac{f(x)-f(a)}{x-a}+\frac{g(x)-g(a)}{x-a}.
\end{aligned}
$$

Al pasar al límite, cada sumando converge a su derivada correspondiente. En la resta se conserva el signo negativo del segundo cociente. Con un factor real constante $c$, la misma operación da

$$
 (cf)'(a)=c\,f'(a).
$$

Estas reglas permiten derivar polinomios término a término: por ejemplo,

$$
 (5x^4-3x^2+7)'=20x^3-6x.
$$

### La derivada del producto

**En la clase (47:10–1:00:20).** Sean $f$ y $g$ derivables en $a$. La derivada del producto es una **suma de dos contribuciones**:

$$
 \boxed{(fg)'(a)=f'(a)g(a)+f(a)g'(a).}
$$

**Demostración reconstruida.** El punto decisivo del cálculo es agregar y quitar el término $f(a)g(x)$, operación que San Martín llama «ni quita ni pone». Para $x\ne a$,

$$
\begin{aligned}
 f(x)g(x)-f(a)g(a)
 &=f(x)g(x)-f(a)g(x)+f(a)g(x)-f(a)g(a)\\
 &=[f(x)-f(a)]g(x)+f(a)[g(x)-g(a)].
\end{aligned}
$$

Dividimos por $x-a$:

$$
\frac{f(x)g(x)-f(a)g(a)}{x-a}
 =\frac{f(x)-f(a)}{x-a}\,g(x)
 +f(a)\frac{g(x)-g(a)}{x-a}.
$$

Puesto que las funciones derivables son continuas, $g(x)\to g(a)$. Los dos cocientes incrementales tienden a $f'(a)$ y $g'(a)$, respectivamente. Aplicando el álgebra de límites se obtiene la fórmula anunciada. La continuidad de $g$ utilizada aquí fue demostrada en el primer teorema de la clase.

![Esquema editorial: funciones y producto](figuras/IC2021_Catedra_14_2/02_producto_funciones.png)

#### Tres factores y generalización
**Ejercicio propuesto por el profesor.** Para tres funciones derivables,

$$
 \boxed{(fgh)'=f'gh+fg'h+fgh'.}
$$

**Solución editorial.** Escribimos $fgh=(fg)h$. La regla del producto aplicada por primera vez da $(fgh)'=(fg)'h+(fg)h'$. Una segunda aplicación a $(fg)'$ produce $(f'g+fg')h+fgh'$, que coincide con la fórmula. Por inducción, para $m$ factores derivables,

$$
\left(\prod_{j=1}^{m}f_j\right)'=
 \sum_{k=1}^{m} f_k'\!\prod_{\substack{1\le j\le m\\j\ne k}}f_j.
$$

La suma contiene $m$ términos; cada término deriva exactamente uno de los factores y conserva los demás.

### Recíproco y cociente

**En la clase (1:00:20–1:09:20).** Sea $g$ derivable en $a$ y $g(a)\ne0$. Por continuidad, $g(x)$ conserva un valor distinto de cero en un entorno de $a$, por lo que $1/g$ está definido allí. El resultado es

$$
 \boxed{\left(\frac1g\right)'(a)=-\frac{g'(a)}{g(a)^2}.}
$$

**Demostración reconstruida.** El cociente incremental del recíproco se transforma mediante denominador común:

$$
\begin{aligned}
\frac{g(x)^{-1}-g(a)^{-1}}{x-a}
 &=\frac{g(a)-g(x)}{g(x)g(a)(x-a)}\\
 &=-\frac{g(x)-g(a)}{x-a}\cdot\frac{1}{g(x)g(a)}.
\end{aligned}
$$

El primer factor tiende a $-g'(a)$ y el segundo a $1/g(a)^2$. De aquí se obtiene el resultado.

![Esquema editorial: una función recíproca y su derivada](figuras/IC2021_Catedra_14_2/03_reciproco_derivada.png)

Si $f$ y $g$ son derivables en $a$ y $g(a)\ne0$, expresamos $f/g=f\cdot(1/g)$ y aplicamos las dos reglas anteriores. Se obtiene la **regla del cociente**:

$$
 \boxed{\left(\frac{f}{g}\right)'(a)
 =\frac{f'(a)g(a)-f(a)g'(a)}{g(a)^2}.}
$$

Es crucial conservar el orden de los términos del numerador: el primero es la derivada del numerador por el denominador, y el segundo es el numerador por la derivada del denominador, con signo negativo.

#### Aplicaciones desarrolladas en la clase
**Potencias negativas (aprox. 1:15).** Tomando $g(x)=x^n$ con $n\in\mathbb N$ y $x\ne0$:

$$
\begin{aligned}
 \frac{d}{dx}x^{-n}
 &=\left(\frac{1}{x^n}\right)'
 =-\frac{nx^{n-1}}{x^{2n}}
 =-nx^{-n-1}.
\end{aligned}
$$

La regla $(x^k)'=kx^{k-1}$ vale así para exponentes enteros $k$, en los dominios donde la función está definida. La clase 14.1 ya había abordado las potencias naturales y las raíces.

**Tangente trigonométrica (aprox. 1:18).** Como $\tan x=\sin x/\cos x$ para $\cos x\ne0$,

$$
\begin{aligned}
 (\tan x)'&=\frac{(\cos x)(\cos x)-(\sin x)(-\sin x)}{\cos^2x}\\
 &=\frac{\cos^2x+\sin^2x}{\cos^2x}
 =\frac{1}{\cos^2x}=\sec^2x.
\end{aligned}
$$

![Esquema editorial: tangente y secante al cuadrado](figuras/IC2021_Catedra_14_2/04_tangente_secante2.png)

### Regla de la cadena: derivar composiciones

**Continuación temática del curso.** La composición aparece en el programa que San Martín anuncia al comenzar la cátedra. Sean $g$ derivable en $a$ y $f$ derivable en $b=g(a)$, con $g$ definida cerca de $a$, sus valores en el dominio de $f$ y las composiciones correspondientes bien definidas. Entonces

$$
 \boxed{(f\circ g)'(a)=f'(g(a))\,g'(a).}
$$

En palabras: se deriva primero la función exterior, evaluándola en el argumento interior, y se multiplica por la derivada de ese argumento. Conviene distinguir el resultado de la derivada de un producto: aunque ambas fórmulas contienen multiplicaciones, la composición utiliza una función **evaluada sobre otra**, mientras que el producto combina los valores de dos funciones en un mismo argumento.

#### Demostración editorial rigurosa
La exposición del profesor advierte que las pruebas de algunos teoremas posteriores exceden las herramientas disponibles en el curso durante el semestre. Por eso la demostración siguiente se presenta como **ampliación editorial**, con el argumento completo.

Sea $b=g(a)$ y definamos la función auxiliar

$$
 A(u)=\begin{cases}
 \dfrac{f(u)-f(b)}{u-b},&u\ne b,\\[5pt]
 f'(b),&u=b.
 \end{cases}
$$

La definición de derivada de $f$ garantiza $\lim_{u\to b}A(u)=f'(b)=A(b)$; por tanto, $A$ es continua en $b$. Como $g$ es derivable en $a$, también es continua en $a$, de manera que $g(a+h)\to b$. Para $h\ne0$ suficientemente pequeño se cumple la identidad

$$
\frac{f(g(a+h))-f(g(a))}{h}
 =A(g(a+h))\cdot\frac{g(a+h)-g(a)}{h}.
$$

Esta identidad es válida incluso cuando $g(a+h)=g(a)$, pues entonces ambos lados son cero. Al pasar al límite, el primer factor tiende a $A(b)=f'(b)$ y el segundo a $g'(a)$. Así se obtiene la regla de la cadena **sin suponer** que la función interior evita siempre el valor $b$.

#### Ejemplo: exponencial de una función cuadrática
**Ejemplo editorial.** Sea $H(x)=\exp(x^2/2)$. La función exterior es $f(u)=e^u$ y la interior es $g(x)=x^2/2$. Tenemos $f'(u)=e^u$ y $g'(x)=x$, por lo que

$$
 \boxed{H'(x)=x\,e^{x^2/2}.}
$$

![Esquema editorial: composición y función derivada](figuras/IC2021_Catedra_14_2/05_regla_de_la_cadena.png)

**Ejemplo editorial.** Para $G(x)=\sin(3x-2)$, la regla de la cadena da $G'(x)=3\cos(3x-2)$. Para $P(x)=(2x^2+1)^5$, resulta $P'(x)=5(2x^2+1)^4(4x)=20x(2x^2+1)^4$.

### Derivada de una función inversa

**Continuación temática y ampliación editorial.** El programa anunciado incluye funciones inversas —logaritmo, arco seno, arco coseno y arco tangente—. Conviene establecer las hipótesis que hacen posible aplicar la fórmula.

Sea $f:I\to J$ una biyección entre intervalos, con inversa $g=f^{-1}$ continua en $b=f(a)$. Si $f$ es derivable en $a$ y $f'(a)\ne0$, y los puntos considerados permiten calcular derivadas bilaterales en los interiores correspondientes, entonces

$$
 \boxed{g'(b)=\frac{1}{f'(a)}=\frac{1}{f'(g(b))}.}
$$

**Demostración editorial.** Para $y=f(x)\ne f(a)$, la inyectividad da $x\ne a$ y la identidad

$$
 \frac{g(y)-g(b)}{y-b}
 =\frac{x-a}{f(x)-f(a)}
 =\left(\frac{f(x)-f(a)}{x-a}\right)^{-1}.
$$

Por continuidad de $g$, si $y\to b$ se tiene $x=g(y)\to a$. El último cociente tiende a $1/f'(a)$, que es finito porque la derivada de $f$ en $a$ es distinta de cero. La continuidad local de la inversa es una hipótesis sustantiva, no una consecuencia de su mera existencia como correspondencia algebraica.

![Esquema editorial: exponencial, logaritmo y reflexión sobre la bisectriz](figuras/IC2021_Catedra_14_2/06_funciones_inversas.png)

#### Derivada del logaritmo natural
Tomamos $f(x)=e^x$, función biyectiva de $\mathbb R$ en $(0,\infty)$. Su inversa es $\ln$, y $f'(x)=e^x$. Para $y>0$,

$$
 \boxed{(\ln y)'=\frac{1}{e^{\ln y}}=\frac{1}{y}.}
$$

Por composición, si $u$ es derivable y $u(x)>0$,

$$
 \boxed{\frac{d}{dx}\ln(u(x))=\frac{u'(x)}{u(x)}.}
$$

#### Inversas trigonométricas
**Ampliación editorial.** La restricción $\sin:[-\pi/2,\pi/2]\to[-1,1]$ es biyectiva y estrictamente creciente; para $-1<y<1$, poniendo $x=\arcsin y$, tenemos $\cos x=\sqrt{1-y^2}>0$. Por tanto,

$$
 \boxed{(\arcsin y)'=\frac{1}{\sqrt{1-y^2}}\quad(-1<y<1).}
$$

Análogamente, en los intervalos de inyectividad habituales,

$$
\boxed{(\arccos y)'=-\frac{1}{\sqrt{1-y^2}}\quad(|y|<1),\qquad
(\arctan y)'=\frac{1}{1+y^2}\quad(y\in\mathbb R).}
$$

Los extremos $\pm1$ de los dominios de las inversas seno y coseno requieren un examen separado: el denominador se anula y la fórmula de derivada finita no se extiende a ellos.

#### Tres precauciones para utilizar funciones inversas
**Ampliación editorial.** La fórmula de la inversa depende de la estructura local de la función original. Un punto en el cual $f'(a)=0$ puede producir una inversa con cociente incremental que crece sin cota. Por ejemplo, $f(x)=x^3$ posee inversa $g(y)=\sqrt[3]{y}$, pero en $a=0$ se tiene $f'(0)=0$; el cociente de $g$ en $y=0$ es $1/y^{2/3}$ y no admite límite real finito. Este ejemplo muestra por qué la hipótesis $f'(a)\ne0$ tiene contenido matemático.

La condición de inyectividad permite hablar de una inversa que sea función. Para $f(x)=x^2$ sobre toda $\mathbb R$, cada $y>0$ tiene dos preimágenes. Su restricción a $[0,\infty)$ sí da una función inversa $g(y)=\sqrt y$, derivable para $y>0$ y con $g'(y)=1/(2\sqrt y)$. Elegir el dominio correcto es parte del teorema y del cálculo.

Las inversas trigonométricas requieren de manera análoga restringir el dominio de la función de partida a un intervalo de monotonía. Por ejemplo, el arco seno utiliza $[-\pi/2,\pi/2]$ y el arco tangente utiliza $(-\pi/2,\pi/2)$.

### Funciones hiperbólicas

**Ampliación editorial motivada por el programa.** La clase anuncia que también pueden estudiarse funciones análogas a las trigonométricas, definidas mediante la exponencial. Se introducen mediante propiedades afirmativas:

$$
 \sinh x=\frac{e^x-e^{-x}}2,
 \qquad \cosh x=\frac{e^x+e^{-x}}2,
 \qquad \cosh^2x-\sinh^2x=1.
$$

Utilizando la derivada exponencial, la suma y la cadena, se demuestra

$$
 \boxed{(\sinh x)'=\cosh x,\qquad (\cosh x)'=\sinh x.}
$$

Estas fórmulas se verifican directamente diferenciando las expresiones exponenciales; además, $\tanh x=\sinh x/\cosh x$ y $(\tanh x)'=1/\cosh^2x$.

![Esquema editorial: seno y coseno hiperbólicos](figuras/IC2021_Catedra_14_2/08_funciones_hiperbolicas.png)

### Registro editorial y fuentes

**Base comprobada de la clase:** grabación de Jorge San Martín, «IC2021: Cátedra 14.2: Sábado 16:15», transmitida el 10 de julio de 2021, [YouTube](https://www.youtube.com/watch?v=eXthvzh8_9Y). Se consultaron subtítulos automáticos en español para el comienzo y el tramo sustantivo hasta aproximadamente 1:19, así como el cierre. El segmento entre ese momento y la despedida no fue recuperado de manera íntegra por el conector; por ello, los contenidos posteriores se presentan como desarrollos editoriales que completan un itinerario de estudio sin reclamar correspondencia minuto a minuto con la grabación. El nombre del programa, la fecha y la caracterización de la cátedra proceden de la fuente.

**Fidelidad:** los teoremas de derivabilidad y continuidad, álgebra de derivadas, regla del producto, recíproco, cociente, potencias negativas y tangente fueron recuperados del desarrollo oral. Las pruebas completas de la cadena y de inversas, el apartado de hiperbólicas y los ejercicios nuevos son ampliaciones editoriales distinguidas. Queda pendiente la lectura íntegra del tramo final de contenido, la revisión visual de la pizarra original y la comparación de expresiones poco claras de los subtítulos.

**Relación curricular:** la cátedra 14.1 introduce la definición de derivada, los puntos interiores y las derivadas elementales. Esta cátedra 14.2 conecta ese resultado con las técnicas de cálculo. El profesor anuncia la continuidad del estudio sistemático de continuidad y derivadas para el semestre posterior.

### Taller de problemas y soluciones

Los ejercicios se presentan a continuación según la fuente de origen; las ampliaciones editoriales de cada apuntes permanecen expresamente identificadas.

#### Ejercicios de consolidación con soluciones — cátedra 14.2

*Los ejercicios de esta sección son editoriales, excepto la generalización del producto de tres factores y las aplicaciones de potencias negativas y tangente, recuperadas de la clase. Sus soluciones se incluyen para el estudio autónomo.*

#### Ejercicio 1. Un criterio sencillo de continuidad
**Enunciado.** Sea $f(x)=3x^2-x+4$. Demostrar su continuidad a partir de la derivabilidad.

**Solución.** El cociente incremental se puede calcular por factorización y su límite vale $f'(a)=6a-1$. Por el teorema 1, $f$ es continua en todo real, pues cada real es punto interior de su dominio.

#### Ejercicio 2. Un ejemplo continuo y no derivable
**Enunciado.** Estudiar $f(x)=|x-2|$ en $a=2$.

**Solución.** El límite de $f$ al acercarse a $2$ es cero, igual a $f(2)$. Su cociente incremental es $|h|/h$, con límites laterales $1$ y $-1$. La función es continua y carece de derivada bilateral en $2$.

#### Ejercicio 3. Producto de tres funciones
**Enunciado.** Derivar $H(x)=x^2 e^x\sin x$.

**Solución.** Derivando cada factor una vez y conservando los otros dos,

$$
 H'(x)=2xe^x\sin x+x^2e^x\sin x+x^2e^x\cos x
 =e^x\bigl[(2x+x^2)\sin x+x^2\cos x\bigr].
$$

#### Ejercicio 4. Cociente racional
**Enunciado.** Derivar $R(x)=(x^2+1)/(x-1)$, $x\ne1$.

**Solución.** La regla del cociente da

$$
R'(x)=\frac{2x(x-1)-(x^2+1)}{(x-1)^2}
=\frac{x^2-2x-1}{(x-1)^2}.
$$

#### Ejercicio 5. Recíproco
**Enunciado.** Derivar $h(x)=1/(x^2+3)$.

**Solución.** Con $g(x)=x^2+3$, se tiene $g'(x)=2x$ y $g(x)>0$. Por la regla del recíproco,

$$
 h'(x)=-\frac{2x}{(x^2+3)^2}.
$$

#### Ejercicio 6. Potencia entera negativa
**Enunciado.** Derivar $f(x)=x^{-4}$, $x\ne0$.

**Solución.** Se aplica la regla recuperada en la clase: $f'(x)=-4x^{-5}=-4/x^5$.

#### Ejercicio 7. Tangente trigonométrica
**Enunciado.** Hallar la derivada de $\tan x$ a partir de $\sin x$ y $\cos x$.

**Solución.** La regla del cociente y $\sin^2x+\cos^2x=1$ conducen a $1/\cos^2x$ para todo $x$ con $\cos x\ne0$.

#### Ejercicio 8. Composición exponencial
**Enunciado.** Derivar $F(x)=e^{3x^2-1}$.

**Solución.** La función exterior tiene derivada $e^u$ y la interior derivada $6x$. Por la regla de la cadena, $F'(x)=6xe^{3x^2-1}$.

#### Ejercicio 9. Seno de un producto
**Enunciado.** Derivar $F(x)=\sin(x e^x)$.

**Solución.** La regla de la cadena da $F'=\cos(xe^x)\,(xe^x)'$. Por el producto, $(xe^x)'=e^x+xe^x=e^x(1+x)$, luego

$$F'(x)=e^x(1+x)\cos(xe^x).$$

#### Ejercicio 10. Logaritmo compuesto
**Enunciado.** Derivar $F(x)=\ln(1+x^2)$.

**Solución.** Puesto que $1+x^2>0$ para todo real, $F$ está definida en $\mathbb R$, y

$$F'(x)=\frac{2x}{1+x^2}.$$

#### Ejercicio 11. Función inversa
**Enunciado.** Calcular la derivada de $f^{-1}$ en $y=8$ cuando $f(x)=x^3$.

**Solución.** El punto preimagen es $a=2$ y $f'(2)=3\cdot2^2=12\ne0$. La regla de la inversa da $(f^{-1})'(8)=1/12$. Es coherente con la inversa $f^{-1}(y)=\sqrt[3]{y}$ y su derivada $1/(3y^{2/3})$ para $y>0$.

#### Ejercicio 12. Composición con una función constante en el punto
**Enunciado.** Sea $f(u)=u^2$ y $g(x)=x^2$. Verificar la cadena en $a=0$.

**Solución.** La composición es $H(x)=x^4$, cuya derivada vale $H'(0)=0$. La regla de la cadena da $f'(g(0))g'(0)=(2\cdot0)(2\cdot0)=0$. La demostración de la cadena sigue funcionando aunque $g(x)-g(0)$ se anule en ciertos valores; la extensión continua del cociente exterior evita divisiones artificiales.

#### Ejercicio 13. Primera aproximación lineal
**Enunciado.** Aproximar $\sqrt{4.04}$ usando la derivada de $\sqrt{x}$ en $a=4$.

**Solución.** Como $f(4)=2$ y $f'(4)=1/(2\sqrt4)=1/4$, para $h=0.04$ se obtiene $\sqrt{4.04}\approx2+(1/4)(0.04)=2.01$. El error se estudia mediante el residuo de la aproximación lineal.

#### Ejercicio 14. Hiperbólicas
**Enunciado.** Comprobar que $(\cosh x)'=\sinh x$ desde la definición exponencial.

**Solución.** Se diferencia término a término $\cosh x=(e^x+e^{-x})/2$; la derivada es $(e^x-e^{-x})/2=\sinh x$.

#### Ejercicio 15. Diferenciabilidad sin continuidad de la derivada
**Enunciado.** Sea $f(x)=x^2\sin(1/x)$ para $x\ne0$ y $f(0)=0$. Probar que $f$ es derivable en cero, y estudiar si $f'$ es continua en cero.

**Solución.** En el origen el cociente incremental es $f(h)/h=h\sin(1/h)$; su valor absoluto está acotado por $|h|$, que tiende a cero. Luego $f'(0)=0$. Para $x\ne0$, las reglas de producto y cadena dan $f'(x)=2x\sin(1/x)-\cos(1/x)$. El primer sumando tiende a cero, mientras que el segundo oscila entre $-1$ y $1$ al aproximarse a cero. Por tanto, $f'$ no es continua en cero, aunque $f$ sí es derivable allí. Este ejercicio distingue **derivabilidad de $f$** y **continuidad de $f'$**.

#### Ejercicio 16. Composición con cociente
**Enunciado.** Hallar $H'(x)$ para $H(x)=\ln\!\left(\frac{x^2+1}{x^2+4}\right)$.

**Solución.** El argumento del logaritmo es positivo para todo $x\in\mathbb R$. Aplicando cadena y cociente, o bien la identidad $H(x)=\ln(x^2+1)-\ln(x^2+4)$,

$$
 H'(x)=\frac{2x}{x^2+1}-\frac{2x}{x^2+4}
 =\frac{6x}{(x^2+1)(x^2+4)}.
$$

#### Ejercicio 17. Comprobación directa de una regla
**Enunciado.** Derivar $f(x)=x^{-1}$ por definición en cualquier $a\ne0$, y comparar con la regla del recíproco.

**Solución.** Para $x\ne a$, $\frac{x^{-1}-a^{-1}}{x-a}=\frac{a-x}{ax(x-a)}=-\frac{1}{ax}$. Al tomar $x\to a$ se obtiene $f'(a)=-1/a^2$. Es la misma fórmula que $-(g'(a))/g(a)^2$ con $g(x)=x$.

---

# Apéndices y registro de procedencia

## Concordancia entre cátedras y capítulos {.unnumbered}

Las lecciones aparecen en el orden temático de este libro. Las sesiones complementarias de 2018, IC2022 y las clases de apoyo se conservan como testigos y lecturas adicionales para evitar duplicar las demostraciones y confundir la procedencia temporal de cada curso.

| Cátedra | Tema en este libro | Grabación |
|:--|:--|:--|
| 1.1 | La estructura algebraica de los números reales | [Ver clase](https://www.youtube.com/watch?v=08n7qZ-H7W8) |
| 1.2 | La estructura algebraica de los números reales | [Ver clase](https://www.youtube.com/watch?v=Tl5Hf5d4U2Y) |
| 2.1 | Orden, desigualdades e inecuaciones | [Ver clase](https://www.youtube.com/watch?v=o5TbpGI9KsU) |
| 2.2 | Orden, desigualdades e inecuaciones | [Ver clase](https://www.youtube.com/watch?v=-NZgH0yH-NI) |
| 3.1 | Coordenadas, distancias y rectas | [Ver clase](https://www.youtube.com/watch?v=vxF8xwRmesA) |
| 3.2 | Coordenadas, distancias y rectas | [Ver clase](https://www.youtube.com/watch?v=h-eNbC2gUpw) |
| 4.1 | Cónicas y curvas cuadráticas | [Ver clase](https://www.youtube.com/watch?v=7qlkE41AITo) |
| 4.2 | Cónicas y curvas cuadráticas | [Ver clase](https://www.youtube.com/watch?v=E2KL0qm2vIg) |
| 5.1 | El lenguaje de las funciones | [Ver clase](https://www.youtube.com/watch?v=qbH2dSX-oYk) |
| 5.2 | El lenguaje de las funciones | [Ver clase](https://www.youtube.com/watch?v=NEYH4Qw4QK4) |
| 6.1 | El círculo trigonométrico y sus identidades | [Ver clase](https://www.youtube.com/watch?v=Omn6hikVwIc) |
| 6.2 | El círculo trigonométrico y sus identidades | [Ver clase](https://www.youtube.com/watch?v=bkh-hjyrE_o) |
| 7.1 | Identidades trigonométricas y resolución de triángulos | [Ver clase](https://www.youtube.com/watch?v=VwFUnoxUw3M) |
| 7.2 | Funciones trigonométricas inversas y ecuaciones | [Ver clase](https://www.youtube.com/watch?v=EoIVowNQD70) |
| 8.1 | Supremos, naturales y propiedad arquimediana | [Ver clase](https://www.youtube.com/watch?v=U2nQmKdc_lo) |
| 8.2 | Supremos, naturales y propiedad arquimediana | [Ver clase](https://www.youtube.com/watch?v=Q-gZ2Ja3kCg) |
| 9.1 | Sucesiones y convergencia | [Ver clase](https://www.youtube.com/watch?v=OvFPirtl0yQ) |
| 9.2 | Sucesiones y convergencia | [Ver clase](https://www.youtube.com/watch?v=fMkNJyhooZY) |
| 10.1 | Comparaciones, velocidad y monotonía de sucesiones | [Ver clase](https://www.youtube.com/watch?v=uWNFjH-GDEA) |
| 10.2 | Comparaciones, velocidad y monotonía de sucesiones | [Ver clase](https://www.youtube.com/watch?v=CQgnnA48rEA) |
| 11.1 | La función exponencial y su inversa logarítmica | [Ver clase](https://www.youtube.com/watch?v=K-9dw9jW2BE) |
| 11.2 | La función exponencial y su inversa logarítmica | [Ver clase](https://www.youtube.com/watch?v=9PVAjc3s-Mg) |
| 12.1 | Puntos de acumulación y límite de una función | [Ver clase](https://www.youtube.com/watch?v=iQD_ImPaRWo) |
| 12.2 | Álgebra, comparación y límites fundamentales | [Ver clase](https://www.youtube.com/watch?v=pn5sq_kgAB0) |
| 13.1 | Límites de composiciones y caracterización épsilon-delta | [Ver clase](https://www.youtube.com/watch?v=R2rghIx2vRc) |
| 13.2 | Límites laterales, infinito y asíntotas | [Ver clase](https://www.youtube.com/watch?v=t3bX0a0x3kU) |
| 14.1 | La derivada como límite de pendientes | [Ver clase](https://www.youtube.com/watch?v=Fc5tth2MNUc) |
| 14.2 | Reglas y técnicas de derivación | [Ver clase](https://www.youtube.com/watch?v=eXthvzh8_9Y) |

## Referencias audiovisuales y sesiones complementarias {.unnumbered}

Las referencias temporales que siguen se extrajeron de los itinerarios de los maestros originales. Sirven para volver al material docente sin interrumpir el orden temático del libro. La edición de notas no altera fechas ni asocia a 2021 grabaciones de otros años.

### Cátedra 1.1

[Grabación original](https://www.youtube.com/watch?v=08n7qZ-H7W8).

| Tramo de video | Núcleo conceptual |
|---|---|
| [06:08](https://www.youtube.com/watch?v=08n7qZ-H7W8&t=368s)–[11:48](https://www.youtube.com/watch?v=08n7qZ-H7W8&t=708s) | Método axiomático; $\mathbb R$ como conjunto; arquitectura de la teoría. |
| [11:48](https://www.youtube.com/watch?v=08n7qZ-H7W8&t=708s)–[23:32](https://www.youtube.com/watch?v=08n7qZ-H7W8&t=1412s) | Dos operaciones binarias y significado de «bien definida». |
| [23:32](https://www.youtube.com/watch?v=08n7qZ-H7W8&t=1412s)–[36:52](https://www.youtube.com/watch?v=08n7qZ-H7W8&t=2212s) | Axioma 1: conmutatividad; axiomas y consecuencias. |
| [36:52](https://www.youtube.com/watch?v=08n7qZ-H7W8&t=2212s)–[48:56](https://www.youtube.com/watch?v=08n7qZ-H7W8&t=2936s) | Axioma 2: asociatividad; primera demostración encadenada. |
| [48:56](https://www.youtube.com/watch?v=08n7qZ-H7W8&t=2936s)–[1:16:56](https://www.youtube.com/watch?v=08n7qZ-H7W8&t=4616s) | Axioma 3: distributividad; demostración de la versión derecha. |
| [1:22:29](https://www.youtube.com/watch?v=08n7qZ-H7W8&t=4949s)–[1:36:26](https://www.youtube.com/watch?v=08n7qZ-H7W8&t=5786s) | Axioma 4: elementos neutros; existencia y unicidad. |
| [1:36:26](https://www.youtube.com/watch?v=08n7qZ-H7W8&t=5786s)–fin | Preguntas finales; operaciones definidas a partir de otras. |

**Idea conductora:** una teoría axiomática parte de objetos y operaciones especificados, formula propiedades fundamentales y deduce de ellas nuevas proposiciones mediante demostraciones. El paso de calcular a **justificar por qué una igualdad es válida** organiza toda la cátedra.

### Cátedra 1.2

[Grabación original](https://www.youtube.com/watch?v=Tl5Hf5d4U2Y).

| Tiempo | Contenido |
|:--|:--|
| [02:01](https://www.youtube.com/watch?v=Tl5Hf5d4U2Y&t=121s) | Plan: concluir los axiomas de cuerpo y estudiar propiedades derivadas. |
| [03:36](https://www.youtube.com/watch?v=Tl5Hf5d4U2Y&t=216s) | Unicidad del neutro aditivo y distinción entre datos y objetivo. |
| [07:44](https://www.youtube.com/watch?v=Tl5Hf5d4U2Y&t=464s) | Advertencia contra el razonamiento circular; tautología $P\Rightarrow P$. |
| [10:50](https://www.youtube.com/watch?v=Tl5Hf5d4U2Y&t=650s) | Demostración de unicidad y bautizo del número $0$. |
| [16:00](https://www.youtube.com/watch?v=Tl5Hf5d4U2Y&t=960s) | Neutro multiplicativo, unicidad del $1$ y $0\ne1$. |
| [18:01](https://www.youtube.com/watch?v=Tl5Hf5d4U2Y&t=1081s) | Axioma 5: existencia de opuestos. |
| [19:51](https://www.youtube.com/watch?v=Tl5Hf5d4U2Y&t=1191s) | Prueba desarrollada de unicidad del opuesto. |
| [38:39](https://www.youtube.com/watch?v=Tl5Hf5d4U2Y&t=2319s) | Notación $-x$ y reconocimiento de un opuesto mediante una suma nula. |
| [45:00](https://www.youtube.com/watch?v=Tl5Hf5d4U2Y&t=2700s) | Recíproco $x^{-1}$ de los reales $x\ne0$; precisión sobre el alcance de un axioma. |
| [53:17](https://www.youtube.com/watch?v=Tl5Hf5d4U2Y&t=3197s) | Conclusión: $(\mathbb R,+,\cdot)$ es un cuerpo. |
| [59:54](https://www.youtube.com/watch?v=Tl5Hf5d4U2Y&t=3594s) | Tabla del cero: $a\cdot0=0$ y uso decisivo de distributividad. |
| [72:46](https://www.youtube.com/watch?v=Tl5Hf5d4U2Y&t=4366s) | Imposibilidad de un recíproco del cero; interés de la condición $0\ne1$. |
| [77:34](https://www.youtube.com/watch?v=Tl5Hf5d4U2Y&t=4654s) | Ecuación $a+x=b$, solución única y definición de resta. |
| [81:31](https://www.youtube.com/watch?v=Tl5Hf5d4U2Y&t=4891s) | Reglas de signos: $-(-a)=a$; opuesto de la suma. |
| [90:14](https://www.youtube.com/watch?v=Tl5Hf5d4U2Y&t=5414s) | Producto con un factor opuesto y actividades propuestas. |
| [91:31](https://www.youtube.com/watch?v=Tl5Hf5d4U2Y&t=5491s) | Apunte oficial, notaciones algebraicas, ejercicios y estudio autónomo. |

### Cátedra 2.1

[Grabación original](https://www.youtube.com/watch?v=o5TbpGI9KsU).

En la semana anterior se introdujeron los **axiomas de cuerpo**: suma, producto, neutros, opuestos e inversos multiplicativos. En esta cátedra se agrega una estructura sobre los mismos reales: un conjunto de números positivos y dos axiomas de orden. El recorrido culmina con la descripción de todas las soluciones de una inecuación lineal.

| Momento | Contenido en la grabación |
|---|---|
| [06:40](https://www.youtube.com/watch?v=o5TbpGI9KsU&t=400s) | Plan de la sesión y carácter acumulativo del curso. |
| [08:20](https://www.youtube.com/watch?v=o5TbpGI9KsU&t=500s) | El subconjunto $\mathbb R_+^*$ de reales estrictamente positivos. |
| [10:28](https://www.youtube.com/watch?v=o5TbpGI9KsU&t=628s) | Axioma 6: tricotomía. |
| [17:01](https://www.youtube.com/watch?v=o5TbpGI9KsU&t=1021s) | Axioma 7: clausura de los positivos por suma y producto. |
| [26:50](https://www.youtube.com/watch?v=o5TbpGI9KsU&t=1610s) | Definiciones de $<$, $>$, $\le$ y $\ge$. |
| [32:37](https://www.youtube.com/watch?v=o5TbpGI9KsU&t=1957s) | Positividad, negatividad y tricotomía para dos reales. |
| [42:00](https://www.youtube.com/watch?v=o5TbpGI9KsU&t=2520s) | Transitividad de $<$; otras propiedades del orden propuestas. |
| [45:35](https://www.youtube.com/watch?v=o5TbpGI9KsU&t=2735s) | Cómo demostrar una implicación. |
| [48:38](https://www.youtube.com/watch?v=o5TbpGI9KsU&t=2918s) | Sumar un mismo número a ambos lados de una desigualdad. |
| [56:50](https://www.youtube.com/watch?v=o5TbpGI9KsU&t=3410s) | Multiplicar por una constante positiva o negativa. |
| [68:08](https://www.youtube.com/watch?v=o5TbpGI9KsU&t=4088s) | Sumar dos desigualdades. |
| [70:47](https://www.youtube.com/watch?v=o5TbpGI9KsU&t=4247s) | Multiplicar desigualdades estrictas entre positivos. |
| [75:23](https://www.youtube.com/watch?v=o5TbpGI9KsU&t=4523s) | «Ni quita ni pone»: sumar y restar el mismo término. |
| [79:48](https://www.youtube.com/watch?v=o5TbpGI9KsU&t=4788s) | Cuadrados, signos de productos y recíprocos; tareas. |
| [82:42](https://www.youtube.com/watch?v=o5TbpGI9KsU&t=4962s) | Recta numérica e intervalos. |
| [85:15](https://www.youtube.com/watch?v=o5TbpGI9KsU&t=5115s) | Inecuaciones de primer grado $ax+b\mathrel{\square}0$. |
| [93:00](https://www.youtube.com/watch?v=o5TbpGI9KsU&t=5580s) | Punto de corte $-b/a$; cambio de signos si $a<0$. |
| [94:59](https://www.youtube.com/watch?v=o5TbpGI9KsU&t=5699s) | Cierre; preparación para inecuaciones de grado superior. |

### Cátedra 2.2

[Grabación original](https://www.youtube.com/watch?v=-NZgH0yH-NI).

| Tiempo | Desarrollo |
|---|---|
| [08:14](https://www.youtube.com/watch?v=-NZgH0yH-NI&t=494s) | Objetivos y recuerdo de los axiomas de orden. |
| [09:02](https://www.youtube.com/watch?v=-NZgH0yH-NI&t=542s) | Signo de $ax+b$ respecto del punto $-b/a$. |
| [12:38](https://www.youtube.com/watch?v=-NZgH0yH-NI&t=758s) | Forma factorizada de las inecuaciones racionales. |
| [14:24](https://www.youtube.com/watch?v=-NZgH0yH-NI&t=864s) | Reducción del ejemplo a $(2x-4)/[x(x-1)]\le 0$. |
| [20:58](https://www.youtube.com/watch?v=-NZgH0yH-NI&t=1258s) | Signo del producto y paridad de factores negativos. |
| [23:10](https://www.youtube.com/watch?v=-NZgH0yH-NI&t=1390s) | Algoritmo para resolver inecuaciones factorizadas. |
| [30:25](https://www.youtube.com/watch?v=-NZgH0yH-NI&t=1825s) | Puntos críticos: ceros del numerador y del denominador. |
| [33:45](https://www.youtube.com/watch?v=-NZgH0yH-NI&t=2025s) | Ejemplo $(x-1)/(x-1)\ge0$ y dominio. |
| [37:00](https://www.youtube.com/watch?v=-NZgH0yH-NI&t=2220s) | Tabla de signos y resolución completa del ejemplo principal. |
| [50:25](https://www.youtube.com/watch?v=-NZgH0yH-NI&t=3025s) | Factores lineales, simplificaciones y cuadráticas. |
| [60:14](https://www.youtube.com/watch?v=-NZgH0yH-NI&t=3614s) | Inicio de la completación de cuadrados perfectos. |
| [75:14](https://www.youtube.com/watch?v=-NZgH0yH-NI&t=4514s) | Completación de cuadrados en $ax^2+bx+c$. |
| [79:51](https://www.youtube.com/watch?v=-NZgH0yH-NI&t=4791s) | Definición y significado del discriminante. |
| [82:22](https://www.youtube.com/watch?v=-NZgH0yH-NI&t=4942s) | Caso $\Delta<0$. |
| [88:17](https://www.youtube.com/watch?v=-NZgH0yH-NI&t=5297s) | Caso $\Delta=0$. |
| [90:31](https://www.youtube.com/watch?v=-NZgH0yH-NI&t=5431s) | Caso $\Delta>0$ y cuestión de las raíces cuadradas. |
| [94:41](https://www.youtube.com/watch?v=-NZgH0yH-NI&t=5681s) | Existencia y unicidad de $x^2=\Delta$. |
| [99:19](https://www.youtube.com/watch?v=-NZgH0yH-NI&t=5959s) | Raíz cuadrada positiva, conclusión de la cátedra. |
| [105:00](https://www.youtube.com/watch?v=-NZgH0yH-NI&t=6300s) | Preguntas sobre métodos de demostración y reversibilidad. |

### Cátedra 3.1

[Grabación original](https://www.youtube.com/watch?v=vxF8xwRmesA).

| Momento | Contenido |
|:--|:--|
| [08:00](https://www.youtube.com/watch?v=vxF8xwRmesA&t=480s) | Inicio de la semana 3; geometría analítica y la completitud pendiente. |
| [10:12](https://www.youtube.com/watch?v=vxF8xwRmesA&t=612s) | Alcance del primer control: circunferencias y rectas. |
| [11:40](https://www.youtube.com/watch?v=vxF8xwRmesA&t=700s) | Geometría y álgebra; idea del método cartesiano. |
| [13:20](https://www.youtube.com/watch?v=vxF8xwRmesA&t=800s) | Ejes, coordenadas y pares ordenados de $\mathbb R^2$. |
| [18:27](https://www.youtube.com/watch?v=vxF8xwRmesA&t=1107s) | Lugar geométrico: subconjunto definido por una condición. |
| [21:20](https://www.youtube.com/watch?v=vxF8xwRmesA&t=1280s) | Siete lugares elementales; origen, ejes, cuadrantes y rectas constantes. |
| [35:34](https://www.youtube.com/watch?v=vxF8xwRmesA&t=2134s) | Circunferencia, centro, radio y necesidad de medir distancias. |
| [37:00](https://www.youtube.com/watch?v=vxF8xwRmesA&t=2220s) | Teorema de Pitágoras y fórmula de distancia euclidiana. |
| [43:17](https://www.youtube.com/watch?v=vxF8xwRmesA&t=2597s) | Definición de circunferencia como lugar geométrico. |
| [49:39](https://www.youtube.com/watch?v=vxF8xwRmesA&t=2979s) | Elevar al cuadrado y equivalencia de ecuaciones. |
| [1:01:13](https://www.youtube.com/watch?v=vxF8xwRmesA&t=3673s) | Ecuación canónica y ejemplos inmediatos. |
| [1:10:00](https://www.youtube.com/watch?v=vxF8xwRmesA&t=4200s) | Continuación tras una pausa técnica; cuatro ejemplos. |
| [1:14:28](https://www.youtube.com/watch?v=vxF8xwRmesA&t=4468s) | Completar cuadrados: $x^2+y^2=-2x$. |
| [1:17:54](https://www.youtube.com/watch?v=vxF8xwRmesA&t=4674s) | Expansión de la ecuación y forma general $x^2+y^2+Ax+By+C=0$. |
| [1:21:21](https://www.youtube.com/watch?v=vxF8xwRmesA&t=4881s) | Completar dos cuadrados y obtener centro y radio. |
| [1:29:03](https://www.youtube.com/watch?v=vxF8xwRmesA&t=5343s) | Clasificación: circunferencia, punto o conjunto vacío. |
| [1:39:11](https://www.youtube.com/watch?v=vxF8xwRmesA&t=5951s) | Cierre, preguntas y anuncio de la clase sobre rectas. |

### Cátedra 3.2

[Grabación original](https://www.youtube.com/watch?v=h-eNbC2gUpw).

| Tiempo | Núcleo de la exposición |
|:--|:--|
| [06:25](https://www.youtube.com/watch?v=h-eNbC2gUpw&t=385s) | Plan: rectas, pendiente, propiedades y aplicaciones; cierre de la materia del primer control. |
| [07:42](https://www.youtube.com/watch?v=h-eNbC2gUpw&t=462s) | Geometría y definición analítica de recta. |
| [09:00](https://www.youtube.com/watch?v=h-eNbC2gUpw&t=540s) | Significado de $A^2+B^2\ne0$ y negación de una conjunción. |
| [18:27](https://www.youtube.com/watch?v=h-eNbC2gUpw&t=1107s) | Lugar geométrico $Ax+By+C=0$. |
| [19:14](https://www.youtube.com/watch?v=h-eNbC2gUpw&t=1154s) | Rectas horizontales y verticales; despejes válidos. |
| [22:51](https://www.youtube.com/watch?v=h-eNbC2gUpw&t=1371s) | Construir puntos de una recta oblicua. |
| [26:36](https://www.youtube.com/watch?v=h-eNbC2gUpw&t=1596s) | Caso especial $C=0$; puntos $(0,0)$ y $(B,-A)$. |
| [31:20](https://www.youtube.com/watch?v=h-eNbC2gUpw&t=1880s) | Clasificación geométrica según los coeficientes. |
| [34:08](https://www.youtube.com/watch?v=h-eNbC2gUpw&t=2048s) | Teorema de la pendiente de una recta no vertical. |
| [38:28](https://www.youtube.com/watch?v=h-eNbC2gUpw&t=2308s) | Demostración algebraica por sustracción de dos ecuaciones. |
| [46:20](https://www.youtube.com/watch?v=h-eNbC2gUpw&t=2780s) | Justificación de $x_2-x_1\ne0$ para puntos distintos de la misma recta. |
| [52:12](https://www.youtube.com/watch?v=h-eNbC2gUpw&t=3132s) | Triángulos semejantes y lectura geométrica de la pendiente. |
| [54:32](https://www.youtube.com/watch?v=h-eNbC2gUpw&t=3272s) | Incrementos $\Delta y=m\Delta x$ e interpretación del signo. |

### Cátedra 4.1

[Grabación original](https://www.youtube.com/watch?v=7qlkE41AITo).

| Minuto | Desarrollo |
|:--|:--|
| [07:37](https://www.youtube.com/watch?v=7qlkE41AITo&t=457s) | Semana 4: cónicas y alcance del primer control. |
| [09:59](https://www.youtube.com/watch?v=7qlkE41AITo&t=599s) | Directriz, foco y excentricidad; definición de cónica. |
| [13:30](https://www.youtube.com/watch?v=7qlkE41AITo&t=810s) | Tres casos: elipse, parábola e hipérbola. |
| [18:02](https://www.youtube.com/watch?v=7qlkE41AITo&t=1082s) | Vértice como punto medio entre foco y pie sobre la directriz. |
| [21:30](https://www.youtube.com/watch?v=7qlkE41AITo&t=1290s) | Elección del sistema cartesiano; foco $(p,0)$, directriz $x=-p$. |
| [26:24](https://www.youtube.com/watch?v=7qlkE41AITo&t=1584s) | Deducción por distancias de $y^2=4px$. |
| [37:00](https://www.youtube.com/watch?v=7qlkE41AITo&t=2220s) | Lectura geométrica de la ecuación: signo de $p$ y regiones del plano. |
| [41:30](https://www.youtube.com/watch?v=7qlkE41AITo&t=2490s) | Simetría respecto del eje $x$. |
| [47:38](https://www.youtube.com/watch?v=7qlkE41AITo&t=2858s) | Intersecciones de rectas con la parábola y ausencia de oscilaciones. |
| [56:59](https://www.youtube.com/watch?v=7qlkE41AITo&t=3419s) | Rama creciente en el primer cuadrante; apertura izquierda o derecha. |
| [1:10:55](https://www.youtube.com/watch?v=7qlkE41AITo&t=4255s) | Retorno de la pausa; secantes, tangentes y rectas exteriores. |
| [1:13:09](https://www.youtube.com/watch?v=7qlkE41AITo&t=4389s) | Discriminante de la intersección y condición $mn=p$. |
| [1:17:50](https://www.youtube.com/watch?v=7qlkE41AITo&t=4670s) | Punto de tangencia y ecuación de la recta tangente. |
| [1:26:58](https://www.youtube.com/watch?v=7qlkE41AITo&t=5218s) | «Desdoblada»: una técnica para curvas de grado uno y dos. |
| [1:35:37](https://www.youtube.com/watch?v=7qlkE41AITo&t=5737s) | Parábola de eje vertical: $x^2=4py$. |
| [1:38:49](https://www.youtube.com/watch?v=7qlkE41AITo&t=5929s) | Ejemplos y anuncio de traslaciones en la clase siguiente. |

**Idea generadora.** Una ecuación obtenida de una condición geométrica contiene información sobre las regiones del plano, la simetría, la forma de la curva y la multiplicidad de sus intersecciones con rectas. El profesor construye esos resultados sin recurrir al cálculo diferencial, que el curso estudiará más adelante.

### Cátedra 4.2

[Grabación original](https://www.youtube.com/watch?v=E2KL0qm2vIg).

| Momento de la grabación | Desarrollo |
|:--|:--|
| [02:31](https://www.youtube.com/watch?v=E2KL0qm2vIg&t=151s) | Segunda cátedra de cónicas; el control del día siguiente comprende la materia previa. |
| [03:09](https://www.youtube.com/watch?v=E2KL0qm2vIg&t=189s) | Repaso de $y^2=4px$, $x^2=4py$ y los signos de $p$. |
| [07:45](https://www.youtube.com/watch?v=E2KL0qm2vIg&t=465s) | Escritura $y=ax^2$ y correspondencia $p=1/(4a)$. |
| [13:09](https://www.youtube.com/watch?v=E2KL0qm2vIg&t=789s) | Traslación del sistema; coordenadas locales $x',y'$. |
| [20:09](https://www.youtube.com/watch?v=E2KL0qm2vIg&t=1209s) | Relaciones $x'=x-x_0$, $y'=y-y_0$. |
| [27:52](https://www.youtube.com/watch?v=E2KL0qm2vIg&t=1672s) | Foco y directriz de la parábola trasladada. |
| [33:42](https://www.youtube.com/watch?v=E2KL0qm2vIg&t=2022s) | Completar cuadrados en $y=ax^2+bx+c$. |
| [43:35](https://www.youtube.com/watch?v=E2KL0qm2vIg&t=2615s) | Discriminante, cortes con el eje horizontal y signo de la cuadrática. |
| [59:58](https://www.youtube.com/watch?v=E2KL0qm2vIg&t=3598s) | Retorno de la pausa: elipse e hipérbola. |
| [1:01:15](https://www.youtube.com/watch?v=E2KL0qm2vIg&t=3675s) | Foco $(f,0)$, directriz $x=d$ y excentricidad $e\ne1$. |
| [1:04:15](https://www.youtube.com/watch?v=E2KL0qm2vIg&t=3855s) | Ecuación general por razón de distancias. |
| [1:13:26](https://www.youtube.com/watch?v=E2KL0qm2vIg&t=4406s) | Elección del origen mediante $f=e^2d$. |
| [1:19:00](https://www.youtube.com/watch?v=E2KL0qm2vIg&t=4740s) | Normalización de la ecuación y separación por el signo de $1-e^2$. |
| [1:24:28](https://www.youtube.com/watch?v=E2KL0qm2vIg&t=5068s) | Semiejes $a,b$ de la elipse. |
| [1:29:35](https://www.youtube.com/watch?v=E2KL0qm2vIg&t=5375s) | Identidad $a^2=b^2+f^2$ y dos focos y directrices. |
| [1:34:00](https://www.youtube.com/watch?v=E2KL0qm2vIg&t=5640s) | Cierre de cónicas; consultas de geometría analítica y del control. |

El recorrido comienza con una pregunta pedagógica esencial: **¿qué información geométrica se puede recuperar de una ecuación algebraica?** La traslación del origen permite interpretar los coeficientes de la parábola; la elección del origen apropiado para otra cónica conduce a sus semiejes, focos y directrices.

### Cátedra 5.1

[Grabación original](https://www.youtube.com/watch?v=qbH2dSX-oYk).

| Momento | Tema |
|:--|:--|
| [01:10](https://www.youtube.com/watch?v=qbH2dSX-oYk&t=70s) | Inicio de la semana 5: funciones reales de variable real. |
| [03:33](https://www.youtube.com/watch?v=qbH2dSX-oYk&t=213s) | Correspondencia entre conjuntos; existencia y unicidad de la imagen. |
| [06:51](https://www.youtube.com/watch?v=qbH2dSX-oYk&t=411s) | Determinación del dominio a partir de la fórmula. |
| [07:47](https://www.youtube.com/watch?v=qbH2dSX-oYk&t=467s) | Raíces cuadradas, expresiones racionales e inecuaciones. |
| [10:38](https://www.youtube.com/watch?v=qbH2dSX-oYk&t=638s) | Simplificación algebraica y conservación del dominio. |
| [16:20](https://www.youtube.com/watch?v=qbH2dSX-oYk&t=980s) | Grafo como subconjunto de $\mathbb R^2$; prueba de la recta vertical. |
| [21:16](https://www.youtube.com/watch?v=qbH2dSX-oYk&t=1276s) | Ceros y conjuntos de positividad y negatividad. |
| [29:47](https://www.youtube.com/watch?v=qbH2dSX-oYk&t=1787s) | Funciones pares e impares y sus simetrías. |
| [36:41](https://www.youtube.com/watch?v=qbH2dSX-oYk&t=2201s) | Ejemplos con potencias, valor absoluto y cocientes. |
| [43:13](https://www.youtube.com/watch?v=qbH2dSX-oYk&t=2593s) | Descomposición par–impar propuesta como teorema. |
| [43:43](https://www.youtube.com/watch?v=qbH2dSX-oYk&t=2623s) | Funciones periódicas: repetición hacia la derecha. |
| [56:36](https://www.youtube.com/watch?v=qbH2dSX-oYk&t=3396s) | Crecimiento y decrecimiento por comparación de imágenes. |
| [1:09:21](https://www.youtube.com/watch?v=qbH2dSX-oYk&t=4161s) | Ejemplo fácil: $x^3+x$. |
| [1:18:04](https://www.youtube.com/watch?v=qbH2dSX-oYk&t=4684s) | Ejemplo difícil: $x^3-x$ y límites del método directo. |
| [1:23:43](https://www.youtube.com/watch?v=qbH2dSX-oYk&t=5023s) | Técnica de la diferencia de imágenes y cociente de secante. |
| [1:31:20](https://www.youtube.com/watch?v=qbH2dSX-oYk&t=5480s) | Tarea de crecimiento en $[1,\infty)$ y anticipo de la próxima clase. |

### Cátedra 5.2

[Grabación original](https://www.youtube.com/watch?v=NEYH4Qw4QK4).

| Momento | Desarrollo |
|:---|:---|
| [09:12](https://www.youtube.com/watch?v=NEYH4Qw4QK4&t=552s) | Inicio del tema: continuación de $f(x)=x^3-x$. |
| [10:00](https://www.youtube.com/watch?v=NEYH4Qw4QK4&t=600s) | Cociente de diferencias y signo de $x_1^2+x_1x_2+x_2^2-1$. |
| [18:19](https://www.youtube.com/watch?v=NEYH4Qw4QK4&t=1099s) | Ampliación del intervalo de crecimiento. |
| [22:18](https://www.youtube.com/watch?v=NEYH4Qw4QK4&t=1338s) | Umbral $1/\sqrt3$ y su justificación. |
| [24:45](https://www.youtube.com/watch?v=NEYH4Qw4QK4&t=1485s) | Decrecimiento en $[0,1/\sqrt3]$. |
| [30:01](https://www.youtube.com/watch?v=NEYH4Qw4QK4&t=1801s) | Gráfico, pendientes secantes y simetría impar. |
| [35:56](https://www.youtube.com/watch?v=NEYH4Qw4QK4&t=2156s) | Anticipo del papel de las derivadas. |
| [40:10](https://www.youtube.com/watch?v=NEYH4Qw4QK4&t=2410s) | Funciones constantes y potencias naturales. |
| [48:55](https://www.youtube.com/watch?v=NEYH4Qw4QK4&t=2935s) | Ecuaciones $x^n=y$; raíces de índice par e impar. |
| [51:55](https://www.youtube.com/watch?v=NEYH4Qw4QK4&t=3115s) | Gráficas de raíces enésimas y reflexión sobre $y=x$. |
| [56:56](https://www.youtube.com/watch?v=NEYH4Qw4QK4&t=3416s) | Álgebra de funciones y dominios. |
| [1:02:14](https://www.youtube.com/watch?v=NEYH4Qw4QK4&t=3734s) | Dominio del cociente y ceros del denominador. |
| [1:12:24](https://www.youtube.com/watch?v=NEYH4Qw4QK4&t=4344s) | Polinomios y funciones racionales. |
| [1:18:19](https://www.youtube.com/watch?v=NEYH4Qw4QK4&t=4699s) | Ejemplo $f(x)=2x/(x+1)$: dominio, ceros y signos. |
| [1:24:45](https://www.youtube.com/watch?v=NEYH4Qw4QK4&t=5085s) | Cociente de diferencias y crecimiento de la racional. |
| [1:33:24](https://www.youtube.com/watch?v=NEYH4Qw4QK4&t=5604s) | Asíntota horizontal $y=2$. |
| [1:38:21](https://www.youtube.com/watch?v=NEYH4Qw4QK4&t=5901s) | Aproximación a $x=-1$; asíntota vertical. |
| [1:41:08](https://www.youtube.com/watch?v=NEYH4Qw4QK4&t=6068s) | Generalizaciones indicadas y preparación para límites. |

### Cátedra 6.1

[Grabación original](https://www.youtube.com/watch?v=Omn6hikVwIc).

| Momento de YouTube | Tema tratado |
|:---|:---|
| [04:35](https://www.youtube.com/watch?v=Omn6hikVwIc&t=275s) | Inicio: medida de ángulos; sistema sexagesimal y centesimal. |
| [08:55](https://www.youtube.com/watch?v=Omn6hikVwIc&t=535s) | Sistema circular: razón entre longitud de arco y radio. |
| [16:50](https://www.youtube.com/watch?v=Omn6hikVwIc&t=1010s) | Ángulos recto, llano y completo; equivalencias con radianes. |
| [24:00](https://www.youtube.com/watch?v=Omn6hikVwIc&t=1440s) | Ángulos orientados, vueltas completas y ángulos negativos. |
| [30:15](https://www.youtube.com/watch?v=Omn6hikVwIc&t=1815s) | Circunferencia unitaria y punto asociado a un ángulo. |
| [36:55](https://www.youtube.com/watch?v=Omn6hikVwIc&t=2215s) | Definiciones de coseno y seno como coordenadas. |
| [42:45](https://www.youtube.com/watch?v=Omn6hikVwIc&t=2565s) | Tangente, cotangente, secante y cosecante; dominios. |
| [55:50](https://www.youtube.com/watch?v=Omn6hikVwIc&t=3350s) | Las tres identidades trigonométricas fundamentales. |
| [1:06:42](https://www.youtube.com/watch?v=Omn6hikVwIc&t=4002s) | Cálculo geométrico de $\pi/4$, $\pi/3$ y $\pi/6$. |
| [1:19:12](https://www.youtube.com/watch?v=Omn6hikVwIc&t=4752s) | Tabla de valores exactos y regla mnemotécnica. |
| [1:21:45](https://www.youtube.com/watch?v=Omn6hikVwIc&t=4905s) | Segmentos trigonométricos y tangente como ordenada en $x=1$. |
| [1:28:55](https://www.youtube.com/watch?v=Omn6hikVwIc&t=5335s) | Construcción de los gráficos de seno, coseno y tangente. |
| [1:37:25](https://www.youtube.com/watch?v=Omn6hikVwIc&t=5845s) | Preguntas: asíntotas, restricción, imagen y acotación. |

**Problema conductor.** Una medida angular determina una posición sobre una circunferencia. Las coordenadas de esa posición, consideradas como funciones de la medida angular, permiten construir el seno y el coseno. Sus cocientes producen otras cuatro funciones y la geometría de la circunferencia ofrece identidades y gráficos.

### Cátedra 6.2

[Grabación original](https://www.youtube.com/watch?v=bkh-hjyrE_o).

| Minuto | Tema |
|:---|:---|
| [09:21](https://www.youtube.com/watch?v=bkh-hjyrE_o&t=561s) | Bienvenida y presentación de la segunda clase de trigonometría. |
| [11:47](https://www.youtube.com/watch?v=bkh-hjyrE_o&t=707s) | Plan: aplicaciones a triángulos rectángulos e identidades. |
| [13:26](https://www.youtube.com/watch?v=bkh-hjyrE_o&t=806s) | Signos del seno, coseno y tangente en los cuatro cuadrantes. |
| [17:12](https://www.youtube.com/watch?v=bkh-hjyrE_o&t=1032s) | Triángulo rectángulo y semejanza con el círculo unitario. |
| [22:41](https://www.youtube.com/watch?v=bkh-hjyrE_o&t=1361s) | Deducción de seno, coseno y tangente como razones de lados. |
| [26:04](https://www.youtube.com/watch?v=bkh-hjyrE_o&t=1564s) | Proyecciones ortogonales de un segmento. |
| [32:23](https://www.youtube.com/watch?v=bkh-hjyrE_o&t=1943s) | Primera aplicación: pendiente de una recta e inclinación. |
| [35:33](https://www.youtube.com/watch?v=bkh-hjyrE_o&t=2133s) | Segunda aplicación: fuerzas sobre un plano inclinado. |
| [41:40](https://www.youtube.com/watch?v=bkh-hjyrE_o&t=2500s) | Reacción normal, cuerda, resorte y equilibrio. |
| [47:18](https://www.youtube.com/watch?v=bkh-hjyrE_o&t=2838s) | Roce estático y ángulo crítico. |
| [51:53](https://www.youtube.com/watch?v=bkh-hjyrE_o&t=3113s) | Inicio de las fórmulas para suma y diferencia de ángulos. |
| [58:37](https://www.youtube.com/watch?v=bkh-hjyrE_o&t=3517s) | Puntos $P_\alpha$, $P_\beta$ y sus coordenadas. |
| [1:00:14](https://www.youtube.com/watch?v=bkh-hjyrE_o&t=3614s) | Distancia entre dos puntos del círculo unitario. |
| [1:10:28](https://www.youtube.com/watch?v=bkh-hjyrE_o&t=4228s) | Rotación simultánea y conservación de la distancia. |
| [1:19:15](https://www.youtube.com/watch?v=bkh-hjyrE_o&t=4755s) | Demostración del coseno de una diferencia. |
| [1:24:42](https://www.youtube.com/watch?v=bkh-hjyrE_o&t=5082s) | Caso $\beta=0$: paridad del coseno. |
| [1:26:05](https://www.youtube.com/watch?v=bkh-hjyrE_o&t=5165s) | Caso $\beta=\pi/2$: ángulos complementarios. |
| [1:35:24](https://www.youtube.com/watch?v=bkh-hjyrE_o&t=5724s) | Imparidad del seno. |
| [1:38:34](https://www.youtube.com/watch?v=bkh-hjyrE_o&t=5914s) | Coseno de una suma y temas reservados para la clase próxima. |

### Cátedra 7.1

[Grabación original](https://www.youtube.com/watch?v=VwFUnoxUw3M).

| Momento | Desarrollo de la sesión |
|:---|:---|
| [09:36](https://www.youtube.com/watch?v=VwFUnoxUw3M&t=576s) | Apertura, programa y continuidad de trigonometría. |
| [11:10](https://www.youtube.com/watch?v=VwFUnoxUw3M&t=670s) | Recordatorio del coseno de una diferencia. |
| [14:54](https://www.youtube.com/watch?v=VwFUnoxUw3M&t=894s) | Deducción del seno de una suma y una diferencia. |
| [20:16](https://www.youtube.com/watch?v=VwFUnoxUw3M&t=1216s) | Tabla de cuatro identidades y comprobación de signos. |
| [26:39](https://www.youtube.com/watch?v=VwFUnoxUw3M&t=1599s) | Seno y coseno del ángulo doble. |
| [29:58](https://www.youtube.com/watch?v=VwFUnoxUw3M&t=1798s) | Fórmulas de ángulo medio y cuadrados trigonométricos. |
| [37:02](https://www.youtube.com/watch?v=VwFUnoxUw3M&t=2222s) | Tangente del ángulo medio y su dominio. |
| [44:00](https://www.youtube.com/watch?v=VwFUnoxUw3M&t=2640s) | Triángulos cualesquiera y problema de su resolución. |
| [46:25](https://www.youtube.com/watch?v=VwFUnoxUw3M&t=2785s) | Deducción de la ley del seno mediante alturas. |
| [53:04](https://www.youtube.com/watch?v=VwFUnoxUw3M&t=3184s) | Dos ángulos y un lado; resolución. |
| [55:21](https://www.youtube.com/watch?v=VwFUnoxUw3M&t=3321s) | Dos lados y un ángulo; caso ambiguo. |
| [1:08:11](https://www.youtube.com/watch?v=VwFUnoxUw3M&t=4091s) | Deducción de la ley del coseno. |
| [1:16:45](https://www.youtube.com/watch?v=VwFUnoxUw3M&t=4605s) | Corrección de Pitágoras e interpretación geométrica. |
| [1:22:20](https://www.youtube.com/watch?v=VwFUnoxUw3M&t=4940s) | Problema 1: altura desde terreno horizontal. |
| [1:25:05](https://www.youtube.com/watch?v=VwFUnoxUw3M&t=5105s) | Problema 2: altura desde terreno inclinado. |
| [1:29:05](https://www.youtube.com/watch?v=VwFUnoxUw3M&t=5345s) | Problema 3: dos observadores y distancia inaccesible. |
| [1:38:40](https://www.youtube.com/watch?v=VwFUnoxUw3M&t=5920s) | Problema 4: inclinación y dos observadores; propuesto. |
| [1:42:36](https://www.youtube.com/watch?v=VwFUnoxUw3M&t=6156s) | Consultas finales sobre parte entera y función piso. |

### Cátedra 7.2

[Grabación original](https://www.youtube.com/watch?v=EoIVowNQD70).

| Momento | Contenido |
|:---|:---|
| [09:29](https://www.youtube.com/watch?v=EoIVowNQD70&t=569s) | Apertura y objetivo: las tres inversas trigonométricas. |
| [10:31](https://www.youtube.com/watch?v=EoIVowNQD70&t=631s) | Inyectividad, sobreyectividad y existencia-unicidad de soluciones. |
| [13:35](https://www.youtube.com/watch?v=EoIVowNQD70&t=815s) | Restricción del seno y búsqueda de una rama invertible. |
| [22:15](https://www.youtube.com/watch?v=EoIVowNQD70&t=1335s) | Restricción del codominio; definición del arcoseno. |
| [27:53](https://www.youtube.com/watch?v=EoIVowNQD70&t=1673s) | Gráfica del arcoseno por intercambio de coordenadas. |
| [31:19](https://www.youtube.com/watch?v=EoIVowNQD70&t=1879s) | La ecuación general $\operatorname{sen}x=a$. |
| [34:00](https://www.youtube.com/watch?v=EoIVowNQD70&t=2040s) | Dos soluciones en el círculo unitario y periodicidad. |
| [43:32](https://www.youtube.com/watch?v=EoIVowNQD70&t=2612s) | Fórmula compacta $k\pi+(-1)^k\alpha$. |
| [47:47](https://www.youtube.com/watch?v=EoIVowNQD70&t=2867s) | Analogía con $x^2=a$ y la raíz principal. |
| [54:50](https://www.youtube.com/watch?v=EoIVowNQD70&t=3290s) | Función coseno: elección de su rama invertible. |
| [1:00:11](https://www.youtube.com/watch?v=EoIVowNQD70&t=3611s) | Definición y gráfica del arcocoseno. |
| [1:10:33](https://www.youtube.com/watch?v=EoIVowNQD70&t=4233s) | Soluciones de $\cos x=a$. |
| [1:22:43](https://www.youtube.com/watch?v=EoIVowNQD70&t=4963s) | Restricción de la tangente y arcotangente. |
| [1:25:37](https://www.youtube.com/watch?v=EoIVowNQD70&t=5137s) | Solución general de $\tan x=a$. |
| [1:27:13](https://www.youtube.com/watch?v=EoIVowNQD70&t=5233s) | Ecuación trigonométrica compuesta: reducción y factorización. |
| [1:37:40](https://www.youtube.com/watch?v=EoIVowNQD70&t=5860s) | Solución por combinación de seno y coseno; propuesta final. |
| [1:41:35](https://www.youtube.com/watch?v=EoIVowNQD70&t=6095s) | Fin de la exposición; consultas administrativas. |

### Cátedra 8.1

[Grabación original](https://www.youtube.com/watch?v=U2nQmKdc_lo).

| Momento | Desarrollo |
|:---|:---|
| [06:38](https://www.youtube.com/watch?v=U2nQmKdc_lo&t=398s) | El sistema de axiomas: cuerpo, orden y completitud. |
| [10:54](https://www.youtube.com/watch?v=U2nQmKdc_lo&t=654s) | Conjuntos reales no vacíos y seis definiciones previas. |
| [12:27](https://www.youtube.com/watch?v=U2nQmKdc_lo&t=747s) | Acotación superior y cuantificadores. |
| [20:03](https://www.youtube.com/watch?v=U2nQmKdc_lo&t=1203s) | Acotación inferior y cotas inferiores. |
| [23:33](https://www.youtube.com/watch?v=U2nQmKdc_lo&t=1413s) | Primeros ejemplos con intervalos; desigualdad débil. |
| [31:37](https://www.youtube.com/watch?v=U2nQmKdc_lo&t=1897s) | Unión de intervalos y examen de cotas. |
| [34:08](https://www.youtube.com/watch?v=U2nQmKdc_lo&t=2048s) | Todas las cotas superiores mayores que otra dada. |
| [44:05](https://www.youtube.com/watch?v=U2nQmKdc_lo&t=2645s) | Máximo y mínimo; pertenencia al conjunto. |
| [48:52](https://www.youtube.com/watch?v=U2nQmKdc_lo&t=2932s) | El ejemplo $[0,1)$ y el problema del extremo abierto. |
| [55:45](https://www.youtube.com/watch?v=U2nQmKdc_lo&t=3345s) | Argumento del punto medio: ninguna cota inferior a 1. |
| [59:20](https://www.youtube.com/watch?v=U2nQmKdc_lo&t=3560s) | Definiciones de supremo e ínfimo. |
| [1:02:06](https://www.youtube.com/watch?v=U2nQmKdc_lo&t=3726s) | **Axioma 8: axioma del supremo.** |
| [1:10:30](https://www.youtube.com/watch?v=U2nQmKdc_lo&t=4230s) | Ínfimo a partir del supremo; introducción a $\sqrt2$. |
| [1:17:00](https://www.youtube.com/watch?v=U2nQmKdc_lo&t=4620s) | Construcción del conjunto $A=\{x\geq0:x^2<2\}$. |
| [1:22:25](https://www.youtube.com/watch?v=U2nQmKdc_lo&t=4945s) | Demostración de acotación superior. |
| [1:27:48](https://www.youtube.com/watch?v=U2nQmKdc_lo&t=5268s) | Existencia de $s=\sup A$ por el axioma. |
| [1:31:40](https://www.youtube.com/watch?v=U2nQmKdc_lo&t=5500s) | Tricotomía: $s^2>2$, $s^2<2$ o $s^2=2$. |
| [1:35:39](https://www.youtube.com/watch?v=U2nQmKdc_lo&t=5739s) | Primera contradicción anunciada; continuación pendiente. |

### Cátedra 8.2

[Grabación original](https://www.youtube.com/watch?v=Q-gZ2Ja3kCg).

| Momento | Desarrollo de la clase |
|:---|:---|
| [15:42](https://www.youtube.com/watch?v=Q-gZ2Ja3kCg&t=942s) | Presentación del enlace entre álgebra, reales y naturales. |
| [18:49](https://www.youtube.com/watch?v=Q-gZ2Ja3kCg&t=1129s) | Definición de conjunto inductivo. |
| [21:15](https://www.youtube.com/watch?v=Q-gZ2Ja3kCg&t=1275s) | Ejemplos de conjuntos inductivos, cada vez menores. |
| [30:21](https://www.youtube.com/watch?v=Q-gZ2Ja3kCg&t=1821s) | Definición de $\mathbb N$ como intersección de todos los inductivos. |
| [32:40](https://www.youtube.com/watch?v=Q-gZ2Ja3kCg&t=1960s) | Teorema: la intersección es inductiva. |
| [41:43](https://www.youtube.com/watch?v=Q-gZ2Ja3kCg&t=2503s) | Minimalidad de $\mathbb N$ y principio de inducción. |
| [49:25](https://www.youtube.com/watch?v=Q-gZ2Ja3kCg&t=2965s) | Cinco propiedades elementales de los naturales. |
| [54:28](https://www.youtube.com/watch?v=Q-gZ2Ja3kCg&t=3268s) | Ejemplo de inducción con una implicación lógica. |
| [1:03:13](https://www.youtube.com/watch?v=Q-gZ2Ja3kCg&t=3793s) | Teorema: $\mathbb N$ es no acotado superiormente. |
| [1:06:00](https://www.youtube.com/watch?v=Q-gZ2Ja3kCg&t=3960s) | Demostración por contradicción mediante el supremo. |
| [1:22:13](https://www.youtube.com/watch?v=Q-gZ2Ja3kCg&t=4933s) | Propiedad arquimediana de $\mathbb R$. |
| [1:29:16](https://www.youtube.com/watch?v=Q-gZ2Ja3kCg&t=5356s) | Negación de cuantificadores y demostración de la propiedad. |
| [1:33:18](https://www.youtube.com/watch?v=Q-gZ2Ja3kCg&t=5598s) | Definición de $\mathbb Z$ y separación de enteros consecutivos. |
| [1:35:28](https://www.youtube.com/watch?v=Q-gZ2Ja3kCg&t=5728s) | Existencia de la función parte entera. |
| [1:44:07](https://www.youtube.com/watch?v=Q-gZ2Ja3kCg&t=6247s) | Definición de racionales y relación con completitud. |
| [1:46:41](https://www.youtube.com/watch?v=Q-gZ2Ja3kCg&t=6401s) | Densidad de racionales e irracionales: estudio propuesto. |
| [1:48:08](https://www.youtube.com/watch?v=Q-gZ2Ja3kCg&t=6488s) | Consulta sobre enteros consecutivos y parte entera. |

### Cátedra 9.1

[Grabación original](https://www.youtube.com/watch?v=OvFPirtl0yQ).

| Minuto | Contenido |
|:---|:---|
| [08:47](https://www.youtube.com/watch?v=OvFPirtl0yQ&t=527s) | Inicio y plan de dos semanas dedicadas a sucesiones. |
| [11:07](https://www.youtube.com/watch?v=OvFPirtl0yQ&t=667s) | Sucesión como función cuyo dominio son los naturales. |
| [14:11](https://www.youtube.com/watch?v=OvFPirtl0yQ&t=851s) | Notación $(s_n)$; distinción entre sucesión y conjunto de valores. |
| [23:51](https://www.youtube.com/watch?v=OvFPirtl0yQ&t=1431s) | Ejemplos de fórmulas y dominios con excepciones finitas. |
| [31:06](https://www.youtube.com/watch?v=OvFPirtl0yQ&t=1866s) | Sucesiones de truncamientos decimales: $0,999\ldots$, $\sqrt2$ y $\pi$. |
| [37:22](https://www.youtube.com/watch?v=OvFPirtl0yQ&t=2242s) | Representación de sucesiones sobre la recta real. |
| [41:45](https://www.youtube.com/watch?v=OvFPirtl0yQ&t=2505s) | Introducción del concepto de convergencia. |
| [48:28](https://www.youtube.com/watch?v=OvFPirtl0yQ&t=2908s) | Definición formal con tres cuantificadores. |
| [50:33](https://www.youtube.com/watch?v=OvFPirtl0yQ&t=3033s) | Distancia, valor absoluto e intervalo $[L-\varepsilon,L+\varepsilon]$. |
| [58:37](https://www.youtube.com/watch?v=OvFPirtl0yQ&t=3517s) | Interpretación del índice umbral $N$ y de las vecindades. |
| [1:11:13](https://www.youtube.com/watch?v=OvFPirtl0yQ&t=4273s) | Preguntas: acercamiento, igualdad con el límite y elección de $\varepsilon$. |
| [1:18:11](https://www.youtube.com/watch?v=OvFPirtl0yQ&t=4691s) | Demostración de que $1/n\to0$ mediante propiedad arquimediana. |
| [1:25:21](https://www.youtube.com/watch?v=OvFPirtl0yQ&t=5121s) | Segunda demostración usando la función parte entera. |
| [1:31:13](https://www.youtube.com/watch?v=OvFPirtl0yQ&t=5473s) | Convergencia de las sucesiones constantes. |
| [1:33:23](https://www.youtube.com/watch?v=OvFPirtl0yQ&t=5603s) | Límite de $\sqrt{n+1}-\sqrt n$; conjugada y cota superior. |
| [1:38:15](https://www.youtube.com/watch?v=OvFPirtl0yQ&t=5895s) | Técnica de la «relajación» de desigualdades. |
| [1:45:14](https://www.youtube.com/watch?v=OvFPirtl0yQ&t=6314s) | Cierre: empleo de la propiedad arquimediana y manejo de cuantificadores. |

### Cátedra 9.2

[Grabación original](https://www.youtube.com/watch?v=fMkNJyhooZY).

| Momento | Desarrollo |
|:---|:---|
| [14:21](https://www.youtube.com/watch?v=fMkNJyhooZY&t=861s) | Motivo de esta clase especial: reelaboración de la cátedra 9.2 para resolver dificultades de comprensión. |
| [16:45](https://www.youtube.com/watch?v=fMkNJyhooZY&t=1005s) | Plan: definición de límite, unicidad y álgebra de límites. |
| [17:37](https://www.youtube.com/watch?v=fMkNJyhooZY&t=1057s) | Recuperación de la definición formal de convergencia. |
| [22:04](https://www.youtube.com/watch?v=fMkNJyhooZY&t=1324s) | Vecindades, índice umbral y rapidez de aproximación. |
| [28:57](https://www.youtube.com/watch?v=fMkNJyhooZY&t=1737s) | Teorema de unicidad del límite. |
| [31:26](https://www.youtube.com/watch?v=fMkNJyhooZY&t=1886s) | Traducción de dos hipótesis de convergencia a desigualdades cuantificadas. |
| [33:00](https://www.youtube.com/watch?v=fMkNJyhooZY&t=1980s) | Elección del mismo $\varepsilon$ y separación de los dos índices testigo. |
| [42:28](https://www.youtube.com/watch?v=fMkNJyhooZY&t=2548s) | Umbral común: máximo de los dos índices. |
| [44:21](https://www.youtube.com/watch?v=fMkNJyhooZY&t=2661s) | Desigualdad triangular e introducción de un punto intermedio. |
| [49:37](https://www.youtube.com/watch?v=fMkNJyhooZY&t=2977s) | Estimación $|L_1-L_2|\leq 2\varepsilon$. |
| [52:15](https://www.youtube.com/watch?v=fMkNJyhooZY&t=3135s) | Lectura de la estimación como cota inferior de $\mathbb R_{>0}$. |
| [57:17](https://www.youtube.com/watch?v=fMkNJyhooZY&t=3437s) | Conclusión de la unicidad. |
| [58:02](https://www.youtube.com/watch?v=fMkNJyhooZY&t=3482s) | Enunciado del álgebra de sucesiones convergentes. |
| [1:00:01](https://www.youtube.com/watch?v=fMkNJyhooZY&t=3601s) | Advertencia: el producto $n(1/n)$ no admite aplicación directa del teorema. |
| [1:02:38](https://www.youtube.com/watch?v=fMkNJyhooZY&t=3758s) | Ejercicio: si $na_n\to L$, entonces $a_n\to0$. |
| [1:05:28](https://www.youtube.com/watch?v=fMkNJyhooZY&t=3928s) | Definición de sucesión nula. |
| [1:07:49](https://www.youtube.com/watch?v=fMkNJyhooZY&t=4069s) | Definición de sucesión acotada y elección $M\geq0$. |
| [1:11:43](https://www.youtube.com/watch?v=fMkNJyhooZY&t=4303s) | Enunciado de las propiedades de nulas y acotadas. |
| [1:19:41](https://www.youtube.com/watch?v=fMkNJyhooZY&t=4781s) | Continuación tras la pausa; organización de las cuatro propiedades. |
| [1:23:06](https://www.youtube.com/watch?v=fMkNJyhooZY&t=4986s) | Propiedad decisiva: nula multiplicada por acotada es nula. |
| [1:26:09](https://www.youtube.com/watch?v=fMkNJyhooZY&t=5169s) | Demostración de que la suma de dos nulas es nula. |
| [1:34:34](https://www.youtube.com/watch?v=fMkNJyhooZY&t=5674s) | Selección de $\varepsilon/2$ (u otra reducción adecuada del error). |
| [1:39:28](https://www.youtube.com/watch?v=fMkNJyhooZY&t=5968s) | Esbozo de la prueba del producto de dos nulas usando $\sqrt\varepsilon$. |
| [1:41:17](https://www.youtube.com/watch?v=fMkNJyhooZY&t=6077s) | Demostración de nula por acotada: recurso a $M+1$. |
| [1:45:58](https://www.youtube.com/watch?v=fMkNJyhooZY&t=6358s) | Consultas: cómo se aborda el cociente de sucesiones. |
| [1:51:24](https://www.youtube.com/watch?v=fMkNJyhooZY&t=6684s) | Convergencia hacia $1$ por la izquierda y por la derecha. |
| [1:58:11](https://www.youtube.com/watch?v=fMkNJyhooZY&t=7091s) | Discusión de la forma $0/0$ con distintos comportamientos. |
| [2:02:32](https://www.youtube.com/watch?v=fMkNJyhooZY&t=7352s) | Cierre: reciprocidad y acotación; cuestiones que continuarán en otras clases. |

### Cátedra 10.1

[Grabación original](https://www.youtube.com/watch?v=uWNFjH-GDEA).

| Núcleo | Fundamento y procedencia |
|:---|:---|
| Continuidad desde la cátedra 9.2 | Definición de convergencia, álgebra de límites y sucesiones nulas y acotadas; notas previas de IC2021. |
| Límites y orden | Apartado 10.1 del resumen MA1001 (2024); prueba reconstruida editorialmente. |
| Teorema del sándwich | Apartado 10.1 del resumen MA1001 (2024); prueba reconstruida editorialmente. |
| Desigualdad de Bernoulli | Apartado 10.2 del resumen MA1001 (2024); ampliación docente complementaria. |
| Sucesiones geométricas y raíces | Apartado 10.2 del resumen MA1001 (2024); ejemplos y demostraciones editoriales. |
| Bernoulli de segundo orden, $\sqrt[n]{n}$ | Apartado 10.3 del resumen MA1001 (2024); ampliación separada para profundizar. |
| Ejercicios de estudio y comprobación | Elaboración editorial original, al final de las notas. |

La **cronología interna del video, las referencias a la pizarra y las preguntas reales del alumnado** continúan pendientes de cotejo. El índice anterior permite estudiar con continuidad el núcleo matemático del capítulo; su secuencia responde al documento complementario de 2024 y a una decisión editorial, no a una transcripción confirmada de la sesión de 2021.

### Cátedra 10.2

[Grabación original](https://www.youtube.com/watch?v=CQgnnA48rEA).

| Momento | Núcleo del razonamiento |
|:---|:---|
| [13:09](https://www.youtube.com/watch?v=CQgnnA48rEA&t=789s) | Inicio sustantivo, cierre de la unidad y plan: $q^n$, raíces enésimas, último teorema. |
| [14:11](https://www.youtube.com/watch?v=CQgnnA48rEA&t=851s) | La sucesión geométrica; casos $q=0$, $q=1$ y $q=-1$. |
| [16:19](https://www.youtube.com/watch?v=CQgnnA48rEA&t=979s) | Caso $0<q<1$, transformación $q=(1+h)^{-1}$, con $h>0$. |
| [20:00](https://www.youtube.com/watch?v=CQgnnA48rEA&t=1200s) | Bernoulli de primer orden y acotación mediante el sándwich. |
| [26:53](https://www.youtube.com/watch?v=CQgnnA48rEA&t=1613s) | Comparación de la velocidad de convergencia a cero por cocientes. |
| [32:18](https://www.youtube.com/watch?v=CQgnnA48rEA&t=1938s) | Comparación entre $q^n$ y $1/n$: estudio de $nq^n$. |
| [35:20](https://www.youtube.com/watch?v=CQgnnA48rEA&t=2120s) | Bernoulli de segundo orden y límite de $nq^n$. |
| [39:48](https://www.youtube.com/watch?v=CQgnnA48rEA&t=2388s) | Bernoulli de tercer orden y límite de $n^2q^n$. |
| [42:55](https://www.youtube.com/watch?v=CQgnnA48rEA&t=2575s) | Generalización: $n^p q^n\to0$ para una potencia fija $p$. |
| [45:37](https://www.youtube.com/watch?v=CQgnnA48rEA&t=2737s) | Bases $-1<q<0$ y alternancia de signos. |
| [48:26](https://www.youtube.com/watch?v=CQgnnA48rEA&t=2906s) | Bases $|q|>1$, recíprocos y falta de acotación. |
| [55:03](https://www.youtube.com/watch?v=CQgnnA48rEA&t=3303s) | Raíces enésimas de una constante positiva; necesidad de demostrar su existencia. |
| [1:00:18](https://www.youtube.com/watch?v=CQgnnA48rEA&t=3618s) | Construcción de $A=\{x>0:x^p<q\}$ y empleo del axioma del supremo. |
| [1:10:22](https://www.youtube.com/watch?v=CQgnnA48rEA&t=4222s) | El supremo $s$: aproximaciones $s\pm1/n$ y paso al límite. |
| [1:21:05](https://www.youtube.com/watch?v=CQgnnA48rEA&t=4865s) | Límite de $\sqrt[n]{q}$ para $q>0$. |
| [1:31:45](https://www.youtube.com/watch?v=CQgnnA48rEA&t=5505s) | La sucesión $\sqrt[n]{n}$ y Bernoulli de segundo orden. |
| [1:36:34](https://www.youtube.com/watch?v=CQgnnA48rEA&t=5794s) | Ejercicio propuesto: $\sqrt[n]{n^2}$. |
| [1:38:38](https://www.youtube.com/watch?v=CQgnnA48rEA&t=5918s) | Enunciado, sin demostración, del teorema de sucesiones monótonas acotadas. |
| [1:43:42](https://www.youtube.com/watch?v=CQgnnA48rEA&t=6222s) | Consultas: por qué funcionan $s\pm1/n$ y relación con las antiguas pruebas $\varepsilon$. |
| [1:52:20](https://www.youtube.com/watch?v=CQgnnA48rEA&t=6740s) | Cierre y enlace con la semana 11. |

### Cátedra 11.1

[Grabación original](https://www.youtube.com/watch?v=K-9dw9jW2BE).

| Momento | Núcleo de la clase |
|:---|:---|
| [12:34](https://www.youtube.com/watch?v=K-9dw9jW2BE&t=754s) | Inicio sustantivo de la semana 11; la exponencial como objeto construido mediante sucesiones. |
| [14:28](https://www.youtube.com/watch?v=K-9dw9jW2BE&t=868s) | La sucesión $(1+x/n)^n$ y la unicidad de su posible límite. |
| [15:35](https://www.youtube.com/watch?v=K-9dw9jW2BE&t=935s) | Error de cálculo: separar el límite de la base del exponente variable. |
| [18:28](https://www.youtube.com/watch?v=K-9dw9jW2BE&t=1108s) | Comparación con las potencias de $(a+x/n)$ para $a<1$. |
| [20:02](https://www.youtube.com/watch?v=K-9dw9jW2BE&t=1202s) | Demostración correcta por acotación y sándwich para $a=1/2$. |
| [22:18](https://www.youtube.com/watch?v=K-9dw9jW2BE&t=1338s) | Razón por la que esa acotación resulta insuficiente en la base límite $1$. |
| [29:35](https://www.youtube.com/watch?v=K-9dw9jW2BE&t=1775s) | Dominio de definición de la exponencial: convergencia de la sucesión para cada $x$. |
| [31:10](https://www.youtube.com/watch?v=K-9dw9jW2BE&t=1870s) | Teorema de convergencia para todo $x\in\mathbb R$; estrategia de monotonía y acotación. |
| [33:29](https://www.youtube.com/watch?v=K-9dw9jW2BE&t=2009s) | Positividad eventual de $1+x/n$ y condición $n>-x$. |
| [37:01](https://www.youtube.com/watch?v=K-9dw9jW2BE&t=2221s) | Monotonía: cociente $E_{n+1}(x)/E_n(x)$ y Bernoulli I. |
| [57:01](https://www.youtube.com/watch?v=K-9dw9jW2BE&t=3421s) | Búsqueda de cota superior; demostración de Bernoulli III. |
| [1:06:11](https://www.youtube.com/watch?v=K-9dw9jW2BE&t=3971s) | Aplicación $E_n(x)\le (1-x)^{-1}$ cuando $x<1$. |
| [1:14:37](https://www.youtube.com/watch?v=K-9dw9jW2BE&t=4477s) | Extensión a $x\ge1$ mediante un entero $m>x$. |
| [1:22:38](https://www.youtube.com/watch?v=K-9dw9jW2BE&t=4958s) | Convergencia y cotas finales de $\exp(x)$. |
| [1:23:29](https://www.youtube.com/watch?v=K-9dw9jW2BE&t=5009s) | Número $e=\exp(1)$ y aproximaciones por dos sucesiones. |
| [1:28:48](https://www.youtube.com/watch?v=K-9dw9jW2BE&t=5328s) | Igualdad fundamental $\exp(x+y)=\exp(x)\exp(y)$. |
| [1:30:09](https://www.youtube.com/watch?v=K-9dw9jW2BE&t=5409s) | Lema: si $h_n\to0$ y $nh_n\to0$, entonces $(1+h_n)^n\to1$. |
| [1:35:52](https://www.youtube.com/watch?v=K-9dw9jW2BE&t=5752s) | Demostración de la igualdad exponencial usando el lema. |
| [1:44:25](https://www.youtube.com/watch?v=K-9dw9jW2BE&t=6265s) | Preguntas: límite, cotas, monotonía y valor de $e$. |
| [1:49:31](https://www.youtube.com/watch?v=K-9dw9jW2BE&t=6571s) | Aclaración de terminología: monotonía no estricta y funciones constantes. |

### Cátedra 11.2

[Grabación original](https://www.youtube.com/watch?v=9PVAjc3s-Mg).

| Momento | Contenido de la sesión |
|:---|:---|
| [10:45](https://www.youtube.com/watch?v=9PVAjc3s-Mg&t=645s) | Bienvenida y programa: corolarios, desigualdad fundamental y logaritmo. |
| [12:45](https://www.youtube.com/watch?v=9PVAjc3s-Mg&t=765s) | Recuperación de la igualdad fundamental de la exponencial. |
| [13:28](https://www.youtube.com/watch?v=9PVAjc3s-Mg&t=808s) | Exponencial del opuesto y de una diferencia. |
| [16:01](https://www.youtube.com/watch?v=9PVAjc3s-Mg&t=961s) | Exponencial de múltiplos enteros; inducción propuesta. |
| [20:20](https://www.youtube.com/watch?v=9PVAjc3s-Mg&t=1220s) | Fracciones $1/n$ y raíces enésimas de una exponencial. |
| [23:47](https://www.youtube.com/watch?v=9PVAjc3s-Mg&t=1427s) | Potencias racionales de base positiva y representación de la fracción. |
| [28:31](https://www.youtube.com/watch?v=9PVAjc3s-Mg&t=1711s) | Identidad $\exp(qx)=(\exp x)^q$ para $q\in\mathbb Q$. |
| [31:19](https://www.youtube.com/watch?v=9PVAjc3s-Mg&t=1879s) | Problema de los exponentes irracionales; anticipo del logaritmo. |
| [34:56](https://www.youtube.com/watch?v=9PVAjc3s-Mg&t=2096s) | Desigualdad fundamental de la exponencial. |
| [38:08](https://www.youtube.com/watch?v=9PVAjc3s-Mg&t=2288s) | Signo de $x$ y posición de $\exp(x)$ respecto de $1$. |
| [42:05](https://www.youtube.com/watch?v=9PVAjc3s-Mg&t=2525s) | Demostración del crecimiento estrictamente monótono. |
| [45:50](https://www.youtube.com/watch?v=9PVAjc3s-Mg&t=2750s) | Teorema: todos los reales positivos tienen preimagen exponencial. |
| [50:40](https://www.youtube.com/watch?v=9PVAjc3s-Mg&t=3040s) | Sucesiones $\exp(-n)$ y $\exp(n)$; preparación del supremo. |
| [55:03](https://www.youtube.com/watch?v=9PVAjc3s-Mg&t=3303s) | Construcción del conjunto $A=\{x:\exp(x)<y\}$. |
| [1:04:45](https://www.youtube.com/watch?v=9PVAjc3s-Mg&t=3885s) | Supremo $s$, perturbaciones $s\pm1/n$ y paso al límite. |
| [1:11:38](https://www.youtube.com/watch?v=9PVAjc3s-Mg&t=4298s) | Pausa de la sesión. |
| [1:16:56](https://www.youtube.com/watch?v=9PVAjc3s-Mg&t=4616s) | Definición del logaritmo natural como función inversa. |
| [1:19:59](https://www.youtube.com/watch?v=9PVAjc3s-Mg&t=4799s) | Producto, cociente y potencias racionales en el logaritmo. |
| [1:26:12](https://www.youtube.com/watch?v=9PVAjc3s-Mg&t=5172s) | Definición de potencia con exponente real. |
| [1:32:13](https://www.youtube.com/watch?v=9PVAjc3s-Mg&t=5533s) | Logaritmos en otras bases y fórmula de cambio de base. |
| [1:37:12](https://www.youtube.com/watch?v=9PVAjc3s-Mg&t=5832s) | Desigualdades para $\exp$ y $\ln$; cotas recíprocas. |
| [1:44:41](https://www.youtube.com/watch?v=9PVAjc3s-Mg&t=6281s) | Consulta sobre una construcción de $\ln(a)$ mediante una sucesión. |
| [1:49:30](https://www.youtube.com/watch?v=9PVAjc3s-Mg&t=6570s) | Despedida y cierre. |

### Cátedra 12.1

[Grabación original](https://www.youtube.com/watch?v=iQD_ImPaRWo).

| Tiempo | Desarrollo identificado |
|:--|:--|
| [11:31](https://www.youtube.com/watch?v=iQD_ImPaRWo&t=691s) | Apertura de la semana 12 y programa: límites de funciones antes de derivadas. |
| [14:52](https://www.youtube.com/watch?v=iQD_ImPaRWo&t=892s) | Idea generadora: comportamiento alrededor de $\bar x$ y valor $f(\bar x)$. |
| [22:45](https://www.youtube.com/watch?v=iQD_ImPaRWo&t=1365s) | Parte entera con dominio $[0,1]$: límite en el extremo. |
| [26:38](https://www.youtube.com/watch?v=iQD_ImPaRWo&t=1598s) | Cocientes con punto excluido: $(x-1)/(x-1)$ y $(x^2-1)/(x-1)$. |
| [31:45](https://www.youtube.com/watch?v=iQD_ImPaRWo&t=1905s) | Formalización mediante sucesiones: tres requisitos. |
| [39:19](https://www.youtube.com/watch?v=iQD_ImPaRWo&t=2359s) | Necesidad del punto de acumulación; intervalos y extremos. |
| [47:21](https://www.youtube.com/watch?v=iQD_ImPaRWo&t=2841s) | Punto aislado y dominio singleton. |
| [51:57](https://www.youtube.com/watch?v=iQD_ImPaRWo&t=3117s) | Definición secuencial de punto de acumulación. |
| [58:36](https://www.youtube.com/watch?v=iQD_ImPaRWo&t=3516s) | Pausa (se reanuda cerca de 1:04). |
| [1:04:08](https://www.youtube.com/watch?v=iQD_ImPaRWo&t=3848s) | Repaso de $[0,1]$, $(0,1)$ y dominios con huecos. |
| [1:09:06](https://www.youtube.com/watch?v=iQD_ImPaRWo&t=4146s) | Conjuntos finitos y $\mathbb N$: ausencia de puntos de acumulación reales. |
| [1:16:55](https://www.youtube.com/watch?v=iQD_ImPaRWo&t=4615s) | Racionales, irracionales y densidad en $\mathbb R$. |
| [1:26:15](https://www.youtube.com/watch?v=iQD_ImPaRWo&t=5175s) | Definición secuencial del límite de una función. |
| [1:34:43](https://www.youtube.com/watch?v=iQD_ImPaRWo&t=5683s) | Ejemplos: función identidad y función $2x$. |
| [1:39:11](https://www.youtube.com/watch?v=iQD_ImPaRWo&t=5951s) | Cocientes con denominador $1-x$; límite $-1$ y $-2$. |
| [1:43:18](https://www.youtube.com/watch?v=iQD_ImPaRWo&t=6198s) | Función por ramas racionales/irracionales; límite en $x=1$. |
| [1:49:51](https://www.youtube.com/watch?v=iQD_ImPaRWo&t=6591s) | Ejercicios propuestos: límites en $0$ y $1/2$; teoremas postergados. |
| [1:51:33](https://www.youtube.com/watch?v=iQD_ImPaRWo&t=6693s) | Preguntas finales: dominios, índices y aproximaciones por ramas. |

### Cátedra 12.2

[Grabación original](https://www.youtube.com/watch?v=pn5sq_kgAB0).

| Minuto verificado | Desarrollo |
|:--|:--|
| [00:01](https://www.youtube.com/watch?v=pn5sq_kgAB0&t=1s)–[03:15](https://www.youtube.com/watch?v=pn5sq_kgAB0&t=195s) | Apertura y plan: teoremas, exponencial y trigonometría. |
| [03:20](https://www.youtube.com/watch?v=pn5sq_kgAB0&t=200s) | Revisión de la definición secuencial de límite. |
| [06:41](https://www.youtube.com/watch?v=pn5sq_kgAB0&t=401s) | Unicidad del límite y criterio de dos sucesiones testigo. |
| [13:01](https://www.youtube.com/watch?v=pn5sq_kgAB0&t=781s) | Álgebra de límites; hipótesis para cocientes. |
| [15:55](https://www.youtube.com/watch?v=pn5sq_kgAB0&t=955s) | Teorema del sándwich y entorno perforado. |
| [22:41](https://www.youtube.com/watch?v=pn5sq_kgAB0&t=1361s) | Identidad, potencias, polinomios y funciones racionales. |
| [27:13](https://www.youtube.com/watch?v=pn5sq_kgAB0&t=1633s) | Un hueco algebraico frente a una asíntota vertical. |
| [32:00](https://www.youtube.com/watch?v=pn5sq_kgAB0&t=1920s) | Cotas de la exponencial y $\lim_{x\to0}e^x$. |
| [40:00](https://www.youtube.com/watch?v=pn5sq_kgAB0&t=2400s) | El límite fundamental $(e^x-1)/x$. |
| [55:45](https://www.youtube.com/watch?v=pn5sq_kgAB0&t=3345s) | Ejercicio propuesto: $\lim_{x\to1}\ln x$. |
| [56:19](https://www.youtube.com/watch?v=pn5sq_kgAB0&t=3379s)–[1:01:51](https://www.youtube.com/watch?v=pn5sq_kgAB0&t=3711s) | Pausa. |
| [1:02:17](https://www.youtube.com/watch?v=pn5sq_kgAB0&t=3737s) | Inicio de los límites trigonométricos. |
| [1:06:04](https://www.youtube.com/watch?v=pn5sq_kgAB0&t=3964s)–[1:17:46](https://www.youtube.com/watch?v=pn5sq_kgAB0&t=4666s) | Desigualdad entre seno, cuerda, arco y tangente. |
| [1:17:51](https://www.youtube.com/watch?v=pn5sq_kgAB0&t=4671s) | $\lim\sin x$, $\lim\cos x$, $\lim\sin x/x$. |
| [1:23:43](https://www.youtube.com/watch?v=pn5sq_kgAB0&t=5023s) | $\lim_{x\to0}(1-\cos x)/x^2=1/2$. |
| [1:25:47](https://www.youtube.com/watch?v=pn5sq_kgAB0&t=5147s)–[1:31:42](https://www.youtube.com/watch?v=pn5sq_kgAB0&t=5502s) | Teorema del límite de una composición y tarea de demostración. |
| [1:32:19](https://www.youtube.com/watch?v=pn5sq_kgAB0&t=5539s)–[1:33:37](https://www.youtube.com/watch?v=pn5sq_kgAB0&t=5617s) | Consulta final: $e^x=\exp(x)$; cierre. |

### Cátedra 13.1

[Grabación original](https://www.youtube.com/watch?v=R2rghIx2vRc).

| Marca temporal verificada | Tema | 
|:--|:--|
| [10:43](https://www.youtube.com/watch?v=R2rghIx2vRc&t=643s)–[12:58](https://www.youtube.com/watch?v=R2rghIx2vRc&t=778s) | Sala de espera, inicio de la clase 13.1 y programa. |
| [13:03](https://www.youtube.com/watch?v=R2rghIx2vRc&t=783s) | Presentación del teorema de composición. |
| [14:11](https://www.youtube.com/watch?v=R2rghIx2vRc&t=851s) | Demostración secuencial y dominio de la composición. |
| [19:30](https://www.youtube.com/watch?v=R2rghIx2vRc&t=1170s)–[21:44](https://www.youtube.com/watch?v=R2rghIx2vRc&t=1304s) | La hipótesis adicional $g(x)\ne b$ cerca del punto. |
| [22:08](https://www.youtube.com/watch?v=R2rghIx2vRc&t=1328s) | Protocolo de cálculo: función interior, condición adicional, función exterior. |
| [26:55](https://www.youtube.com/watch?v=R2rghIx2vRc&t=1615s) | Límite general de $e^x$ mediante $u=x-a$. |
| [34:41](https://www.youtube.com/watch?v=R2rghIx2vRc&t=2081s) | Cociente $(e^x-e^a)/(x-a)$. |
| [41:00](https://www.youtube.com/watch?v=R2rghIx2vRc&t=2460s) | Límite general de $\sin x$. |
| [44:54](https://www.youtube.com/watch?v=R2rghIx2vRc&t=2694s) | Cociente incremental del seno. |
| [56:00](https://www.youtube.com/watch?v=R2rghIx2vRc&t=3360s) | Se proponen el cociente incremental del coseno y el de la tangente. |
| [59:19](https://www.youtube.com/watch?v=R2rghIx2vRc&t=3559s) | Ejemplo del cociente incremental de $x^2$. |
| [1:01:03](https://www.youtube.com/watch?v=R2rghIx2vRc&t=3663s)–[1:06:22](https://www.youtube.com/watch?v=R2rghIx2vRc&t=3982s) | Pausa y regreso. |
| [1:07:07](https://www.youtube.com/watch?v=R2rghIx2vRc&t=4027s) | $\lim_{x\to0}\sin(ax)/x$: distinción del caso $a=0$. |
| [1:13:04](https://www.youtube.com/watch?v=R2rghIx2vRc&t=4384s) | $\lim_{x\to0}\sin(ax)/\sin(bx)$ con $b\ne0$. |
| [1:15:03](https://www.youtube.com/watch?v=R2rghIx2vRc&t=4503s) | Ejercicio compuesto con seno, coseno y exponencial; fórmula oral parcialmente ambigua. |
| [1:18:02](https://www.youtube.com/watch?v=R2rghIx2vRc&t=4682s) | $\lim_{x\to1}\ln x/(x-1)$. |
| [1:22:01](https://www.youtube.com/watch?v=R2rghIx2vRc&t=4921s) | Caracterización épsilon-delta. |
| [1:30:32](https://www.youtube.com/watch?v=R2rghIx2vRc&t=5432s) | Condiciones sobre el dominio y punto de acumulación. |
| [1:33:27](https://www.youtube.com/watch?v=R2rghIx2vRc&t=5607s) | Ejemplos $\sqrt{x}$ en $-8$ y parte entera en $1$. |
| [1:37:00](https://www.youtube.com/watch?v=R2rghIx2vRc&t=5820s) | Cuantificadores sobre conjuntos vacíos. |
| [1:42:32](https://www.youtube.com/watch?v=R2rghIx2vRc&t=6152s)–[1:45:08](https://www.youtube.com/watch?v=R2rghIx2vRc&t=6308s) | Anuncio de límites laterales y cierre. |

### Cátedra 13.2

[Grabación original](https://www.youtube.com/watch?v=t3bX0a0x3kU).

| Marca temporal | Núcleo de la exposición |
|:--|:--|
| [0:02](https://www.youtube.com/watch?v=t3bX0a0x3kU&t=2s)–[1:06](https://www.youtube.com/watch?v=t3bX0a0x3kU&t=66s) | Pruebas de conexión y apertura. |
| [1:07](https://www.youtube.com/watch?v=t3bX0a0x3kU&t=67s) | Inicio, programa y anuncio de las 25 definiciones. |
| [2:28](https://www.youtube.com/watch?v=t3bX0a0x3kU&t=148s) | Recordatorio de la caracterización $\varepsilon$–$\delta$. |
| [5:09](https://www.youtube.com/watch?v=t3bX0a0x3kU&t=309s) | Intersección con el dominio y función del punto de acumulación. |
| [8:09](https://www.youtube.com/watch?v=t3bX0a0x3kU&t=489s) | Primer cambio: límite por la derecha. |
| [13:30](https://www.youtube.com/watch?v=t3bX0a0x3kU&t=810s) | Segundo cambio: límite por la izquierda. |
| [16:20](https://www.youtube.com/watch?v=t3bX0a0x3kU&t=980s)–[20:37](https://www.youtube.com/watch?v=t3bX0a0x3kU&t=1237s) | Teorema de coincidencia de límites laterales y sus hipótesis de dominio. |
| [22:41](https://www.youtube.com/watch?v=t3bX0a0x3kU&t=1361s) | Parte entera alrededor de $1$. |
| [25:46](https://www.youtube.com/watch?v=t3bX0a0x3kU&t=1546s) | Raíz cuadrada alrededor de $0$: un extremo del dominio. |
| [34:20](https://www.youtube.com/watch?v=t3bX0a0x3kU&t=2060s) | Oscilación de $\sin(1/x)$ y sucesiones de testigos. |
| [41:07](https://www.youtube.com/watch?v=t3bX0a0x3kU&t=2467s) | Cociente $|x|/x$ y sus dos valores laterales. |
| [46:33](https://www.youtube.com/watch?v=t3bX0a0x3kU&t=2793s) | Límites hacia $+\infty$ y asíntota horizontal. |
| [52:21](https://www.youtube.com/watch?v=t3bX0a0x3kU&t=3141s) | Límite hacia $-\infty$ y uso de un umbral negativo. |
| [58:14](https://www.youtube.com/watch?v=t3bX0a0x3kU&t=3494s)–[1:03:23](https://www.youtube.com/watch?v=t3bX0a0x3kU&t=3803s) | Pausa y regreso. |
| [1:03:43](https://www.youtube.com/watch?v=t3bX0a0x3kU&t=3823s) | Matriz de cinco modalidades de entrada. |
| [1:07:40](https://www.youtube.com/watch?v=t3bX0a0x3kU&t=4060s) | Cinco modalidades de salida; 25 combinaciones. |
| [1:11:05](https://www.youtube.com/watch?v=t3bX0a0x3kU&t=4265s) | Ejemplo $x\to a^-$ con salida aproximándose a $L$ desde arriba. |
| [1:16:43](https://www.youtube.com/watch?v=t3bX0a0x3kU&t=4603s) | Ejemplo $x\to-\infty$ con salida hacia $+\infty$. |
| [1:19:25](https://www.youtube.com/watch?v=t3bX0a0x3kU&t=4765s) | Asíntotas verticales y límites infinitos laterales. |
| [1:22:22](https://www.youtube.com/watch?v=t3bX0a0x3kU&t=4942s) | Álgebra, formas indeterminadas, composición y sándwich ampliados. |
| [1:29:29](https://www.youtube.com/watch?v=t3bX0a0x3kU&t=5369s) | Demostración de $1/x\to0$ desde arriba cuando $x\to+\infty$. |
| [1:35:43](https://www.youtube.com/watch?v=t3bX0a0x3kU&t=5743s) | Demostración de $e^x\to0$ desde arriba cuando $x\to-\infty$. |
| [1:42:26](https://www.youtube.com/watch?v=t3bX0a0x3kU&t=6146s)–[1:45:46](https://www.youtube.com/watch?v=t3bX0a0x3kU&t=6346s) | Cierre de la unidad, control 3 y anuncio de derivadas. |

### Cátedra 14.1

[Grabación original](https://www.youtube.com/watch?v=Fc5tth2MNUc).

| Tiempo | Desarrollo |
|---|---|
| [13:26](https://www.youtube.com/watch?v=Fc5tth2MNUc&t=806s) | Introducción de las derivadas |
| [16:34](https://www.youtube.com/watch?v=Fc5tth2MNUc&t=994s) | Pendientes y secantes |
| [24:43](https://www.youtube.com/watch?v=Fc5tth2MNUc&t=1483s) | Tangente como límite |
| [31:10](https://www.youtube.com/watch?v=Fc5tth2MNUc&t=1870s) | Experimentos con curvas y pendientes |
| [46:40](https://www.youtube.com/watch?v=Fc5tth2MNUc&t=2800s) | Punto interior y dominio |
| [51:40](https://www.youtube.com/watch?v=Fc5tth2MNUc&t=3100s) | Intervalos y puntos extremos |
| [1:07:05](https://www.youtube.com/watch?v=Fc5tth2MNUc&t=4025s) | Conjuntos discretos |
| [1:20:15](https://www.youtube.com/watch?v=Fc5tth2MNUc&t=4815s) | Definición formal |
| [1:22:10](https://www.youtube.com/watch?v=Fc5tth2MNUc&t=4930s) | Exponencial y trigonometría |
| [1:26:10](https://www.youtube.com/watch?v=Fc5tth2MNUc&t=5170s) | Potencias enteras |
| [1:34:10](https://www.youtube.com/watch?v=Fc5tth2MNUc&t=5650s) | Raíces y potencias fraccionarias |
| [1:44:51](https://www.youtube.com/watch?v=Fc5tth2MNUc&t=6291s) | Cierre y consultas |

### Cátedra 14.2

[Grabación original](https://www.youtube.com/watch?v=eXthvzh8_9Y).

| Momento | Tema y procedencia |
|:--|:--|
| [14:11](https://www.youtube.com/watch?v=eXthvzh8_9Y&t=851s) | Inicio accesible y pruebas de audio |
| [16:30](https://www.youtube.com/watch?v=eXthvzh8_9Y&t=990s) | Última clase del semestre; examen y programa |
| [17:44](https://www.youtube.com/watch?v=eXthvzh8_9Y&t=1064s) | Panorama de las técnicas de derivación |
| [20:20](https://www.youtube.com/watch?v=eXthvzh8_9Y&t=1220s) | Teorema: derivabilidad implica continuidad |
| [29:55](https://www.youtube.com/watch?v=eXthvzh8_9Y&t=1795s) | Contraejemplo: valor absoluto en cero |
| [41:57](https://www.youtube.com/watch?v=eXthvzh8_9Y&t=2517s) | Álgebra de derivadas: suma y resta |
| [47:10](https://www.youtube.com/watch?v=eXthvzh8_9Y&t=2830s) | Derivada del producto y el «ni quita ni pone» |
| [56:35](https://www.youtube.com/watch?v=eXthvzh8_9Y&t=3395s) | Producto de tres o más factores |
| [1:00:20](https://www.youtube.com/watch?v=eXthvzh8_9Y&t=3620s) | Derivada del recíproco |
| [1:05:07](https://www.youtube.com/watch?v=eXthvzh8_9Y&t=3907s) | Regla del cociente |
| [1:09:20](https://www.youtube.com/watch?v=eXthvzh8_9Y&t=4160s) | Pausa de la clase |
| [1:15:20](https://www.youtube.com/watch?v=eXthvzh8_9Y&t=4520s) | Potencias con exponentes negativos |
| [1:18:40](https://www.youtube.com/watch?v=eXthvzh8_9Y&t=4720s) | Derivada de la tangente trigonométrica |
| [1:59:25](https://www.youtube.com/watch?v=eXthvzh8_9Y&t=7165s) | Despedida y continuidad del curso el semestre siguiente |

La transcripción automática puede contener errores de nomenclatura y signos: los pasajes algebraicos se presentan en su forma matemáticamente consistente. Las secciones de ampliación incluyen demostraciones completas y ejercicios nuevos, sin atribuirlos al profesor.

## Material complementario no fusionado {.unnumbered}

Los siguientes materiales se consultan en el proyecto como apoyos con procedencia independiente. Su lectura es opcional; no forman parte de la secuencia de veintiocho cátedras del primer semestre de IC2021:

- **Función logaritmo** (grabación publicada en 2018), complemento del capítulo sobre exponencial y logaritmo: <https://www.youtube.com/watch?v=1y-RblVMKXM>.
- **Límites exponenciales** (grabación publicada en 2018), complemento de los capítulos de límites de sucesiones y funciones: <https://www.youtube.com/watch?v=LW1Og2jyQCM>.
- **Sesiones de ejercicios sobre supremo y sucesiones** (materiales de apoyo IC2022), para consolidar los capítulos de completitud y convergencia.
- **Sesión complementaria de la semana 11** (registro S04), para profundizar en propiedades de exponenciales y logaritmos.

## Criterios de esta edición {.unnumbered}

1. **Cobertura.** Los capítulos están basados en los maestros de las cátedras 1.1 a 14.2, con procedencia identificada. Los itinerarios cronológicos se conservan en este apéndice.
2. **Intervención.** Se han omitido mapas de sesión, apartados administrativos y recapitulaciones duplicadas; se conservan los argumentos, las soluciones y las figuras pertinentes. Los encabezados y la organización se han normalizado en torno a temas.
3. **Fidelidad.** Las reconstrucciones originales provienen de grabaciones y transcripciones automáticas con incertidumbres ya documentadas. No se atribuyen al docente demostraciones escritas exclusivamente en las ampliaciones editoriales.
4. **Calidad matemática.** Los resultados reutilizados y las condiciones de aplicación se conservan; no se declara una auditoría matemática completa de cada ejercicio de las 28 notas originales.
5. **Reproducción.** La fuente Markdown y la compilación XeLaTeX se adjuntan con todas las figuras en escala de grises y un manifiesto SHA-256.

**Colofón.** Primera edición temática de estudio, 1 de noviembre de 2026. Este libro se prepara para lectura, anotación y revisión sucesiva dentro de una bóveda Markdown de Obsidian.

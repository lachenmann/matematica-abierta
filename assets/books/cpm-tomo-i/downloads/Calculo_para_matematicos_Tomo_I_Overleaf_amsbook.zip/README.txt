CÁLCULO PARA MATEMÁTICOS — TOMO I
Edición revisada de 16 de octubre de 2026 · A. Peña · Matemática Abierta

OVERLEAF
Cargue este ZIP como proyecto. Use pdfLaTeX con TeX Live 2025 o posterior.
main.tex: A4 para lectura digital.
main-carta.tex: carta para impresión.
Ambos documentos se han compilado en el entorno de producción.

FUENTES Y CONTENIDO
Veinte capítulos completos; 800 ejercicios y 800 soluciones; 80 figuras.
chapters/ conserva el LaTeX editable; markdown/ contiene la adaptación
identificada de las fuentes. source-manifest.json registra las huellas
del Markdown canónico de Obsidian/Drive y la revisión R05.

El canon editable sigue siendo Markdown. El LaTeX es un derivado.
Las soluciones son visibles en el PDF. Los IDs se conservan como destinos
internos y no se imprimen como rótulos de ejercicios.

COMPOSICIÓN
Clase amsbook, Latin Modern 11 pt, márgenes 28/28/27/29 mm.
Las 65 fórmulas anchas registradas en layout-transforms.json se reparten
en líneas sin cambiar sus símbolos; la reducción residual se limita al
90 % mediante control de compilación. La tabla de bisección utiliza
fracciones apiladas y conserva todos sus valores. Los marcadores tienen
alternativas textuales legibles para los títulos con símbolos.

COMPILACIÓN LOCAL
latexmk -pdf main.tex
latexmk -pdf main-carta.tex

LICENCIA
GNU Free Documentation License, versión 1.3 o posterior.
El texto completo se incluye en COPYING.FDL.
https://matematicaabierta.cl

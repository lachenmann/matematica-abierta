# Análisis real para matemáticos — Overleaf v04

A. Peña · Matemática Abierta · 16 de octubre de 2026.

Proyecto autosuficiente en AMS Book, Latin Modern de 11 puntos y XeLaTeX.

- `main.tex`: A4 para lectura digital.
- `main-carta.tex`: carta para impresión.

Contiene el prefacio, los 32 capítulos, el epílogo y 1.290 ejercicios con sus soluciones. Los dos archivos principales comparten el mismo texto.

Las expresiones breves se componen en línea; las fórmulas extensas, complejas o destacadas conservan su espacio propio. Se unen párrafos fragmentarios sin cambiar sus palabras o cálculos. Las figuras vectoriales se presentan completas, en la orientación que aprovecha mejor el papel, y sus leyendas se miden antes de asignar el alto disponible. Se recorta únicamente el borde blanco exterior de las imágenes; no se emplean vistas parciales ampliadas.

`chapters/` contiene el LaTeX final editable. `source/` conserva el Markdown de trazabilidad. `figure-macros.tex` controla el encuadre conjunto de cada imagen y su leyenda. `figures/` contiene las 263 figuras completas. `source-manifest.json`, `figure-layout.json`, `preservation-audit.json` y `qa-report.json` documentan la edición. El compilador es XeLaTeX, también configurado en `.latexmkrc`.

La autoría y licencia del libro se conservan. Esta versión corregida se entrega para revisión del autor.

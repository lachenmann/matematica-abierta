---
title: "MA-PDF v1.0 — Protocolo de edición PDF de Matemática Abierta"
document-type: editorial-protocol
protocol-key: MA-PDF
version: "1.0"
status: ACTIVE
date-created: 2026-10-14
effective-from: 2026-10-14
adoption: "Instrucción expresa del autor: establecer desde ahora un protocolo de PDF basado en Cálculo para matemáticos."
canonical-authoring: "Obsidian Markdown crudo sincronizado con Drive"
reference-project: "Cálculo para matemáticos, Tomo I, edición amsbook"
scope: "Nuevas ediciones y recompilaciones PDF de libros y tratados de Matemática Abierta, respetando las normas particulares de cada obra"
related-protocols:
  - MA_PED_v1.0
  - MA_STYLE_v1.8
  - MA-NOT_v1.0
  - MA_FIG_NUMERACION_ANCLAS_PARA_MATEMATICOS_v1.0
  - MA_CONVERSACION_A_LIBRO_PROTOCOLO_CANONICO_v3.0
tags:
  - matematica-abierta
  - pdf
  - protocolo
  - edicion
---

# MA-PDF v1.0 — Protocolo de edición PDF de Matemática Abierta

## 1. Norma vigente

Los PDF de Matemática Abierta seguirán la base editorial de *Cálculo para matemáticos*: composición matemática con `amsbook`, tipografía Latin Modern de 11 puntos, caja de lectura estable, jerarquía de capítulos y secciones, numeración coherente, figuras con leyendas y navegación interna. Esta norma rige desde el 14 de octubre de 2026. Las instrucciones expresas del autor y las convenciones particulares de una obra prevalecen cuando exista una diferencia documentada.

El PDF debe permitir leer y estudiar una obra completa. La conversión conserva la prosa, las hipótesis, los cuantificadores, los cálculos y las demostraciones. El cambio de soporte no autoriza resumir, reescribir o suprimir contenido para reducir páginas.

Una obra cuya edición prevé HTML y PDF no se declara terminada por el solo cierre de la web. El cierre exige generar, verificar y guardar todos los formatos previstos, salvo una instrucción expresa que limite la entrega a un soporte concreto.

El protocolo complementa las normas de voz editorial, pedagogía, notación y figuras. En un tratado formal conserva sus restricciones propias; no impone ilustraciones ni recursos que ese proyecto excluya.

## 2. Fuente canónica y cadena de producción

La fuente editable continúa siendo el Markdown crudo de la bóveda de Obsidian sincronizada mediante Drive. Google Docs queda prohibido como intermediario. El LaTeX, el HTML, el PDF y el EPUB son derivados de una misma fuente identificada.

Antes de compilar se recupera la versión canónica vigente y se registra su identidad y huella. Si se utiliza el repositorio de publicación, se acredita su correspondencia con el canon, incluidos los cambios de enlaces y rutas necesarios para ese soporte. Se congela una instantánea para que una edición no mezcle capítulos de fechas o estados diferentes.

Quarto es el motor editorial ordinario y el perfil LaTeX implementa esta norma. Una compilación directa con Pandoc y LaTeX debe utilizar el mismo perfil y dejar registrada la equivalencia de la transformación. Los ajustes de composición se realizan en filtros, plantillas y configuración versionados; las correcciones de contenido vuelven primero al Markdown canónico y después se regeneran todos los formatos afectados.

La generación, compilación, comprobación y entrega se ejecutan en el entorno de trabajo disponible. No se traslada al autor la obligación de instalar programas, ejecutar comandos o compilar manualmente.

## 3. Perfil tipográfico de la colección

| Elemento | Norma |
|---|---|
| Clase de documento | `amsbook`, 11 puntos, `oneside` como edición digital ordinaria |
| Perfil de impresión | Carta, 215,9 × 279,4 mm, `letterpaper` |
| Perfil de lectura digital | A4, 210 × 297 mm, `a4paper`, con la misma familia y estructura |
| Márgenes | Izquierdo y derecho: 28 mm; superior: 27 mm; inferior: 29 mm |
| Texto | Latin Modern Roman; cursivas y negritas de la misma familia |
| Matemáticas | Familia matemática compatible con Latin Modern y AMS |
| Párrafos | Sangría ordinaria de 1,2 em; separación de 2 puntos, respetando el comportamiento de `amsbook` tras los títulos |
| Español | Configuración española, signos y tildes completos; punto decimal preservado donde lo exija la notación de la obra |
| Microtipografía | `microtype`, con partición de palabras compatible con el español |
| Índice | Capítulos y secciones, profundidad 1 en LaTeX, salvo decisión local expresa |
| Enlaces | Activos y discretos, `hidelinks`; sin recuadros visibles |
| Encabezados | Título breve de la obra a la izquierda; tomo o parte a la derecha, cuando corresponda |
| Folio | Centrado en el pie; regla de encabezado de 0,3 puntos; altura de encabezado de 14 puntos o la necesaria para evitar colisiones |
| Diseño | Sobrio, legible en pantalla e impresión; jerarquía tipográfica sin recursos decorativos que compitan con la matemática |

**Carta se utiliza para impresión y A4 para lectura digital**, según la decisión expresa del autor. Cada archivo identifica su uso; los dos formatos mantienen la misma arquitectura y familia tipográfica, y se componen por separado. La paginación se verifica en cada perfil. Una edición de impresión a doble cara exige un perfil propio de encuadernación y una nueva revisión de márgenes y aperturas. La edición digital conserva enlaces, marcadores y selección de texto funcionales; la edición de impresión comprueba además márgenes, contraste y legibilidad en papel.

El motor ordinario del perfil de referencia es pdfLaTeX. LuaLaTeX o XeLaTeX pueden utilizarse cuando una necesidad de cobertura o compatibilidad lo requiera, manteniendo la familia, la caja y el resultado visual del perfil. La sustitución de tipografía se registra y se revisa; no se cambia silenciosamente la familia por conveniencia del entorno.

## 4. Portada, créditos y preliminares

La portada conserva el título y subtítulo aprobados, el tomo o parte, el nombre del autor, Matemática Abierta, la identificación real de la edición y el sitio de la colección. El nombre del autor y el de la colección ocupan sus funciones respectivas. La marca editorial no reemplaza la atribución autoral.

La página de créditos identifica la edición, la licencia aplicable y los datos editoriales verificados. La fecha visible corresponde a la edición efectivamente entregada; no se hereda sin cotejo una fecha de una plantilla anterior. El número de capítulos, ejercicios y soluciones se obtiene del manifiesto de esa obra, nunca de las cifras del libro usado como modelo.

Los preliminares siguen el orden aprobado de cada obra: portada, créditos, dedicatoria o epígrafes si existen, prefacio, convenciones e índice. La posición concreta del índice respeta la arquitectura editorial del proyecto. Los preliminares pueden llevar numeración romana y el cuerpo numeración arábiga; ambas deben coincidir con las etiquetas de página del visor.

La licencia se proporciona en forma legible y completa dentro de la entrega según la licencia de la obra. Un enlace de consulta acompaña esa información. El PDF no incorpora estados de trabajo, IDs de tareas, comentarios del asistente, advertencias del proceso de conversión ni registros de auditoría dentro de la exposición.

## 5. Capítulos, resultados y navegación

Se conservan el orden, los títulos y los límites de los capítulos del canon. Un capítulo 0 mantiene su número; no se desplaza a 1 por el contador predeterminado de LaTeX. Se mantienen las numeraciones aprobadas de secciones, resultados, ejercicios y soluciones mediante una correspondencia explícita con sus identificadores.

Los entornos de definición, teorema, lema, proposición, corolario y ejemplo usan la base AMS. La forma concreta respeta la voz y la identificación de cada obra. Un título que ya contiene su número no recibe un segundo número automático. Las demostraciones y sus signos de cierre se conservan sin duplicación.

El índice enlaza al destino correcto y se actualiza después de estabilizar la composición. Los marcadores del visor ofrecen capítulos y secciones. Sus títulos se leen como texto matemático inteligible; no muestran comandos como `\\mathbb`, etiquetas internas ni restos de Markdown.

Las referencias internas conducen a secciones, resultados, figuras y ejercicios presentes en el volumen. Los enlaces que salen de él se identifican y llevan al destino público estable o a la referencia bibliográfica pertinente. Se distinguen la página física del PDF, el folio impreso y el destino de navegación.

## 6. Fórmulas y símbolos

Las fórmulas se componen como matemáticas LaTeX. La cobertura incluye letras griegas, letras de doble trazo, signos de relación, flechas, primas, índices, sumas, integrales y macros específicas. El manifiesto de macros debe estar completo antes de compilar; ningún comando desconocido se elimina para conseguir una salida.

Una fórmula extensa se organiza primero mediante alineación, división en líneas o un entorno apropiado. Se respeta el orden lógico, la relación entre los miembros y el significado de los delimitadores. La reducción de escala es un recurso final: los símbolos principales no se reducen por debajo del 90 % del tamaño matemático ordinario. Ese límite no modifica los tamaños tipográficos propios de índices y subíndices. Si la fórmula sigue sin caber, se recompone su distribución y se vuelve a revisar.

Se prohíbe resolver un desborde mediante recorte, ocultación o reducción ilimitada. Los ajustes visuales nunca modifican un signo estricto, un extremo, una hipótesis, un dominio o un cuantificador. Las fórmulas dentro de tablas, títulos, notas y leyendas reciben la misma comprobación de cobertura.

El control de correspondencia compara el inventario de fórmulas y su estructura con la fuente. La extracción de texto del PDF sirve de apoyo, pero no demuestra por sí sola la integridad de una fórmula ni su legibilidad.

## 7. Figuras, tablas y notas

En los libros pedagógicos se conservan las figuras aprobadas, su orden, sus leyendas y sus identificadores estables. Se aplica una sola numeración visible por presentación. El perfil ordinario del libro combinado numera por capítulo; cuando una obra ya tenga otra convención aprobada, se preserva y se documenta. El ID canónico de una figura nunca se sustituye por su ordinal de lectura.

La leyenda no añade un segundo «Figura N» al número del entorno. Las referencias se vinculan al ancla estable. La imagen permanece cerca del pasaje que la utiliza, dentro de los límites razonables de composición. No se duplica una figura en una solución cuando el canon dispone que se enlace a la figura de la exposición.

Los gráficos se mantienen vectoriales cuando el original lo permita. Las conversiones preservan los archivos originales y sus huellas. No se crean, redibujan o modifican ilustraciones por una mera necesidad de exportación; se ajusta su colocación o conversión. Las imágenes raster se comprueban a su tamaño final, con resolución suficiente para líneas y etiquetas.

Se permite escalar conservando la proporción. Las etiquetas principales deben ser legibles a tamaño de impresión; como referencia de QA se exige al menos 8,5 puntos para textos de ejes y leyendas. Un gráfico que no cumpla requiere una colocación mayor, una distribución alternativa o una incidencia documentada. No se certifica por el hecho de que el SVG abra correctamente.

Las tablas conservan encabezados, filas, unidades y fórmulas; pueden continuarse entre páginas con encabezado repetido. Se revisan las columnas más estrechas, las notas y la relación entre datos y encabezados. Las notas pedagógicas usan cajas discretas y divisibles, como la base `cpmnote` de CPM, cuando el proyecto las contemple. Ninguna caja pierde contenido ni oculta una continuación.

## 8. Ejercicios y soluciones

La edición completa conserva todos los ejercicios y microcontroles con sus soluciones desarrolladas. Una respuesta se publica bajo su pregunta o en el solucionario previsto por la arquitectura de la obra, con correspondencia verificable en ambos sentidos.

En el PDF, una solución desplegable de la web se transforma en una solución visible y correctamente identificada. No se imprimen las instrucciones «Ver solución», las etiquetas HTML de `<details>` ni elementos de interfaz. La transformación conserva todo el cuerpo de la respuesta y su relación con cada inciso.

Puede existir una edición de lectura que conserve los enunciados y omita las respuestas. Debe identificarse inequívocamente como variante y compartir la misma instantánea del contenido con la edición completa. La supresión afecta únicamente a los bloques de respuesta previstos; no elimina pruebas de la exposición, explicaciones de un ejemplo, hipótesis ni figuras necesarias para la pregunta. La edición completa continúa siendo parte obligatoria de la entrega prevista para la obra.

Los rótulos «Demostración», «Solución» y los títulos de actividades acompañan al menos las primeras líneas de su contenido. Un corte entre el enunciado y una solución puede ser necesario; un rótulo aislado al pie de página debe corregirse. No se separa un inciso de su fórmula, ni una conclusión breve de su justificación cuando la composición pueda evitarlo sin grandes huecos.

## 9. Paginación y volumen

La caja y la tipografía se mantienen estables durante la edición. El número de páginas es una consecuencia de esa composición y del contenido aprobado. No se reduce artificialmente mediante tipos pequeños, márgenes insuficientes o eliminación de desarrollo pedagógico.

Se evitan títulos huérfanos, líneas aisladas, encabezados que colisionan, leyendas separadas de la figura, tablas recortadas y páginas vacías accidentales. Las páginas blancas intencionales de una edición de impresión se identifican en el informe y reciben el tratamiento editorial previsto.

Los volúmenes extensos pueden entregarse también por capítulos o tomos, respetando sus fronteras intelectuales. Los capítulos separados conservan la paginación del libro o adoptan una propia expresamente identificada. Después de la separación se revisan los enlaces: se mantienen los destinos internos válidos y se resuelven las referencias al resto de la obra mediante enlaces o referencias legibles. No se usa el número de página de otra variante como si perteneciera al archivo actual.

## 10. Secuencia obligatoria de producción

1. **Fijar la fuente.** Recuperar el canon actual, su estado editorial y los activos; congelar una instantánea con huellas y cuentas por capítulo.
2. **Cargar el perfil.** Registrar MA-PDF v1.0, tamaño de papel, motor, fuentes, márgenes, macros, numeración y variante de soluciones.
3. **Generar.** Transformar Markdown en LaTeX mediante el flujo versionado, conservando identificadores y correspondencias. Eliminar solamente la interfaz del soporte anterior.
4. **Compilar.** Resolver dependencias y errores en el entorno de trabajo. Repetir los pases necesarios para estabilizar índice, tablas, referencias y destinos. Una compilación incompleta o un PDF parcial no constituye entrega.
5. **Comprobar contenido.** Cotejar capítulos, ejercicios, microcontroles, respuestas, incisos, figuras, tablas y fórmulas con el manifiesto. Toda diferencia debe corresponder a una transformación editorial identificada.
6. **Comprobar composición.** Revisar registros de compilación, cobertura de fuentes, límites de página, folios, enlaces, marcadores y rótulos huérfanos en el PDF final.
7. **Revisar visualmente.** Renderizar todas las páginas para una inspección de conjunto y registrar la cobertura. Examinar a escala de lectura todas las aperturas y cierres de capítulos, figuras, tablas y páginas señaladas por los controles; ampliar las fórmulas y símbolos dudosos. Una hoja de miniaturas no sustituye la lectura a tamaño final.
8. **Cerrar los derivados.** Generar variantes y capítulos separados desde la instantánea final, repetir sus controles pertinentes y comprobar la integridad de los ZIP. Todo cambio que altere la composición invalida la revisión visual de las páginas afectadas.
9. **Guardar.** Preservar los entregables y el paquete reproducible, confirmar las identidades de archivo y actualizar el registro canónico mediante Markdown crudo con lectura posterior.
10. **Publicar cuando corresponda.** Si la entrega incluye publicación web, incorporar los archivos y enlaces, esperar el despliegue y comprobar las descargas de la versión correcta. Registrar por separado PDF generado, PDF guardado y PDF publicado.

## 11. Criterios de aceptación

| Control | Condición de cierre |
|---|---|
| Fuente | Instantánea canónica identificada; cuentas por capítulo y huellas disponibles |
| Contenido | Todas las unidades previstas, con diferencias de variante explicadas y cotejadas |
| Matemática | Signos, macros, cuantificadores, cálculos, pruebas e incisos conservados |
| Compilación | Sin errores ni avisos de referencias pendientes; índice y destinos estabilizados |
| Tipografía | Sin glifos ausentes; fórmulas y etiquetas legibles a tamaño final |
| Composición | Sin recortes, colisiones, desbordes materiales ni rótulos huérfanos |
| Navegación | Índice, marcadores y referencias conducen a destinos correctos, sin comandos visibles |
| Figuras y tablas | Inventario íntegro, pies correctos, escalas y continuaciones revisadas |
| Autoría y créditos | Nombre del autor, título, tomo, fecha y licencia correctos |
| Revisión visual | Cobertura registrada sobre el PDF que efectivamente se entrega |
| Archivo | PDF abre completo; ZIP íntegro; guardado confirmado; huellas de entrega registradas |
| Publicación | Cuando forma parte del alcance, despliegue y descargas comprobados |

Los avisos de caja insuficientemente llena se evalúan visualmente; no se consideran automáticamente defectos ni se silencian para obtener un registro limpio. Las diferencias esperadas de numeración de figuras entre HTML, volumen combinado y capítulo aislado se comprueban contra sus anclas y contextos.

Los estados son `SOURCE_FROZEN`, `COMPILED`, `CONTENT_QA_PASS`, `LAYOUT_QA_PASS`, `VISUAL_QA_PASS`, `SAVED` y, cuando proceda, `PUBLISHED`. El estado de un formato no certifica los demás. La aprobación matemática del manuscrito y la aprobación de composición del PDF se registran separadamente.

## 12. Entrega y continuidad

La entrega ordinaria de una edición completa contiene el PDF A4 para lectura digital y el PDF Carta para impresión, salvo una instrucción expresa que limite los soportes. Incluye también las variantes solicitadas y un paquete reproducible con configuración, fuentes derivadas, activos, manifiesto y registro de QA. Cuando se entregue un proyecto de Overleaf, incluye todo lo necesario para compilar y señala el archivo principal y el motor ya comprobados. El autor no necesita ejecutar esa compilación para considerar terminada la entrega.

Los nombres de archivo distinguen obra, tomo, formato, variante y versión. Ejemplos: `ANM_A4_Digital_Con_Soluciones_v02.pdf` y `ANM_Carta_Impresion_Con_Soluciones_v02.pdf`. La numeración de versión no se reinicia ni se asigna sin consultar los archivos existentes. Los nombres de código y la estructura interna se mantienen fuera del cuerpo del libro.

El registro canónico consigna versión del protocolo, fuente, perfil, motor, cuentas reales, resultados de QA, incidencias resueltas, identidades persistentes y estado de publicación. Una recompilación futura consulta ese registro y este protocolo antes de escoger tipografía o márgenes.

Los PDF anteriores conservan su identidad de edición. La adopción de esta norma no les atribuye conformidad retroactiva. Los PDF de ANM entregados el 14 de octubre con clase `book`, papel A4 y DejaVu Serif deberán adecuarse a MA-PDF en su próxima recompilación; sus verificaciones de contenido y las entregas ya realizadas siguen identificadas como correspondientes a aquella edición. Este tramo establece la norma y no regenera esos archivos.

## 13. Base comprobada y decisiones adoptadas

Se examinó el PDF `Calculo_para_matematicos_Tomo_I_carta_amsbook.pdf`, de 1.805 páginas y caja física de 612 × 792 puntos, junto con `main.tex` y `main-carta.tex` de `Calculo_para_matematicos_Tomo_I_Overleaf_amsbook.zip`, versión 2. El perfil de referencia contiene `amsbook`, Latin Modern, 11 puntos, márgenes 28/28/27/29 mm, sangría 1,2 em, separación de 2 puntos, índice hasta secciones y encabezados discretos. La portada atribuye la obra a A. Peña. Estas propiedades se verificaron en las fuentes y en páginas renderizadas del PDF.

La correspondencia Carta–impresión y A4–lectura digital queda fijada por instrucción expresa del autor del 14 de octubre de 2026. El umbral de legibilidad de gráficos, el límite a la reducción de fórmulas y la secuencia de aceptación quedan adoptados mediante este protocolo. La referencia CPM proporciona una base de composición; sus cuentas, fechas, contenidos y posibles incidencias no se trasladan a otras obras.

Referencias de archivo:

- PDF Carta CPM: `libfile_de7d0a8606e08191a90279f7cdec7b94`.
- Proyecto CPM Overleaf: `libfile_d4953915ae3881918a4ad34d4255cd7a`, versión 2.
- Normas complementarias de pedagogía y figuras: `MA_PED_v1.0.md` y `MA_FIG_NUMERACION_ANCLAS_PARA_MATEMATICOS_v1.0.md`, consultadas en la administración general de Matemática.

**Norma de continuidad:** toda nueva generación o recompilación PDF de Matemática Abierta carga MA-PDF v1.0 y conserva la arquitectura editorial aprobada de la obra.

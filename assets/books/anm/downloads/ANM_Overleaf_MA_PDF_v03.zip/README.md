# Análisis real para matemáticos — Proyecto Overleaf

Edición revisada v03 · MA-PDF v1.0, de 16 de octubre de 2026. A. Peña — Matemática Abierta.

El proyecto contiene el prefacio, los 32 capítulos, el epílogo y las 3.338 soluciones desarrolladas. La composición usa `amsbook`, Latin Modern de 11 puntos y los márgenes establecidos por MA-PDF. XeLaTeX permite mantener esa familia con cobertura Unicode; DejaVu Sans Mono se limita a los fragmentos de código que necesitan sus símbolos.

## Archivos principales

| Archivo | Papel y uso | Respuestas |
|---|---|---|
| `main.tex` | A4 para lectura digital | Todas las soluciones integradas |
| `main-carta.tex` | Carta para impresión | Todas las soluciones integradas |

El compilador comprobado es **XeLaTeX**. Los dos archivos principales se compilaron antes de la entrega. El archivo predeterminado es `main.tex` y `.latexmkrc` conserva la selección del motor. Para editar una variante en Overleaf, se selecciona su archivo principal con el mismo compilador.

## Estructura

- `book.tex`: portada, créditos y orden del volumen.
- `preamble.tex` y `highlighting.tex`: composición, cobertura de símbolos y presentación de código.
- `chapters/`: un archivo LaTeX por capítulo, además del prefacio y el epílogo.
- `figures/`: las figuras vectoriales necesarias para compilar, con rutas relativas.
- `source/`: Markdown intermedio utilizado para la trazabilidad de la transformación. Las compilaciones parten de los archivos LaTeX finales comprobados. El canon editable continúa en la bóveda de Obsidian del proyecto.
- `source-manifest.json`: correspondencias y huellas de fuentes y figuras.
- `MA_PDF_v1.0.md` y `MA_PDF_PERFIL_v1.0.json`: norma y configuración de los perfiles.
- `GNU-FDL-1.3.txt`: licencia completa.
- `qa-report.json`: resultados de comprobación de los PDF entregados.

Los ajustes de línea de las fórmulas y los destinos únicos de navegación pertenecen a la composición del derivado. Las fuentes canónicas se conservaron. Las 3.338 soluciones se incluyen en ambos perfiles mediante `ANMSolution`, conservando una sola fuente común.

El paquete es autosuficiente: no requiere descargar figuras ni acceder a rutas locales externas para compilar.

## Figuras y vistas ampliadas

Las figuras anchas se presentan en páginas apaisadas cuando esa disposición mejora la lectura. El tamaño físico sigue siendo el del perfil A4 o Carta. Las figuras que requieren ampliación conservan su esquema completo y disponen de vistas de detalle superpuestas, incluidas 63 vistas centrales adicionales, para leer las anotaciones pequeñas. Esas vistas usan el mismo archivo vectorial; no modifican la figura ni añaden afirmaciones matemáticas.

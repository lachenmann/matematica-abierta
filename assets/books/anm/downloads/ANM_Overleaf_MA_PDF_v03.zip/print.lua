local symbols={['ε']='\\varepsilon',['≤']='\\le',['≥']='\\ge',['η']='\\eta',['′']='^{\\prime}',['⇒']='\\Rightarrow',['δ']='\\delta',['₀']='_0',['α']='\\alpha',['₂']='_2',['φ']='\\phi',['↦']='\\mapsto',['⇔']='\\Leftrightarrow',['≠']='\\ne',['∪']='\\cup',['ω']='\\omega',['ₙ']='_n',['λ']='\\lambda',['₁']='_1',['β']='\\beta',['∩']='\\cap',['∈']='\\in',['₃']='_3',['ₖ']='_k',['ξ']='\\xi',['σ']='\\sigma',['⊊']='\\subsetneq',['θ']='\\theta',['⁻']='^{-}',['⁴']='^4',['ₓ']='_x',['ℝ']='\\mathbb{R}',['ˣ']='^x',['π']='\\pi',['ⁿ']='^n',['⊆']='\\subseteq'}
function Str(el)
  local output={};local buffer='';local changed=false
  for _,cp in utf8.codes(el.text) do
    local ch=utf8.char(cp)
    if symbols[ch] then
      if buffer~='' then table.insert(output,pandoc.Str(buffer));buffer='' end
      table.insert(output,pandoc.Math('InlineMath',symbols[ch]));changed=true
    else buffer=buffer..ch end
  end
  if buffer~='' then table.insert(output,pandoc.Str(buffer)) end
  if changed then return output end
end
function Image(el)
  el.attributes['width']='100%';el.attributes['height']='80%'
  return el
end
function Math(el)
  if el.mathtype=='DisplayMath' then return pandoc.RawInline('latex','\\[\\ANMFitMath{'..el.text..'}\\]') end
end
function Header(el)
  if el.level==1 then
    local n=el.identifier:match('^anm%-c(%d+)$')
    if n then return {pandoc.RawBlock('latex','\\setcounter{chapter}{'..tonumber(n)..'}\\setcounter{figure}{0}\\setcounter{table}{0}'),el} end
  else return {pandoc.RawBlock('latex','\\Needspace{5\\baselineskip}'),el} end
end
function Div(el)
  if el.classes:includes('anm-solution') then
    local result={pandoc.RawBlock('latex','\\begin{ANMSolution}')}
    for _,b in ipairs(el.content) do table.insert(result,b) end
    table.insert(result,pandoc.RawBlock('latex','\\end{ANMSolution}'))
    return result
  end
end

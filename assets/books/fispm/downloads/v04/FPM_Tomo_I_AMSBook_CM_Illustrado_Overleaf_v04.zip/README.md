# Física para matemáticos — Tomo I · candidata v04

A. Peña · Matemática Abierta. Segunda pasada editorial sobre v03, sin canonización ni publicación.

## Overleaf

Importar el ZIP, seleccionar **XeLaTeX** y una instalación completa reciente de TeX Live. Abrir `main.tex` o `main_A4_Lectura.tex` para A4; `main_Carta_Impresion.tex` para carta a doble cara. Recompilar hasta cerrar índice y referencias; se verificaron tres pasadas completas por formato.

La clase es `amsbook`, 11 pt. Se utilizan CMU Serif y New Computer Modern Math disponibles en TeX Live. No se incluyen archivos OTF/TTF. La bibliografía y las notas están en los capítulos; no se necesita BibTeX ni conversión SVG en Overleaf.

## Recursos y control

- `chapters/`: treinta capítulos completos.
- `figuras_nuevas/`: 155 fuentes TikZ y sus PDF vectoriales; 61 añadidas en v04.
- `figuras/`, `figuras_originales_svg/`: archivos originales intactos.
- `figuras_edicion/`: copias de composición y lámina F18 compacta editable.
- `figures_layout_v04.tex`: anchuras revisadas individualmente.
- `PDFs/`: A4 de 1140 páginas y carta de 1230.
- `auditoria/`: controles ejecutados, logs, pruebas y copia de control v03.
- `scripts/`: compilación y verificaciones. `compile_final_v04.py` recompila el libro. `build_figures.py` recompila las fuentes TikZ definitivas. `ampliar_figuras_v04.py` documenta y genera las 61 adiciones; no sustituye las restantes fuentes revisadas.

Para auditoría local se emplean Python 3, PyMuPDF, Pillow, NumPy y SymPy. `pdffonts`, XeLaTeX y xdvipdfmx deben estar disponibles. Las figuras ya están compiladas: estos programas Python no son necesarios para usar Overleaf.

El informe distingue comprobaciones ejecutadas, avisos conservados y límites de la auditoría. El trabajo se limita al derivado LaTeX/PDF.

# Física para matemáticos — Tomo I: Fundamentos y mecánica
## Informe de edición de la candidata v03

A. Peña · Matemática Abierta · 17 de octubre de 2026.

**Resultado:** proyecto AMSBook completo y dos PDF compilados. Candidata para revisión; no canonizada ni publicada. El trabajo se limitó al derivado LaTeX y sus PDF. No se editó la web, GitHub ni la bóveda.

## Base y conservación

La única base de composición fue `FPM_Tomo_I_AMSBook_ComputerModern_Optimizado_Overleaf_y_PDFs_v02.zip`, versión 2 del archivo aportado. Sus fuentes originales se utilizaron para cotejo, sin sustituir los capítulos por manuscritos anteriores.

| Control | Resultado ejecutado |
|---|---:|
| Capítulos conservados y presentes en ambos índices PDF | 30 |
| Ejercicios numerados, localizados por capítulo en cada PDF | 900 |
| Soluciones desarrolladas conservadas en el LaTeX | 900 |
| Notas al pie conservadas | 222 |
| Bloques matemáticos cotejados, excluida navegación tipográfica | 27,067 |
| Figuras originales conservadas con sus PDF y SVG intactos | 21 |
| Figuras nuevas en TikZ, con PDF vectorial y código | 94 |
| Total integrado y rotulado en cada PDF | 115 |

El capítulo 1 contiene 32 pares ejercicio–solución y el 2 contiene 28; cada uno de los otros 28 contiene 30. No se forzó artificialmente una distribución de treinta en los dos primeros capítulos. La secuencia matemática se comparó después de normalizar espacios y rótulos de remisión, excluyendo los epígrafes y la navegación. Se conservan las 587 marcas `\square` de la base. Las copias de los treinta manuscritos y los 42 archivos gráficos PDF/SVG originales son idénticas byte a byte.

## Depuración global

- Se retiraron los siete menús «Navegación del capítulo» o «Recorrido del capítulo», completos, de los capítulos 3–9. Las 25 remisiones wiki narrativas restantes se convirtieron en enlaces a capítulos o secciones reales.
- Los tres apartados «Prerrequisitos y propósito» quedan sin numeración. El capítulo 8 comienza su contenido en la sección 1, sin menú ni `[[#§...]]`. Se consultó también la captura que documentaba el defecto original.
- Se suprimieron los bloques iniciales de estado editorial y 27 etiquetas internas de familia de ejercicios. Se conservaron los niveles, indicaciones y explicaciones didácticas legibles, y las etiquetas conceptuales que el capítulo 1 define expresamente.
- Se convirtieron 38 anuncios repetidos del próximo apartado en remisiones breves y se fusionaron 29 encabezados locales que repetían inmediatamente el rótulo formal. No se eliminaron las secciones de contenido ni los mapas conceptuales que desarrollan relaciones entre ideas.
- Se recuperaron las categorías de 241 rótulos de los capítulos 4 y 5 cotejando la secuencia de llamadas de las fuentes originales. Así se distinguen, por ejemplo, definición 4.1, proposición 4.1 y ejercicio 4.1. Las claves internas de remisión se expandieron a nombres y números legibles.
- Se mantienen las optimizaciones v02: las 1.718 conversiones de fórmulas breves a línea y las 1.577 uniones de párrafos no se revirtieron. Los nuevos ajustes afectan rótulos, remisiones e ilustraciones.

El registro inicial contiene archivo y rango de líneas de la base; los cambios tardíos tienen registros específicos y cada capítulo dispone además de un diff completo v02→v03. Los treinta TeX de control se incluyen en `auditoria/base_v02/chapters/`. El script de reconstrucción por diff comprueba la reproducibilidad del texto final.

## Ilustraciones y exactitud del soporte visual

Los capítulos 1–9 y 12–29 reciben tres figuras nuevas cada uno; el 10 recibe seis y el 11 cinco. El capítulo 30 recibe dos nuevas, además de sus dieciocho originales: su densidad previa hace innecesario repetir los retratos ya presentes. El capítulo 10 queda con nueve figuras. Los capítulos conceptuales iniciales concentran la ilustración en los puntos donde una representación resuelve una dificultad: frontera, observación, unidades, escalamiento, incertidumbre, geometría afín y curvas.

Todas las nuevas figuras tienen parámetros o hipótesis explícitos en el epígrafe y en el inventario. Los esquemas cualitativos se identifican como tales. Se distinguen fuerzas, ejes, desplazamientos y velocidades; los DCL de partículas aisladas muestran sólo las fuerzas externas declaradas. Se controlaron normales, fricción y restricciones de cuerda, proyecciones, derivadas, potenciales, órbitas, regímenes de amortiguamiento y orientación de los flujos.

Se ejecutaron 52 verificaciones analíticas o numéricas independientes de los modelos gráficos, con sustitución en ecuaciones diferenciales, derivadas, integrales, condiciones iniciales y signos. Los contornos de incertidumbre usan matrices normalizadas explícitas. Para dos originales se realizó además una reproducción numérica: el contorno de 1.604 puntos del mapa estándar conserva área 2; los 31 estados del péndulo forzado coinciden con RK4 dentro del redondeo del SVG, y reducir el paso de 0,002 a 0,001 produce una diferencia máxima inferior a 3×10⁻¹³.

Las 21 figuras originales se conservan intactas en `figuras/` y sus fuentes anteriores en `figuras_originales_svg/`. Las copias de composición de `figuras_edicion/` corrigen superíndices, subíndices, primas y desigualdades que la conversión previa mostraba como cuadros vacíos. Se retiraron de esas copias los rótulos internos antiguos; la numeración visible es única y automática por capítulo. La geometría original de las curvas no se cambió.

## Composición y compilación

Se conservan `amsbook`, 11 pt, XeLaTeX, CMU Serif y New Computer Modern Math. No se distribuyen archivos de fuentes. Los PDF llevan las fuentes Computer Modern incrustadas; el detalle real de `pdffonts` está en el expediente.

Las figuras nuevas se insertan junto al pasaje correspondiente, a tamaño natural y con límites de anchura y altura. Las originales complejas disponen de más altura para conservar rótulos legibles; su colocación flotante mejora el aprovechamiento de la mancha. Algunas láminas complejas conservan una página de mayor holgura para respetar su legibilidad y el orden de remisión. Se limita la altura gráfica a la mitad de la caja y se impide que figuras pendientes adelanten la numeración de las nuevas.

| Salida | v02 | Candidata v03 | Capítulos | Figuras |
|---|---:|---:|---:|---:|
| Lectura A4 | 1099 | 1123 | 30 | 115 |
| Impresión carta, doble cara | 1184 | 1209 | 30 | 115 |

Se efectuaron tres pasadas completas de XeLaTeX por formato en un directorio de compilación aislado, seguidas de la conversión real a PDF. Se comprobaron el cierre de los auxiliares, el índice, las 115 etiquetas y la ausencia de avisos de recompilación. Los archivos se copiaron a la entrega sólo después de cerrarse.

## Auditoría de todas las páginas y revisión visual

| Control final | A4 | Carta |
|---|---:|---:|
| Errores LaTeX | 0 | 0 |
| Referencias o citas indefinidas | 0 | 0 |
| Avisos de glifos faltantes | 0 | 0 |
| Desbordamientos horizontales | 0 | 0 |
| Textos fuera del margen físico seguro de 33 pt | 0 | 0 |
| Destinos de enlace interno fuera del PDF | 0 | 0 |
| Páginas en blanco | 0 | 14 |
| Avisos verticales leves conservados | 9 | 10 |
| Mayor aviso vertical | 2.778 pt | 4.055 pt |

Las páginas en blanco de carta corresponden al arranque de capítulo en recto exigido por `openright`; se verificó su relación con el capítulo siguiente. Los avisos verticales son pequeños ajustes de caja, inferiores a una línea de texto, sin invasión del papel ni recorte detectado. Sus páginas se incluyeron en las pruebas visuales; el JSON conserva los mensajes y localizaciones aproximadas de TeX. No se ocultan los avisos `Underfull`: son advertencias de ajuste o distribución, no errores de contenido.

Se inspeccionaron las 115 figuras individualmente y, mediante pruebas de contacto, todos los comienzos de capítulo y todas las páginas ilustradas de ambos formatos. La selección final abarca 178 páginas A4 y 181 de carta, con ampliaciones para el capítulo 8, DCL, láminas complejas y avisos. La mecánica de márgenes y navegación recorre la totalidad de las 2332 páginas. La inspección por contacto controla la composición; no equivale a leer visualmente cada línea de cada página.

## Límites y estado de aprobación

Esta auditoría acredita conservación, composición y el soporte científico de las figuras; **no se presenta como una nueva auditoría matemática exhaustiva de cada demostración del manuscrito**. Se conservan las fuentes y atribuciones bibliográficas; no se revalidaron en línea todas las URL ni cada localización de las ediciones citadas. El proyecto compila localmente con recursos autocontenidos; no se abrió una sesión real en Overleaf.

La candidata v03 queda lista para revisión del autor. La web, GitHub y los manuscritos canónicos permanecen sin cambios. La canonización y cualquier actualización web requieren la aprobación posterior del autor.

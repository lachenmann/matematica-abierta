from pathlib import Path
import json,re,fitz
R=Path(__file__).resolve().parents[1];I=json.loads(((R/'INVENTARIO_ILUSTRACIONES_v03.json') if (R/'INVENTARIO_ILUSTRACIONES_v03.json').exists() else R/'auditoria/historico_v03/INVENTARIO_ILUSTRACIONES_v03.json').read_text());A=json.loads((R/'figuras_nuevas/inventario_ampliacion_v04.json').read_text())
for x in A:
 p=R/f"chapters/c{x['chapter']:02}.tex";s=p.read_text();hs=list(re.finditer(r'\\section\{([^{}\n]+)\}\\label\{([^{}]+)\}',s));matches=[(k,h)for k,h in enumerate(hs)if h[1].lower().startswith(x['section_keyword'].lower())];assert len(matches)==1,(x['id'],matches)
 k,h=matches[0];end=hs[k+1].start()if k+1<len(hs)else len(s);seg=s[h.end():end];label=h[2];candidates=[]
 for m in re.finditer(r'(?:^|\n\n)([^\n][\s\S]*?)(?=\n\n|$)',seg):
  t=m[1]
  if len(t)>160 and not t.startswith('\\') and not any(z in t for z in ['\\begin{','\\[','\\]']):candidates.append(m.end())
 pos=h.end()+(candidates[0]if candidates else 0);x['section_label']=label;x['placement']='Tras el primer párrafo de explicación; sección '+h[1]
 block='\n\n'+r'\FPMIllustration{'+x['pdf']+'}{fig:'+x['id']+'}{'+x['caption']+r' Véase §\ref{'+label+'}.}\n\n'
 if 'fig:'+x['id']not in s:s=s[:pos]+block+s[pos:];p.write_text(s)
# Cap display sizes individually; small diagrams receive more room, originals less.
L=[];defs=['% Escalas por figura. Anchuras en puntos; límite vertical aplicado al calcularlas.']
for x in I+A:
 
 if x['id']=='FPM-I-30-F18':x['pdf']='figuras_edicion/FPM-I-30-F18_compacto_v04.pdf';x['source']='figuras_edicion/FPM-I-30-F18_compacto_v04.tex';x['composition_note']='Mismos datos analíticos en composición horizontal compacta; originales SVG/PDF intactos.'
 p=R/x['pdf'];d=fitz.open(p);rect=d[0].rect;w,h=rect.width,rect.height
 if x['id'].startswith('FPM'):
  scale=min((340 if x['chapter']==10 else 320)/w,270/h)
 else:
  scale=min(1.30 if w<160 else 1.15,330/w,200/h)
 tw=w*scale;th=h*scale
 defs.append(r'\expandafter\def\csname FPMwidth@fig:'+x['id']+r'\endcsname{'+f'{tw:.3f}pt'+'}')
 L.append({'id':x['id'],'native_width_pt':w,'native_height_pt':h,'scale':scale,'display_width_pt':tw,'display_height_pt':th,'previous_version':'v03'if x in I else 'new'})
(R/'figures_layout_v04.tex').write_text('\n'.join(defs)+'\n');(R/'auditoria/ESCALAS_FIGURAS_v04.json').write_text(json.dumps(L,ensure_ascii=False,indent=2))
macro=r'''% Escalas individuales revisadas para v04.
\input{figures_layout_v04.tex}
\newcommand{\FPMGraphic}[2]{\includegraphics[width=\csname FPMwidth@#2\endcsname]{#1}}
\renewcommand{\FPMOriginal}[3]{%
\begin{figure}[!htbp]\centering
\refstepcounter{figure}\label{#2}%
\FPMGraphic{#1}{#2}\par
\smallskip{\footnotesize\raggedright\textbf{Figura \thefigure.} #3\par}
\end{figure}}
\renewcommand{\FPMIllustration}[3]{%
\FloatBarrier\par\addvspace{8pt}\noindent\begin{minipage}{\linewidth}
\refstepcounter{figure}\label{#2}%
\centering\FPMGraphic{#1}{#2}\par
\smallskip{\footnotesize\raggedright\textbf{Figura \thefigure.} #3\par}
\end{minipage}\par\addvspace{8pt}}
\pretocmd{\section}{\Needspace{6\baselineskip}}{}{}
\pretocmd{\subsection}{\Needspace{5\baselineskip}}{}{}
\pretocmd{\subsubsection}{\Needspace{4\baselineskip}}{}{}
'''
for name in ['main_A4_Lectura.tex','main_Carta_Impresion.tex']:
 p=R/name;s=p.read_text();s=s if 'FPMwidth@' in s or 'figures_layout_v04.tex' in s else s.replace(r'\begin{document}',macro+'\n'+r'\begin{document}');p.write_text(s)
(R/'INVENTARIO_ILUSTRACIONES_v04.json').write_text(json.dumps(I+A,ensure_ascii=False,indent=2))
print('Integrated',len(A),'additional figures;',len(I+A),'total')

"""Independent analytic/numeric audit of graphical models (not a manuscript proof audit)."""
from pathlib import Path
import json,math
import numpy as np
import sympy as S
R=Path(__file__).resolve().parents[1];out=[]
def check(name,condition,detail):
 ok=bool(condition);out.append({'check':name,'pass':ok,'evidence':detail});assert ok,(name,detail)
x,t,r=S.symbols('x t r',real=True);positive=S.symbols('rho',positive=True)
# Interpolation; dimensions; uncertainty linearization.
check('I-01-N03: same finite data',all(S.simplify((x+x*(x-1)*(x-2)/3-x).subs(x,i))==0 for i in [0,1,2]),'Polynomial difference vanishes exactly at 0,1,2.')
check('I-02-N03: scaling',abs(math.sqrt(2)-math.sqrt(4)/math.sqrt(2))<1e-14,'T ∝ sqrt(L); doubling L gives sqrt(2).')
check('I-03-N03: tangent error',S.expand(x*x-(2*x-1))==(x-1)**2 or S.simplify(x*x-(2*x-1)-(x-1)**2)==0,'f-linear=(x-1)^2.')
# Kinematics.
check('I-05-N02: secant/tangent',S.diff(x*x/3,x).subs(x,S.Rational(3,2))==1,'Derivative at X=1.5 equals 1.')
check('I-06-N02: Taylor bound',all(0<=q-math.sin(q)<=q**3/6+1e-15 for q in np.linspace(0,1,1001)),'1001 point checks plus Taylor theorem |f'''+'|≤1.')
check('I-07-N01: derivatives',S.diff(t*t/2,t)==t and S.diff(t,t)==1,'X′=V, V′=A.')
check('I-07-N02: signed/absolute areas',S.integrate(1-t,(t,0,2))==0 and S.integrate(1-t,(t,0,1))+S.integrate(t-1,(t,1,2))==1,'Displacement 0; distance 1.')
check('I-07-N03: stop event',S.diff(2*t-t*t/2,t).subs(t,2)==0,'V=2-t; A=-1; stop at t=2.')
check('I-08-N01: projectile',S.diff(2*t-t*t/2,t,2)==-1 and (2*t-t*t/2).subs(t,4)==0,'A=(0,-1), return u=4, apex u=2.')
check('I-08-N02: polar basis',abs(np.dot([.8,.6],[-.6,.8]))<1e-14,'e_r·e_theta=0; e_theta positive ccw.')
# Force diagrams and constraints.
n=np.array([-math.sin(math.pi/6),math.cos(math.pi/6)]);fk=-np.array([math.cos(math.pi/6),math.sin(math.pi/6)])
check('I-10-N03: incline DCL',abs(n@fk)<1e-12 and n[1]>0 and fk[0]<0 and fk[1]<0,'Normal perpendicular to slope, kinetic friction down slope for upward slip, gravity vertical.')
check('I-11-N05: pendulum geometry',abs(np.dot([1,-2],[2,1]))<1e-14,'Tension radial, virtual displacement tangent.')
check('I-11-N01/N02: string constraints',S.diff(S.Function('y1')(t)+2*S.Function('y2')(t),t,2)==S.diff(S.Function('y1')(t),t,2)+2*S.diff(S.Function('y2')(t),t,2),'Mobile pulley factor 2 derives from two varying segments; fixed pulley factor 1.')
check('I-12-N02/N03: integrals',S.integrate(x,(x,0,1))==S.Rational(1,2),'Work and power normalize to exact triangular area.')
U=(x*x-1)**2
check('I-13-N01: extrema',S.diff(U,x).subs(x,0)==0 and S.diff(U,x,2).subs(x,0)<0 and S.diff(U,x,2).subs(x,1)>0,'±1 minima, 0 maximum; barrier height 1.')
check('I-13-N03: circulation',abs(2*math.pi-2*math.pi)<1e-14,'On radius R, F·dr=dtheta; ∮=2π; puncture excluded.')
check('I-14-N01: center of mass',(-2+3*2)/4==1,'Positions -2,+2, masses 1,3 → R=1.')
check('I-14-N02: impulse',S.integrate(t,(t,0,1))+S.integrate(2-t,(t,1,2))==1,'Impulse normalized=1; mean normalized=.5.')
check('I-15-N01: torque',np.cross([3,0,0],[0,1.7,0])[2]>0,'r right, F up → torque +z.')
check('I-15-N02: focus',S.simplify(S.sqrt(2**2-1**2)-S.sqrt(3))==0,'Ellipse axes 2,1; focus sqrt(3), not center.')
check('I-16-N02: sphere field',S.limit(positive,positive,1,dir='-')==S.limit(1/positive**2,positive,1,dir='+'),'Uniform sphere: radial magnitude continuous at R; interior slope positive, exterior negative.')
check('I-16-N03: tidal eigenvalues',np.trace(np.diag([2,-1,-1]))==0,'Vacuum Newtonian tide: stretching radial, compression transverse.')
Ueff=1/(2*positive**2)-1/positive
check('I-17-N02: effective potential',S.diff(Ueff,positive).subs(positive,1)==0 and S.diff(Ueff,positive,2).subs(positive,1)>0,'Minimum -.5 at r=1; roots for E=-.3: (5±sqrt(10))/3.')
check('I-17-N03: central oscillator',S.simplify(S.diff(2*S.cos(t),t,2)+2*S.cos(t))==0,'x″=-x, y″=-y; angular momentum 2; radial period π.')
check('I-18-N01: focus and eccentricity',math.sqrt(4-3)==1,'a=2,b=sqrt3,c=1,e=.5; center=-1, right focus=0.')
check('I-18-N02: admissible conic branches',all(1+e*math.cos(th)>0 for e,aa in [(.5,math.pi),(1,2),(1.5,1.75)] for th in np.linspace(-aa,aa,2001)),'All plotted denominators positive; no branch through infinity.')
check('I-18-N03: monotone Kepler map',min(1-.5*np.cos(np.linspace(0,2*math.pi,2001)))>=.5,'M′≥.5.')
check('I-19-N03: scattering monotonicity',S.diff(2*S.atan(1/positive),positive).simplify()==-2/(positive**2+1),'χ decreases from π to zero; repulsive inverse-radius potential.')
check('I-20-N02: Coriolis direction',np.allclose(-2*np.cross([0,0,1],[1,0,0]),[0,-2,0]),'Ω out of plane, velocity right → inertial term down.')
check('I-20-N03: centrifugal potential',S.diff(-positive**2/2,positive)==-positive,'-dU/dr=+r outward.')
check('I-21-N03: inertia',np.allclose(np.diag([1,2])@np.array([1.5,1]),[1.5,2]),'L=Iω; not parallel for these data.')
check('I-22-N01: torque power',np.dot([0,1.7,0],[2,0,0])==0,'Instantaneous power zero for perpendicular vectors.')
# Exact damped solutions independently substituted into their ODEs.
for beta in [S.Rational(3,10),S.Integer(1),S.Rational(3,2)]:
 if beta<1:
  om=S.sqrt(1-beta**2);f=S.exp(-beta*t)*(S.cos(om*t)+beta/om*S.sin(om*t))
 elif beta==1:f=(1+t)*S.exp(-t)
 else:
  d=S.sqrt(beta**2-1);f=((beta+d)*S.exp((-beta+d)*t)+(-beta+d)*S.exp((-beta-d)*t))/(2*d)
 check('I-23-N02: ODE beta='+str(beta),S.simplify(S.diff(f,t,2)+2*beta*S.diff(f,t)+f)==0 and f.subs(t,0)==1 and S.simplify(S.diff(f,t).subs(t,0))==0,'Exact equation and both initial conditions.')
A=1/S.sqrt((1-x*x)**2+S.Rational(16,100)*x*x)
check('I-23-N03: resonance',S.simplify(S.diff(A,x).subs(x,S.sqrt(S.Rational(92,100))))==0,'Amplitude maximum at sqrt(.92), β=.2.')
K=S.Matrix([[2,-1],[-1,2]])
check('I-24-N01/N02: modes',K*S.Matrix([1,1])==S.Matrix([1,1]) and K*S.Matrix([1,-1])==3*S.Matrix([1,-1]),'Eigenvalues 1,3; mode sign arbitrary.')
v=S.Matrix([(S.cos(t)+S.cos(S.sqrt(3)*t))/2,(S.cos(t)-S.cos(S.sqrt(3)*t))/2])
check('I-24-N03: solution',all(S.simplify(a)==0 for a in v.diff(t,2)+K*v),'M=I, K above; v(0)=(1,0), v′(0)=0.')
check('I-25-N03: second variation',S.simplify((S.pi/x)**2-1).subs(x,S.pi)==0,'Sign changes at Tω=π; positive factor removed.')
check('I-27-N03: energy exchange',S.trigsimp(S.sin(t)**2/2+S.cos(t)**2/2)==S.Rational(1,2),'K+U=.5 exactly.')
check('I-28-N01: Legendre tangent',S.diff(x*x/2,x).subs(x,1)==1,'Tangent v-.5, intercept -H=-.5.')
check('I-28-N02/N03: Hamilton flow',np.cross([1,0],[0,-1])<0,'At q>0,p=0, pdot=-q; clockwise flow. Pendulum separatrix E=2.')
check('I-29-N01/N02: symplectic matrices',S.det(S.Matrix([[2,0],[0,S.Rational(1,2)]]))==1 and S.det(S.Matrix([[1,0],[1,1]]))==1,'Each 2×2 map preserves canonical area.')
phi,J=S.symbols('phi J',positive=True);q=S.sqrt(2*J)*S.cos(phi);p=-S.sqrt(2*J)*S.sin(phi)
check('I-29-N03: action-angle convention',S.simplify(S.det(S.Matrix([[S.diff(q,phi),S.diff(q,J)],[S.diff(p,phi),S.diff(p,J)]])))==1,'dq∧dp=dphi∧dJ; H=J, phidot=1.')
f=1/(1+3*S.exp(-t))
check('I-30-N02: logistic flow',S.simplify(S.diff(f,t)-f*(1-f))==0,'Exact ODE; positive ordered initial values yield no crossing.')
# Original scientific illustrations: check nontrivial quantities in their captions.
B=S.Matrix([[-1,1],[0,-1]]);P=S.Matrix([[S.Rational(1,2),S.Rational(1,4)],[S.Rational(1,4),S.Rational(3,4)]])
check('Original F12: Lyapunov matrix',B.T*P+P*B==-S.eye(2),'V=x²/2+xy/2+3y²/4; derivative=-x²-y².')
eigs=np.linalg.eigvalsh(np.array(P).astype(float));check('Original F12: trapping radii',eigs[0]>.15 and eigs[1]*.3**2<.15,'Boundary radius1 has V≥.34549; radius.3 has V≤.08141.')
check('Original F15: horizons',abs(math.log(1e-1/1e-6)/.2-57.56462732485)<1e-10 and abs(math.log(2)/.2-3.4657359028)<1e-9,'Halving initial error adds log2/.2; second horizon 61.03036.')
check('Original F18: escape',S.Rational(1,1)/(2*S.Rational(65,100)**2)==S.Rational(200,169),'Escape of sigma=+1 at 200/169>1; finite window is admissible.')
check('Original F08: fourth iterate branch fixed point',S.Rational(4,17)==4-16*S.Rational(4,17),'Point lies in (3/16,1/4); exact period four under tent map.')
z=S.Rational(4,17);orb=[]
for i in range(4):orb.append(z);z=2*z if z<=S.Rational(1,2) else 2*(1-z)
check('Original F08: minimal period',z==orb[0] and len(set(orb))==4,'Four distinct orbit points.')
u=S.symbols('u',real=True)
X=S.sqrt(S.Rational(4,5))*S.cos(u)+S.sqrt(S.Rational(1,5))*S.sin(u)
Y=S.sqrt(S.Rational(4,5))*S.cos(u)-S.sqrt(S.Rational(1,5))*S.sin(u)
check('I-03-N02: standardized covariance contours',S.trigsimp(X*X-S.Rational(6,5)*X*Y+Y*Y-S.Rational(16,25))==0,'C=[[1,.6],[.6,1]], positive eigenvalues .4 and 1.6; level X²-1.2XY+Y²=.64. Uncorrelated level is a circle.')
(R/'auditoria/QA_CIENTIFICO_FIGURAS_v04.json').write_text(json.dumps({'scope':'Support-visual audit; not a reproof of the manuscript','checks':out},ensure_ascii=False,indent=2))
print(len(out),'independent checks passed')

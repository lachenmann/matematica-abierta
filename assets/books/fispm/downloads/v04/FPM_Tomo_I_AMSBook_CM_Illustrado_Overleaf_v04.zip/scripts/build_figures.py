from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import tempfile,subprocess,shutil,json
R=Path(__file__).resolve().parents[1];d=R/'figuras_nuevas';W=Path(tempfile.mkdtemp(prefix='fpm_figuras_v04_',dir='/tmp'))
for p in d.glob('*.tex'):shutil.copy2(p,W/p.name)
def run(p):
 r=subprocess.run(['xelatex','-halt-on-error','-interaction=nonstopmode',p.name],cwd=W,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 if r.returncode:print(p.name,r.stdout.decode(errors='replace')[-1500:],flush=True)
 else:
  out=d/p.with_suffix('.pdf').name;tmp=out.with_suffix('.pdf.closed');shutil.copy2(W/p.with_suffix('.pdf').name,tmp);tmp.replace(out)
 return {'file':p.name,'returncode':r.returncode}
with ThreadPoolExecutor(max_workers=5)as e:res=list(e.map(run,sorted(W.glob('*.tex'))))
(R/'auditoria/QA_RECOMPILACION_TODAS_FIGURAS_v04.json').write_text(json.dumps(res,indent=2))
assert len(res)==155 and all(x['returncode']==0 for x in res)
print('155 definitive figure sources compiled and closed')

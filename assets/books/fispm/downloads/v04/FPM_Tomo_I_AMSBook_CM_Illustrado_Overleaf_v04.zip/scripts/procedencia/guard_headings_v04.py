from pathlib import Path
import re,json
R=Path(__file__).resolve().parents[2];rows=[]
for p in sorted((R/'chapters').glob('*.tex')):
 s=p.read_text();hs=list(re.finditer(r'\\((?:sub)*section)\*?\{([^{}\n]*)\}\\label\{([^{}]+)\}',s));inserts=[];i=0
 while i<len(hs):
  chain=[hs[i]];j=i
  while j+1<len(hs):
   body=s[hs[j].end():hs[j+1].start()];body=re.sub(r'\\phantomsection|\\label\{[^}]+\}','',body).strip()
   if not body and hs[j+1][1].count('sub')>hs[j][1].count('sub'):chain.append(hs[j+1]);j+=1
   else:break
  if len(chain)>1:
   reserve=5+3*len(chain);inserts.append((hs[i].start(),r'\Needspace{'+str(reserve)+r'\baselineskip}'+'\n'));rows.append({'chapter':p.stem,'chain':[h[2]for h in chain],'reserved_baselines':reserve})
  i=j+1
 for pos,txt in reversed(inserts):s=s[:pos]+txt+s[pos:]
 p.write_text(s)
for name in ['main_A4_Lectura.tex','main_Carta_Impresion.tex']:
 p=R/name;s=p.read_text();s=re.sub(r'\\pretocmd\{\\(?:sub)*section\}[^\n]*\n','',s);p.write_text(s)
(R/'auditoria/UNION_ENCABEZADOS_v04.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2));print(len(rows),'heading stacks guarded as units')

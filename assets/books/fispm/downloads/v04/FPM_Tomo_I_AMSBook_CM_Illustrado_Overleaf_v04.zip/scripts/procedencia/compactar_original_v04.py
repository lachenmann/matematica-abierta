from pathlib import Path
import math,subprocess,tempfile,shutil,json
R=Path(__file__).resolve().parents[2];base=(R/'figuras_nuevas/I-30-R00.tex')if False else R/'figuras_nuevas/I-29-R01.tex'
header=base.read_text().split('\\begin{tikzpicture}')[0]
code=r'''\begin{tikzpicture}[>=Stealth,font=\small,line cap=round,line join=round]
\draw[->] (0,0)--(5.5,0)node[right]{$t$};
\draw[->] (0,0)--(0,3.05)node[above]{$r(t)$};
'''
# Same three analytic curves, initial condition and finite time as original F18.
for sigma,style in [(-1,'thick'),(0,'thick,dashed'),(1,'thick,densely dotted')]:
 pts=[]
 for j in range(201):
  t=j/200;r=.65/math.sqrt(1-2*sigma*.65**2*t);pts.append((5*t,1.6*r))
 code+='\\draw['+style+'] plot coordinates {'+' '.join(f'({x:.6f},{y:.6f})'for x,y in pts)+'};\n'
for t in [0,.5,1]:code+=f'\\draw ({5*t},.06)--({5*t},-.06)node[below]{{${t:g}$}};\n'
for r in [.5,1,1.5]:code+=f'\\draw (.06,{1.6*r})--(-.06,{1.6*r})node[left]{{${r:g}$}};\n'
code+=r'''\fill (0,1.04)circle(2pt);
\node[anchor=west] at (1,3.4){$r(0)=0{,}65,\quad 0\le t\le1$};
\draw[thick] (0,-.85)--(.5,-.85)node[right]{$\sigma=-1$};
\draw[thick,dashed] (2,-.85)--(2.5,-.85)node[right]{$\sigma=0$};
\draw[thick,densely dotted] (4,-.85)--(4.5,-.85)node[right]{$\sigma=1$};
\end{tikzpicture}
\end{document}
'''
p=R/'figuras_edicion/FPM-I-30-F18_compacto_v04.tex';p.write_text(header+code)
with tempfile.TemporaryDirectory(prefix='fpm_f18_',dir='/tmp')as tmp:
 w=Path(tmp);shutil.copy2(p,w/p.name);r=subprocess.run(['xelatex','-halt-on-error','-interaction=nonstopmode',p.name],cwd=w,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);assert r.returncode==0,r.stdout[-1200:];shutil.copy2(w/p.with_suffix('.pdf').name,p.with_suffix('.pdf'))
p=R/'chapters/c30.tex';s=p.read_text().replace('figuras_edicion/FPM-I-30-F18.pdf','figuras_edicion/FPM-I-30-F18_compacto_v04.pdf');p.write_text(s)
print('Original F18: same analytic data in a compact vector composition')

from pathlib import Path
R=Path(__file__).resolve().parents[2];p=R/'scripts/ampliar_figuras_v04.py';s=p.read_text();lines=s.splitlines()
newcodes={
"add(8,'Tiro parabólico'":r'''s=axes((-.2,4.5),(-.4,2.8),'$x$','$y$')+curve(lambda t:(t,2*t-.5*t*t),0,4)+line((2,0),(2,2),'thin,dashed')+r'\fill(2,2)circle(2pt);'+node(2.9,2.45,'$t=2$')+node(1.4,1,'$2$')+node(4,-.4,'$4$')+node(2,-.8,'alcance')''',
"add(9,'Tercera ley'":r'''s=box(-1.7,0,1,.7,'$A$')+box(1.7,0,1,.7,'$B$')+r'\draw[dashed,rounded corners](-2.5,-1.1)rectangle(2.5,.9);'+arrow((-1.7,.6),(-.3,.6),r'$f$','above left')+arrow((1.7,.6),(.3,.6),r'$-f$','above right')+arrow((2.2,0),(3.6,0),r'$F_{\rm ext}$','above')+node(0,-.65,'sistema $A+B$')''',
"add(12,'Trabajo de una fuerza variable'":r'''s=graph([(lambda x:1+x,'thick')],0,2,(0,3.2),'$x$','$F$',shade=(lambda x:1+x,0,2))+arrow((.3,-.8),(4.7,-.8),'$W=4$','below')+arrow((4.7,-1.8),(.3,-1.8),'$W=-4$','below','thin,dashed')'''
}
for i,l in enumerate(lines):
 for prefix,code in newcodes.items():
  if l.startswith(prefix):assert lines[i-1].startswith('s=');lines[i-1]=code
s='\n'.join(lines)+'\n'
changes=[
('En el tiro ideal $r(t)=(t,2t-t^2/2)$, la aceleración es $(0,-1)$ y la velocidad es $(1,2-t)$. La flecha vertical representa aceleración; no es un diagrama de fuerzas.',r'En el tiro ideal $r(t)=(t,2t-t^2/2)$, la altura máxima es $2$ en $t=2$. El retorno al nivel inicial ocurre en $t=4$, con alcance $4$. El segmento discontinuo mide altura y las coordenadas están normalizadas.'),
('En una interacción atractiva entre $A$ y $B$, las fuerzas son opuestas y tienen receptores diferentes. Se cancelan en el balance del sistema compuesto, no en el diagrama individual de cada cuerpo.',r'Las fuerzas internas $f$ y $-f$ se cancelan al sumar los balances de $A$ y $B$. La fuerza externa queda en $\dot P=F_{\rm ext}$. La frontera discontinua declara qué cuerpos se han incluido; cada balance individual conserva su fuerza interna.')
]
for old,new in changes:
 assert old in s;s=s.replace(old,new)
 for n in [8,9]:
  cp=R/f'chapters/c{n:02}.tex';txt=cp.read_text();txt=txt.replace(old,new);cp.write_text(txt)
p.write_text(s)

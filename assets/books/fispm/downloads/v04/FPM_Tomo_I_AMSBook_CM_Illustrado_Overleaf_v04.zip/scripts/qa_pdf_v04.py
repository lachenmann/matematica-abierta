from pathlib import Path
import fitz,re,json,collections,hashlib,subprocess
R=Path(__file__).resolve().parents[1];Q={};visual={}
for kind,folder,stem in [('A4','build_A4','main_A4_Lectura'),('Carta','build_Carta','main_Carta_Impresion')]:
 d=fitz.open(R/folder/(stem+'.pdf'));a=(R/folder/(stem+'.aux')).read_text();log=(R/folder/(stem+'.log')).read_text();toc=d.get_toc();ch=[a for a in toc if a[0]==1 and a[1].startswith('Capítulo')];num_offset=ch[0][2]-1
 figlabels={m[1]:{'number':m[2],'printed_page':m[3],'pdf_page':int(m[3])+num_offset} for m in re.finditer(r'\\newlabel\{(fig:[^}]+)\}\{\{([^}]+)\}\{([^}]+)\}',a)}
 blanks=[];outside=[];sizes=set();badglyph=[];fontset=set();image_pages=[];links=collections.Counter();badlinks=[];words=0;caption_count=0
 for p in d:
  sizes.add(tuple(round(v,2) for v in (p.rect.width,p.rect.height)));text=p.get_text();words+=len(text.split());caption_count+=len(re.findall(r'Figura \d+\.\d+\.',text));
  if not text.strip():blanks.append(p.number+1)
  if '\ufffd' in text or '\u25a1' in text:badglyph.append(p.number+1)
  for b in p.get_text('dict')['blocks']:
   if 'lines' not in b:continue
   for l in b['lines']:
    for s in l['spans']:
     fontset.add(s['font']);rect=fitz.Rect(s['bbox'])
     if s['text'].strip() and (rect.x0<33 or rect.y0<33 or rect.x1>p.rect.width-33 or rect.y1>p.rect.height-33):outside.append({'page':p.number+1,'rect':list(rect),'text':s['text'][:60]})
  for k in p.get_links():
   links[k['kind']]+=1
   if k['kind']==fitz.LINK_GOTO and not 0<=k['page']<len(d):badlinks.append(p.number+1)
  if p.get_images():image_pages.append(p.number+1)
 # Determine warning pages from TeX shipment markers.
 over=[]
 for m in re.finditer(r'Overfull \\vbox \(([^)]+)\)[\s\S]*?(?=\n\n|$)',log):
  prev=list(re.finditer(r'\[(\d+)\]',log[:m.start()]));nextp=re.search(r'\[(\d+)\]',log[m.end():]);pp=int(nextp[1]) if nextp else int(prev[-1][1])+1
  over.append({'warning':m[0].split('\n')[0],'printed_page_approx':pp,'pdf_page_approx':pp+num_offset})
 q={'pages':len(d),'page_sizes_pt':list(sizes),'chapter_bookmarks':len(ch),'chapters':ch,'figure_labels':figlabels,'figure_label_count':len(figlabels),'caption_count':caption_count,'blank_pages':blanks,'blank_pages_explained':all(x+1 in {c[2] for c in ch} for x in blanks),'out_of_33pt_safe_margins':outside,'bad_replacement_glyph_pages':badglyph,'fonts':sorted(fontset),'links_by_kind':dict(links),'invalid_internal_link_pages':badlinks,'missing_glyph_warnings':log.count('Missing character:'),'overfull_hbox_warnings':log.count('Overfull \\hbox'),'overfull_vbox_warnings':over,'undefined_reference_warnings':len(re.findall(r'(?:Reference|Citation).*undefined',log)),'label_rerun_warning':'Label(s) may have changed' in log,'tex_errors':len(re.findall(r'^!|LaTeX Error:|Package .* Error:',log,re.M)),'words_extracted':words}
 Q[kind]=q
 figpages=sorted({x['pdf_page'] for x in figlabels.values()});newfigpages=sorted({v['pdf_page'] for k,v in figlabels.items() if k.startswith('fig:I-')});chapterpages=[x[2] for x in ch]
 sample=sorted(set([1,2,3,len(d)]+[i for i in range(40,len(d),73)]+[max(1,c[2]+3) for c in ch]));problem=sorted({p['pdf_page_approx'] for p in over})
 visual[kind]={'all_figure_pages':figpages,'new_figure_pages':newfigpages,'chapter_opening_pages':chapterpages,'additional_sample_pages':sample,'vertical_warning_pages_approx':problem,'review_pages':sorted(set(figpages+chapterpages+sample+problem))}
 print(kind,len(d),'chapter',len(ch),'figures',len(figlabels),'figpages',len(figpages),'blanks',len(blanks),'outside',len(outside),'warnings',len(over),'rerun',q['label_rerun_warning'])
 (R/'auditoria'/('FUENTES_'+kind+'_v04.txt')).write_text(subprocess.check_output(['pdffonts',str(R/folder/(stem+'.pdf'))]).decode())
(R/'auditoria/QA_PDF_MECANICO_v04.json').write_text(json.dumps(Q,ensure_ascii=False,indent=2))
(R/'auditoria/PLAN_REVISION_VISUAL_v04.json').write_text(json.dumps(visual,ensure_ascii=False,indent=2))

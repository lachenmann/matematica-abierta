"""Editable vector illustrations. Coordinates computed from explicit analytic models.
Run from project root: python3 scripts/figures_v03.py
Then: python3 scripts/build_figures.py
"""
from pathlib import Path
import math,json
from math import sin,cos,pi,sqrt,exp,atan
ROOT=Path(__file__).resolve().parents[1]; FD=ROOT/'figuras_nuevas';FD.mkdir(exist_ok=True)
DATA=[]
def arrow(a,b,l='',pos='above',style='thick'):
 return f'\\draw[->,{style}] ({a[0]},{a[1]}) -- ({b[0]},{b[1]})'+(f' node[{pos}] {{{l}}}' if l else '')+';\n'
def node(x,y,s):return f'\\node at ({x},{y}) {{{s}}};\n'
def line(a,b,style=''):return f'\\draw[{style}] ({a[0]},{a[1]}) -- ({b[0]},{b[1]});\n'
def curve(fun,a,b,N=121,style='thick'):
 pts=[fun(a+(b-a)*i/(N-1)) for i in range(N)]
 assert all(math.isfinite(x) and math.isfinite(y) for x,y in pts)
 return '\\draw['+style+'] plot coordinates {'+' '.join(f'({x:.5f},{y:.5f})' for x,y in pts)+'};\n'
def axes(x=(-.2,4),y=(-.2,2.5),xl='$x$',yl='$y$'):
 return arrow((x[0],0),(x[1],0),xl,'right','thin')+arrow((0,y[0]),(0,y[1]),yl,'above','thin')+node(-.14,-.18,'$0$')
def graph(fs,a,b,yr,xl,yl,notes='',shade=None):
 # linear coordinate maps; y=0 and x=0 retained; analytic domain stated in caption
 sx=5/(b-a);sy=2.5/(yr[1]-yr[0]);
 def tr(x,y):return ((x-a)*sx,(y-yr[0])*sy)
 out=arrow((0,-yr[0]*sy),(5.35,-yr[0]*sy),xl,'right','thin')+arrow((-a*sx,0),(-a*sx,2.85),yl,'above','thin')
 for i,(f,sty) in enumerate(fs):out+=curve(lambda t:tr(t,f(t)),a,b,161,sty)
 if shade:
  f,aa,bb=shade;pts=[tr(aa+(bb-aa)*i/80,f(aa+(bb-aa)*i/80)) for i in range(81)];pts+=[tr(bb,0),tr(aa,0)]
  out+='\\fill[black,opacity=.08] '+' -- '.join(f'({x:.4f},{y:.4f})' for x,y in pts)+' -- cycle;\n'
 for x in sorted(set([a,0,b])):
  if a<=x<=b:
   xx,yy=tr(x,0);out+=line((xx,yy-.06),(xx,yy+.06))+node(xx,yy-.25,f'${ticklabel(x)}$')
 for y in [yr[0],yr[1]]:
  if y:out+=node(-a*sx-.35,(y-yr[0])*sy,f'${ticklabel(y)}$')
 return out+(node(2.5,3.25,notes) if notes else '')
def ticklabel(v):
 if abs(v-pi)<1e-9:return r'\pi'
 if abs(v-2*pi)<1e-9:return r'2\pi'
 return f'{v:g}'
def box(x,y,w=1,h=.6,label='$m$'):
 return f'\\draw[fill=white] ({x-w/2},{y-h/2}) rectangle ({x+w/2},{y+h/2});\n'+node(x,y,label)
def spring(a,b,y=0):
 out=line((a,y),(a+.2,y));N=12;pts=[(a+.2,y)]+[(a+.2+(b-a-.4)*i/N,y+(.12 if i%2 else -.12)) for i in range(1,N)]+[(b-.2,y),(b,y)]
 return out+'\\draw '+' -- '.join(f'({x:.3f},{yy:.3f})' for x,yy in pts)+';\n'
def dcl(forces,context='',extra=''):
 # No velocity, acceleration or fictitious ma arrow in these isolated-body diagrams.
 out='\\fill (0,0) circle (2pt);\n'
 for x,y,l,pos in forces:out+=arrow((0,0),(x,y),l,pos,'very thick')
 return out+(node(0,2.15,context) if context else '')+extra

def add(ch,key,title,caption,code,model,assumptions='Coordenadas normalizadas salvo rótulo explícito; trazos continuos y discontinuos distinguen curvas sin depender del color.'):
 num=1+sum(d['chapter']==ch for d in DATA);fid=f'I-{ch:02}-R{num:02}'
 if fid=='I-04-R04':
  code=code.replace('node[above left] {$r$}', 'node[pos=.4,above left] {$r$}').replace(r'node[above] {$r^{\prime}$}',r'node[pos=.8,above right] {$r^{\prime}$}')

 if fid=='I-04-R04':
  code=code.replace(r' node[pos=.8,above right] {$r^{\prime}$}', '')
  code+=r'\node at (3.5,2.4) {$r^{\prime}$};'+'\n'
 if fid=='I-12-R02':code=code.replace('(0,0.35) -- (1,0.35)', '(0.5,0.35) -- (1.7,0.35)')
 if fid=='I-04-R05':code=code.replace('(0,3.2)', '(0,3.7)')
 if fid=='I-05-R02':code=code.replace('(1.3,2.8)', '(1.9,3.6)')

 txt=r'''\documentclass[11pt,border=5pt]{standalone}
\usepackage{fontspec}
\setmainfont{cmunrm.otf}[BoldFont=cmunbx.otf,ItalicFont=cmunti.otf,BoldItalicFont=cmunbi.otf]
\usepackage{amsmath}
\usepackage{unicode-math}
\setmathfont{NewCMMath-Regular.otf}
\usepackage{tikz}
\usetikzlibrary{arrows.meta,patterns,angles,quotes}
\begin{document}
\begin{tikzpicture}[>=Stealth,font=\small,line cap=round,line join=round]
'''+code+'\n\\end{tikzpicture}\n\\end{document}\n'
 (FD/(fid+'.tex')).write_text(txt)
 DATA.append(dict(id=fid,chapter=ch,concept=title,section_keyword=key,caption=caption,model=model,assumptions=assumptions,source=f'figuras_nuevas/{fid}.tex',pdf=f'figuras_nuevas/{fid}.pdf',generator='scripts/ampliar_figuras_v04.py',qa='Analítico: fórmula, dominio y signos cotejados; revisión visual registrada separadamente.'))
# The following exact examples supply geometric support to the named sections.
# 1
s=axes((-.2,4),(-.3,2.8),'$t$','$x$')+curve(lambda t:(t,2*t*t/9),0,3.5)+arrow((1,2/9),(1.8,2/9+3.2/9),'$v$','above')+node(2,-.7,r'$x(t)=t^2/,4{,}5$')
add(1,'Una pregunta física','Historia, estado y pregunta física',r'Una curva de posición contiene una historia cinemática. La tangente expresa velocidad; para explicar por qué cambia hacen falta interacciones y un modelo dinámico. El ejemplo usa $x=t^2/4{,}5$ en unidades normalizadas.',s,'x(t)=2t²/9; vector tangente proporcional a (1,4t/9); t>=0.')
s=graph([(lambda t:exp(-t),'thick'),(lambda t:1-t,'thick,dashed')],0,2,(-1,1.1),'$u$','$y$')
add(1,'Idealización','Modelo exacto y aproximación local',r'Las expresiones normalizadas $e^{-u}$ y $1-u$ comparten valor y derivada en $u=0$. La segunda sirve localmente y se vuelve negativa para $u>1$; esa extrapolación puede contrariar el significado físico de una cantidad positiva.',s,'Exponencial y Taylor de orden uno; 0<=u<=2.')
s=axes((-.2,4),(-1.1,1.2),'$u$','$r$')+curve(lambda t:(t,.4*sin(pi*t)),0,3.5)+node(2,1.4,r'$r=y_{\rm obs}-y_{\rm mod}$')
add(1,'Cómo se elige','Los residuos conservan información',r'El residuo es la diferencia entre la observación y la predicción. Un patrón oscilatorio persistente puede señalar estructura que el modelo no representa. La curva es un esquema de diagnóstico, no una prueba estadística de rechazo.',s,'Esquema r(u)=.4 sin(pi u); no se asignan probabilidades.')
s=axes((-.2,4),(-.2,2.5),r'$\varepsilon$','$u$')+r'\fill[pattern=north east lines,pattern color=gray] (0,0) rectangle (1.2,2);\draw[dashed] (1.2,0)--(1.2,2.4);'+node(.6,1,r'régimen')+node(2.6,1,r'extrapolación')
add(1,'Dominio de validez','El dominio pertenece al modelo',r'Las condiciones de régimen seleccionan una parte del espacio de parámetros. Extender una fórmula fuera de esa región exige una justificación nueva. La frontera vertical es esquemática y no representa un umbral universal.',s,'Diagrama cualitativo de dos parámetros adimensionales.')
s=box(-2,0,2.1,.7,'hipótesis')+arrow((-.9,0),(.4,0),'')+box(1.6,0,2.2,.7,'predicción')+node(1.6,-1.1,'contraste con datos')+arrow((1.6,-.4),(1.6,-.8))+arrow((.4,-1.1),(-2,-.4),'revisión','below','thin,dashed')
add(1,'Cuando una predicción','El contraste puede revisar varias piezas',r'Una discrepancia motiva revisar hipótesis, condiciones iniciales y procedimiento de observación. El esquema no adjudica por sí solo el fallo a una ley fundamental.',s,'Flujo lógico de contraste, sin equivalencia causal entre sus etapas.')
s=graph([(lambda t:t*t,'thick')],0,1,(0,1.1),'$u$','$y$')+node(3.5,2.2,r'$y=u^2$')
add(1,'Exactitud matemática','Exactitud interna y significado físico',r'La igualdad $y=u^2$ define exactamente la curva dibujada. Su uso como ley de un fenómeno requiere declarar qué representan $u$ e $y$, cómo se miden y dónde se ha contrastado la relación.',s,'Parábola exacta en variables adimensionales; no se afirma una ley empírica.')
# 2
s=node(2,1.3,r'$x=2\,{\rm m}=200\,{\rm cm}$')+line((.4,.5),(3.5,.5),'thick')+node(.4,.15,'$0$')+node(3.5,.15,r'$2\,{\rm m}$')
add(2,'Magnitudes, clases','Magnitud y representación numérica',r'Cambiar de metros a centímetros multiplica por cien el valor numérico y divide por cien la unidad empleada. El segmento físico representado permanece igual: $2\,\mathrm m=200\,\mathrm{cm}$.',s,'Cambio de unidad exacto m↔cm; segmento de longitud 2 m.')
s=line((0,0),(0,-2.1))+line((0,0),(1.3,-1.65),'thick')+r'\fill (1.3,-1.65) circle (3pt);\draw (0,-.6) arc(-90:-52:0.6);'+node(.4,-.7,r'$\theta$')+node(1,-.7,r'$\ell$')+node(3,-1,r'$T=\sqrt{\ell/g}\,\Phi(\theta_0)$')
add(2,'Dimensión física','La dimensión fija una escala, no una función',r'Para un péndulo ideal, el análisis de dimensiones permite escribir $T=\sqrt{\ell/g}\,\Phi(\theta_0)$. No determina la función de la amplitud. En oscilaciones pequeñas, la dinámica da $\Phi(0)=2\pi$.',s,'Péndulo ideal; amplitud angular adimensional; límite de pequeña amplitud.')
s=r'\draw (0,0) rectangle (1,1);\draw (2,0) rectangle (4,2);'+node(.5,-.4,'$L$')+node(3,-.4,'$2L$')+node(.5,1.5,'$A$')+node(3,2.5,'$4A$')
add(2,'Semejanza, escalamiento','La escala lineal no es la escala de área',r'En figuras semejantes, duplicar todas las longitudes multiplica el área por cuatro y el volumen por ocho. La comparación exige conservar la forma; el dibujo ilustra la relación de áreas.',s,'Cuadrados de lados L y 2L; áreas L² y 4L².')
s=axes((-.2,3.2),(-.2,2.8),'$x$','$y$')+r'\draw[thick] (0,0)--(2,0) arc(0:57.2958:2)--cycle;'+node(1.15,.4,'$1$ rad')+node(2.2,1.3,'$s=R$')+node(1,-.4,'$R$')
add(2,'Cantidades de dimensión uno','El ángulo como razón geométrica',r'En radianes, $\theta=s/R$. Un arco de longitud igual al radio determina un radián. Ser una razón de longitudes no vuelve intercambiables el ángulo y cualquier otra cantidad de dimensión uno.',s,'Sector circular de radio2; ángulo1 rad; arco2.')
s=graph([(lambda u:u*u,'thick')],0,2,(0,4.2),r'$\lambda$',r'$\lambda^2$')+node(3,2.5,r'área relativa')
add(2,'Adimensionalización','Comparar usando referencias declaradas',r'Si $L=L_*\lambda$, una familia de áreas semejantes satisface $A/A_*=\lambda^2$. Ambas razones son adimensionales; su interpretación conserva las referencias físicas $L_*$ y $A_*$.',s,'A*=L*² para cuadrados; relación exacta en λ>=0.')
s=node(0,1.1,r'$[v]=LT^{-1}$')+node(3,1.1,r'$[g]=LT^{-2}$')+node(1.5,0,r'$\Pi=\dfrac{v}{\sqrt{g\ell}}$')+node(1.5,-1,r'$[\Pi]=1$')
add(2,'El teorema','Un grupo adimensional explícito',r'Con las magnitudes $v$, $g$ y $\ell$, la combinación $\Pi=v/\sqrt{g\ell}$ tiene dimensión uno. El control dimensional no fija su valor ni garantiza que esas tres magnitudes describan por completo el fenómeno.',s,'v dimensiónLT^-1,gLT^-2,ℓL; g,ℓ>0.')
# 3
s=axes((-.2,5),(-.2,1.8),'$x$','')
for x in range(5):s+=line((x,0),(x,.25),'thick')
s+=r'\draw[<->] (1,.8)--(2,.8);'+node(1.5,1.1,r'$\Delta$')+r'\draw[dashed] (1.43,0)--(1.43,.55);'
add(3,'Instrumentos, escalas','La resolución delimita la lectura',r'Las marcas vecinas están separadas por $\Delta$. La posición entre marcas exige un procedimiento de lectura y una evaluación de incertidumbre; la resolución no determina por sí sola toda la incertidumbre de la medición.',s,'Escala uniforme; no se impone una distribución de error.')
s=axes((-.2,5),(-.2,2.7),'$x$','densidad relativa')
for mu,st in [(1.5,'thick'),(3.3,'thick,dashed')]:s+=curve(lambda x:(x,2*exp(-((x-mu)/.45)**2)),0,4.7,style=st)
s+=line((1.5,0),(1.5,2.4),'thin,dotted')+node(1.5,-.4,'referencia')
add(3,'Error, sesgo','Dispersión y sesgo responden a preguntas distintas',r'Dos distribuciones de igual anchura pueden estar centradas en lugares diferentes. La curva discontinua representa una serie desplazada respecto de la referencia. La anchura ilustra dispersión; el desplazamiento de su centro ilustra sesgo.',s,'Perfiles gaussianos esquemáticos con igual varianza; medias1.5 y3.3.')
s=graph([(lambda x:x*x,'thick')],-1,2,(0,4.2),'$x$','$x^2$')+node(3.8,2.9,r'$\overline{x^2}\ne\bar x^{,2}$')
add(3,'Propagación mediante','Una transformación no lineal cambia los promedios',r'Para datos simétricos $x=\pm a$, la media de $x$ es cero y la de $x^2$ vale $a^2$. Transformar la media y promediar los valores transformados son operaciones distintas. La derivada nula en el origen no elimina esta variación de segundo orden.',s,'Datos±a con igual peso; promedioexacto; funcióny=x².')
s=graph([(lambda x:1/x,'thick')],.3,2,(0,3.5),'$X$','$Y$')+node(3.4,2.6,r'$Y=1/X$')
add(3,'Cómo se reporta','La transformación puede volver asimétrico un intervalo',r'Un intervalo $X\in[1/2,3/2]$ se transforma bajo $Y=1/X$ en $Y\in[2/3,2]$. Sus extremos quedan a distancias diferentes de $Y(1)=1$. El ejemplo es un intervalo de valores admisibles, sin asignación de probabilidad.',s,'X>0; funciónmonótonadecreciente; extremos exactos .5,1.5.')
s=axes((-.2,5),(-.2,2.5),'resultado normalizado','')+line((1,.7),(3,.7),'thick')+line((2,1.7),(4.5,1.7),'thick')+r'\fill (2,.7) circle(2pt);\fill(3.25,1.7) circle(2pt);'+node(.6,.7,'$A$')+node(.6,1.7,'$B$')
add(3,'Incertidumbre relativa','Comparar intervalos exige una regla',r'Los dos intervalos dibujados se solapan. Ese hecho geométrico no equivale por sí solo a una prueba de compatibilidad estadística: hacen falta el significado de las barras, las correlaciones y el criterio declarado.',s,'IntervalosA=[1,3],B=[2,4.5]; puntoscentrales2y3.25; sinnivelconfianza.')
# 4
s=axes((-.3,3.6),(-.3,2.8))+arrow((0,0),(2,0),'$u$','below')+arrow((2,0),(3,2),'$v$','right')+arrow((0,0),(3,2),'$u+v$','above left')+line((0,0),(1,2),'dashed')+line((1,2),(3,2),'dashed')
add(4,'La estructura afín','La composición de desplazamientos',r'Si $u=\overrightarrow{AB}$ y $v=\overrightarrow{BC}$, entonces $u+v=\overrightarrow{AC}$. El paralelogramo compara la composición de desplazamientos con su representación vectorial.',s,'u=(2,0),v=(1,2); reglaafín exacta.')
s=axes((-.3,3.5),(-.3,2.5))+arrow((0,0),(2.5,1.8),'$v$','above')+arrow((0,0),(2.5,0),r'$v_{\parallel}$','below')+line((2.5,0),(2.5,1.8),'dashed')+r'\draw(2.3,0)--(2.3,.2)--(2.5,.2);'
add(4,'Proyecciones, ángulos','Proyectar conserva una componente',r'La proyección ortogonal sobre el eje horizontal es $v_\parallel=(v\cdot e_1)e_1$. El residuo perpendicular no desaparece del vector: $v=v_\parallel+v_\perp$.',s,'v=(2.5,1.8), e1=(1,0); productoeuclídeo.')
s=axes((-.3,3.5),(-.3,2.7),'$e_1$','$e_2$')+r'\draw[thick] (.2,.2) circle(.18);\fill(.2,.2) circle(1pt);'+node(1.6,1.6,r'$e_1\times e_2=e_3$')+node(1.6,.9,'$e_3$: hacia el lector')
add(4,'Producto vectorial','El orden fija la orientación',r'En una base ortonormal positivamente orientada, $e_1\times e_2=e_3$. El punto dentro del círculo indica una dirección que sale del papel; invertir los factores invierte ese vector.',s,'Baseortonormalderecha; convenióndepunto saliente.')
s=axes((-.3,3.5),(-.3,2.7))+arrow((1,.6),(3,2.3),r'$r^{\prime}$','above')+arrow((0,0),(3,2.3),'$r$','above left')+arrow((0,0),(1,.6),'$a$','above left')+node(1,.1,"$O'$" )
add(4,'Cambios de origen','Una traslación cambia la posición representada',r'Para orígenes separados por $a=\overrightarrow{OO^\prime}$ y bases iguales, los vectores de posición cumplen $r=a+r^\prime$. El punto físico y las diferencias entre puntos permanecen iguales.',s,'a=(1,.6), r=(3,2.3), r′=(2,1.7); ejesparalelos.')
s=axes((-2.5,2.5),(-.2,2.8))+arrow((0,0),(1.6,1.8),'$v$','right')+arrow((0,0),(-1.6,1.8),'$Sv$','left')+node(0,3.2,r'$S=\mathrm{diag}(-1,1)$')
add(4,'Rotaciones, reflexiones','Una isometría puede invertir la orientación',r'La reflexión $S(x,y)=(-x,y)$ conserva longitudes y ángulos y tiene determinante $-1$. Por ello no es una rotación propia del plano.',s,'S^TS=I,detS=-1; vectores(±1.6,1.8).')
# 5
s=axes((-.2,4),(-.2,3),'$x$','$y$')+curve(lambda u:(u,.2*u*u),0,3.5)+arrow((2,.8),(3,1.6),'$v$','right')+arrow((2,.8),(2,1.6),'$a$','left')
add(5,'Aceleración como','Velocidad tangente y aceleración',r'Para $r(u)=(u,u^2/5)$, la velocidad es $(1,2u/5)$ y la aceleración es $(0,2/5)$. La aceleración no tiene por qué ser paralela a la trayectoria ni a la velocidad.',s,'Curvaparametrizadaexacta; flechasv escalada1ya escalada2;u=2.')
s=axes((-2.4,2.4),(-.2,2.8),'$x$','$y$')+curve(lambda u:(u**3,u*u),-1.25,1.25)+node(1.3,2.8,r'$r(u)=(u^3,u^2)$')
add(5,'Tangente, regularidad','Un instante singular del parámetro',r'La curva $r(u)=(u^3,u^2)$ tiene $r^\prime(0)=0$. La fórmula del vector tangente unitario $r^\prime/\lVert r^\prime\rVert$ no está definida allí. El ejemplo obliga a comprobar regularidad antes de usar esa expresión.',s,'u∈[-1.25,1.25]; cúspideexactaenorigen.')
s=graph([(lambda u:u,'thick'),(lambda u:u*u,'thick,dashed')],0,1,(0,1.1),'$u$','$s$')
add(5,'Reparametrización','Dos relojes y una regla de derivación',r'Las leyes $s=u$ y $s=u^2$ recorren el mismo intervalo con velocidades distintas. Bajo un cambio $s=\phi(u)$, la derivada de $r(\phi(u))$ contiene el factor $\phi^\prime(u)$. En $u=0$, el segundo reloj deja de ser regular.',s,'φ(u)=u², u∈[0,1]; φ′(0)=0.')
s=axes((-.2,4),(-.2,3))+curve(lambda u:(u,.15*u*u),0,3.6)
pts=[(u,.15*u*u)for u in [0,.9,1.8,2.7,3.6]]
s+=r'\draw[dashed] '+' -- '.join(f'({x},{y})'for x,y in pts)+';'
add(5,'Fórmula de longitud','Longitud como límite de cuerdas',r'Las cuerdas de una partición aproximan la longitud de una curva regular. El límite es $\int\lVert r^\prime(u)\rVert\,du$; la norma se integra antes de confundirla con el desplazamiento entre extremos.',s,'r(u)=(u,.15u²),0<=u<=3.6; cuatrocuerdas.')
s=axes((-.2,4),(-.3,2.6),'$x$','$y$')+arrow((0,0),(2,1),'$r$','above')+arrow((1,-.1),(3,.9),r'$r^\prime$','below')+line((0,0),(1,-.1),'dashed')+line((2,1),(3,.9),'dashed')
add(5,'Marcos fijos','Trasladar la descripción conserva la velocidad',r'Entre marcos de igual base y orígenes separados por una constante, las posiciones difieren en esa constante. Derivarla da cero y las velocidades representadas coinciden. El dibujo compara vectores de posición, no dos fuerzas.',s,'Traslaciónespacialconstante; ejesfijosparalelos.')
# 6
s=graph([(lambda x:exp(-x/.1),'thick'),(lambda x:0,'thick,dashed')],0,1,(0,1.1),'$x$','$y$')
add(6,'Límite regular','Un límite puede fallar cerca de una frontera',r'La familia $y_\varepsilon=e^{-x/\varepsilon}$ converge a cero para cada $x>0$ y conserva $y_\varepsilon(0)=1$. La gráfica usa $\varepsilon=0{,}1$: la aproximación exterior $y=0$ no es uniforme en $[0,1]$.',s,'0<=x<=1, ε=.1; sup|yε|=1 para cada ε>0.')
s=graph([(lambda x:abs(exp(x)-1-x),'thick'),(lambda x:exp(1)*x*x/2,'thick,dashed')],-1,1,(0,1.5),'$x$','error y cota')
add(6,'Resto de Taylor','Una cota necesita su dominio',r'En $|x|\le1$, el resto de $e^x\approx1+x$ satisface $|e^x-1-x|\le(e/2)x^2$. La cota discontinua usa el máximo de la segunda derivada en ese intervalo.',s,'TaylorLagrange exacto; maxe^ξ=e en[-1,1].')
s=graph([(lambda u:u,'thick'),(lambda u:.1*u*u,'thick,dashed')],0,15,(0,23),'$u$','términos')
add(6,'Términos dominantes','El término dominante puede cambiar',r'Los términos $u$ y $\varepsilon u^2$, con $\varepsilon=0{,}1$, son iguales en $u=10$. El segundo es pequeño respecto del primero sólo si $\varepsilon u\ll1$, aunque $\varepsilon$ sea pequeño.',s,'Comparaciónexacta u y .1u²; u>=0.')
s=axes((-.2,4),(-.2,2.5),'$u$','error relativo')+curve(lambda u:(u,.03*u*u),0,3.8)+line((0,.2),(4,.2),'dashed')+node(2.4,1.7,r'$\varepsilon u^2$')
add(6,'Coherencia a posteriori','Comprobar el tamaño después de resolver',r'Un residuo modelo $\varepsilon u^2$ debe compararse con una tolerancia declarada a lo largo de la solución. Aquí $\varepsilon=0{,}03$ y la línea discontinua vale $0{,}2$; el umbral se alcanza en $u=\sqrt{20/3}$.',s,'Residuo normalizado .03u²; tolerancia .2; no ecuacióndinámicaparticular.')
# 7-13
s=graph([(lambda t:1 if t<=1 else 2-t,'thick')],0,3,(-1.1,1.2),'$t$','$v$')
add(7,'Historias definidas','Una velocidad continua con cambio de aceleración',r'La ley $v=1$ hasta $t=1$ y $v=2-t$ después es continua. La aceleración cambia de $0$ a $-1$ en el empalme y no tiene allí un valor clásico único. No hay salto de posición ni impulso requerido por un salto de velocidad.',s,'v continua portramos, t∈[0,3]; aceleraciónunilateral.')
s=graph([(lambda t:t,'thick'),(lambda t:1+t,'thick,dashed')],0,2,(0,3.2),'$t$','$x$')
add(7,'Problemas inversos','La velocidad no determina el origen de posición',r'Las historias $x=t$ y $x=1+t$ comparten velocidad y aceleración. Para seleccionar una de ellas hace falta un dato de posición. Todas las variables del ejemplo están normalizadas.',s,'Dos primitivas dev=1; diferenciaconstante1.')
s=axes((-.2,4.5),(-.4,2.8),'$x$','$y$')+curve(lambda t:(t,2*t-.5*t*t),0,4)+line((2,0),(2,2),'thin,dashed')+r'\fill(2,2)circle(2pt);'+node(2.9,2.45,'$t=2$')+node(1.4,1,'$2$')+node(4,-.4,'$4$')+node(2,-.8,'alcance')
add(8,'Tiro parabólico','La aceleración permanece vertical',r'En el tiro ideal $r(t)=(t,2t-t^2/2)$, la altura máxima es $2$ en $t=2$. El retorno al nivel inicial ocurre en $t=4$, con alcance $4$. El segmento discontinuo mide altura y las coordenadas están normalizadas.',s,'g=1,vx0=1,vy0=2; suelo y=0;t∈[0,4]; flechas escaladas. ')
s=axes((-.2,3.4),(-.2,2.9))+arrow((0,0),(2,1),'$e_r$','right')+arrow((2,1),(1.4,2.2),r'$e_\theta$','above')+node(2,3.5,r'$\dot e_r=\dot\theta e_\theta$')
add(8,'Coordenadas polares','La base polar también se deriva',r'La base ortonormal polar gira con el ángulo: $\dot e_r=\dot\theta e_\theta$ y $\dot e_\theta=-\dot\theta e_r$. Las flechas muestran sus direcciones; su longitud es esquemática.',s,'θ=atan(.5); eθ perpendicularpositivoaer.')
s=box(-1.7,0,1,.7,'$A$')+box(1.7,0,1,.7,'$B$')+r'\draw[dashed,rounded corners](-2.5,-1.1)rectangle(2.5,1.4);'+arrow((-1.7,.6),(-.3,.6),r'$f$','above left')+arrow((1.7,.6),(.3,.6),r'$-f$','above right')+arrow((2.2,0),(3.6,0),r'$F_{\rm ext}$','above')+node(0,-.65,'sistema $A+B$')
add(9,'Tercera ley','La pareja actúa sobre cuerpos distintos',r'Las fuerzas internas $f$ y $-f$ se cancelan al sumar los balances de $A$ y $B$. La fuerza externa queda en $\dot P=F_{\rm ext}$. La frontera discontinua declara qué cuerpos se han incluido; cada balance individual conserva su fuerza interna.',s,'Parejacentralatractiva; flechasdeigualmódulo.')
s=axes((-.2,4),(-.2,2.8),'$x$','$v$')+curve(lambda u:(u,1),0,3.5)+curve(lambda u:(u,2),0,3.5,style='thick,dashed')+arrow((1,1),(1.8,1),'','above')+arrow((1,2),(2.3,2),'','above','thick,dashed')
add(9,'Estado, ecuación','El estado incluye posición y velocidad',r'En el movimiento libre, cada recta horizontal del plano $(x,v)$ conserva una velocidad. Conocer sólo $x$ deja muchos estados posibles; especificar $(x_0,v_0)$ selecciona una trayectoria del sistema de primer orden.',s,'xdot=v,vdot=0; ramasv=1y2; flechaspositivas.')
s=axes((-.2,3.8),(-.2,2.5),'separación $h$','normal $N$')+line((0,0),(0,2),'very thick')+line((0,0),(3.4,0),'very thick')+node(2,1.5,r'$h\ge0,\ N\ge0,\ hN=0$')
add(10,'Contacto normal','La normal no puede tirar del cuerpo',r'Para un contacto unilateral ideal no adhesivo, la separación y la normal satisfacen $h\ge0$, $N\ge0$ y $hN=0$. Los estados admisibles están sobre los ejes: contacto con reacción o separación sin reacción.',s,'Complementariedadideal; sinadhesión; ejesnormalizados.')
s=axes((-2.5,2.5),(-.2,2.7),'$f$','$N$')+line((0,0),(1.2,2.4),'thick')+line((0,0),(-1.2,2.4),'thick')+r'\fill[black,opacity=.06] (0,0)--(1.2,2.4)--(-1.2,2.4)--cycle;'+node(0,3.6,r'$|f_s|\le\mu_s N$')
add(10,'Plano inclinado y umbrales','La fricción estática tiene un conjunto admisible',r'Para $\mu_s=1/2$, la cuña representa $|f_s|\le N/2$ y $N\ge0$. En el interior la fricción se ajusta al equilibrio; la frontera corresponde al umbral del modelo de Coulomb.',s,'Conodefricciónenunacomponentetangencial; μs=.5.')
s=dcl([(0,1.25,'$T$','right'),(0,-1.65,'$m_1g$','right')],'')+r'\begin{scope}[xshift=3cm]'+dcl([(0,1.25,'$T$','right'),(0,-.85,'$m_2g$','right')],'')+r'\end{scope}'+node(0,-2.2,'$m_1$')+node(3,-2.2,'$m_2$')
add(11,'Cuerda sobre una polea fija','Dos DCL y una restricción',r'Con $m_1>m_2$, la máquina de Atwood ideal tiene una tensión común y aceleraciones opuestas. Los diagramas corresponden a cada masa por separado: $m_1g>T>m_2g$. La polea y la cuerda no se incluyen dentro de esos cuerpos.',s,'Poleafijasinmasa,nifricción,cuerdainextensible; flechascoherentesconm1>m2.')
s=axes((-.2,3.5),(-.2,2.5),'$x$','$y$')+r'\draw[thick] (0,0) circle(1.4);'+arrow((1.4,0),(1.4,1),'$v$','right')+arrow((1.4,0),(.5,0),'$N$','above')+node(0,-1.9,r'$v^2/R$ hacia el centro')
add(11,'Fuerzas de vínculo','La guía puede cambiar la dirección sin cambiar la rapidez',r'Una partícula en una guía circular fija y lisa puede tener reacción normal centrípeta, perpendicular a su velocidad. Si esa reacción es la única fuerza, su potencia es cero aunque cambie la dirección del movimiento.',s,'Guíabilateralcircular; partículaen(R,0);N=mv²/R.')
s=graph([(lambda x:1+x,'thick')],0,2,(0,3.2),'$x$','$F$',shade=(lambda x:1+x,0,2))+arrow((.3,-.8),(4.7,-.8),'$W=4$','below')+arrow((4.7,-1.8),(.3,-1.8),'$W=-4$','below','thin,dashed')
add(12,'Trabajo de una fuerza variable','El trabajo es un área firmada',r'Con $F(x)=1+x$ y desplazamiento desde $0$ hasta $2$, el trabajo normalizado vale $\int_0^2(1+x)\,dx=4$. Invertir el sentido de integración cambia su signo.',s,'F(x)=1+x; integralexacta4.')
s=line((-2,0),(2,0),'thick')+box(0,.35,1,.7,'$m$')+arrow((0,1.3),(1.7,1.3),'$v$','above','thin,dashed')+arrow((0,.35),(1,.35),'$F$','above','very thick')
add(12,'Trabajo de vínculos fijos','Un vínculo móvil puede suministrar energía',r'Una fuerza de vínculo tiene potencia $F\cdot v$ evaluada en el punto sobre el cuerpo. Cuando su punto de aplicación se mueve en la dirección de la fuerza, esa potencia puede ser positiva. No basta invocar idealidad para imponer trabajo nulo.',s,'Esquemadefuerzahorizontalypuntodeaplicaciónconvelocidadparalela; noleycompleta delmotor.')
s=axes((-2.3,2.3),(-.2,2.5),'$x$','$U$')+curve(lambda x:(x,.4*x*x),-2,2)+arrow((1.4,.784),(.7,.784),'$F$','above')+arrow((-1.4,.784),(-.7,.784),'$F$','above')
add(13,'Extremos no degenerados','La fuerza apunta hacia un mínimo cuadrático',r'Para $U=2x^2/5$, la fuerza es $F=-4x/5$. A ambos lados del mínimo apunta hacia el origen. Con masa positiva, la energía conserva las perturbaciones pequeñas dentro de niveles cercanos.',s,'Potencialquadráticopositivo; F=-U′; mínimoestableconservativo.')
s=axes((-2.3,2.3),(-2.3,2.3),'$x$','$y$')+r'\draw[thick] (0,0) circle(1.5);\draw[fill=white] (0,0) circle(.25);'+arrow((1.5,0),(1.5,.8),'$F$','right')+arrow((0,1.5),(-.8,1.5),'','above')+node(0,-2.9,r'$\oint F\cdot dr=2\pi$')
add(13,'Obstrucciones globales','El dominio perforado conserva una obstrucción',r'En $\mathbb R^2\setminus\{0\}$, el campo $F=(-y,x)/(x^2+y^2)$ tiene rotacional nulo localmente y circulación $2\pi$ en un círculo positivo. No admite allí un potencial escalar global monovaluado.',s,'Campovórticeexacto; círculoR1.5; curl=0r>0; circulación2π.')
# 14-29: one additional figure at a distinct physical bottleneck.
s=axes((-.2,4),(-.2,1.5),'$x$','')+box(.5,.5,.7,.5,'$m$')+box(2,.5,.7,.5,'$m$')+arrow((.5,1),(1.7,1),'$v$','above')+node(3,1,r'$e=1$')+node(2.1,-.6,'antes')
s+=r'\begin{scope}[yshift=-2.5cm]'+line((0,0),(4,0))+box(.5,.5,.7,.5,'$m$')+box(2,.5,.7,.5,'$m$')+arrow((2,1),(3.2,1),'$v$','above')+node(2,-.5,'después')+r'\end{scope}'
add(14,'Colisiones elásticas','Una colisión intercambia velocidades iguales',r'En una colisión elástica frontal de dos masas iguales, la masa incidente se detiene y la inicialmente quieta adquiere su velocidad. Se conservan momento y energía cinética; las viñetas comparan velocidades, con separaciones esquemáticas, sin resolver la fuerza de contacto.',s,'m1=m2,coeficienterestitucióne=1;v1=v,v2=0→v1′=0,v2′=v.')
s=axes((-.2,4),(-.2,2.8),'$x$','$y$')+arrow((3,.6),(3,2.6),'$F$','right')+line((0,0),(3,.6),'thick')+line((0,0),(3,0),'dashed')+r'\draw[<->] (0,-.5)--(3,-.5);'+node(1.5,-.85,'$d$')
add(15,'Torque y lugar','El brazo es la distancia a la línea de acción',r'La fuerza vertical tiene torque $\tau_z=dF$ respecto del origen. El brazo $d$ es la distancia perpendicular a su línea de acción, no la distancia desde el origen hasta el punto de aplicación.',s,'r=(3,.6),F=(0,F); d=3;torquepositivo.')
s=axes((-.2,5.4),(-.2,2.9),r'$r/R$',r'$|g|/(GM/R^2)$')+line((0,0),(5/3,0),'thick')+curve(lambda r:(5*r/3,2.5/(1.1*r*r)),1,3)+r'\draw[fill=white] (1.66667,0) circle(2pt);\draw[fill=white] (1.66667,2.27273) circle(2pt);'+node(5/3,-.4,'$1$')+node(5,-.4,'$3$')+node(-.35,2.27273,'$1$')
add(16,'Una cáscara','El campo cambia al cruzar una cáscara ideal',r'Una cáscara esférica homogénea infinitamente delgada produce campo nulo dentro y magnitud $GM/r^2$ fuera. La gráfica muestra los límites a cada lado; el campo sobre la superficie singular necesita una convención aparte.',s,'CáscaraidealradioR; curvaexteriorr>R; interior0; no asignacampoensuperficie.')
s=graph([(lambda r:.5/r**2-1/r,'thick')],.35,4,(-.6,1.5),'$r$',r'$U_{\rm ef}$')+node(3.5,1.9,r'$\mu=k=\ell=1$')+line((0,(.6-.25)*2.5/2.1),(5,(.6-.25)*2.5/2.1),'dashed')+node(3.3,.8,'$E=-1/4$')
add(17,'Cuadraturas y puntos','Los retornos se leen sobre el potencial efectivo',r'En el modelo $U_{\rm ef}=1/(2r^2)-1/r$, una energía $E=-1/4$ admite movimiento entre dos radios $r=2\pm\sqrt2$. La velocidad radial se anula allí; la componente angular puede permanecer distinta de cero.',s,'μ=k=ℓ=1; E=-.25;raícesexactas2±sqrt2.')
s=axes((-3.5,3),(-2,2),'$x$','$y$')+r'\draw[thick] (0,0) ellipse (2.7 and 1.8);\fill (-2.01246,0) circle(2pt);'+line((-2.01246,0),(2.7*cos(.35),1.8*sin(.35)),'thin')+line((-2.01246,0),(2.7*cos(.9),1.8*sin(.9)),'thin')+node(-2,-.4,'foco')
add(18,'Área y período','La ley de áreas se refiere al foco de fuerza',r'En una órbita kepleriana, el radio desde el foco gravitatorio barre áreas iguales en tiempos iguales. El foco no coincide con el centro geométrico de una elipse excéntrica. Los dos radios señalan un sector, sin asignarle aquí una duración numérica.',s,'Elipse a2.7,b1.8; foco=-sqrt(a²-b²); radios dibujados esquemáticosdentroelipse.')
s=graph([(lambda th:1/math.tan(th/2),'thick')],.35,2.8,(0,6),r'$\chi$','$b/a$')
add(19,'La ley inversa','Ángulo y parámetro de impacto',r'En dispersión por una fuerza inversa del cuadrado, $b=a\cot(\chi/2)$, con $a>0$ fijado por el acoplamiento y la energía lejana. Los encuentros de mayor parámetro de impacto producen menor desviación, bajo las hipótesis de esa ley.',s,'RelacióndeRutherfordmagnitudes, χ∈(.35,2.8),a>0.')
s=axes((-.2,3.8),(-.2,2.8),'$x$','$y$')+arrow((1,1),(2.5,1),r'$v^{\prime}$','above','thick,dashed')+arrow((1,1),(1,.1),'$F_C$','left')+node(2,2.5,r'$\Omega=\Omega e_z,\quad\Omega>0$')
add(20,'Cuatro términos','La dirección de Coriolis depende de la velocidad relativa',r'Con $\Omega$ saliente y velocidad relativa hacia la derecha, $-2m\Omega\times v^\prime$ apunta hacia abajo. La velocidad discontinua es un dato cinemático; la flecha continua representa el término de fuerza en el marco que gira.',s,'Ωz>0,v′x>0; ey negativoporproductovectorial.')
s=r'\draw[thick] (0,1) circle(1);\draw(-2,0)--(3,0);'+arrow((0,1),(1.3,1),'$V_C$','above')+arrow((0,2),(2.6,2),r'$v_{\rm sup}=2V_C$','above')+r'\fill(0,0) circle(2pt);'+node(0,-.4,r'$v_{\rm contacto}=0$')
add(21,'El eje instantáneo','Velocidades en rodadura sin deslizamiento',r'Una rueda que avanza hacia la derecha sin deslizar tiene velocidad nula en el contacto instantáneo y velocidad $2V_C$ en el punto superior. La condición es $V_C=R|\omega|$, con giro horario.',s,'Círculoradio1,rodaduraplana;v=VC+ω×r;contactoinstantáneo.')
s=arrow((0,0),(0,2.4),'$L$','above')+arrow((0,1.5),(1.5,1.5),r'$\tau$','right')+arrow((0,0),(1.1,2.4),'$L+dL$','right','thin,dashed')+node(1.5,-.7,r'$dL=\tau\,dt$')
add(22,'Cuándo existe una precesión','El torque puede cambiar la dirección del momento',r'Cuando el torque es perpendicular al momento angular, el cambio de primer orden altera su dirección sin alterar su módulo. El dibujo es una construcción diferencial; no identifica por sí solo las tasas de precesión de un trompo.',s,'L=(0,L),τ=(τ,0),dL=τdt; perpendicularidad instantánea.')
s=graph([(lambda w:math.atan2(.4*w,1-w*w),'thick')],0,2,(0,pi),r'$\Omega/\omega_0$',r'$\delta$')
add(23,'Fuerza sinusoidal','El desfase atraviesa un cuarto de período',r'Para $\ddot x+0{,}4\dot x+x=F_0\cos\Omega t$, la fase estacionaria satisface $\delta=\operatorname{atan2}(0{,}4\Omega,1-\Omega^2)$. En $\Omega=1$, la respuesta se retrasa $\pi/2$ respecto de la fuerza.',s,'β=.2,ω0=1; respuestaAcos(Ωt-δ);0<=δ<=π.')
s=graph([(lambda t:cos(t/2)**2,'thick'),(lambda t:sin(t/2)**2,'thick,dashed')],0,2*pi,(0,1.1),'$u$','fracción')
add(24,'Energía de los modos','Intercambio local y conservación modal',r'En un esquema de batidos, dos contribuciones locales pueden intercambiarse como $\cos^2(u/2)$ y $\sin^2(u/2)$ mientras su suma permanece uno. Es una ilustración normalizada del intercambio; no identifica cada curva con la energía modal conservada del sistema general.',s,'Identidadcos²+sin²=1; esquemaenvolvente, nocomputoenergíaexactademasas.')
s=r'\draw[thick] (0,0) circle(1.4);'+arrow((1.4,0),(1.4,1.2),r'$\delta r$','right','thin,dashed')+arrow((1.4,0),(.4,0),'$N$','above')+node(0,-2,r'$N\cdot\delta r=0$')
add(25,'Qué se supone','Desplazamiento virtual y reacción ideal',r'En una guía circular fija y lisa, el desplazamiento virtual admisible es tangente y la reacción es normal. Su trabajo virtual es cero. Las flechas no describen dos fuerzas que se equilibren.',s,'Vínculoholónomofijoideal; variacióntangente;Nradial.')
s=box(0,0,1,.7,'$M$')+line((0,.35),(1.2,-1.7),'thick')+r'\fill(1.2,-1.7) circle(3pt);'+arrow((-.7,.7),(.7,.7),'$X$','above','thin,dashed')+node(2,-.8,r'$x=X+\ell\sin\theta$')+node(2,-1.4,r'$y=-\ell\cos\theta$')
add(26,'Un apoyo que también','El apoyo móvil acopla las coordenadas',r'Para un péndulo sobre un carro, la posición de la masa es $(X+\ell\sin\theta,-\ell\cos\theta)$. Al derivarla aparece un término cinético cruzado proporcional a $\dot X\dot\theta\cos\theta$. Las coordenadas no generan energías cinéticas independientes.',s,'Soportesobrecarrohorizontal; θdesdelaverticalinferior; longitudfija.')
s=axes((-.2,4),(-.2,2.5),'$t$','$x$')+curve(lambda t:(t,.4+.4*t),0,3.4)+curve(lambda t:(t,1+.4*t),0,3.4,style='thick,dashed')+node(2,2.8,r'$x\mapsto x+\varepsilon$')
add(27,'Traslaciones y momento','Una simetría transforma soluciones completas',r'En el lagrangiano libre $L=m\dot x^2/2$, trasladar la posición por una constante conserva la acción y genera otra historia de igual velocidad. La carga de Noether asociada es el momento $p=m\dot x$.',s,'Partículalibre; traslaciónespacialconstante .6; pendiente .4.')
s=graph([(lambda v:v,'thick'),(lambda v:v+1,'thick,dashed')],-1,2,(-1.2,3.2),'$v$','$p$')
add(28,'Lagrangianos cuadráticos','El momento puede diferir de la masa por la velocidad',r'Para $L=v^2/2+a v-U$, el momento es $p=v+a$. Las dos rectas comparan $a=0$ y $a=1$. Invertir la relación exige conservar ese desplazamiento al construir $H=(p-a)^2/2+U$.',s,'m=1,a constante; Hessiano1; transformadaexacta.')
s=axes((-.2,4),(-.2,2.8),'$q$','$p$')+r'\draw[thick] (.3,.3) rectangle(1.3,1.3);\draw[dashed] (2,.3) rectangle(3,2.3);'+node(.8,1.8,r'área $1$')+node(2.6,2.8,r'área $2$')
add(29,'Qué significa','El determinante detecta un cambio no canónico en el plano',r'El cambio $Q=q$, $P=2p$ duplica el área y satisface $\{Q,P\}=2$. No es canónico con la forma estándar. Los rectángulos están desplazados en la página para facilitar su comparación.',s,'Mapalinealdiag(1,2);det2; forma multiplicada2; áreade1a2.')
(FD/'inventario_ampliacion_v04.json').write_text(json.dumps(DATA,ensure_ascii=False,indent=2))
print(len(DATA),'additional figures')

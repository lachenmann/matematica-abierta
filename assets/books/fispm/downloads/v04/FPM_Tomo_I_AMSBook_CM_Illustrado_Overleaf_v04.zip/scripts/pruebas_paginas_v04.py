from pathlib import Path
import json,re,fitz,math
from PIL import Image,ImageDraw
R=Path(__file__).resolve().parents[1];OUT=R/'auditoria/pruebas_paginas';OUT.mkdir(exist_ok=True);manifest=[]
Q=json.loads((R/'auditoria/QA_PDF_MECANICO_v04.json').read_text());H=json.loads((R/'auditoria/QA_ENCABEZADOS_v04.json').read_text())
for fmt,stem in [('A4','main_A4_Lectura'),('Carta','main_Carta_Impresion')]:
 d=fitz.open(R/f'build_{fmt}/{stem}.pdf');ch=[a[2]for a in d.get_toc()if a[0]==1 and a[1].startswith('Capítulo')];figpages={v['pdf_page']for v in Q[fmt]['figure_labels'].values()};pages=set(figpages)|set(ch)|{x-1 for x in ch[1:]}|{len(d)}|{1,2,3}
 # Every final chapter page in letter can be followed by the intentional openright blank.
 for x in ch[1:]:
  if not d[x-2].get_text().strip():pages.add(x-2)
 for z in Q[fmt]['overfull_vbox_warnings']:pages.add(z['pdf_page_approx'])
 aux=(R/f'build_{fmt}/{stem}.aux').read_text();labels={m[1]:int(m[2])+3 for m in re.finditer(r'\\newlabel\{([^}]+)\}\{\{[^}]*\}\{(\d+)\}',aux)}
 for h in H[fmt]['unmatched_titles']:
  p=labels.get(h['label'])
  if p:pages.update([p,min(len(d),p+1)])
 for h in H[fmt]['possible_stranded_headings']:pages.update([h['pdf_page'],min(len(d),h['pdf_page']+1)])
 pages=sorted(x for x in pages if 1<=x<=len(d))
 for k in range(math.ceil(len(pages)/16)):
  subset=pages[k*16:(k+1)*16];sheet=Image.new('RGB',(1600,2240),'#e7e7e7');draw=ImageDraw.Draw(sheet)
  for i,p in enumerate(subset):
   pg=d[p-1];pix=pg.get_pixmap(matrix=fitz.Matrix(.7,.7),alpha=False);im=Image.frombytes('RGB',(pix.width,pix.height),pix.samples);im.thumbnail((390,525));x=(i%4)*400;y=(i//4)*560
   draw.text((x+6,y+5),f'{fmt}: PDF {p}'+(' / fig'if p in figpages else '')+(' / inicio'if p in ch else ''),fill='black');sheet.paste(im,(x+(400-im.width)//2,y+25))
  name=f'{fmt}_{k+1:02}.jpg';tmp=OUT/(name+'.closed.jpg');sheet.save(tmp,quality=93,optimize=True,subsampling=0);tmp.replace(OUT/name);manifest.append({'format':fmt,'file':name,'pages':subset,'status':'pending_visual_inspection'})
 print(fmt,len(pages),'pages',flush=True)
(R/'auditoria/PRUEBAS_VISUALES_v04.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2));print(len(manifest),'proof sheets')

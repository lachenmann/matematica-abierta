from pathlib import Path
import xml.etree.ElementTree as E
import math,json
R=Path(__file__).resolve().parents[1];r=E.parse(R/'figuras_originales_svg/FPM-I-30-F14.svg').getroot()
points=[((float(e.get('cx'))-340)/125,(300-float(e.get('cy')))/125) for e in r.iter() if e.tag.endswith('circle') and e.get('fill')=='#087f8c']
def F(t,y):
 x,v=y;return (v,-math.sin(x)-.2*v+.7*math.cos(2*math.pi*t/3))
def rk(h,N):
 y=(.4,-.1);obs=[y]
 for i in range(N):
  t=i*h;k1=F(t,y);k2=F(t+h/2,tuple(y[j]+h*k1[j]/2 for j in range(2)));k3=F(t+h/2,tuple(y[j]+h*k2[j]/2 for j in range(2)));k4=F(t+h,tuple(y[j]+h*k3[j] for j in range(2)))
  y=tuple(y[j]+h*(k1[j]+2*k2[j]+2*k3[j]+k4[j])/6 for j in range(2))
  if (i+1)%round(3/h)==0:obs.append(y)
 return obs
obs=rk(.002,45000);ref=rk(.001,90000)
err=max(max(abs(a-b) for a,b in zip(p,o)) for p,o in zip(points,obs));conv=max(max(abs(a-b) for a,b in zip(p,o)) for p,o in zip(obs,ref));assert len(points)==31 and err<5e-6 and conv<1e-9
out={'F14':{'blue_points_including_initial':len(points),'rk4_step':.002,'time':90,'max_svg_coordinate_error':err,'step_halving_max_difference':conv,'pass':True}}
r=E.parse(R/'figuras_originales_svg/FPM-I-30-F11.svg').getroot();edges=[]
for e in r.iter():
 if e.tag.endswith('polyline') and e.get('stroke')=='#087f8c':edges.append([((float(p.split(',')[0])-360)/90,(235-float(p.split(',')[1]))/90) for p in e.get('points').split()])
errs=[]
for edge in edges:
 for Q,P in edge:
  q=Q-P;p=P-.8*math.sin(q);errs.append(min(abs(abs(q)-1),abs(abs(p)-.5)))
pts=sum(edges,[]);area=abs(sum(a[0]*b[1]-a[1]*b[0] for a,b in zip(pts,pts[1:]+pts[:1]))/2);assert max(errs)<2e-5 and abs(area-2)<1e-4
out['F11']={'boundary_points':len(pts),'inverse_map_max_distance_to_rectangle_boundary':max(errs),'polygonal_area':area,'exact_area':2,'pass':True}
(R/'auditoria/QA_NUMERICO_ORIGINALES_v04.json').write_text(json.dumps(out,ensure_ascii=False,indent=2));print(json.dumps(out,indent=2))

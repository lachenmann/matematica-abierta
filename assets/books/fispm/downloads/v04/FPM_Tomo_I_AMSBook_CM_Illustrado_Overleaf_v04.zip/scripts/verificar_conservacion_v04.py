from pathlib import Path
import re,json,hashlib,difflib
R=Path(__file__).resolve().parents[1];B=R/'auditoria/base_v03';res=[]
def group(s,start):
 depth=1;i=start+1
 while depth:
  if s[i]=='{'and s[i-1]!=chr(92):depth+=1
  if s[i]=='}'and s[i-1]!=chr(92):depth-=1
  i+=1
 return i
def strip(s):
 while(m:=re.search(r'\\FPM(?:Illustration|Original)\{',s)):
  end=m.end()-1
  for _ in range(3):end=group(s,end)
  s=s[:m.start()]+s[end:]
 return s
def maths(s):return [re.sub(r'\s+','',a+b)for a,b in re.findall(r'\\\[(.*?)\\\]|\\\((.*?)\\\)',strip(s),re.S)]
for n in range(1,31):
 p=R/f'chapters/c{n:02}.tex';s=p.read_text();b=(B/'chapters'/p.name).read_text();eq=maths(b)==maths(s);assert eq,p
 sols=lambda z:len(re.findall(r'\\textbf\{Solución[^}]*}',z))
 assert sols(s)==sols(b);assert s.count('\\footnote{')==b.count('\\footnote{')
 fs=(R/'fuentes_originales');assert all(p.read_bytes()==(B/'fuentes_originales'/p.name).read_bytes()for p in fs.iterdir()if p.is_file())
 res.append({'chapter':n,'mathematical_sequence_preserved':eq,'math_blocks':len(maths(s)),'solutions':sols(s),'footnotes':s.count('\\footnote{')})
 (R/f'auditoria/c{n:02}_v03_v04.diff').write_text(''.join(difflib.unified_diff(b.splitlines(True),s.splitlines(True),fromfile='v03',tofile='v04')))
orig=[]
for p in (R/'figuras').iterdir():
 if p.is_file():same=p.read_bytes()==(B/'figuras'/p.name).read_bytes();assert same;orig.append({'file':p.name,'unchanged':same})
assert sum(x['solutions']for x in res)==900
out={'chapters':res,'exercise_solution_pairs':900,'footnotes':sum(x['footnotes']for x in res),'original_files':orig,'original_files_unchanged':True,'canonical_source_copies_unchanged':True}
(R/'auditoria/QA_CONSERVACION_v04.json').write_text(json.dumps(out,ensure_ascii=False,indent=2));print('30 chapters; 900 solutions; math sequence, original files and 222 footnotes preserved')

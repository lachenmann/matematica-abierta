from pathlib import Path
import re,json,fitz,unicodedata
R=Path(__file__).resolve().parents[1];heads=[]
pat=r'\\((?:sub)*section)\*?\{([^{}\n]*)\}\\label\{([^{}]+)\}'
def norm(s):return ''.join(c for c in unicodedata.normalize('NFKD',s).lower()if c.isalnum())
for p in sorted((R/'chapters').glob('*.tex')):
 s=p.read_text();ms=list(re.finditer(pat,s))
 for k,m in enumerate(ms):
  nextm=ms[k+1]if k+1<len(ms)else None;body=s[m.end():nextm.start()if nextm else len(s)];body=re.sub(r'\\phantomsection|\\label\{[^}]+\}','',body).strip()
  if not body and (not nextm or len(nextm[1])<=len(m[1])):raise AssertionError(('Empty heading',p.name,m[2]))
  heads.append({'chapter':p.stem,'kind':m[1],'title':m[2],'label':m[3]})
res={}
for fmt,stem in [('A4','main_A4_Lectura'),('Carta','main_Carta_Impresion')]:
 d=fitz.open(R/f'build_{fmt}/{stem}.pdf');aux=(R/f'build_{fmt}/{stem}.aux').read_text();labels={m[1]:int(m[2])+3 for m in re.finditer(r'\\newlabel\{([^}]+)\}\{\{[^}]*\}\{(\d+)\}',aux)};cache={};possible=[];found=0;missing=[]
 for h in heads:
  pnum=labels.get(h['label'])
  if not pnum:continue
  if pnum not in cache:
   page=d[pnum-1];lines=[]
   for b in page.get_text('dict')['blocks']:
    for l in b.get('lines',[]):
     text=''.join(s['text']for s in l['spans']);lines.append({'text':text,'norm':norm(text),'box':l['bbox'],'sizes':[s['size']for s in l['spans']]})
   cache[pnum]=lines
  ls=cache[pnum];n=norm(h['title']);hit=[]
  for j,line in enumerate(ls):
   z='';ind=[]
   for k in range(j,min(j+4,len(ls))):
    z+=ls[k]['norm'];ind.append(k)
    if n in z and len(n)>4:hit=ind;break
   if hit:break
  if not hit:missing.append(h);continue
  found+=1;j=hit[-1];bottom=ls[j]['box'][3];pageheight=d[pnum-1].rect.height
  # A title in the lower part of the page with no body line following it.
  following=[l for l in ls[j+1:]if l['box'][1]>bottom-1 and l['text'].strip()and not re.fullmatch(r'\d+',l['text'].strip())]
  if bottom>pageheight*.72 and not following and not any(n in norm(''.join(l['text'] for l in ls[k:j+1])) and len(norm(''.join(l['text'] for l in ls[k:j+1])).split(n,1)[1])>4 for k in range(max(0,j-3),j+1)):possible.append({**h,'pdf_page':pnum,'heading_bottom':bottom})
 res[fmt]={'source_headings':len(heads),'matched_in_PDF':found,'unmatched_titles':missing,'possible_stranded_headings':possible}
(R/'auditoria/QA_ENCABEZADOS_v04.json').write_text(json.dumps(res,ensure_ascii=False,indent=2));print({k:{'matched':v['matched_in_PDF'],'unmatched':len(v['unmatched_titles']),'possible_orphans':v['possible_stranded_headings']}for k,v in res.items()})

from pathlib import Path
import re,json,fitz
R=Path(__file__).resolve().parents[1];res={}
for fmt,stem in [('A4','main_A4_Lectura'),('Carta','main_Carta_Impresion')]:
 d=fitz.open(R/('build_'+fmt)/(stem+'.pdf'));toc=d.get_toc();ch=[];full=[]
 for i,t in enumerate(toc):
  tx='\n'.join(d[p].get_text() for p in range(t[2]-1,toc[i+1][2]-1 if i+1<len(toc) else len(d)))
  tx=re.sub(r'(\w)-\n(?=\w)',r'\1',tx);full.append(tx);n=i+1
  pat=r'\bEjercicio\s+'+(r'(\d+)\s*[—-]' if n==2 else str(n)+r'\.\s*(\d+)\b')
  ids=set(map(int,re.findall(pat,tx)));need=32 if n==1 else 28 if n==2 else 30
  ch.append({'chapter':n,'exercise_ids':sorted(ids),'expected':need,'all_expected_found':set(range(1,need+1)).issubset(ids)})
 tx='\n'.join(full);res[fmt]={'chapters':ch,'unique_numbered_exercises':sum(len(a['exercise_ids']) for a in ch),'all_exercise_ids_found':all(a['all_expected_found'] for a in ch),'forbidden_residue':[w for w in ['Recorrido del capítulo','Navegación del capítulo','MASTER_CANONICO','[[#','E-MOD','E-CON','\ufffd'] if w in tx]}
 print(fmt,res[fmt]['unique_numbered_exercises'],res[fmt]['all_exercise_ids_found'],flush=True)
(R/'auditoria/QA_CONTENIDO_PDF_v04.json').write_text(json.dumps(res,ensure_ascii=False,indent=2))

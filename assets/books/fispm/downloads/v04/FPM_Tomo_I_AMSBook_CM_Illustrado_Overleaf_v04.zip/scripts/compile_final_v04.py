from pathlib import Path
import tempfile,shutil,subprocess,re,json
R=Path(__file__).resolve().parents[1].resolve();W=Path(tempfile.mkdtemp(prefix='fpm_v04_compile_',dir='/tmp'))
for f in ['main.tex','main_A4_Lectura.tex','main_Carta_Impresion.tex','figures_layout_v04.tex']:shutil.copy2(R/f,W/f)
for folder in ['chapters','figuras','figuras_nuevas','figuras_edicion']:
 dest=W/folder;dest.mkdir()
 for p in (R/folder).iterdir():
  if p.suffix in ['.tex','.pdf','.svg','.json']:shutil.copy2(p,dest/p.name)
res=[]
for fmt,stem in [('A4','main_A4_Lectura'),('Carta','main_Carta_Impresion')]:
 for i in range(1,4):
  z=subprocess.run(['xelatex','-no-pdf','-halt-on-error','-interaction=nonstopmode','-file-line-error',stem+'.tex'],cwd=W,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
  (W/f'{stem}_pass{i}.stdout').write_bytes(z.stdout)
  assert z.returncode==0,z.stdout[-2000:].decode(errors='replace')
  a=(W/(stem+'.aux')).read_text();assert '\\gdef \\@abspage@last' in a[-100:],'Incomplete auxiliary file'
  print(fmt,'XeLaTeX pass',i,'complete',flush=True)
 log=(W/(stem+'.log')).read_text();assert 'Label(s) may have changed' not in log
 z=subprocess.run(['xdvipdfmx','-q','-o',stem+'.pdf',stem+'.xdv'],cwd=W,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);assert z.returncode==0,z.stdout
 assert a.count('\\newlabel{fig:')==176
 res.append({'format':fmt,'passes':3,'aux_closed':True,'figure_labels':176,'conversion_returncode':z.returncode,'pdf_bytes':(W/(stem+'.pdf')).stat().st_size})
 print(fmt,'PDF complete',flush=True)
# Publish only closed files to the task workspace.
for fmt,stem in [('A4','main_A4_Lectura'),('Carta','main_Carta_Impresion')]:
 target=R/('build_'+fmt);target.mkdir(exist_ok=True)
 for ext in ['pdf','aux','toc','out','log']:
  src=W/(stem+'.'+ext)
  if src.exists():
   tmp=target/(src.name+'.closed');shutil.copy2(src,tmp);tmp.replace(target/src.name)
 for i in range(1,4):shutil.copy2(W/f'{stem}_pass{i}.stdout',target/f'ultima_pasada_{i}.stdout')
(R/'auditoria/COMPILACION_CERRADA_v04.json').write_text(json.dumps(res,indent=2))
print('Both complete PDFs and closed auxiliary files installed',flush=True)

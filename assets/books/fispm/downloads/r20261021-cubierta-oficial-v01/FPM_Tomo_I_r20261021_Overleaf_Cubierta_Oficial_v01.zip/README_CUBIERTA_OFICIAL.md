# Física para matemáticos — Tomo I — cubierta oficial

Edición textual canónica r20261021: capítulos 0–27, 565 ejercicios resueltos y 200 figuras. Formato A4 de lectura; 532 páginas. Compilador canónico: pdfLaTeX. Archivo principal: main.tex.

La cubierta oficial se produce automáticamente al compilar main.tex mediante styles/ma-cubiertas.sty. Configuración MA: título Física, subtítulo para matemáticos, Tomo I, tema Fundamentos y mecánica, color MAfisica (RGB 114,137,166; HEX #7289A6), tinta MAclaro y logotipos claros. Los archivos de identidad originales se conservan en originales/ y las variantes reproducibles en logos/.

El respaldo backup-cubiertas/main-original-r20261021.tex conserva el principal de la edición publicada el 21 de octubre. El ZIP original completo permanece archivado en la bóveda. Los 28 archivos de capítulos y las 200 figuras de esta edición no se modificaron.

Compilar main.tex tres veces con pdfLaTeX, o recompilar normalmente en Overleaf. Los paquetes son estándar de TeX Live/Overleaf. No se requieren fuentes externas, ejecución de scripts ni shell-escape.

Verificación: compilación exitosa; comparación de las 531 páginas interiores con el PDF publicado: texto, rasterizado a 72 dpi y enlaces internos idénticos. Se conservan los 332 marcadores. La cubierta utiliza glifos auténticos LMRomanCaps10-Regular. Solo se sustituye la primera página.

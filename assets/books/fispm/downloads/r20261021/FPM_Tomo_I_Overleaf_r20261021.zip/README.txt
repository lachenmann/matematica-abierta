Física para matemáticos · A. Peña · Matemática Abierta
Tomo I: Fundamentos y mecánica. Edición revisada de 21 de octubre de 2026.
Compilar main.tex tres veces con pdfLaTeX y español instalado, o importar la carpeta completa en Overleaf.
28 capítulos, 565 ejercicios resueltos, 200 figuras; PDF de 532 páginas A4 verticales.
Licencia del texto original: GFDL-1.3-or-later.

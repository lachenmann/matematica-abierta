# Composición de terceros

Base: **Colored Math TextBook**, AMD Raizen. Ficha oficial consultada el 21 de octubre de 2026:
https://www.overleaf.com/latex/templates/colored-math-textbook/rgvcbknkyfkg

Licencia declarada por esa ficha: **LaTeX Project Public License 1.3c**.
Texto oficial: https://www.latex-project.org/lppl/lppl-1-3c/

El enlace a Overleaf permite obtener el original completo. `original/` conserva los archivos de la plantilla recibidos por el proyecto; no se presenta esa selección como una copia íntegra de todo el archivo descargable de Overleaf.

La adaptación `amd-abierta.sty` identifica su condición modificada. Los cambios del proyecto MA incluyen soporte Unicode con XeLaTeX, eliminación de dependencias no usadas, geometría y color propios, formato A4/A5, recuadros de problemas, tablas y figuras integradas. Los maestros y las fuentes de MA se conservan en esta entrega. La autoría de la plantilla original se distingue de la adaptación y del contenido del libro.

Este registro documenta la procedencia de la composición. El texto y las ilustraciones originales del libro están bajo GNU FDL 1.3 o posterior por decisión del editor. La licencia de la plantilla sigue siendo LPPL 1.3c. La adaptación no atribuye al autor original responsabilidad de mantenimiento sobre la versión de MA.

# A. Certificado reproducible de S126

**Archivo:** `S126_REPRODUCIBLE_CERTIFICATE_v01.md`  
**Versión:** 1.0. **Objeto:** sistema final de C3, congelado por `OUC_GENERATION1_FINAL_REPORT_v01.md`.  
**Etiquetas:** [P] resultado publicado utilizado como dependencia; [R] construcción y verificación del proyecto; [I] explicación de la convención; [A] cuestión no establecida.

Este documento fija el sistema, sus dominios y su circuito. Conserva los nombres históricos de los registros del apéndice B de C3, incluidos sus huecos: el número de registro no es un coste acumulado. Las instrucciones nuevas `I001`–`I126` son únicamente números de fila consecutivos. No se modifica ni se optimiza S126.

## A.1 Convención y dominio

[R] La entrada es un entero \(x>0\). Los parámetros \((z,u,y)\) son los índices admisibles definidos exactamente en A.4, fijos para el conjunto representado. Los 37 testigos pertenecen a \(\mathbb Z_{>0}\). Su orden es

\[
\begin{split}
\mathbf v={}&(b,e,g,\ell,m,n,q,r,t,w,\alpha,\lambda,\theta,p,s,k,\tau,\eta,h_0,A,\\
&c,\varphi,d,\gamma,f,i,j,\omega,C_1,D_1,J,\nu,\rho,\zeta,
\varepsilon_e,\varepsilon_\ell,\varepsilon_g).
\end{split}
\]

Definimos la convención \(\mathcal C_{\rm proj}\): cada operación binaria \(+,-,\times\) cuesta una unidad. Multiplicar por una constante cuesta uno; un cuadrado cuesta un producto. Las entradas, los testigos ya propuestos y los literales están disponibles. Copiar o reutilizar un registro calculado no añade coste. Los intermedios pertenecen a \(\mathbb Z\) y pueden ser negativos. El DAG usa solamente los literales \(1,2,4,5,E\), con

\[
E=5^{60}=867361737988403547205962240695953369140625.
\]

Se excluyen las comparaciones finales y de dominio, la búsqueda de testigos, la compilación de parámetros, el almacenamiento de constantes y el tamaño binario de los enteros. No hay división, exponenciación, binomiales, extracción de cifras ni selección de índices como instrucciones gratuitas. Las potencias que aparecen en las ecuaciones se desarrollan en A.5. No se incluye la conversión de las 25 ecuaciones en una sola suma de cuadrados.

[I] El verificador recibe todos los valores, ejecuta las 126 instrucciones y acepta si se cumplen los dominios y las 25 igualdades de A.7. Una igualdad entre testigos no autoriza sustituir uno por otro durante la evaluación: cada uno sigue siendo una entrada propuesta.

La afirmación de coste es \(o_{\rm proj}(S126)=126\) para este circuito y esta convención; no es una afirmación de coste mínimo.

## A.2 Lista de símbolos

En las tablas ejecutables se usa ASCII: `ell` significa \(\ell\), `lambda` significa \(\lambda\), etc. `C1` es el testigo \(C_1\), no una comparación ni el nombre de la fase C1. `t` es un testigo; `t1`, `t2`, etc., son registros distintos. `E01`–`E25` abrevia las etiquetas `S126-E01`–`S126-E25`.

La tabla siguiente enumera individualmente todas las entradas, constantes operacionales y salidas. «Primera utilización» se refiere al orden del DAG y después al de las comparaciones.

| símbolo | tipo | entrada/parámetro/testigo/registro | dominio | primera utilización |
| --- | --- | --- | --- | --- |
| `x` / \(x\) | entero | entrada | \(\mathbb Z_{>0}\) | I009 |
| `z` / \(z\) | entero | parámetro | \(\mathbb Z_{>0}\) | I014 |
| `u` / \(u\) | entero | parámetro | \(\mathbb Z_{>0}\) | I017 |
| `y` / \(y\) | entero | parámetro | \(\mathbb Z_{>0}\) | I009 |
| `b` / \(b\) | entero | testigo | \(\mathbb Z_{>0}\) | I001 |
| `e` / \(e\) | entero | testigo | \(\mathbb Z_{>0}\) | I026 |
| `g` / \(g\) | entero | testigo | \(\mathbb Z_{>0}\) | I022 |
| `ell` / \(\ell\) | entero | testigo | \(\mathbb Z_{>0}\) | I033 |
| `m` / \(m\) | entero | testigo | \(\mathbb Z_{>0}\) | I018 |
| `n` / \(n\) | entero | testigo | \(\mathbb Z_{>0}\) | I047 |
| `q` / \(q\) | entero | testigo | \(\mathbb Z_{>0}\) | I004 |
| `r` / \(r\) | entero | testigo | \(\mathbb Z_{>0}\) | I054 |
| `t` / \(t\) | entero | testigo | \(\mathbb Z_{>0}\) | I016 |
| `w` / \(w\) | entero | testigo | \(\mathbb Z_{>0}\) | I056 |
| `alpha` / \(\alpha\) | entero | testigo | \(\mathbb Z_{>0}\) | I010 |
| `lambda` / \(\lambda\) | entero | testigo | \(\mathbb Z_{>0}\) | I011 |
| `theta` / \(\theta\) | entero | testigo | \(\mathbb Z_{>0}\) | I015 |
| `p` / \(p\) | entero | testigo | \(\mathbb Z_{>0}\) | I059 |
| `s` / \(s\) | entero | testigo | \(\mathbb Z_{>0}\) | I053 |
| `k` / \(k\) | entero | testigo | \(\mathbb Z_{>0}\) | I061 |
| `tau` / \(\tau\) | entero | testigo | \(\mathbb Z_{>0}\) | I064 |
| `eta` / \(\eta\) | entero | testigo | \(\mathbb Z_{>0}\) | I067 |
| `h0` / \(h_0\) | entero | testigo | \(\mathbb Z_{>0}\) | I070 |
| `A` / \(A\) | entero | testigo | \(\mathbb Z_{>0}\) | I055 |
| `c` / \(c\) | entero | testigo | \(\mathbb Z_{>0}\) | I078 |
| `varphi` / \(\varphi\) | entero | testigo | \(\mathbb Z_{>0}\) | I075 |
| `d` / \(d\) | entero | testigo | \(\mathbb Z_{>0}\) | I089 |
| `gamma` / \(\gamma\) | entero | testigo | \(\mathbb Z_{>0}\) | I081 |
| `f` / \(f\) | entero | testigo | \(\mathbb Z_{>0}\) | I094 |
| `i` / \(i\) | entero | testigo | \(\mathbb Z_{>0}\) | I090 |
| `j` / \(j\) | entero | testigo | \(\mathbb Z_{>0}\) | I103 |
| `omega` / \(\omega\) | entero | testigo | \(\mathbb Z_{>0}\) | I095 |
| `C1` / \(C_1\) | entero | testigo | \(\mathbb Z_{>0}\) | I074 |
| `D1` / \(D_1\) | entero | testigo | \(\mathbb Z_{>0}\) | I114 |
| `J` / \(J\) | entero | testigo | \(\mathbb Z_{>0}\) | I109 |
| `nu` / \(\nu\) | entero | testigo | \(\mathbb Z_{>0}\) | I120 |
| `rho` / \(\rho\) | entero | testigo | \(\mathbb Z_{>0}\) | I123 |
| `zeta` / \(\zeta\) | entero | testigo | \(\mathbb Z_{>0}\) | I066 |
| `eps_e` / \(\varepsilon_e\) | entero | testigo | \(\mathbb Z_{>0}\) | I124 |
| `eps_l` / \(\varepsilon_\ell\) | entero | testigo | \(\mathbb Z_{>0}\) | I125 |
| `eps_g` / \(\varepsilon_g\) | entero | testigo | \(\mathbb Z_{>0}\) | I126 |
| `1` | entero fijo | constante | 1 | I012 |
| `2` | entero fijo | constante | 2 | I014 |
| `4` | entero fijo | constante | 4 | I079 |
| `5` | entero fijo | constante | 5 | I080 |
| `E` | entero fijo | constante | \(E=5^{60}\) | I110 |
| `t1` | entero calculado | registro | \(\mathbb Z\) | I001 (definición); I002 (uso) |
| `t2` | entero calculado | registro | \(\mathbb Z\) | I002 (definición); I003 (uso) |
| `t3` | entero calculado | registro | \(\mathbb Z\) | I003 (definición); I011 (uso) |
| `t4` | entero calculado | registro | \(\mathbb Z\) | I004 (definición); I005 (uso) |
| `t5` | entero calculado | registro | \(\mathbb Z\) | I005 (definición); I036 (uso) |
| `t6` | entero calculado | registro | \(\mathbb Z\) | I006 (definición); I007 (uso) |
| `t8` | entero calculado | registro | \(\mathbb Z\) | I007 (definición); I008 (uso) |
| `t9` | entero calculado | registro | \(\mathbb Z\) | I008 (definición); E09 (uso) |
| `t15` | entero calculado | registro | \(\mathbb Z\) | I009 (definición); I010 (uso) |
| `t16` | entero calculado | registro | \(\mathbb Z\) | I010 (definición); E01 (uso) |
| `t18` | entero calculado | registro | \(\mathbb Z\) | I011 (definición); I012 (uso) |
| `t19` | entero calculado | registro | \(\mathbb Z\) | I012 (definición); E05 (uso) |
| `t20` | entero calculado | registro | \(\mathbb Z\) | I013 (definición); E05 (uso) |
| `t21` | entero calculado | registro | \(\mathbb Z\) | I014 (definición); I015 (uso) |
| `t22` | entero calculado | registro | \(\mathbb Z\) | I015 (definición); E06 (uso) |
| `t23` | entero calculado | registro | \(\mathbb Z\) | I016 (definición); I017 (uso) |
| `t24` | entero calculado | registro | \(\mathbb Z\) | I017 (definición); E07 (uso) |
| `t25` | entero calculado | registro | \(\mathbb Z\) | I018 (definición); I019 (uso) |
| `t26` | entero calculado | registro | \(\mathbb Z\) | I019 (definición); E08 (uso) |
| `t27` | entero calculado | registro | \(\mathbb Z\) | I020 (definición); I021 (uso) |
| `t28` | entero calculado | registro | \(\mathbb Z\) | I021 (definición); I022 (uso) |
| `t29` | entero calculado | registro | \(\mathbb Z\) | I022 (definición); I023 (uso) |
| `t30` | entero calculado | registro | \(\mathbb Z\) | I023 (definición); I024 (uso) |
| `t31` | entero calculado | registro | \(\mathbb Z\) | I024 (definición); I027 (uso) |
| `t32` | entero calculado | registro | \(\mathbb Z\) | I025 (definición); I026 (uso) |
| `t33` | entero calculado | registro | \(\mathbb Z\) | I026 (definición); I027 (uso) |
| `t34` | entero calculado | registro | \(\mathbb Z\) | I027 (definición); I028 (uso) |
| `t35` | entero calculado | registro | \(\mathbb Z\) | I028 (definición); I030 (uso) |
| `t36` | entero calculado | registro | \(\mathbb Z\) | I029 (definición); I031 (uso) |
| `t37` | entero calculado | registro | \(\mathbb Z\) | I030 (definición); I031 (uso) |
| `t38` | entero calculado | registro | \(\mathbb Z\) | I031 (definición); I032 (uso) |
| `t39` | entero calculado | registro | \(\mathbb Z\) | I032 (definición); I033 (uso) |
| `t40` | entero calculado | registro | \(\mathbb Z\) | I033 (definición); I034 (uso) |
| `t41` | entero calculado | registro | \(\mathbb Z\) | I034 (definición); I035 (uso) |
| `t42` | entero calculado | registro | \(\mathbb Z\) | I035 (definición); I036 (uso) |
| `t43` | entero calculado | registro | \(\mathbb Z\) | I036 (definición); I037 (uso) |
| `t44` | entero calculado | registro | \(\mathbb Z\) | I037 (definición); I050 (uso) |
| `t45` | entero calculado | registro | \(\mathbb Z\) | I038 (definición); I039 (uso) |
| `t46` | entero calculado | registro | \(\mathbb Z\) | I039 (definición); I040 (uso) |
| `t47` | entero calculado | registro | \(\mathbb Z\) | I040 (definición); I043 (uso) |
| `t48` | entero calculado | registro | \(\mathbb Z\) | I041 (definición); I042 (uso) |
| `t49` | entero calculado | registro | \(\mathbb Z\) | I042 (definición); I043 (uso) |
| `t50` | entero calculado | registro | \(\mathbb Z\) | I043 (definición); I046 (uso) |
| `t51` | entero calculado | registro | \(\mathbb Z\) | I044 (definición); I045 (uso) |
| `t52` | entero calculado | registro | \(\mathbb Z\) | I045 (definición); I046 (uso) |
| `t53` | entero calculado | registro | \(\mathbb Z\) | I046 (definición); I051 (uso) |
| `t54` | entero calculado | registro | \(\mathbb Z\) | I047 (definición); I048 (uso) |
| `t55` | entero calculado | registro | \(\mathbb Z\) | I048 (definición); I050 (uso) |
| `t56` | entero calculado | registro | \(\mathbb Z\) | I049 (definición); I051 (uso) |
| `t57` | entero calculado | registro | \(\mathbb Z\) | I050 (definición); I052 (uso) |
| `t58` | entero calculado | registro | \(\mathbb Z\) | I051 (definición); I052 (uso) |
| `t59` | entero calculado | registro | \(\mathbb Z\) | I052 (definición); E10 (uso) |
| `t60` | entero calculado | registro | \(\mathbb Z\) | I053 (definición); I054 (uso) |
| `t61` | entero calculado | registro | \(\mathbb Z\) | I054 (definición); I055 (uso) |
| `t62` | entero calculado | registro | \(\mathbb Z\) | I055 (definición); I057 (uso) |
| `t63` | entero calculado | registro | \(\mathbb Z\) | I056 (definición); I072 (uso) |
| `t64` | entero calculado | registro | \(\mathbb Z\) | I057 (definición); I058 (uso) |
| `t65` | entero calculado | registro | \(\mathbb Z\) | I058 (definición); E11 (uso) |
| `t66` | entero calculado | registro | \(\mathbb Z\) | I059 (definición); I060 (uso) |
| `t67` | entero calculado | registro | \(\mathbb Z\) | I060 (definición); I062 (uso) |
| `t68` | entero calculado | registro | \(\mathbb Z\) | I061 (definición); I062 (uso) |
| `t69` | entero calculado | registro | \(\mathbb Z\) | I062 (definición); I063 (uso) |
| `t70` | entero calculado | registro | \(\mathbb Z\) | I063 (definición); E12 (uso) |
| `t71` | entero calculado | registro | \(\mathbb Z\) | I064 (definición); E12 (uso) |
| `t73` | entero calculado | registro | \(\mathbb Z\) | I065 (definición); I066 (uso) |
| `t74` | entero calculado | registro | \(\mathbb Z\) | I066 (definición); E13 (uso) |
| `t77` | entero calculado | registro | \(\mathbb Z\) | I067 (definición); E14 (uso) |
| `t78` | entero calculado | registro | \(\mathbb Z\) | I068 (definición); I071 (uso) |
| `t79` | entero calculado | registro | \(\mathbb Z\) | I069 (definición); I070 (uso) |
| `t80` | entero calculado | registro | \(\mathbb Z\) | I070 (definición); I071 (uso) |
| `t81` | entero calculado | registro | \(\mathbb Z\) | I071 (definición); E15 (uso) |
| `t84` | entero calculado | registro | \(\mathbb Z\) | I072 (definición); E16 (uso) |
| `t85` | entero calculado | registro | \(\mathbb Z\) | I073 (definición); I074 (uso) |
| `t86` | entero calculado | registro | \(\mathbb Z\) | I074 (definición); I075 (uso) |
| `t87` | entero calculado | registro | \(\mathbb Z\) | I075 (definición); E17 (uso) |
| `t88` | entero calculado | registro | \(\mathbb Z\) | I076 (definición); I082 (uso) |
| `t89` | entero calculado | registro | \(\mathbb Z\) | I077 (definición); I078 (uso) |
| `t90` | entero calculado | registro | \(\mathbb Z\) | I078 (definición); I082 (uso) |
| `t91` | entero calculado | registro | \(\mathbb Z\) | I079 (definición); I080 (uso) |
| `t92` | entero calculado | registro | \(\mathbb Z\) | I080 (definición); I081 (uso) |
| `t93` | entero calculado | registro | \(\mathbb Z\) | I081 (definición); I083 (uso) |
| `t94` | entero calculado | registro | \(\mathbb Z\) | I082 (definición); I083 (uso) |
| `t95` | entero calculado | registro | \(\mathbb Z\) | I083 (definición); E18 (uso) |
| `t96` | entero calculado | registro | \(\mathbb Z\) | I084 (definición); I085 (uso) |
| `t97` | entero calculado | registro | \(\mathbb Z\) | I085 (definición); I087 (uso) |
| `t98` | entero calculado | registro | \(\mathbb Z\) | I086 (definición); I087 (uso) |
| `t99` | entero calculado | registro | \(\mathbb Z\) | I087 (definición); I088 (uso) |
| `t100` | entero calculado | registro | \(\mathbb Z\) | I088 (definición); E19 (uso) |
| `t101` | entero calculado | registro | \(\mathbb Z\) | I089 (definición); I098 (uso) |
| `t102` | entero calculado | registro | \(\mathbb Z\) | I090 (definición); I091 (uso) |
| `t103` | entero calculado | registro | \(\mathbb Z\) | I091 (definición); I092 (uso) |
| `t104` | entero calculado | registro | \(\mathbb Z\) | I092 (definición); I093 (uso) |
| `t105` | entero calculado | registro | \(\mathbb Z\) | I093 (definición); E20 (uso) |
| `t106` | entero calculado | registro | \(\mathbb Z\) | I094 (definición); I099 (uso) |
| `t107` | entero calculado | registro | \(\mathbb Z\) | I095 (definición); I096 (uso) |
| `t108` | entero calculado | registro | \(\mathbb Z\) | I096 (definición); I097 (uso) |
| `t109` | entero calculado | registro | \(\mathbb Z\) | I097 (definición); E21 (uso) |
| `t110` | entero calculado | registro | \(\mathbb Z\) | I098 (definición); I099 (uso) |
| `t111` | entero calculado | registro | \(\mathbb Z\) | I099 (definición); I100 (uso) |
| `t112` | entero calculado | registro | \(\mathbb Z\) | I100 (definición); I101 (uso) |
| `t113` | entero calculado | registro | \(\mathbb Z\) | I101 (definición); I102 (uso) |
| `t114` | entero calculado | registro | \(\mathbb Z\) | I102 (definición); I106 (uso) |
| `t115` | entero calculado | registro | \(\mathbb Z\) | I103 (definición); I104 (uso) |
| `t116` | entero calculado | registro | \(\mathbb Z\) | I104 (definición); I105 (uso) |
| `t117` | entero calculado | registro | \(\mathbb Z\) | I105 (definición); I106 (uso) |
| `t118` | entero calculado | registro | \(\mathbb Z\) | I106 (definición); I107 (uso) |
| `t119` | entero calculado | registro | \(\mathbb Z\) | I107 (definición); E21 (uso) |
| `t129` | entero calculado | registro | \(\mathbb Z\) | I108 (definición); I109 (uso) |
| `t130` | entero calculado | registro | \(\mathbb Z\) | I109 (definición); I110 (uso) |
| `t131` | entero calculado | registro | \(\mathbb Z\) | I110 (definición); E22 (uso) |
| `t132` | entero calculado | registro | \(\mathbb Z\) | I111 (definición); I112 (uso) |
| `t133` | entero calculado | registro | \(\mathbb Z\) | I112 (definición); I113 (uso) |
| `t134` | entero calculado | registro | \(\mathbb Z\) | I113 (definición); E23 (uso) |
| `t135` | entero calculado | registro | \(\mathbb Z\) | I114 (definición); E23 (uso) |
| `t136` | entero calculado | registro | \(\mathbb Z\) | I115 (definición); I116 (uso) |
| `t137` | entero calculado | registro | \(\mathbb Z\) | I116 (definición); I117 (uso) |
| `t138` | entero calculado | registro | \(\mathbb Z\) | I117 (definición); I118 (uso) |
| `t139` | entero calculado | registro | \(\mathbb Z\) | I118 (definición); I120 (uso) |
| `t140` | entero calculado | registro | \(\mathbb Z\) | I119 (definición); I121 (uso) |
| `t142` | entero calculado | registro | \(\mathbb Z\) | I120 (definición); I122 (uso) |
| `t143` | entero calculado | registro | \(\mathbb Z\) | I121 (definición); I122 (uso) |
| `t144` | entero calculado | registro | \(\mathbb Z\) | I122 (definición); E24 (uso) |
| `t146` | entero calculado | registro | \(\mathbb Z\) | I123 (definición); E25 (uso) |
| `t147` | entero calculado | registro | \(\mathbb Z\) | I124 (definición); E02 (uso) |
| `t148` | entero calculado | registro | \(\mathbb Z\) | I125 (definición); E03 (uso) |
| `t149` | entero calculado | registro | \(\mathbb Z\) | I126 (definición); E04 (uso) |


Las siguientes abreviaturas no añaden testigos ni nodos. Sus definiciones se expanden por sustitución; los alias operacionales señalan registros que ya se pagan.

| símbolo | tipo | entrada/parámetro/testigo/registro | dominio | primera utilización |
| --- | --- | --- | --- | --- |
| \(\beta=b^5\) | expresión | alias de `t3` | \(\mathbb Z\) | A.3, E05 |
| \(C_0=1+x\beta+g\) | expresión | alias de `t29` | \(\mathbb Z\) | A.3, definición de \(H\) |
| \(H\) | expresión | alias de `t38` | \(\mathbb Z\) | A.3 |
| \(S\) | expresión | alias de `t44` | \(\mathbb Z\) | A.3, E10 |
| \(T+1\) | expresión | alias de `t53`; \(T\) sólo se usa en la prueba | \(\mathbb Z\) | A.3, E10 |
| \(M=rsn^2\) | expresión | alias de `t61` | \(\mathbb Z\) | A.3, E11 |
| \(V=A-M\) | expresión | alias de `t62` | \(\mathbb Z\) | A.3, E11 |
| \(U=wn^2\) | expresión | alias de `t63` | \(\mathbb Z\) | A.3, E16 |
| \(N=2r+1\) | expresión | alias de `t85` | \(\mathbb Z\) | A.4 |
| \(Y=sn^2\) | expresión | alias de `t60` | \(\mathbb Z\) | A.4 |
| \(\kappa=5^{58},K=5^{59}\) | constantes | sólo prueba/compilación | \(\mathbb Z_{>0}\) | A.4 |
| \(W\) | conjunto c.e. | objeto representado | subconjunto de \(\mathbb Z_{>0}\) | A.4 |
| \(P,p_{\boldsymbol i},P_{\boldsymbol i}\) | polinomio y coeficientes | fuente y compilación | \(\mathbb Z[\xi_0,\ldots,\xi_{58}]\), \(\mathbb Z\), \(\mathbb Z\) | A.4 |
| \(\xi_0=x,\xi_1,\ldots,\xi_{58}\) | variables fuente | entrada y auxiliares de la fuente; no testigos del DAG | \(x>0\), restantes \(\ge0\) | A.4 |
| \(\boldsymbol i=(i_0,\ldots,i_{58}),\lvert\boldsymbol i\rvert\) | multiíndice y suma de componentes | compilación | \(\mathbb Z_{\ge0}^{59}\), suma \(\le4\) | A.4 |
| \(a,h,j_0,d_0\) | base, índices y cifra genéricos | variables locales de prueba | enteros en los rangos indicados | A.4 |
| \(\chi_a(h),\psi_a(h)\) | sucesiones Pell | sólo prueba | \(\mathbb Z_{\ge0}\), \(a\ge2,h\ge0\) | A.4 |
| \(W_0=bw,\Delta_b=2Ab-b^2-1\) | expresiones | sólo prueba | \(\mathbb Z\), positivas bajo las hipótesis | A.4 |
| \(F_h,Q_h\) | sucesiones auxiliares | sólo prueba del selector | \(\mathbb Z\) | A.4 |
| \(R=c/k,P_0=(U+1)^{2r}/U^r,T_0\) | racionales | sólo prueba de ventana | \(\mathbb Q_{>0}\) | A.4 |
| \(Z\) | parte entera binomial | sólo prueba | \(\mathbb Z_{>0}\) | A.4 |
| \(S_a,T_a,N_a\), \(a=1,2,3\) | bloques digitales | sólo prueba | enteros con cotas explícitas | A.4 |
| \(\tau_2(v,w)=0\) | predicado de ausencia de acarreos binarios | sólo prueba; no instrucción | \(v,w\ge0\) | A.4 |
| \(X,[X^K]\) | indeterminada y extracción de coeficiente | sólo prueba | anillo \(\mathbb Z[X]\) | A.4 |
| \(\mathcal C(X),\mathcal E(X),\Lambda(X),E_0\) | polinomios y entero detector | sólo prueba | \(\mathbb Z[X]\), \(\mathbb Z\) | A.4 |
| \(h\), \(j\) en sumatorios | índices mudos | sólo prueba | rangos escritos en cada suma | A.4 |
| \(N_+,N_-,N_\times\) | contadores | metadatos del circuito | \(\mathbb Z_{\ge0}\) | A.6 |

Los índices mudos no son los testigos \(i,j,t\); se escribirá \(j_0\) para un índice Pell cuya confusión con el testigo \(j\) sería posible. Los identificadores locales del programa de A.9 son variables del verificador, no símbolos del sistema diofántico.

## A.3 Sistema S126

[R] Abreviaturas completamente determinadas:

\[
\begin{gathered}
\beta=b^5,\quad C_0=1+x\beta+g,\\
H=2(e-z\lambda)C_0^4+\lambda\beta(1+q^4),\\
S=g+eq^3+\ell q^5+Hq^7,\\
T+1=q^3-b\ell+\ell+\theta\lambda q^3+(\beta-2)q^8,\\
M=rsn^2,\quad V=A-M,\quad U=wn^2.
\end{gathered}
\]

Las ecuaciones finales son las siguientes. No se presupone que una de ellas ya se haya satisfecho al evaluar otra.

\[
\begin{array}{rl}
\text{S126-E01}&b=xy+\alpha,\\
\text{S126-E02}&e+\varepsilon_e=q^2,\\
\text{S126-E03}&\ell+\varepsilon_\ell=q^2,\\
\text{S126-E04}&g+\varepsilon_g=q,\\
\text{S126-E05}&\lambda+q^4=1+\lambda\beta,\\
\text{S126-E06}&\theta+2z=\beta,\\
\text{S126-E07}&\ell=u+t\theta,\\
\text{S126-E08}&e=y+m\theta,\\
\text{S126-E09}&n=q^{16},\\
\text{S126-E10}&r=S(n^2-n)+(T+1)(n^2-1),\\
\text{S126-E11}&p=2MV,\\
\text{S126-E12}&(p^2-1)k^2+1=\tau^2,\\
\text{S126-E13}&c=ksn^2+\zeta,\\
\text{S126-E14}&k=\zeta+\eta,\\
\text{S126-E15}&k=r+1+h_0(p-1),\\
\text{S126-E16}&V=MU,\\
\text{S126-E17}&c=2r+1+C_1+\varphi,\\
\text{S126-E18}&d=bw+c(A-2)+(4A-5)\gamma,\\
\text{S126-E19}&d^2=(A^2-1)c^2+1,\\
\text{S126-E20}&f^2=(A^2-1)(ic^2)^2+1,\\
\text{S126-E21}&(d+\omega f)^2=\bigl((A+f^2(d^2-A))^2-1\bigr)(2r+1+jc)^2+1,\\
\text{S126-E22}&C_1=E+J(A-1),\\
\text{S126-E23}&D_1^2=(A^2-1)C_1^2+1,\\
\text{S126-E24}&D_1=q+C_1(A-b)+\nu(2Ab-b^2-1),\\
\text{S126-E25}&r=n+\rho.
\end{array}
\]

Procedencia exacta: E01–E04 son M1a–M1d de C3; E13–E14 son L10a–L10b de C2; E22–E24 son H18–H20 de C1. E17 conserva la forma \(c=2r+1+C_1+\varphi\), con los testigos del selector C1. Las restantes ecuaciones son las preservadas en C3. La nueva \(\alpha\) y la nueva \(\eta\) tienen las funciones indicadas aquí; no se identifican con los testigos homónimos de versiones anteriores.

## A.4 Teorema lógico

### Fuente, normalización y admisibilidad

[P] Se utiliza la representación normalizada de Jones (1982, pp. 560–561): el conjunto c.e. \(W\subseteq\mathbb Z_{>0}\) tiene una representación mediante un polinomio entero de **grado total a lo sumo cuatro**, con 58 auxiliares no negativos, tal que

\[
x\in W\iff\exists\xi_1,\ldots,\xi_{58}\ge0\;P(x,\xi_1,\ldots,\xi_{58})=0,
\qquad P(x,0,\ldots,0)\ne0\quad(x>0).
\]

Esta representación publicada es una dependencia de la construcción; no se afirma que cualquier polinomio cuártico arbitrario ya tenga esa normalización. Se incluye la variable \(x=\xi_0\) en el grado total. Escribimos

\[
P=\sum_{|\boldsymbol i|\le4}p_{\boldsymbol i}\prod_{j=0}^{58}\xi_j^{i_j},
\qquad P_{\boldsymbol i}=(4-|\boldsymbol i|)!\left(\prod_{j=0}^{58}i_j!\right)p_{\boldsymbol i}.
\]

La suma recorre **todos** los multiíndices de grado a lo sumo cuatro, incluidos los de coeficiente cero. Con \(\kappa=5^{58},K=5^{59},E=5^{60}\), la admisibilidad significa exactamente que se ha elegido una potencia de dos

\[
z>1+\max_{|\boldsymbol i|\le4}|P_{\boldsymbol i}|,
\]

y se han compilado

\[
u=\sum_{j=1}^{58}(2z)^{5^j},\qquad
y=\sum_{|\boldsymbol i|\le4}(z+P_{\boldsymbol i})(2z)^{K-\sum_{j=0}^{58}i_j5^j}.
\]

Los exponentes son distintos y no negativos, pues \(\sum i_j5^j\le4\kappa<K\). Además \(0<z+P_{\boldsymbol i}<2z\), \(u\ge2z\) y \(y\ge(2z)^K>2z60^4>32z\). Los parámetros dependen de \(P\), no de la entrada \(x\).

**[R] Teorema.** Para cualquier representación fuente y cualquier terna admisible así obtenida,

\[
\boxed{\forall x\in\mathbb Z_{>0},\qquad
x\in W\iff\exists\mathbf v\in\mathbb Z_{>0}^{37}\;S126(x,\mathbf v;z,u,y).}
\]

### Dependencias matemáticas de la demostración

[P] Se utilizan los siguientes resultados de Jones (1982), en las instancias fijadas por los expedientes. Se explicitan porque verificar identidades polinómicas no demuestra por sí solo el teorema lógico.

1. **Pell (lemas 2.18 y 2.20).** Para \(a\ge2\), se define \((\chi_a(0),\psi_a(0))=(1,0)\) y
   \[
   \chi_a(h+1)=a\chi_a(h)+(a^2-1)\psi_a(h),\quad
   \psi_a(h+1)=\chi_a(h)+a\psi_a(h).
   \]
   Las soluciones positivas de \(X^2-(a^2-1)Y^2=1\) son exactamente \((\chi_a(h),\psi_a(h))\), \(h\ge1\). Se tiene \(\psi_a(h)\equiv h\pmod{a-1}\), monotonía estricta y, para los índices \(h>2\) usados abajo, \((2a-1)^{h-1}<\psi_a(h)<(2a)^{h-1}\).
2. **Índice Pell impar (corolario 2.29).** Con \(A>1\), \(N\) impar y \(1<N<c\), las ecuaciones E19–E21 —con \(N=2r+1\) en E21— y testigos positivos \(f,i,j,\omega\) certifican exactamente \(c=\psi_A(N),d=\chi_A(N)\). Recíprocamente esos valores admiten dichos testigos positivos, conservando \(d\).
3. **Puente exponencial/binomial (lemas 2.22, 2.24–2.26).** La congruencia \(3W_0\psi_A(N)\equiv2(W_0^2-1)\pmod{4A-5}\), bajo \(N>1\), \(W_0>1\), \(A>W_0^3\) y \(A>2^{3N}\), da \(W_0=2^N\) en la instancia de base dos usada aquí. En la dirección constructiva del paquete, para \(b\) potencia de dos, \(r>n>b>1\), \(n>8\) y \(n^2\mid\binom{2r}{r}\), se toma \(w=2^{2r+1}/b\), \(U=wn^2\), \(Y=\lfloor(U+1)^{2r}/U^r\rfloor\), \(s=Y/n^2\), \(M=rY\), \(A=M(U+1)\), \(p=2M^2U\), \(k=\psi_p(r+1)\), \(c=\psi_A(2r+1)\), \(d=\chi_A(2r+1)\). El paquete proporciona la norma de \(k\), su congruencia de índice, la ventana \(|c/k-Y|<1/2\), la congruencia de E18 y las cotas de crecimiento utilizadas abajo. C2 refina la ventana a \(0<c/k-Y<1/4\); esa refinación se justifica explícitamente en la corrección.
4. **Acarreos y cambio de base (lemas 2.7–2.9, 2.11 y 2.16; §4).** Para \(n\) potencia de dos, \(0<S,T<n\) y \(r=S(n^2-n)+(T+1)(n^2-1)\), se tiene \(n^2\mid\binom{2r}{r}\iff\tau_2(S,T)=0\). Los bloques de longitudes potencia de dos, con \(0\le S_a,T_a<N_a\), separan esta condición en tres condiciones independientes. El cambio de base usa bases potencia de dos \(2z<\beta\), longitudes \(K+1<2K<4K\), la cota \(2(2z)^{2K+1}<\beta\) y las congruencias de E07–E08: con \(e,\ell<q^2\) y la máscara de \(4K\) posiciones, recupera las expansiones escritas abajo. La primera máscara recupera los dígitos de \(g\). No se utiliza ninguna de estas operaciones digitales como instrucción del DAG.

### Completitud

[R] Supongamos \(x\in W\). Elegimos una solución fuente \(\boldsymbol\xi\ge0\) de \(P=0\). No es totalmente nula por la normalización. Tomamos \(b\), potencia de dos, suficientemente grande para que \(b>xy\) y \(\xi_j<b\), y definimos

\[
\beta=b^5,\quad q=\beta^K=b^E,\quad
\lambda=\frac{q^4-1}{\beta-1},\quad\theta=\beta-2z,
\]
\[
\ell=\sum_{j=1}^{58}\beta^{5^j},\quad
e=\sum_{|\boldsymbol i|\le4}(z+P_{\boldsymbol i})\beta^{K-\sum i_j5^j},\quad
g=\sum_{j=1}^{58}\xi_j\beta^{5^j}.
\]

Estos enteros son positivos. Las cotas \(\ell<2\beta^\kappa\), \(e<2z\beta^{K+1}\), \(g<b\beta^\kappa\) implican \(e,\ell<q^2\) y \(g<q\). Por tanto

\[
\alpha=b-xy,\quad\varepsilon_e=q^2-e,\quad
\varepsilon_\ell=q^2-\ell,\quad\varepsilon_g=q-g
\]

son positivos. Evaluar el mismo polinomio en \(\beta\) y en \(2z\) da congruencias módulo \(\beta-2z\); además \(\ell>u,e>y\). Se fijan \(t=(\ell-u)/\theta>0\), \(m=(e-y)/\theta>0\). Quedan satisfechas E01–E08.

Se toma \(n=q^{16}\) y se define \(r\) por E10. Los bloques digitales de la corrección son positivos y menores que sus ventanas. Sus dos primeras condiciones de ausencia de acarreo se cumplen por las expansiones; la tercera equivale a \(P=0\) por la identidad detectora demostrada abajo. De ahí \(n^2\mid\binom{2r}{r}\) y \(r>n\). Ponemos \(\rho=r-n>0\).

Aplicamos ahora la construcción del puente binomial del punto 3. El cociente \(w=2^{2r+1}/b\) es entero porque \(b\) es potencia de dos y \(r>b\). La expansión binomial de \(P_0\) y \(n^2\mid\binom{2r}{r}\) aseguran que \(Y\) es divisible por \(n^2\). Así \(s,M,A,p,k,c,d\) quedan fijados como allí se indica. Tomamos

\[
\tau=\chi_p(r+1),\qquad h_0=\frac{k-r-1}{p-1}>0.
\]

La congruencia Pell hace entero a \(h_0\), y el crecimiento de \(\psi_p(r+1)\) da su positividad. E11, E12, E15 y E16 se satisfacen. El argumento de C2 expuesto abajo, que también vale partiendo de la ventana simétrica del puente, da \(0<c-kY<k/4\). Definimos

\[
\zeta=c-kY>0,\qquad\eta=k-\zeta>0,
\]

y obtenemos E13–E14. La congruencia constructiva del puente hace entero a

\[
\gamma=\frac{d-bw-(A-2)c}{4A-5}.
\]

Es positivo: \(d=Ac-\psi_A(N-1)\), \(N=2r+1\), y las cotas del paquete dan \(c>bw\), de modo que el numerador es \(2c-\psi_A(N-1)-bw>c-bw>0\). E18 queda satisfecha; el corolario 2.29 proporciona los testigos positivos \(f,i,j,\omega\) para E19–E21.

Resta construir el selector final. Se tienen \(E<N<A\). Elegimos

\[
C_1=\psi_A(E),\quad D_1=\chi_A(E),\quad
J=\frac{\psi_A(E)-E}{A-1},\quad
\varphi=c-N-\psi_A(E).
\]

La congruencia Pell y \(\psi_A(E)>E\) dan \(J>0\) entero. Los incrementos de \(\psi_A\) satisfacen \(\psi_A(h+1)-\psi_A(h)\ge2h+1\); por ello
\(\psi_A(N)-\psi_A(E)\ge N^2-E^2>N\) y \(\varphi>0\). Esto prueba E17, E22 y E23 con todos sus dominios.

Definamos \(\Delta_b=2Ab-b^2-1\), \(F_h=\chi_A(h)+(b-A)\psi_A(h)\). La recurrencia da

\[
F_{h+1}-bF_h=\Delta_b\psi_A(h),\qquad
F_E=b^E+\Delta_b Q_E,\quad
Q_E=\sum_{h=1}^{E-1}b^{E-1-h}\psi_A(h)>0.
\]

Con \(\nu=Q_E\) y \(q=b^E\) se cumple E24. Se han construido los 37 testigos estrictamente positivos de las 25 ecuaciones.

### Corrección

[R] Supongamos una solución positiva de S126. E01–E04 dan \(b>xy\), \(e,\ell<q^2\), \(g<q\). E05 implica \(q^4=1+\lambda(\beta-1)\ge b^5\), luego \(q>b\). E09 y E25 dan \(n=q^{16}<r\). La admisibilidad implica, antes de recuperar la exponencial, \(b>y>32z\), \(b>2z60^4\) y \(b>3E\).

**Paquete Pell y ventana C2.** Pongamos \(Y=sn^2,U=wn^2,M=rY,N=2r+1,W_0=bw,R=c/k\). E11 y E16 dan

\[
A=M(U+1),\qquad p=2M^2U.
\]

En particular \(A>1,p>A,2A<2p-1,p>r+2\), y \(Y,U>64\). Por E17, \(1<N<c\); el corolario 2.29 aplica a E19–E21 y da \(c=\psi_A(N),d=\chi_A(N)\). E12 identifica \(k=\psi_p(j_0)\) para algún \(j_0\ge1\). E15 y la congruencia Pell dan \(j_0=r+1+h(p-1)\), \(h\ge0\). E13–E14 implican \(0<R-Y<1\). Si \(h\ge1\), las cotas Pell dan

\[
R<\frac{(2A)^{2r}}{(2p-1)^{r+p-1}}
<(2p-1)^{r-p+1}<1,
\]

en contradicción con \(R>Y-1>63\). Por tanto \(k=\psi_p(r+1)\).

Para \(P_0=(U+1)^{2r}/U^r\), las cotas Pell y Bernoulli proporcionan

\[
P_0(1-r/A)<R<P_0(1+r/p).
\]

Como \(r/A=1/[Y(U+1)]<1/64\) y \(R<Y+1\), se obtiene \(P_0/Y<2\) y \(Y>U^{r-1}\). En consecuencia

\[
A>rU^r>n^n,\quad N<A,\quad A>2^{3N},\quad A>W_0^3.
\]

E18 y E19 dan algebraicamente
\(3W_0c\equiv2(W_0^2-1)\pmod{4A-5}\). El lema 2.22, con las cotas recién verificadas, fuerza \(W_0=2^N\); por tanto \(b\) es potencia de dos.

Ahora \(n^2>4b\), así que \(U>4W_0=8\cdot4^r\). Descomponemos exactamente

\[
P_0=Z+T_0,\quad
Z=\sum_{h=r}^{2r}\binom{2r}{h}U^{h-r},\quad
T_0=\sum_{h=0}^{r-1}\binom{2r}{h}U^{h-r}.
\]

Se tiene \(\binom{2r}{r-1}/U\le T_0<4^r/U<1/8\), con \(\binom{2r}{r-1}>2\). Las estimaciones previas dan \(|R-P_0|<2/(U+1)\), de donde

\[
0<T_0-\frac2{U+1}<R-Z<T_0+\frac2{U+1}<\frac14.
\]

La ventana \(0<R-Y<1\) fuerza \(Y=Z\). El mismo resultado vale para la ventana constructiva \(|R-Y|<1/2\): cualquier entero distinto de \(Z\) queda a distancia mayor que \(3/4\) o mayor que uno. Esto justifica la refinación usada en completitud. Finalmente \(Z\equiv\binom{2r}{r}\pmod U\), \(n^2\mid U\) y \(n^2\mid Y\), luego

\[
n^2\mid\binom{2r}{r}.
\]

**Selector C1.** Las cotas \(3E<b<q<n<r\), \(A>n^n\) dan \(E<N<A\), \(b^{3E}<A\), \(q^3<A\). E23 identifica \(C_1=\psi_A(j_0),D_1=\chi_A(j_0)\). E17 implica \(C_1<c=\psi_A(N)\), luego \(1\le j_0<N<A\). E22 y la congruencia de Pell dan \(j_0\equiv E\pmod{A-1}\); ambos están entre 1 y \(A-2\), de modo que \(j_0=E\). La identidad de \(F_E\) y E24 implican \(q\equiv b^E\pmod{\Delta_b}\). Puesto que \(0<q,b^E<A<\Delta_b\), resulta

\[
q=b^E=\beta^K,\qquad
\lambda=\sum_{h=0}^{4K-1}\beta^h,\qquad\theta=\beta-2z.
\]

**Bloques digitales.** Definimos

\[
\begin{array}{lll}
S_1=g,&T_1=q^3-1-(b-1)\ell,&N_1=q^3,\\
S_2=e+\ell q^2,&T_2=\theta\lambda,&N_2=q^4,\\
S_3=H,&T_3=(\beta-2)q,&N_3=q^9.
\end{array}
\]

Entonces \(S=S_1+S_2N_1+S_3N_1N_2\), \(T=T_1+T_2N_1+T_3N_1N_2\), \(N_1N_2N_3=n\). Las cotas previas dan \(0<S_a,T_a<N_a\): para el segundo bloque, \(S_2\le q^4-1\) y \(T_2<(\beta-1)\lambda=q^4-1\). Para el tercero, \(x\beta<q\), \(C_0<2q\) y

\[
0<\lambda q^4(\beta-32z)<H
<32q^6+2q^4+2q^8<4q^8<q^9.
\]

Aquí se utiliza la desigualdad válida \(\beta\lambda<2q^4\). C3 corrigió explícitamente la desigualdad heredada \(\beta\lambda<q^4\), que es falsa porque \(\beta\lambda=q^4+\lambda-1\). Este apéndice conserva esa corrección ya documentada, sin cambiar el sistema.

Los lemas de acarreos se aplican ahora, con todas sus cotas verificadas:

\[
n^2\mid\binom{2r}{r}
\iff\tau_2(S,T)=0
\iff\bigwedge_{a=1}^3\tau_2(S_a,T_a)=0.
\]

Las zonas de \(e+\ell q^2\) no se solapan. E07–E08 dan las congruencias módulo \(\beta-2z\). Se cumplen \(2(2z)^{2K+1}<\beta\), \(e,\ell<(2z)\beta^{2K}\), y las longitudes del cambio de base son \(K+1,2K,4K\). La segunda máscara recupera exactamente las expansiones de \(e,\ell\) de la completitud. La primera máscara y \(g<q\) recuperan

\[
g=\sum_{j=1}^{58}\xi_j\beta^{5^j},\qquad0\le\xi_j<b.
\]

**Detector final.** Definimos

\[
\mathcal C(X)=1+xX+\sum_{j=1}^{58}\xi_jX^{5^j},\quad
\Lambda(X)=\sum_{h=0}^{4K-1}X^h,
\]
\[
\mathcal E(X)=\sum_{|\boldsymbol i|\le4}(z+P_{\boldsymbol i})X^{K-\sum i_j5^j}.
\]

La inyectividad de las posiciones en base cinco y la normalización factorial dan

\[
[X^K]\mathcal C(X)^4(\mathcal E(X)-z\Lambda(X))=24P(x,\boldsymbol\xi).
\]

Todos sus coeficientes tienen valor absoluto menor que \(z60^4b^4<\beta/2\), y el soporte está en \([0,8K)\). Añadir \((\beta/2)\Lambda(X)(1+X^{4K})\) sitúa cada cifra estrictamente entre 0 y \(\beta\), sin transportes al evaluar en \(\beta\). El dígito de orden \(K\) de

\[
E_0=C_0^4(e-z\lambda)+(\beta/2)\lambda(1+q^4)
\]

es \(\beta/2+24P(x,\boldsymbol\xi)\). Para \(0<d_0<\beta\), con \(\beta\) potencia de dos, la ausencia de acarreo con \(\beta/2-1\) equivale a \(d_0=\beta/2\). Por tanto

\[
\tau_2(E_0,(\beta/2-1)q)=0\iff P(x,\boldsymbol\xi)=0.
\]

Multiplicar ambos sumandos por dos sólo desplaza los bits: \(H=2E_0\), \(T_3=2(\beta/2-1)q\). La tercera condición de acarreo fuerza \(P=0\), y con ello \(x\in W\). Esto completa la corrección. La prueba no presupone la antigua cota multiplicativa de S146 ni la usa para justificar circularmente el selector.

## A.5 DAG aritmético completo

[R] Cada fila tiene exactamente una operación binaria. `*` significa producto. «Reutilizada en» lista todos los consumidores **directos**, incluidas las comparaciones finales. Usar dos veces un registro en un cuadrado no crea dos consumidores distintos ni dos productos. Las comparaciones se ejecutan al final y cuestan cero bajo la convención fijada.

| ID | operación | operandos | salida | reutilizada en | coste acumulado |
| --- | --- | --- | --- | --- | --- |
| I001 | * | `b`, `b` | `t1` | I002 | 1 |
| I002 | * | `t1`, `t1` | `t2` | I003 | 2 |
| I003 | * | `t2`, `b` | `t3` | I011, I020, I044, E06 | 3 |
| I004 | * | `q`, `q` | `t4` | I005, I006, I032, I034, E02, E03 | 4 |
| I005 | * | `t4`, `q` | `t5` | I036, I039, I042 | 5 |
| I006 | * | `t4`, `t4` | `t6` | I007, I013, I029 | 6 |
| I007 | * | `t6`, `t6` | `t8` | I008, I045 | 7 |
| I008 | * | `t8`, `t8` | `t9` | E09 | 8 |
| I009 | * | `x`, `y` | `t15` | I010 | 9 |
| I010 | + | `t15`, `alpha` | `t16` | E01 | 10 |
| I011 | * | `lambda`, `t3` | `t18` | I012, I029, I030 | 11 |
| I012 | + | `t18`, `1` | `t19` | E05 | 12 |
| I013 | + | `lambda`, `t6` | `t20` | E05 | 13 |
| I014 | * | `2`, `z` | `t21` | I015 | 14 |
| I015 | + | `theta`, `t21` | `t22` | E06 | 15 |
| I016 | * | `t`, `theta` | `t23` | I017 | 16 |
| I017 | + | `u`, `t23` | `t24` | E07 | 17 |
| I018 | * | `m`, `theta` | `t25` | I019 | 18 |
| I019 | + | `y`, `t25` | `t26` | E08 | 19 |
| I020 | * | `x`, `t3` | `t27` | I021 | 20 |
| I021 | + | `t27`, `1` | `t28` | I022 | 21 |
| I022 | + | `t28`, `g` | `t29` | I023 | 22 |
| I023 | * | `t29`, `t29` | `t30` | I024 | 23 |
| I024 | * | `t30`, `t30` | `t31` | I027 | 24 |
| I025 | * | `z`, `lambda` | `t32` | I026 | 25 |
| I026 | - | `e`, `t32` | `t33` | I027 | 26 |
| I027 | * | `t33`, `t31` | `t34` | I028 | 27 |
| I028 | * | `2`, `t34` | `t35` | I030 | 28 |
| I029 | * | `t18`, `t6` | `t36` | I031 | 29 |
| I030 | + | `t35`, `t18` | `t37` | I031 | 30 |
| I031 | + | `t37`, `t36` | `t38` | I032 | 31 |
| I032 | * | `t38`, `t4` | `t39` | I033 | 32 |
| I033 | + | `ell`, `t39` | `t40` | I034 | 33 |
| I034 | * | `t40`, `t4` | `t41` | I035 | 34 |
| I035 | + | `e`, `t41` | `t42` | I036 | 35 |
| I036 | * | `t42`, `t5` | `t43` | I037 | 36 |
| I037 | + | `g`, `t43` | `t44` | I050 | 37 |
| I038 | * | `b`, `ell` | `t45` | I039 | 38 |
| I039 | - | `t5`, `t45` | `t46` | I040 | 39 |
| I040 | + | `t46`, `ell` | `t47` | I043 | 40 |
| I041 | * | `theta`, `lambda` | `t48` | I042 | 41 |
| I042 | * | `t48`, `t5` | `t49` | I043 | 42 |
| I043 | + | `t47`, `t49` | `t50` | I046 | 43 |
| I044 | - | `t3`, `2` | `t51` | I045 | 44 |
| I045 | * | `t51`, `t8` | `t52` | I046 | 45 |
| I046 | + | `t50`, `t52` | `t53` | I051 | 46 |
| I047 | * | `n`, `n` | `t54` | I048, I049, I053, I056 | 47 |
| I048 | - | `t54`, `n` | `t55` | I050 | 48 |
| I049 | - | `t54`, `1` | `t56` | I051 | 49 |
| I050 | * | `t44`, `t55` | `t57` | I052 | 50 |
| I051 | * | `t53`, `t56` | `t58` | I052 | 51 |
| I052 | + | `t57`, `t58` | `t59` | E10 | 52 |
| I053 | * | `s`, `t54` | `t60` | I054, I065 | 53 |
| I054 | * | `r`, `t60` | `t61` | I055, I057, I072 | 54 |
| I055 | - | `A`, `t61` | `t62` | I057, E16 | 55 |
| I056 | * | `w`, `t54` | `t63` | I072 | 56 |
| I057 | * | `t61`, `t62` | `t64` | I058 | 57 |
| I058 | * | `2`, `t64` | `t65` | E11 | 58 |
| I059 | * | `p`, `p` | `t66` | I060 | 59 |
| I060 | - | `t66`, `1` | `t67` | I062 | 60 |
| I061 | * | `k`, `k` | `t68` | I062 | 61 |
| I062 | * | `t67`, `t68` | `t69` | I063 | 62 |
| I063 | + | `t69`, `1` | `t70` | E12 | 63 |
| I064 | * | `tau`, `tau` | `t71` | E12 | 64 |
| I065 | * | `k`, `t60` | `t73` | I066 | 65 |
| I066 | + | `t73`, `zeta` | `t74` | E13 | 66 |
| I067 | + | `zeta`, `eta` | `t77` | E14 | 67 |
| I068 | + | `r`, `1` | `t78` | I071, I073 | 68 |
| I069 | - | `p`, `1` | `t79` | I070 | 69 |
| I070 | * | `h0`, `t79` | `t80` | I071 | 70 |
| I071 | + | `t78`, `t80` | `t81` | E15 | 71 |
| I072 | * | `t61`, `t63` | `t84` | E16 | 72 |
| I073 | + | `r`, `t78` | `t85` | I074, I104 | 73 |
| I074 | + | `t85`, `C1` | `t86` | I075 | 74 |
| I075 | + | `t86`, `varphi` | `t87` | E17 | 75 |
| I076 | * | `b`, `w` | `t88` | I082 | 76 |
| I077 | - | `A`, `2` | `t89` | I078 | 77 |
| I078 | * | `c`, `t89` | `t90` | I082 | 78 |
| I079 | * | `4`, `A` | `t91` | I080 | 79 |
| I080 | - | `t91`, `5` | `t92` | I081 | 80 |
| I081 | * | `t92`, `gamma` | `t93` | I083 | 81 |
| I082 | + | `t88`, `t90` | `t94` | I083 | 82 |
| I083 | + | `t94`, `t93` | `t95` | E18 | 83 |
| I084 | * | `A`, `A` | `t96` | I085 | 84 |
| I085 | - | `t96`, `1` | `t97` | I087, I092, I112 | 85 |
| I086 | * | `c`, `c` | `t98` | I087, I090 | 86 |
| I087 | * | `t97`, `t98` | `t99` | I088 | 87 |
| I088 | + | `t99`, `1` | `t100` | E19 | 88 |
| I089 | * | `d`, `d` | `t101` | I098, E19 | 89 |
| I090 | * | `i`, `t98` | `t102` | I091 | 90 |
| I091 | * | `t102`, `t102` | `t103` | I092 | 91 |
| I092 | * | `t97`, `t103` | `t104` | I093 | 92 |
| I093 | + | `t104`, `1` | `t105` | E20 | 93 |
| I094 | * | `f`, `f` | `t106` | I099, E20 | 94 |
| I095 | * | `omega`, `f` | `t107` | I096 | 95 |
| I096 | + | `d`, `t107` | `t108` | I097 | 96 |
| I097 | * | `t108`, `t108` | `t109` | E21 | 97 |
| I098 | - | `t101`, `A` | `t110` | I099 | 98 |
| I099 | * | `t106`, `t110` | `t111` | I100 | 99 |
| I100 | + | `A`, `t111` | `t112` | I101 | 100 |
| I101 | * | `t112`, `t112` | `t113` | I102 | 101 |
| I102 | - | `t113`, `1` | `t114` | I106 | 102 |
| I103 | * | `j`, `c` | `t115` | I104 | 103 |
| I104 | + | `t85`, `t115` | `t116` | I105 | 104 |
| I105 | * | `t116`, `t116` | `t117` | I106 | 105 |
| I106 | * | `t114`, `t117` | `t118` | I107 | 106 |
| I107 | + | `t118`, `1` | `t119` | E21 | 107 |
| I108 | - | `A`, `1` | `t129` | I109 | 108 |
| I109 | * | `J`, `t129` | `t130` | I110 | 109 |
| I110 | + | `t130`, `E` | `t131` | E22 | 110 |
| I111 | * | `C1`, `C1` | `t132` | I112 | 111 |
| I112 | * | `t97`, `t132` | `t133` | I113 | 112 |
| I113 | + | `t133`, `1` | `t134` | E23 | 113 |
| I114 | * | `D1`, `D1` | `t135` | E23 | 114 |
| I115 | - | `A`, `b` | `t136` | I116, I119 | 115 |
| I116 | + | `t136`, `A` | `t137` | I117 | 116 |
| I117 | * | `b`, `t137` | `t138` | I118 | 117 |
| I118 | - | `t138`, `1` | `t139` | I120 | 118 |
| I119 | * | `C1`, `t136` | `t140` | I121 | 119 |
| I120 | * | `nu`, `t139` | `t142` | I122 | 120 |
| I121 | + | `q`, `t140` | `t143` | I122 | 121 |
| I122 | + | `t143`, `t142` | `t144` | E24 | 122 |
| I123 | + | `n`, `rho` | `t146` | E25 | 123 |
| I124 | + | `e`, `eps_e` | `t147` | E02 | 124 |
| I125 | + | `ell`, `eps_l` | `t148` | E03 | 125 |
| I126 | + | `g`, `eps_g` | `t149` | E04 | 126 |


## A.6 Desglose independiente

[R] El recuento directo de la columna «operación» de A.5 da

\[
N_+=42,\qquad N_-=16,\qquad N_\times=68,\qquad42+16+68=126.
\]

Esta segunda partición agrupa filas disjuntas por función; cada registro aparece en un solo bloque, aunque lo utilicen varias ecuaciones:

| bloque disjunto | + | − | × | total |
| --- | --- | --- | --- | --- |
| Potencias iniciales | 0 | 0 | 8 | 8 |
| Cotas C3 | 4 | 0 | 1 | 5 |
| E05–E08 | 5 | 0 | 4 | 9 |
| Detector H | 4 | 1 | 7 | 12 |
| Ensamblaje S | 3 | 0 | 3 | 6 |
| Ensamblaje T+1 | 3 | 2 | 4 | 9 |
| Cuadrado n² | 0 | 0 | 1 | 1 |
| Cierre E10 | 1 | 2 | 2 | 5 |
| Resto | 22 | 11 | 38 | 71 |


Además se ejecutó el verificador independiente de A.9: vuelve a analizar las filas, cuenta los operadores mediante dos recorridos y compara simbólicamente los **50 miembros** del sistema con una especificación polinómica separada del DAG. El verificador original de C3, escrito en JavaScript, también se ejecutó sin cambios: devolvió 42/16/68, 25 comparaciones, 37 testigos, 21 ecuaciones preservadas y cero registros muertos. Las dos implementaciones no deducen la distribución de operadores del total declarado.

## A.7 Cobertura de ecuaciones

[R] `lhs` y `rhs` indican entradas o registros finales, sin aritmética adicional. «Registros» enumera el cono de dependencias completo de cada igualdad, en orden topológico. Su unión es exactamente el conjunto de las 126 salidas de A.5. No se calcula un residuo `lhs-rhs`: se comparan los valores directamente.

| ecuación | lhs | rhs | registros | comparación final |
| --- | --- | --- | --- | --- |
| S126-E01 | `b` | `t16` | t15, t16 | `b == t16` |
| S126-E02 | `t147` | `t4` | t4, t147 | `t147 == t4` |
| S126-E03 | `t148` | `t4` | t4, t148 | `t148 == t4` |
| S126-E04 | `t149` | `q` | t149 | `t149 == q` |
| S126-E05 | `t20` | `t19` | t1, t2, t3, t4, t6, t18, t19, t20 | `t20 == t19` |
| S126-E06 | `t22` | `t3` | t1, t2, t3, t21, t22 | `t22 == t3` |
| S126-E07 | `ell` | `t24` | t23, t24 | `ell == t24` |
| S126-E08 | `e` | `t26` | t25, t26 | `e == t26` |
| S126-E09 | `n` | `t9` | t4, t6, t8, t9 | `n == t9` |
| S126-E10 | `r` | `t59` | t1, t2, t3, t4, t5, t6, t8, t18, t27, t28, t29, t30, t31, t32, t33, t34, t35, t36, t37, t38, t39, t40, t41, t42, t43, t44, t45, t46, t47, t48, t49, t50, t51, t52, t53, t54, t55, t56, t57, t58, t59 | `r == t59` |
| S126-E11 | `p` | `t65` | t54, t60, t61, t62, t64, t65 | `p == t65` |
| S126-E12 | `t70` | `t71` | t66, t67, t68, t69, t70, t71 | `t70 == t71` |
| S126-E13 | `c` | `t74` | t54, t60, t73, t74 | `c == t74` |
| S126-E14 | `k` | `t77` | t77 | `k == t77` |
| S126-E15 | `k` | `t81` | t78, t79, t80, t81 | `k == t81` |
| S126-E16 | `t62` | `t84` | t54, t60, t61, t62, t63, t84 | `t62 == t84` |
| S126-E17 | `c` | `t87` | t78, t85, t86, t87 | `c == t87` |
| S126-E18 | `d` | `t95` | t88, t89, t90, t91, t92, t93, t94, t95 | `d == t95` |
| S126-E19 | `t101` | `t100` | t96, t97, t98, t99, t100, t101 | `t101 == t100` |
| S126-E20 | `t106` | `t105` | t96, t97, t98, t102, t103, t104, t105, t106 | `t106 == t105` |
| S126-E21 | `t109` | `t119` | t78, t85, t101, t106, t107, t108, t109, t110, t111, t112, t113, t114, t115, t116, t117, t118, t119 | `t109 == t119` |
| S126-E22 | `C1` | `t131` | t129, t130, t131 | `C1 == t131` |
| S126-E23 | `t135` | `t134` | t96, t97, t132, t133, t134, t135 | `t135 == t134` |
| S126-E24 | `D1` | `t144` | t136, t137, t138, t139, t140, t142, t143, t144 | `D1 == t144` |
| S126-E25 | `r` | `t146` | t146 | `r == t146` |


## A.8 Dependencias compartidas

[R] La siguiente lista es exhaustiva para los registros que pertenecen al cono de **más de una ecuación**. La expresión de cada registro está definida en A.5; se incluyen tanto reutilizaciones directas como transitivas.

| registro / subexpresión definida en A.5 | ecuaciones que lo usan (directa o transitivamente) |
| --- | --- |
| `t1` | E05, E06, E10 |
| `t2` | E05, E06, E10 |
| `t3` | E05, E06, E10 |
| `t4` | E02, E03, E05, E09, E10 |
| `t6` | E05, E09, E10 |
| `t8` | E09, E10 |
| `t18` | E05, E10 |
| `t54` | E10, E11, E13, E16 |
| `t60` | E11, E13, E16 |
| `t61` | E11, E16 |
| `t62` | E11, E16 |
| `t78` | E15, E17, E21 |
| `t85` | E17, E21 |
| `t96` | E19, E20, E23 |
| `t97` | E19, E20, E23 |
| `t98` | E19, E20 |
| `t101` | E19, E21 |
| `t106` | E20, E21 |


Por ejemplo, `t4=q*q` verifica las dos cotas E02–E03, alimenta `t6=q^4` y participa en el ensamblaje de E10. `t54=n*n` sirve a E10 y a la infraestructura de E11, E13 y E16. `t97=A*A-1` se comparte entre E19, E20 y E23. Ninguno se vuelve a calcular por cada uso.

Si se sumaran los tamaños de los 25 conos por separado, se contarían **157** operaciones, repitiendo esas dependencias. La unión de los conos contiene 126 nodos. El coste certificado es el del DAG global, no la suma de costes de evaluaciones independientes de cada ecuación.

## A.9 QA reproducible

[R] Se ejecutaron los tres verificadores originales, extraídos de los bloques JavaScript de C1, C2 y C3, con sus respectivos expedientes como entrada. C1 confirmó 130 operaciones y las identidades de su selector; C2 confirmó 128 operaciones y la preservación de 20 ecuaciones; C3 confirmó las 126 operaciones finales y la preservación de las 21 ecuaciones ajenas a su sustitución. Estos datos sólo documentan la concordancia entre expedientes; no se incorporan circuitos anteriores al certificado final.

Se contrastaron además las referencias internas de los verificadores con los expedientes efectivos: las 130 instrucciones y 21 comparaciones de C1 coinciden exactamente con la base incorporada por C2; las 128 instrucciones y 22 comparaciones de C2 coinciden exactamente con la base incorporada por C3. No se detectaron discrepancias de ecuaciones, operaciones ni dominios en esa cadena.

El contraste documental con el informe final confirma el dominio positivo, las 37 incógnitas, las 25 ecuaciones, los parámetros admisibles, la normalización y el desglose 42/16/68. La palabra «provisional» del expediente C3 describe su estado antes del cierre: el informe final lo congela como S126. El informe escribe \(\phi\) donde C3 escribe \(\varphi\); aquí se mantiene `varphi`, el identificador del DAG. Para evitar colisiones de notación, se escribe \(\Delta_b=2Ab-b^2-1\) en el selector y se deja \(A^2-1\) explícito en las normas. Son aclaraciones de nombres, no modificaciones de ecuaciones.

| comprobación | resultado ejecutado o contraste documental |
| --- | --- |
| DAG acíclico y orden topológico | PASS; cada operando está disponible antes de usarse |
| Dependencias y nombres de salida | PASS; sin redefiniciones ni referencias adelantadas |
| Nodos operacionales | PASS; exactamente 126 |
| Distribución de operadores | PASS; 42 sumas, 16 restas, 68 productos |
| Comparaciones finales | PASS; exactamente 25 |
| Entrada, parámetros y testigos | PASS; 1 + 3 + 37; todos utilizados |
| Símbolos operacionales huérfanos | PASS; ninguno |
| Registros muertos | PASS; ninguno; los 126 llegan a una comparación |
| Cobertura | PASS; 25 conos calculados y comparados con A.7 |
| Doble cómputo | PASS; 126 salidas distintas, cada una pagada una vez |
| Especificación algebraica | PASS; igualdad polinómica exacta de los 50 miembros |
| Consumidores de A.5 | PASS; listas reconstruidas desde operandos y comparaciones |
| C1/C2/C3 | PASS; verificadores originales ejecutados; transformaciones y pruebas conservadas |
| Informe final | Conforme en interfaz, admisibilidad y presupuesto; contraste textual |
| Formalización de la prueba lógica | No realizada; prueba escrita de A.4 con dependencias publicadas explícitas |

### Verificador independiente del propio apéndice

Guardar el bloque siguiente como `verify_certificate.py` y ejecutar:

```bash
python3 verify_certificate.py S126_REPRODUCIBLE_CERTIFICATE_v01.md
```

Sólo requiere Python 3 y su biblioteca estándar. No genera testigos ni prueba automáticamente los lemas de A.4. Analiza las tablas publicadas, comprueba su estructura y expande polinomios exactamente sobre \(\mathbb Z\); no emplea muestreo numérico.

```python
"""Python 3, biblioteca estándar. Uso: python3 verify_certificate.py certificado.md"""
import ast
import collections
import json
import re
import sys
from pathlib import Path

# Polinomios dispersos sobre Z. Monomio: tupla ordenada (variable, exponente).
class Poly:
    def __init__(self, terms):
        self.terms = {m: c for m, c in terms.items() if c}
    @staticmethod
    def cast(x):
        return x if isinstance(x, Poly) else Poly({(): x})
    @staticmethod
    def var(name):
        return Poly({((name, 1),): 1})
    def __add__(self, other):
        other = Poly.cast(other)
        d = dict(self.terms)
        for m, c in other.terms.items():
            d[m] = d.get(m, 0) + c
        return Poly(d)
    __radd__ = __add__
    def __neg__(self):
        return Poly({m: -c for m, c in self.terms.items()})
    def __sub__(self, other):
        return self + -Poly.cast(other)
    def __rsub__(self, other):
        return Poly.cast(other) + -self
    def __mul__(self, other):
        other = Poly.cast(other)
        d = collections.defaultdict(int)
        for m, c in self.terms.items():
            for n, e in other.terms.items():
                powers = dict(m)
                for v, h in n:
                    powers[v] = powers.get(v, 0) + h
                d[tuple(sorted(powers.items()))] += c * e
        return Poly(d)
    __rmul__ = __mul__
    def __pow__(self, n):
        assert isinstance(n, int) and n >= 0
        r = Poly.cast(1)
        for _ in range(n):
            r = r * self
        return r
    def __eq__(self, other):
        return self.terms == Poly.cast(other).terms

def expression(text, env):
    def walk(node):
        if isinstance(node, ast.Name):
            return env[node.id]
        if isinstance(node, ast.Constant):
            assert type(node.value) is int
            return node.value
        if isinstance(node, ast.BinOp):
            a, b = walk(node.left), walk(node.right)
            if isinstance(node.op, ast.Add): return a + b
            if isinstance(node.op, ast.Sub): return a - b
            if isinstance(node.op, ast.Mult): return a * b
            if isinstance(node.op, ast.Pow): return a ** b
        raise ValueError(ast.dump(node))
    return Poly.cast(walk(ast.parse(text, mode='eval').body))

md = Path(sys.argv[1]).read_text()
dag = md.split('## A.5 ')[1].split('## A.6 ')[0]
coverage = md.split('## A.7 ')[1].split('## A.8 ')[0]
ops = []
for row in dag.splitlines():
    if not re.match(r'^\| I\d{3} \|', row): continue
    fields = [s.strip() for s in row.strip('|').split('|')]
    ident, op, operands, out, uses, accumulated = fields
    a, b = re.fullmatch(r'`(\w+)`, `(\w+)`', operands).groups()
    reg = out.strip('`')
    assert op in '+-*'
    assert ident == 'I%03d' % (len(ops)+1)
    assert int(accumulated) == len(ops)+1
    ops.append((reg, a, op, b, uses))
cs = []
for row in coverage.splitlines():
    if not row.startswith('| S126-E'): continue
    ident, a, b, regs, comparison = [s.strip() for s in row.strip('|').split('|')]
    assert ident == 'S126-E%02d' % (len(cs)+1)
    a, b = a.strip('`'), b.strip('`')
    assert comparison == f'`{a} == {b}`'
    cs.append((a, b, set(regs.split(', ')) if regs else set()))

inputs = 'x z u y b e g ell m n q r t w alpha lambda theta p s k tau eta h0 A c varphi d gamma f i j omega C1 D1 J nu rho zeta eps_e eps_l eps_g'.split()
assert len(inputs) == len(set(inputs)) == 41
env = {v: Poly.var(v) for v in inputs + ['E']}
env.update({str(n): Poly.cast(n) for n in [1, 2, 4, 5]})
orig = dict(env)
ancestors = {}; consumers = collections.defaultdict(list)
counts = collections.Counter()
for index, (reg, a, op, b, uses) in enumerate(ops, 1):
    assert reg not in env and a in env and b in env
    counts[op] += 1
    env[reg] = (env[a] + env[b] if op == '+' else
                env[a] - env[b] if op == '-' else env[a] * env[b])
    ancestors[reg] = {reg} | ancestors.get(a, set()) | ancestors.get(b, set())
    for v in set([a, b]): consumers[v].append('I%03d' % index)
live = set()
for index, (a, b, listed) in enumerate(cs, 1):
    assert a in env and b in env
    actual = ancestors.get(a, set()) | ancestors.get(b, set())
    assert listed == actual, ('coverage', index)
    live |= actual
    for v in set([a, b]): consumers[v].append('E%02d' % index)
assert len(ops) == len(ancestors) == len(live) == 126
assert len(cs) == 25
assert counts == {'+': 42, '-': 16, '*': 68}
assert all(consumers[v] for v in orig), 'unused input/constant'
for reg, a, op, b, uses in ops:
    assert uses == ', '.join(consumers[reg]), ('consumers', reg)

# Segunda cuenta por filas, independiente del Counter acumulado en la evaluación.
independent = {op: sum(row[2] == op for row in ops) for op in '+-*'}
assert independent == {'+': 42, '-': 16, '*': 68}
assert sum(independent.values()) == 126

# Especificación polinómica independiente del DAG, transcripción de A.3.
definitions = {
    'beta': 'b**5', 'C0': '1+x*b**5+g',
    'H': '2*(e-z*lambda)*C0**4+lambda*beta*(1+q**4)',
    'S': 'g+e*q**3+ell*q**5+H*q**7',
    'Tp': 'q**3-b*ell+ell+theta*lambda*q**3+(beta-2)*q**8',
    'M': 'r*s*n**2', 'V': 'A-M', 'U': 'w*n**2'
}
# lambda es palabra reservada de Python; se renombra solo en el analizador.
def parse(text, scope):
    return expression(re.sub(r'\blambda\b', 'lam', text),
                      {('lam' if k == 'lambda' else k): v for k,v in scope.items()})
for k, text in definitions.items(): orig[k] = parse(text, orig)
equations = [
    ('b','x*y+alpha'), ('e+eps_e','q**2'),
    ('ell+eps_l','q**2'), ('g+eps_g','q'),
    ('lambda+q**4','1+lambda*beta'), ('theta+2*z','beta'),
    ('ell','u+t*theta'), ('e','y+m*theta'), ('n','q**16'),
    ('r','S*(n**2-n)+Tp*(n**2-1)'), ('p','2*M*V'),
    ('(p**2-1)*k**2+1','tau**2'), ('c','k*s*n**2+zeta'),
    ('k','zeta+eta'), ('k','r+1+h0*(p-1)'), ('V','M*U'),
    ('c','2*r+1+C1+varphi'), ('d','b*w+c*(A-2)+(4*A-5)*gamma'),
    ('d**2','(A**2-1)*c**2+1'), ('f**2','(A**2-1)*(i*c**2)**2+1'),
    ('(d+omega*f)**2','((A+f**2*(d**2-A))**2-1)*(2*r+1+j*c)**2+1'),
    ('C1','E+J*(A-1)'), ('D1**2','(A**2-1)*C1**2+1'),
    ('D1','q+C1*(A-b)+nu*(2*A*b-b**2-1)'), ('r','n+rho')
]
for index, ((a,b,_),(lhs,rhs)) in enumerate(zip(cs,equations),1):
    assert env[a] == parse(lhs,orig), ('lhs',index)
    assert env[b] == parse(rhs,orig), ('rhs',index)
assert len(equations) == 25
print(json.dumps({'status':'PASS','operations':len(ops),'count':dict(counts),
 'independent_count':independent,'comparisons':len(cs),'witnesses':37,
 'live_registers':len(live),'exact_polynomial_sides':50,
 'topological':True,'coverage':True,'consumer_lists':True}, indent=2))

```

Salida obtenida:

```json
{
  "status": "PASS",
  "operations": 126,
  "count": {"*": 68, "+": 42, "-": 16},
  "independent_count": {"+": 42, "-": 16, "*": 68},
  "comparisons": 25,
  "witnesses": 37,
  "live_registers": 126,
  "exact_polynomial_sides": 50,
  "topological": true,
  "coverage": true,
  "consumer_lists": true
}
```

### Expedientes utilizados y trazabilidad

Los expedientes se leyeron íntegramente. Las huellas corresponden a las copias textuales UTF-8 utilizadas en esta ejecución, reconstruidas de la lectura íntegra; no se presentan como huellas de los archivos binarios originales.

| expediente (texto leído íntegro) | SHA-256 del texto local UTF-8 |
| --- | --- |
| `C1_SELECTOR_EXPONENCIAL.md` | 5b8fc89e60356a859918f33703d8f6255497e6d503097220627c44e33872cc0e |
| `C2_PELL_BINOMIAL.md` | fecc3845a64e3d1f54e7d8fdd414d68399e75422ae4d57f76dcc045259373085 |
| `C3_MASCARAS_CODIFICACION.md` | a152fc4219c9aac88c85c631010c058180f47bf74d5828c01b916991d598b981 |
| `OUC_GENERATION1_FINAL_REPORT_v01.md` | 82e5e1dfa5aee22962cb1abd7ee561996338109f730cf79946667dfb8b6d67f8 |
| `Texto pegado(2).txt` | c878dee2f01041acae06b053bdc713d547a447f2bba360445223c4cfedc9248a |


- **[C1]** `C1_SELECTOR_EXPONENCIAL.md`, §§1–3, sistema y verificador: selector final, dominios y completitud positiva.
- **[C2]** `C2_PELL_BINOMIAL.md`, §§1–3, §9 y verificador: ventana lineal y prueba contextual de suficiencia.
- **[C3]** `C3_MASCARAS_CODIFICACION.md`, §§1, 3–4 y apéndices B–C: cotas positivas, corrección de estimaciones, DAG final y comparaciones.
- **[F]** `OUC_GENERATION1_FINAL_REPORT_v01.md`, §§3–4 y cierre: estado canónico y alcance lógico/aritmético.
- **[S0]** `S146_CERTIFICADO_v1.0.md`, contenido en `Texto pegado(2).txt`, §§1–6: fuente normalizada, índice admisible y dependencias publicadas de la completitud. Se utilizan únicamente esas dependencias; no se trasladan sus ecuaciones ni sus cotas auxiliares corregidas posteriormente por C3.
- **[P]** James P. Jones, “Universal Diophantine Equation”, *The Journal of Symbolic Logic* **47**(3), 1982, pp. 549–571. Referencias internas utilizadas: lemas 2.7–2.9, 2.11, 2.16, 2.18, 2.20, 2.22–2.26, corolario 2.29 y §4, según los expedientes auditados. No se realizó nueva búsqueda histórica.

## A.10 Alcance

[R] Este apéndice certifica **S126**: el sistema final de 25 ecuaciones con 37 testigos positivos, su equivalencia lógica bajo los parámetros admisibles y su verificador aritmético explícito de 126 operaciones bajo \(\mathcal C_{\rm proj}\).

No reconstruye el circuito histórico de Jones ni identifica automáticamente \(o_{\rm proj}\) con la convención histórica de \(o_{\rm Jones}\). No prueba optimalidad, no convierte 126 en una cota inferior y no formaliza toda la demostración en Lean, Coq o Isabelle. [A] El mínimo bajo una convención operacional fijada permanece sin determinar. «VERIFIED» designa las comprobaciones ejecutadas y el alcance documental y matemático explicitado en A.4 y A.9; no designa una formalización completa en un asistente de pruebas.

\[
\boxed{\texttt{S126-REPRO v1.0 — VERIFIED}}
\]

"""Python 3, biblioteca estándar. Uso: python3 verify_certificate.py certificado.md"""
import ast
import collections
import json
import re
import sys
from pathlib import Path

# Polinomios dispersos sobre Z. Monomio: tupla ordenada (variable, exponente).
class Poly:
    def __init__(self, terms):
        self.terms = {m: c for m, c in terms.items() if c}
    @staticmethod
    def cast(x):
        return x if isinstance(x, Poly) else Poly({(): x})
    @staticmethod
    def var(name):
        return Poly({((name, 1),): 1})
    def __add__(self, other):
        other = Poly.cast(other)
        d = dict(self.terms)
        for m, c in other.terms.items():
            d[m] = d.get(m, 0) + c
        return Poly(d)
    __radd__ = __add__
    def __neg__(self):
        return Poly({m: -c for m, c in self.terms.items()})
    def __sub__(self, other):
        return self + -Poly.cast(other)
    def __rsub__(self, other):
        return Poly.cast(other) + -self
    def __mul__(self, other):
        other = Poly.cast(other)
        d = collections.defaultdict(int)
        for m, c in self.terms.items():
            for n, e in other.terms.items():
                powers = dict(m)
                for v, h in n:
                    powers[v] = powers.get(v, 0) + h
                d[tuple(sorted(powers.items()))] += c * e
        return Poly(d)
    __rmul__ = __mul__
    def __pow__(self, n):
        assert isinstance(n, int) and n >= 0
        r = Poly.cast(1)
        for _ in range(n):
            r = r * self
        return r
    def __eq__(self, other):
        return self.terms == Poly.cast(other).terms

def expression(text, env):
    def walk(node):
        if isinstance(node, ast.Name):
            return env[node.id]
        if isinstance(node, ast.Constant):
            assert type(node.value) is int
            return node.value
        if isinstance(node, ast.BinOp):
            a, b = walk(node.left), walk(node.right)
            if isinstance(node.op, ast.Add): return a + b
            if isinstance(node.op, ast.Sub): return a - b
            if isinstance(node.op, ast.Mult): return a * b
            if isinstance(node.op, ast.Pow): return a ** b
        raise ValueError(ast.dump(node))
    return Poly.cast(walk(ast.parse(text, mode='eval').body))

md = Path(sys.argv[1]).read_text()
dag = md.split('## A.5 ')[1].split('## A.6 ')[0]
coverage = md.split('## A.7 ')[1].split('## A.8 ')[0]
ops = []
for row in dag.splitlines():
    if not re.match(r'^\| I\d{3} \|', row): continue
    fields = [s.strip() for s in row.strip('|').split('|')]
    ident, op, operands, out, uses, accumulated = fields
    a, b = re.fullmatch(r'`(\w+)`, `(\w+)`', operands).groups()
    reg = out.strip('`')
    assert op in '+-*'
    assert ident == 'I%03d' % (len(ops)+1)
    assert int(accumulated) == len(ops)+1
    ops.append((reg, a, op, b, uses))
cs = []
for row in coverage.splitlines():
    if not row.startswith('| S126-E'): continue
    ident, a, b, regs, comparison = [s.strip() for s in row.strip('|').split('|')]
    assert ident == 'S126-E%02d' % (len(cs)+1)
    a, b = a.strip('`'), b.strip('`')
    assert comparison == f'`{a} == {b}`'
    cs.append((a, b, set(regs.split(', ')) if regs else set()))

inputs = 'x z u y b e g ell m n q r t w alpha lambda theta p s k tau eta h0 A c varphi d gamma f i j omega C1 D1 J nu rho zeta eps_e eps_l eps_g'.split()
assert len(inputs) == len(set(inputs)) == 41
env = {v: Poly.var(v) for v in inputs + ['E']}
env.update({str(n): Poly.cast(n) for n in [1, 2, 4, 5]})
orig = dict(env)
ancestors = {}; consumers = collections.defaultdict(list)
counts = collections.Counter()
for index, (reg, a, op, b, uses) in enumerate(ops, 1):
    assert reg not in env and a in env and b in env
    counts[op] += 1
    env[reg] = (env[a] + env[b] if op == '+' else
                env[a] - env[b] if op == '-' else env[a] * env[b])
    ancestors[reg] = {reg} | ancestors.get(a, set()) | ancestors.get(b, set())
    for v in set([a, b]): consumers[v].append('I%03d' % index)
live = set()
for index, (a, b, listed) in enumerate(cs, 1):
    assert a in env and b in env
    actual = ancestors.get(a, set()) | ancestors.get(b, set())
    assert listed == actual, ('coverage', index)
    live |= actual
    for v in set([a, b]): consumers[v].append('E%02d' % index)
assert len(ops) == len(ancestors) == len(live) == 126
assert len(cs) == 25
assert counts == {'+': 42, '-': 16, '*': 68}
assert all(consumers[v] for v in orig), 'unused input/constant'
for reg, a, op, b, uses in ops:
    assert uses == ', '.join(consumers[reg]), ('consumers', reg)

# Segunda cuenta por filas, independiente del Counter acumulado en la evaluación.
independent = {op: sum(row[2] == op for row in ops) for op in '+-*'}
assert independent == {'+': 42, '-': 16, '*': 68}
assert sum(independent.values()) == 126

# Especificación polinómica independiente del DAG, transcripción de A.3.
definitions = {
    'beta': 'b**5', 'C0': '1+x*b**5+g',
    'H': '2*(e-z*lambda)*C0**4+lambda*beta*(1+q**4)',
    'S': 'g+e*q**3+ell*q**5+H*q**7',
    'Tp': 'q**3-b*ell+ell+theta*lambda*q**3+(beta-2)*q**8',
    'M': 'r*s*n**2', 'V': 'A-M', 'U': 'w*n**2'
}
# lambda es palabra reservada de Python; se renombra solo en el analizador.
def parse(text, scope):
    return expression(re.sub(r'\blambda\b', 'lam', text),
                      {('lam' if k == 'lambda' else k): v for k,v in scope.items()})
for k, text in definitions.items(): orig[k] = parse(text, orig)
equations = [
    ('b','x*y+alpha'), ('e+eps_e','q**2'),
    ('ell+eps_l','q**2'), ('g+eps_g','q'),
    ('lambda+q**4','1+lambda*beta'), ('theta+2*z','beta'),
    ('ell','u+t*theta'), ('e','y+m*theta'), ('n','q**16'),
    ('r','S*(n**2-n)+Tp*(n**2-1)'), ('p','2*M*V'),
    ('(p**2-1)*k**2+1','tau**2'), ('c','k*s*n**2+zeta'),
    ('k','zeta+eta'), ('k','r+1+h0*(p-1)'), ('V','M*U'),
    ('c','2*r+1+C1+varphi'), ('d','b*w+c*(A-2)+(4*A-5)*gamma'),
    ('d**2','(A**2-1)*c**2+1'), ('f**2','(A**2-1)*(i*c**2)**2+1'),
    ('(d+omega*f)**2','((A+f**2*(d**2-A))**2-1)*(2*r+1+j*c)**2+1'),
    ('C1','E+J*(A-1)'), ('D1**2','(A**2-1)*C1**2+1'),
    ('D1','q+C1*(A-b)+nu*(2*A*b-b**2-1)'), ('r','n+rho')
]
for index, ((a,b,_),(lhs,rhs)) in enumerate(zip(cs,equations),1):
    assert env[a] == parse(lhs,orig), ('lhs',index)
    assert env[b] == parse(rhs,orig), ('rhs',index)
assert len(equations) == 25
print(json.dumps({'status':'PASS','operations':len(ops),'count':dict(counts),
 'independent_count':independent,'comparisons':len(cs),'witnesses':37,
 'live_registers':len(live),'exact_polynomial_sides':50,
 'topological':True,'coverage':True,'consumer_lists':True}, indent=2))

Álgebra para matemáticos — Tomo I
A. Peña — Matemática Abierta
Fuentes derivadas de los 26 capítulos revisados y ampliados de Obsidian.

Overleaf: importe este ZIP, seleccione pdfLaTeX y main.tex (A4 digital) o main-carta.tex (Carta para impresión).
Local: latexmk -pdf main.tex ; latexmk -pdf main-carta.tex
Incluye las cinco figuras vectoriales PDF; no requiere shell escape.
AMSBook, 11 pt, Latin Modern. Las dos ediciones contienen ejercicios y soluciones completos.
26 capítulos, 2352 pares de ejercicios y soluciones, 43521 expresiones matemáticas y 99 tablas.
La licencia GNU FDL 1.3 completa está incorporada como apéndice de ambos PDF.
Los Markdown canónicos originales permanecen en Obsidian; no fueron modificados.
Esta entrega verifica conversión y maquetación, no vuelve a demostrar todos los resultados del libro.
Edición: 15 de octubre de 2026.
